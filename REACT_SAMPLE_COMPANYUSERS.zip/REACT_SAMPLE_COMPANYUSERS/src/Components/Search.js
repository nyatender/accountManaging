
import React from "react";   
import { SearchField } from '@wsa/echo-components';
const Search=({input ,handleChange })=>{

    return (
		<SearchField
			id="search"
            placeholder="Search for address"
			value={input}
			onChange={handleChange}
		/>
	);
}

export default Search