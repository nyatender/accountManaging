import React from "react";    
import { Dialog , Typography , Button , Spacing , DialogFooter ,Icon} from '@wsa/echo-components';
import Search from "./Search";

const ConfirmatiomDialog = ({ isVisible ,handleClose ,headline,subheadline ,input ,handleChange ,validateEmail }) => {
    return (
        <>
            <Dialog
				aria-label="Form Dialog"
				id="form-dialog"
				isVisible={isVisible}
				showCloseIcon={true}
				onClose={handleClose}
				colSpanL={6}
				>
			<div style={{
				display: 'flex',
				flexDirection: "column",
				alignItems:"center"
			}}>
			<Typography
				children={headline}
				component="h2"
				variant="body"
			/>
			<Spacing mt={2} />
			<Typography
				children={subheadline}
				component="h6"
				variant="caption"
				/>
			<Spacing mt={4} />
			 <Search input={input} handleChange={handleChange}/>
			<DialogFooter>
				<Button className="echo-button--small" variant="primary" onClick={validateEmail}>
					Check Email
				</Button>
			</DialogFooter>
			</div>
			</Dialog>
        </>
        )
    }

export default ConfirmatiomDialog;
    
        