
import React ,{ useState } from "react";
import { Button } from '@wsa/echo-components';

import ConfirmationDialog from '../ConfirmationDialog';
import styles from './styles.scss'; // .button { width: 500px; height 150px; }

//const MyButton = ({ text }) => <Button className={styles.button}>{text}</Button>;

function CompanyUsers() {
    const [isVisible, setisVisible] = useState(false);
    const [input, setInput] = useState('');
    const [showUserProfile ,setshowUserProfile]  = useState(false)
	const handleChange = (e) => {
        console.log(e)
		setInput(e);
	};
    const handleAddUser=()=>{
        console.log("hi")
        setisVisible(true)
    }
    const handleClose = () => {
        setisVisible(false);
      };
    const validateEmail =() =>{
        setshowUserProfile(true)
    }
    return(
        <div>
        {/*   <MyButton text={'Add'} /> */}
        <Button className="echo-button echo-button--small" onClick={() => handleAddUser()}>Add</Button>
        <ConfirmationDialog isVisible={isVisible} 
         handleClose={handleClose}
         headline="Add User"
         subheadline="Please enter User's email"
         input={input}
         handleChange={handleChange}
         validateEmail={validateEmail}
         /> 
        </div>
    )
}

export default CompanyUsers;
    