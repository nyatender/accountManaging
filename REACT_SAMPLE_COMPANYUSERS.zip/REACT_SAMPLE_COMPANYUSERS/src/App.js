import React, { useState, useEffect } from "react";
import CompanyUsers from "./Components/CompanyUsers/CompnayUsers";

function App() {
    //const [resp, setresp] = useState({})
    //const [name, setName] = useState('')
    // useEffect(() => {
    //     var token = authentication.getAccessToken();
    //     console.log("the token is",token);
    //     fetch('https://identity.widex.com/api/queries/company/getonfields'+'?skip=0&take=20')
    //     // fetch('https://jsonplaceholder.typicode.com/users')
    //         .then(response => response.json())
    //         .then(json => {
    //             console.log(json);
    //             setresp(json);
    //         })

    // }, [])
/*     const onChangeHandler = (e) => {
        console.log(e);
        // console.log(e.target.value);
        // setName(e.target.value);
        setName(e.toString());
    } */
    return <>
        <div>
           {/*  <InputField
                required
                label="E-mail"
                value={name}
                onChange={onChangeHandler}
            /> */}
            {/* <input value={name} required onChange={onChangeHandler} /> */}
            <CompanyUsers/>
        </div>
    </>
}

export default App;