# basic-react-app-setup-from-scratch
A project to demonstrate the setup of basic react application from scratch using webpack and babel

You can go through this blog https://medium.com/@harshverma04111989/basic-setup-for-react-application-without-cra-8f885d9dbbf which has the step by step explanation of this code base
