const { merge } = require("webpack-merge");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const commonConfig = require("./webpack.common");
const deps = require("../package.json").dependencies;

const prodConfig = {
  mode: "production",
  output: {
    filename: "[name].[contenthash].js",
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "DDX Dashboard App",
      remotes: {
        contracts: `contracts@${getRemoteEntryUrl("contractmngfrpocrv")}`,
      },
      shared: deps,
    }),
  ],
};

function getRemoteEntryUrl(param) {
  return `https://ddx-${param}-ddx.eu1.mindsphere.io/remoteEntry.js`;
}

module.exports = merge(commonConfig, prodConfig);
