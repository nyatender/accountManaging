import React from "react";
import { authProvider } from "../context/authProvider";
import { AzureAD, AuthenticationState } from "react-aad-msal";
import Layout from "../layout/Layout";
import SiemensLogin from "../siemenslogin/SiemensLogin";
import { Outlet } from "react-router-dom";
import Header from "../header/Header";

function Login() {
  return (
    <>
      <AzureAD provider={authProvider}>
        {({ login, logout, authenticationState }) => {
          const isInProgress =
            authenticationState === AuthenticationState.InProgress;
          const isAuthenticated =
            authenticationState === AuthenticationState.Authenticated;
          const isUnauthenticated =
            authenticationState === AuthenticationState.Unauthenticated;

          if (isAuthenticated) {
            return (
              <React.Fragment>
                <Header logout={logout} />
                <Layout logout={logout} isAuthenticate={isAuthenticated} />
                <Outlet />
              </React.Fragment>
            );
          } else if (isUnauthenticated || isInProgress) {
            return (
              <>
                <SiemensLogin login={login} disabled={isInProgress} />
              </>
            );
          }
        }}
      </AzureAD>
    </>
  );
}

export default Login;
