import React, { useState } from "react";
import './header.css';
import logoutImg from "../images/exitIcon.svg"
import ModalPopup from "../modalpopup/ModalPopup";

function Header({logout}){
    const [open, setOpen]=useState(false);

    function handleClick(){
        setOpen(true)
    }
    function handleClose(){
        setOpen(false) 
    }
    return(
       /*  <div id="_ddx-header"> */<>
            <nav class="navbar navbar-expand-sm" id="_ddx-header">
                <div className="container-fluid">
                <a style={{color:"#fff"}}className="navbar-brand" href="#">DDX Cloud</a>
                <form class="d-flex">
                <img
                    style={{height:"30px"}}
                    src={logoutImg}
                    alt={'LogoutAltText'}
                    onClick={handleClick}
                />
                </form>
               </div>
            </nav>
            
            {open&&<ModalPopup show={open} close={handleClose} logout={logout}/>}
            </>
        //</div>
    )
}

export default Header;