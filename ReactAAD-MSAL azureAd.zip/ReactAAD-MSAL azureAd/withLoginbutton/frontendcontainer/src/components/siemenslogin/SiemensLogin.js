import React from "react";
import "./base.css";

function SiemensLogin({ login, disabled }) {
  return (
    <div class="container-xxs p-t-lg p-lg-t-xl">
      <header class="m-b-md text-center" role="banner">
        <img
          id="header-img"
          alt="Siemens"
          width="150"
          src="https://static.mentor-cdn.com/auth0/logo.svg"
        />
      </header>
      <main
        style={{
          borderColor: "#ccc",
          borderStyle: "solid",
          borderWidth: "1px",
        }}
        class="card m-b-sm p-t-sm br-a border-a border-1 border-gray-light"
      >
        <div id="login">
          <div class="card-block p-x-lg p-y-md">
            <h1 style={{ fontSize: "2rem" }} class="display-2 m-b-sm">
              <span>Sign In</span>
            </h1>
            <p>
              <span>New user?</span>{" "}
              <a id="signup" href="#" rel="signup">
                <span>Create an account</span>
              </a>
            </p>
            <hr class="m-y-md" />
            <form>
              <div class="form-group">
                <label class="text-lg">
                  <span>Email</span>
                </label>
                <input
                  id="username"
                  tabindex="0"
                  name="username"
                  required=""
                  class="form-control form-control-lg br-a-sm"
                  type="text"
                  autocomplete="off"
                  placeholder="user@domain.com"
                  value=""
                />
              </div>
              <div class="form-group">
                <div class="item-flex">
                  <label class="text-lg">
                    <span>Password</span>
                  </label>
                  <a
                    href="#"
                    class="btn-reset text-sm text-info m-l-auto"
                    tabindex="-1"
                  >
                    <svg
                      focusable="false"
                      viewBox="0 0 576 512"
                      class="icon"
                      height="16"
                      width="16"
                    >
                      <path d="M288 144a110.94 110.94 0 0 0-31.24 5 55.4 55.4 0 0 1 7.24 27 56 56 0 0 1-56 56 55.4 55.4 0 0 1-27-7.24A111.71 111.71 0 1 0 288 144zm284.52 97.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400c-98.65 0-189.09-55-237.93-144C98.91 167 189.34 112 288 112s189.09 55 237.93 144C477.1 345 386.66 400 288 400z"></path>
                    </svg>
                    <span style={{ paddingLeft: "3px" }}>Show</span>
                  </a>
                </div>
                <input
                  id="password"
                  name="password"
                  autocomplete="off"
                  required=""
                  class="form-control form-control-lg br-a-sm"
                  type="password"
                  placeholder="Enter your password"
                />
                <div class="text-sm m-y-sm text-right">
                  <a
                    tabindex="-1"
                    id="reset"
                    href="#"
                    rel="reset"
                    class="text-xs"
                  >
                    <span>Forgot your password?</span>
                  </a>
                </div>
                <div class="m-y-md">
                  <button
                    style={{ color: "#fff", backgroundColor: "#eb780a" }}
                    id="submit"
                    class="btn btn-yellow btn-lg btn-block br-a text-700"
                  >
                    <span>Sign In</span>
                  </button>
                </div>
                <h6 style={{ textAlign: "center" }}>OR</h6>
                <div class="m-y-md">
                  <button
                    style={{ color: "#fff", backgroundColor: "#0d6efd" }}
                    class="btn btn-yellow btn-lg btn-block br-a text-700"
                    onClick={login}
                    disabled={disabled}
                  >
                    <span>Azure AD</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>
      <div id="footer">
        <footer class="text-xs item-flex-wrap m-b">
          <div>© 2023 Siemens Digital Industries Software</div>
          <div>
            <a
              target="_blank"
              href="https://www.plm.automation.siemens.com/global/en/legal/privacy-policy.html"
              class="text-muted text-700"
            >
              <span>Privacy</span>
            </a>
            <a
              target="_blank"
              href="https://new.siemens.com/global/en/general/terms-of-use.html"
              class="text-muted text-700 m-x"
            >
              <span>Terms</span>
            </a>
            <a
              target="_blank"
              href="https://www.plm.automation.siemens.com/global/en/support/"
              class="text-muted text-700"
            >
              <span>Help</span>
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default SiemensLogin;
