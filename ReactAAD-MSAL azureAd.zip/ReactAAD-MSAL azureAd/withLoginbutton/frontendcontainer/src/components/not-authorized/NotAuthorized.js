import React from 'react';

const NotAuthorized = () => {
  return (
    <h3 className="ddx-content">You are not authorized to see the page.</h3>
  );
};

export default NotAuthorized;
