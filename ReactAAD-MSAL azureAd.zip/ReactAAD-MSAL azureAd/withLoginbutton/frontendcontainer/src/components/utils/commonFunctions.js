import React, { useEffect, useRef, useState } from 'react';
import './CustomPopover.scss';
export function useDebounce(value, delay) {
  // State and setters for debounced value
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(
    () => {
      // Update debounced value after delay
      const handler = setTimeout(() => {
        setDebouncedValue(value);
      }, delay);

      // Cancel the timeout if value changes (also on delay change or unmount)
      // This is how we prevent debounced value from updating if value is changed ...
      // .. within the delay period. Timeout gets cleared and restarted.
      return () => {
        clearTimeout(handler);
      };
    },
    [value, delay] // Only re-call effect if value or delay changes
  );

  return debouncedValue;
}

export function nonEmptyObjects(obj) {
  for (const propName in obj) {
    if (
      obj[propName] === null ||
      obj[propName] === undefined ||
      obj[propName] === ''
    ) {
      delete obj[propName];
    }
  }
  return obj;
}

export const renderLongTexts = (text) => {
  return text.length > 20 ? text.substring(0, 20) + '...' : text;
};

export const getStatusClass = (status) => {
  if (!status) {
    return;
  }
  switch (status.toLowerCase()) {
    case 'published':
      return 'has-bgColor-success';
    case 'validated':
      return 'has-bgColor-warning';
    case 'draft':
      return '';
    default:
      return '';
  }
};

export const customListColumn = (column, label, firstChild) => {
  if (column?.length > 20) {
    return (
      <div className="column">
        <div className="infotip custom infotip--hover infotip--bottom infotip--wide">
          <button type="button">
            <p className="header">
              {firstChild ? (column ? renderLongTexts(column) : '-') : label}
            </p>
            <p className="content">
              {firstChild ? label : column ? renderLongTexts(column) : '-'}
            </p>
          </button>
          <div role="tooltip">
            <div className="infotip__wrapper">{column}</div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="column">
      <p className="header">{firstChild ? (column ? column : '-') : label}</p>
      <p className="content">{firstChild ? label : column ? column : '-'}</p>
    </div>
  );
};

export const customTableColumn = (column) => {
  if (column?.length > 20) {
    return (
      <td>
        <div className="infotip custom infotip--hover infotip--right infotip--wide">
          <button type="button">
            <p className="parag">{column ? renderLongTexts(column) : '-'}</p>
          </button>
          <div role="tooltip">
            <div className="infotip__wrapper">{column}</div>
          </div>
        </div>
      </td>
    );
  }
  return <td>{column ? column : '-'}</td>;
};

// Hook
export function usePrevious(value) {
  // The ref object is a generic container whose current property is mutable ...
  // ... and can hold any value, similar to an instance property on a class
  const ref = useRef();
  // Store current value in ref
  useEffect(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes
  // Return previous value (happens before update in useEffect above)
  return ref.current;
}
