module.exports = {
  API_USER: 'users',
  API_FINANCIAL_INSTITUTE: 'contractOwners',
  API_ADMIN: '/system-user/admin',
  API_APPLICATION_ENGINEER: '/system-user/application-engineer',
  BACKEND_QUERY_LIMIT: 100,
  IAM_REPOSITORY: '/iam/',
  SCOPES: 'scopes',
  ROLES: 'roles',

  DATA_TYPE: [
    'INT',
    'LONG',
    'DOUBLE',
    'STRING',
    'BOOLEAN',
    'BIG_STRING',
    'TIMESTAMP',
  ],
};
