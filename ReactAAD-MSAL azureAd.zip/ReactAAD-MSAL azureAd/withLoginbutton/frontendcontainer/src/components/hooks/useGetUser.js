import { authProvider } from "../context/authProvider";
import axios from "axios";
import { getUserApi } from "../api/User";
import { useNavigate } from "react-router-dom";

const useGetUser = (setisLoading) => {
  const navigate = useNavigate();

  const getAuthToken = async () => {
    const accessTokenRequest = {
      scopes: ["0ffb1b0f-2404-41a5-b594-2360ed7bcb7d/.default"],
    };
    try {
      const authToken = await authProvider.acquireTokenSilent(
        accessTokenRequest
      );
      setisLoading(false);
      return authToken;
    } catch (err) {}
    setisLoading(false);
    navigate("/notAuthorized");
  };

  const getUserData = async (token) => {
    setisLoading(true);
    const getUserEndPoint = getUserApi().url;
    const getUserEndPointConfig = getUserApi().config(token?.accessToken);

    const resultantData = await axios
      .get(getUserEndPoint, getUserEndPointConfig)
      .then((data) => {
        setisLoading(false);
        return data;
      })
      .catch(() => {
        setisLoading(false);
        navigate("/notAuthorized");
      });
    return resultantData;
  };

  return { getUserData, getAuthToken };
};

export { useGetUser };
