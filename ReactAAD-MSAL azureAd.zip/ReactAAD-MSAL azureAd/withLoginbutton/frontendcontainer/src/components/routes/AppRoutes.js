import React, { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { Dashboard } from "../dashboard/Dashboard";
import SpinnerApp from "../spinners/SpinnerApp";
import NotAuthorized from "../not-authorized/NotAuthorized";
import { ProtectedRoute } from "./ProtectedRoutes";
import Login from "../login/Login";

const ContractsApp = lazy(() => import("contracts/ContractsApp"));

function AppRoutes() {
  return (
    <Suspense fallback={<SpinnerApp />}>
      <Routes>
        <Route path="/" element={<Login />}>
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/contract-management/*"
            element={
              <ProtectedRoute>
                <ContractsApp />
              </ProtectedRoute>
            }
          />
          <Route path="/notAuthorized" element={<NotAuthorized />} />
        </Route>
      </Routes>
    </Suspense>
  );
}

export default AppRoutes;
