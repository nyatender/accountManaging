import { Navigate } from "react-router-dom";
import React, { useContext } from "react";
import { GlobalContext } from "../context/gobalContext";

export const ProtectedRoute = ({ children }) => {
  const { auth_value } = useContext(GlobalContext);
  const [isAuthenticated] = auth_value;
  if (!isAuthenticated) {
    // user is not authenticated
    return <Navigate to="/" />;
  }
  return children;
};
