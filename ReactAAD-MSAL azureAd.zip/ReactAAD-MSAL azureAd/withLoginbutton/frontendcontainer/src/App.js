import React from "react";
import AppRoutes from "./components/routes/AppRoutes";
import ErrorBoundary from "./components/error-boundary/ErrorBoundary";
import { ContextValue, GlobalContext } from "./components/context/gobalContext";

function App() {
  const globalContextValue = ContextValue();
  return (
    <div className="ddx-cloud-app" data-testid="ddx-cloud-app-test">
      <GlobalContext.Provider value={globalContextValue}>
        <ErrorBoundary>
          <AppRoutes />
        </ErrorBoundary>
      </GlobalContext.Provider>
    </div>
  );
}

export default App;
