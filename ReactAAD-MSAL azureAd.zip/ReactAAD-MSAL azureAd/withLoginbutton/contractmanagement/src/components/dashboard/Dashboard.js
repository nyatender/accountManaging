import React from "react";

function Dashboard(props) {
  return <h1>Contract Management Dashboard</h1>;
}

export default Dashboard;
