import { useMsal ,useIsAuthenticated } from '@azure/msal-react';
import axios from "axios";
import { getUserApi } from "../api/User";
import { useNavigate } from "react-router-dom";

const useGetUser = (setisLoading) => {
  const navigate = useNavigate();
  const { instance } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  

  const getAuthToken = async () => {
    if (isAuthenticated) {
      const account = instance.getAllAccounts()[0];

      const accessTokenRequest = {
        scopes: ["0ffb1b0f-2404-41a5-b594-2360ed7bcb7d/.default"],
        account: account,
      };

    try {
      const authToken = await instance.acquireTokenSilent(
        accessTokenRequest
      );
      setisLoading(false);
      return authToken;
    } catch (err) {}
    setisLoading(false);
    navigate("/notAuthorized");
  }
  };

  const getUserData = async (token) => {
    setisLoading(true);
    const getUserEndPoint = getUserApi().url;
    const getUserEndPointConfig = getUserApi().config(token?.accessToken);

    const resultantData = await axios
      .get(getUserEndPoint, getUserEndPointConfig)
      .then((data) => {
        setisLoading(false);
        return data;
      })
      .catch(() => {
        setisLoading(false);
        navigate("/notAuthorized");
      });
    return resultantData;
  };

  return { getUserData, getAuthToken };
};


export { useGetUser };
