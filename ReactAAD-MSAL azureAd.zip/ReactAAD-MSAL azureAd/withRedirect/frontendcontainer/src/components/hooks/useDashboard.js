import { useState, useEffect } from "react";
import { useGetUser } from "./useGetUser";

const useDashboard = () => {
  const [rowData, setRowData] = useState([]);
  const [isLoading, setisLoading] = useState(false);
  const { getAuthToken, getUserData } = useGetUser(setisLoading);

  useEffect(() => {
    getUsers();
  }, []);

  const getUsers = async () => {
    setisLoading(true);
    const accessToken = await getAuthToken();
    const result = await getUserData(accessToken);

    setisLoading(false);
    setRowData(result?.data || []);
  };

  return {
    rowData,
    isLoading,
  };
};

export { useDashboard };
