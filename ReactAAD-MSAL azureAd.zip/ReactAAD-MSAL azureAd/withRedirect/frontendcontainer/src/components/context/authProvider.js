import { MsalAuthProvider, LoginType } from "react-aad-msal";

// Msal Configurations
const config = {
  auth: {
    authority: "https://login.microsoftonline.com/siemens.onmicrosoft.com",
    clientId: "0ffb1b0f-2404-41a5-b594-2360ed7bcb7d", // need to add client id /appid generated in azure
    postLogoutRedirectUri: window.location.origin,
    redirectUri: window.location.origin,
    //validateAuthority: true,
    // After being redirected to the "redirectUri" page, should user
    // be redirected back to the Url where their login originated from?
    navigateToLoginRequestUrl: true
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: true,
  },
};

// Authentication Parameters
export const authenticationParameters = {
    scopes: [
        `0ffb1b0f-2404-41a5-b594-2360ed7bcb7d/.default`
    ]
    }

export const authenticationParametersGraph = {
    scopes: [
    'openid'
    ]
    }
        // Options
export const options = {
loginType: LoginType.Redirect,
tokenRefreshUri: window.location.origin
}
export const authProvider = new MsalAuthProvider(config, authenticationParameters, options)



