import { Navigate } from "react-router-dom";
import React from "react";
import { AzureAD, AuthenticationState } from 'react-aad-msal';
import { authProvider } from "../context/authProvider";

export const ProtectedRoute = ({ children }) => {
  return(
    <>
    <AzureAD provider={authProvider} forceLogin={true}>
      {
        ({authenticationState})=>{
          switch (authenticationState) {
            case AuthenticationState.Authenticated:
              return children;
            case AuthenticationState.Unauthenticated:
              {
              return <Navigate to="/" />;
              }
            default:
                return(
                  <></>
                )
          
        }
        }
      }
    </AzureAD>
    </>
  )
};
