import React from 'react';
import { AzureAD, AuthenticationState } from 'react-aad-msal';
import { authProvider } from '../context/authProvider';
import Layout from "../layout/Layout";
import Header from '../header/Header';
import { Outlet } from 'react-router-dom';

const Login = () => {
  function countdownToLogin(loginFunction){
    setInterval(()=>{
      loginFunction();
    },1000)    
  };
    
    return (
        <div>
            <AzureAD provider={authProvider} forceLogin={true}>
                {
                    ({login, logout, authenticationState, error, accountInfo}) => {
                      switch (authenticationState) {
                        case AuthenticationState.Authenticated:
                          return (
                            <>
                            <Header logout={logout}/>
                            <Layout/>
                            <Outlet/>
                            </>
                          );
                        case AuthenticationState.Unauthenticated:
                          {
                            countdownToLogin(login);
                          return (
                            <></>
                          );
                          }
                        default:
                            return(
                              <></>
                            )
                      
                    }
                    }
                 }
              </AzureAD>
        </div>
    );
};

export default Login;