import { IFactoryAssetListTypes } from './components/pages/factory-asset-list/DrawerContentPropType'

const factoryAssetMapping: IFactoryAssetListTypes = {
  assetId: 'Asset Id',
  contractName: 'Contract Name',
  contractStatus: 'Contract Status',
  customerName: 'Customer Name',
  assetStatus: 'Asset Status',
  assetAddress: 'Asset Address',
  assetName: 'Asset Name',
  assetSerialId: 'Asset SerialId',
  contractType: 'Contract Type',
  selectedMetricName: 'Metric Name',
  insurancePremiumVariable: 'Insurance Premium Variable',
  startDate: 'Start Date',
  endDate: 'End Date',
}

const initialFactoryAssetListData: IFactoryAssetListTypes = {
  startDate: '',
  endDate: '',
  contractType: '',
  contractName: '',
  contractStatus: '',
  customerName: '',
  assetId: '',
  assetSerialId: '',
  assetStatus: '',
  assetAddress: '',
  selectedMetricName: '',
  insurancePremiumVariable: '',
  assetName: '',
}

const CfoDashboardTitle = 'CFO Dashboard'
const CfoDashboardSubtitle = 'RnV Insurance Frankfurt'
const CfoFactoryAssets = 'Factory Assets'

const factoryAssetListPageTitle = 'Factory Asset'
const DrawerHeaderTitle = 'Asset List'
const DrawerTile1Title = 'Asset Status'
const DrawerTile2Title = 'Insurance Expiry'
const DrawerTile2subtitle = 'N/A'
const DrawerCancelButton = {
  buttonText: 'Cancel',
}
const DrawerGetInsureButton = {
  buttonText: 'Get Insurance',
}
const DRAWER_WIDTH = 23
const FactoryAssetListSearchInputPlaceHolder = 'Search Assets'

const DonutChartColors = ['#0cc', '#D2D2D2']
const DonutChartLabelsMapping: { [key: string]: string } = {
  tobeInsuredAssets: 'To Be Insured Assets',
  insuredAssets: 'Insured Assets',
}

const unLoadableWidgetAlertMessage = 'Asset not allowed to get Insured !'
export {
  factoryAssetMapping,
  initialFactoryAssetListData,
  CfoDashboardTitle,
  CfoDashboardSubtitle,
  CfoFactoryAssets,
  DrawerHeaderTitle,
  DrawerTile1Title,
  DrawerTile2Title,
  DrawerTile2subtitle,
  DrawerCancelButton,
  DrawerGetInsureButton,
  DRAWER_WIDTH,
  FactoryAssetListSearchInputPlaceHolder,
  factoryAssetListPageTitle,
  DonutChartColors,
  DonutChartLabelsMapping,
  unLoadableWidgetAlertMessage,
}
