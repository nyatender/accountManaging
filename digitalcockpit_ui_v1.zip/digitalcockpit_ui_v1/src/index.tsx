//@ts-nocheck
import React from 'react'
import AzureAD, {
  AuthenticationState,
  IAzureADFunctionProps,
} from 'react-aad-msal'

import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
import reportWebVitals from './reportWebVitals'
import { BrowserRouter } from 'react-router-dom'
import LoginPage from './components/pages/loginPage/LoginPage'
import { authProvider } from './authConfig'

const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement)
root.render(
  <BrowserRouter>
    <AzureAD provider={authProvider}>
      {({
        login,
        logout,
        authenticationState,
        accountInfo,
      }: IAzureADFunctionProps): JSX.Element => {
        if (
          authenticationState === AuthenticationState.Authenticated &&
          accountInfo
        ) {
          return <App logout={logout} />
        }

        // AuthenticationState.Unauthenticated:
        return <LoginPage login={login} />
      }}
    </AzureAD>
  </BrowserRouter>
)

reportWebVitals()
