import { MsalAuthProvider, LoginType } from 'react-aad-msal'

export const authProvider = new MsalAuthProvider(
  {
    auth: {
      authority: `https://login.microsoftonline.com/${process.env.REACT_APP_TENANT_ID}`,
      clientId: `${process.env.REACT_APP_CLIENT_ID}`,
      postLogoutRedirectUri: window.location.origin,
      redirectUri: window.location.origin,
      validateAuthority: true,
      navigateToLoginRequestUrl: false,
    },
    cache: {
      cacheLocation: 'sessionStorage',
      storeAuthStateInCookie: false,
    },
  },
  {
    scopes: ['openid', 'profile', 'user.read'],
  },
  {
    loginType: LoginType.Popup,
    tokenRefreshUri: window.location.origin + '/auth.html',
  }
)
