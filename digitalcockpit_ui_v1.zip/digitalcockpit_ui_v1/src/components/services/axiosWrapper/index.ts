import axios, { AxiosHeaders } from 'axios'
import { authProvider } from '../../../authConfig'

const API = axios.create()
API.defaults.headers.common['Accept'] = 'application/json,text/plain,*/*'
API.defaults.headers.common['Content-Type'] = 'application/json'
API.defaults.timeout = 3 * 60 * 1000

API.interceptors.request.use(
  //@ts-ignore
  async (config: AxiosHeaders) => {
    const accessTokenRequest = {
      scopes: [process.env.REACT_APP_SCOPES ?? ''],
    }
    const { accessToken: token } = await authProvider.acquireTokenSilent(
      accessTokenRequest
    )
    return {
      ...config,
      headers: {
        ...(token !== null && { Authorization: `Bearer ${token}` }),
        ...config.headers,
      },
    }
  },
  (error) => {
    return Promise.reject(error)
  }
)

async function getAPI<T>(url: string, config?: object): Promise<Awaited<T>> {
  return await API.get(`${url}`, config)
}

async function postAPI(url: string, payload: object[] = [], config?: object) {
  return await API.post(`${url}`, payload, config)
}

async function deleteAPI(url: string, config?: object) {
  return await API.delete(`${url}`, config)
}

export { getAPI, postAPI, deleteAPI }
