const serverMessages = {
  chartDataNotFound: 'Failed to get chart data',
  widgetNotFound: `Failed to get Loadable Widget`,
  contractsDataNotFound: `Failed to get contracts data`,
}

export { serverMessages }
