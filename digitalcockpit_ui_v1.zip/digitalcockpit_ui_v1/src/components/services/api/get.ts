const getChartDataAPI = `http://${process.env.REACT_APP_DIGITALCOCKPIT_HOST}/api/v1/dashboard`
const isWidgetLoadTrueAPI = `http://${process.env.REACT_APP_DIGITALCOCKPIT_HOST}/api/v1/true`
const isWidgetLoadFalseAPI = `http://${process.env.REACT_APP_DIGITALCOCKPIT_HOST}/api/v1/false`
const toCheckValidOnboardedUser = `http://${process.env.REACT_APP_CUSTOMER_SPACE_HOST}/api/v1/user/getByEmailAddress`
const getContractsAPI = `http://${process.env.REACT_APP_DIGITALCOCKPIT_HOST}/api/v1/contracts`
const getBrokerCodeAPI = `http://${process.env.REACT_APP_DIGITALCOCKPIT_HOST}/api/v1/getbtoken`
export {
  getChartDataAPI,
  isWidgetLoadTrueAPI,
  isWidgetLoadFalseAPI,
  toCheckValidOnboardedUser,
  getContractsAPI,
  getBrokerCodeAPI,
}
