import { style } from '@vanilla-extract/css'

export const ErrorStyles = style({
  position: 'fixed',
  top: '6em',
  marginLeft: '6em',
})
