import React from 'react'
import { customRender } from '../../utils/testUtils'
import { Error } from './Error'
import { screen } from '@testing-library/react'

describe('Test Error Page', () => {
  it('test Error Page Rendering eith Given Error Message', () => {
    customRender(<Error errorMessage="New Error" />)
    const errorMessageRendered = screen.queryByTestId(/test-ErrorMessageHolder/)
    expect(errorMessageRendered).toHaveTextContent(/New error/i)
  })
})
