import React from 'react'
import { ErrorStyles } from './Error.css'
import { ErrorPropTypes } from './ErrorPropTypes'
const Error = ({ errorMessage }: ErrorPropTypes) => {
  return (
    <div className={ErrorStyles}>
      <h1>404</h1>
      {errorMessage && (
        <h5 data-testid="test-ErrorMessageHolder">{errorMessage}</h5>
      )}
    </div>
  )
}

export { Error }
