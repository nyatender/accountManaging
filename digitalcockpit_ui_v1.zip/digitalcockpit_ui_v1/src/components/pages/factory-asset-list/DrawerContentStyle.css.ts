import { style } from '@vanilla-extract/css'

export const drawerContainerRow1Styles = style({
  display: 'flex',
  flexDirection: 'column',
  paddingLeft: '1rem',
})

export const ContentHeaderContainerStyles = style({
  height: '2rem',
})

export const drawerContainerRow2Styles = style({
  display: 'flex',
  alignItems: 'center',
  gap: '2%',
  height: '5rem',
  paddingRight: '1em',
})

export const TileContainerStyles = style({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'space-between',
  background: '#F3F3F0',
  borderRadius: '2%',
  flex: 1,
  padding: '3% 0',
})

export const Tile1Row1Styles = style({
  width: '100%',
  display: 'flex',
  alignItems: 'flex-start',
  justifyContent: 'flex-start',
  paddingLeft: '0.5em',
})

export const Tile1Row2ContainerStyles = style({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  paddingRight: '0.5em',
})

export const Tile1Row2Styles = style({
  fontSize: '0.9em',
})

export const Tile2ContainerStyles = style({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  flex: 1,
  background: '#F3F3F0',
  borderRadius: '2%',
  padding: '3% 0',
})

export const Tile2Row1Styles = style({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-start',
  paddingLeft: '0.5em',
})

export const Tile2Row2ContainerStyles = style({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  paddingRight: '0.5em',
})

export const Tile2Row2Styles = style({
  fontSize: '14px',
})

export const KeyValContainerStyles = style({
  height: '25rem',
  overflowY: 'scroll',
})

export const footerButtonsContainerStyles = style({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  height: '2.7rem',
  paddingRight: '2em',
  gap: '5%',
})

export const DrawerTileTitleStyle = style({
  fontSize: '13px',
})

export const infoKeyStyle = style({
  paddingTop: '1em',
})
