import React from 'react'
import { Button } from '../../atoms/button/Button'
import { ContentHeader } from '../../atoms/content-header'
import { IDrawerContentPropTypes } from './DrawerContentPropType'
import {
  DrawerCancelButton,
  DrawerGetInsureButton,
  DrawerHeaderTitle,
  DrawerTile1Title,
  DrawerTile2Title,
  DrawerTile2subtitle,
} from '../../../constants'
import { contentHeaderStyle } from './FactoryAssetListStyle.css'
import {
  ContentHeaderContainerStyles,
  DrawerTileTitleStyle,
  KeyValContainerStyles,
  Tile1Row1Styles,
  Tile1Row2ContainerStyles,
  Tile1Row2Styles,
  Tile2ContainerStyles,
  Tile2Row1Styles,
  Tile2Row2ContainerStyles,
  Tile2Row2Styles,
  TileContainerStyles,
  drawerContainerRow1Styles,
  drawerContainerRow2Styles,
  footerButtonsContainerStyles,
} from './DrawerContentStyle.css'
import { useGetDrawerContentData } from '../../hooks/use-factory-asset-list/useGetDrawerContentData'

/**
 *
 * @param param0 drawerData : data displayed on the row of a table and onClose : drawer-Close handler
 * @returns Drawer component with data
 */
const DrawerContent = ({ drawerData, onClose }: IDrawerContentPropTypes) => {
  const { renderKeyVal, handleGetInsuredClick, loading, error } =
    useGetDrawerContentData(drawerData)

  return (
    <div className={drawerContainerRow1Styles}>
      <div className={ContentHeaderContainerStyles}>
        <ContentHeader
          headerTitle={DrawerHeaderTitle}
          className={contentHeaderStyle}
        />
      </div>
      <div className={drawerContainerRow2Styles}>
        <div className={TileContainerStyles}>
          <div className={Tile1Row1Styles}>
            <span className={DrawerTileTitleStyle}>{DrawerTile1Title}</span>
          </div>
          <div className={Tile1Row2ContainerStyles}>
            <div className={Tile1Row2Styles}>
              {drawerData?.assetStatus ?? ''}
            </div>
          </div>
        </div>

        <div className={Tile2ContainerStyles}>
          <div className={Tile2Row1Styles}>
            <span className={DrawerTileTitleStyle}>{DrawerTile2Title}</span>
          </div>
          <div className={Tile2Row2ContainerStyles}>
            <div className={Tile2Row2Styles}>{DrawerTile2subtitle}</div>
          </div>
        </div>
      </div>
      <div className={KeyValContainerStyles}>
        <React.Fragment>{renderKeyVal()}</React.Fragment>
      </div>
      <div
        className={footerButtonsContainerStyles}
        // style={
        //   drawerData.contractStatus === `READY`
        //     ? {
        //         display: 'none',
        //       }
        //     : {}
        // }
      >
        <Button
          variant={'Primary'}
          isOutLined
          buttonText={DrawerCancelButton.buttonText}
          onClick={onClose}
        />
        {/**
         * button which triggers RnV Widget based on condition
         */}

        <Button
          variant={'Primary'}
          buttonText={DrawerGetInsureButton.buttonText}
          onClick={handleGetInsuredClick}
          isDisabled={!!error || !!loading}
        />
      </div>
    </div>
  )
}

export { DrawerContent }
