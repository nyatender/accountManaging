import React, { useMemo, useState } from 'react'
import { SearchInput } from '../../atoms/search-input/SearchInput'
import { Drawer } from '../../atoms/drawer/Drawer'

import { Table } from '../../atoms/table/Table'
import { DrawerContent } from './DrawerContent'
import { IFactoryAssetListTypes } from './DrawerContentPropType'
import {
  DRAWER_WIDTH,
  FactoryAssetListSearchInputPlaceHolder,
  factoryAssetListPageTitle,
  initialFactoryAssetListData,
} from '../../../constants'
import {
  FactoryAssetListPageContainerStyle,
  FullSizeTableStyle,
  HalfSizeStyle,
  SearchInputContainerStyle,
  drawerStyles,
  factoryAssetListPageTitleHeaderStyle,
  tableLoaderStyle,
} from './FactoryAssetListStyle.css'
import { ContentHeader } from '../../atoms/content-header'
import { useGetFactoryAssetsData } from '../../hooks/use-factory-asset-list/useGetFactoryAssetsData'
import { Loader } from '../../atoms/loader'
import { factoryAssetListColumns } from '../../utils/utils'

/**
 *
 * @returns Table with factory Asset List
 */
function FactoryAssetList() {
  const [showDrawer, setShowDrawer] = useState<boolean>(false)
  const {
    data: factoryAssetListRows,
    isLoading: rowDataLoading,
    error: rowDataError,
    handleChange,
  } = useGetFactoryAssetsData()

  /**
   * to store data preset in particular row which user clicked
   */
  const [drawerData, setDrawerData] = useState<IFactoryAssetListTypes>(
    initialFactoryAssetListData
  )

  const handleRowClick = (data: IFactoryAssetListTypes): void => {
    setDrawerData(data)
    setShowDrawer(!showDrawer)
  }

  /**
   * set column and row data for the table
   */
  const columnDefs = useMemo(() => factoryAssetListColumns, [])
  const rowData = useMemo(() => {
    return factoryAssetListRows
  }, [factoryAssetListRows])

  const onClose = () => {
    setShowDrawer(!showDrawer)
  }

  return (
    <div data-testid="test-factoryAssetListContainer">
      <div style={{ width: '100%', height: '100%' }} data-testid="test-Drawer">
        <Drawer
          show={showDrawer}
          setShow={onClose}
          className={drawerStyles}
          children={DrawerContent({
            drawerData,
            onClose,
          })}
          drawerWidth={DRAWER_WIDTH}
        />
      </div>
      <div className={FactoryAssetListPageContainerStyle}>
        <ContentHeader
          headerTitle={factoryAssetListPageTitle}
          className={factoryAssetListPageTitleHeaderStyle}
        />
        <div
          className={SearchInputContainerStyle}
          data-testid="test-SearchContainer"
        >
          <SearchInput
            placeholder={FactoryAssetListSearchInputPlaceHolder}
            handleChange={handleChange}
          />
        </div>

        {rowDataError?.message || rowDataLoading ? (
          <div className={tableLoaderStyle} data-testid="test-loaderContainer">
            <Loader size={'large'} />
          </div>
        ) : (
          <div
            className={
              showDrawer ? `${HalfSizeStyle}` : `${FullSizeTableStyle}`
            }
            data-testid="test-tableContainer"
          >
            <Table
              columnDefs={columnDefs}
              rowData={rowData}
              onRowClicked={handleRowClick}
            />
          </div>
        )}
      </div>
    </div>
  )
}

export { FactoryAssetList }
