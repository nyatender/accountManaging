import { style } from '@vanilla-extract/css'

export const drawerStyles = style({
  position: 'absolute',
  top: 'auto',
  zIndex: 1,
  height: '96%',
})

export const contentHeaderStyle = style({
  padding: '0 0 1em 1em',

  borderTop: '1px solid rgb(206, 206, 200)',
})

export const keyValStyle = style({
  paddingLeft: '1em',
})

export const FullSizeTableStyle = style({
  boxSizing: 'border-box',
  width: '100%',
  transition: 'width 0.25s ease-in-out',
})

export const HalfSizeStyle = style({
  boxSizing: 'border-box',
  width: '70%',
  transition: 'width 0.25s ease-in-out',
})

export const FactoryAssetListPageContainerStyle = style({
  width: '100%',
  height: '100%',
})

export const SearchInputContainerStyle = style({
  width: '35%',
  marginLeft: '-0.5em',
  paddingBottom: '1em',
})

export const factoryAssetListPageTitleHeaderStyle = style({
  paddingTop: '1em',
})

export const paginationStyle = style({
  padding: '1em',
})

export const tableLoaderStyle = style({
  width: '100%',
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
})
