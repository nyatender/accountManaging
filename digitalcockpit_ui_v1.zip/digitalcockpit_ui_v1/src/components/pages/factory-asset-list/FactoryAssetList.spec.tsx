//@ts-nocheck
import React from 'react'
import { FactoryAssetList } from './FactoryAssetList'
import * as useFADataHook from '../../hooks/use-factory-asset-list/useGetFactoryAssetsData'
import { customRender } from '../../utils/testUtils'
import { screen, act } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('Test Factory Asset List Page', () => {
  let useGetFactoryAssetsData = null
  let handleChangeMock = jest.fn()

  beforeAll(() => {
    useGetFactoryAssetsData = jest.spyOn(
      useFADataHook,
      'useGetFactoryAssetsData'
    )
  })

  beforeEach(() => {
    useGetFactoryAssetsData.mockClear()
  })

  it('test whether Loading is rendered when Data is null', () => {
    useGetFactoryAssetsData.mockReturnValue({
      data: null,
      isLoading: true,
      error: null,
      handleChange: handleChangeMock,
    })

    customRender(<FactoryAssetList />)

    const testLoaderContainer = screen.queryByTestId(/test-loaderContainer/)
    expect(testLoaderContainer).toBeInTheDocument()
  })

  it('test whether table is rendered when Data is not null', () => {
    useGetFactoryAssetsData.mockReturnValue({
      data: [
        {
          startDate: 'TEST1',
          endDate: 'TEST1',
          contractType: 'TEST1',
          contractName: 'TEST1',
          contractStatus: 'TEST1',
          customerName: 'TEST1',
          assetId: 1,
          assetSerialId: 'TEST1',
          assetStatus: 'TEST1',
          assetAddress: 'TEST1',
          selectedMetricName: 'TEST1',
          insurancePremiumVariable: 1,
          assetName: 'TEST1',
        },
        {
          startDate: 'TEST2',
          endDate: 'TEST2',
          contractType: 'TEST2',
          contractName: 'TEST2',
          contractStatus: 'TEST2',
          customerName: 'TEST2',
          assetId: 2,
          assetSerialId: 'TEST2',
          assetStatus: 'TEST2',
          assetAddress: 'TEST2',
          selectedMetricName: 'TEST2',
          insurancePremiumVariable: 2,
          assetName: 'TEST2',
        },
      ],
      isLoading: false,
      error: null,
      handleChange: handleChangeMock,
    })

    customRender(<FactoryAssetList />)

    const testTableContainer = screen.queryByTestId(/test-tableContainer/)
    expect(testTableContainer).toBeInTheDocument()
  })

  it('test whether Search is working', async () => {
    useGetFactoryAssetsData.mockReturnValue({
      data: [
        {
          startDate: 'TEST1TEST',
          endDate: 'TEST1',
          contractType: 'TEST1',
          contractName: 'TEST1',
          contractStatus: 'TEST1',
          customerName: 'TEST1TEST',
          assetId: 1,
          assetSerialId: 'TEST1',
          assetStatus: 'TEST1',
          assetAddress: 'TEST1',
          selectedMetricName: 'TEST1',
          insurancePremiumVariable: 1,
          assetName: 'TEST1',
        },
        {
          startDate: 'TEST2',
          endDate: 'TEST2',
          contractType: 'TEST2',
          contractName: 'TEST2',
          contractStatus: 'TEST2',
          customerName: 'TEST2',
          assetId: 2,
          assetSerialId: 'TEST2',
          assetStatus: 'TEST2',
          assetAddress: 'TEST2',
          selectedMetricName: 'TEST2',
          insurancePremiumVariable: 2,
          assetName: 'TEST2',
        },
      ],
      isLoading: false,
      error: null,
      handleChange: handleChangeMock,
    })

    customRender(<FactoryAssetList />)
    const SearchInputContainer = await screen.findByPlaceholderText(
      /Search Assets/
    )
    // eslint-disable-next-line testing-library/no-unnecessary-act
    act(() => {
      userEvent.type(SearchInputContainer, 'TEST1TEST')
    })
    expect(SearchInputContainer).toHaveValue('TEST1TEST')
  })
})
