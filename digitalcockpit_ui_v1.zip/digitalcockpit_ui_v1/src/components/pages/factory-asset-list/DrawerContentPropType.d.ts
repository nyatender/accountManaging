export interface IFactoryAssetListTypes {
  startDate: string
  endDate: string
  contractType: string
  contractName: string
  contractStatus: string
  customerName: string
  assetId: string
  assetSerialId: string
  assetStatus: string
  assetAddress: string
  selectedMetricName: string
  insurancePremiumVariable: string
  assetName: string
}

export interface IDrawerContentPropTypes {
  drawerData: IFactoryAssetListTypes
  onClose: () => void
}
