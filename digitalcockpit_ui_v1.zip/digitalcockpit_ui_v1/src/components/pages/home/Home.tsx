import React from 'react'
import { Navigation } from '../../atoms/navigation'
import { ReactComponent as SiemensLogo } from '../../assets/Siemens.svg'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import { showModal } from '@siemens/ix-react'
import CustomModal from '../../atoms/customModal/CustomModal'
import { IHomePropTypes } from './HomeProptypes'
import {
  DefaultHomeContainerStyle,
  HomeLoaderStyle,
  breadCrumbContainerStyle,
} from './Home.css'
import { Breadcrumb } from '../../atoms/breadcrumb/Breadcrumb'
import { useGetAuthToken } from '../../hooks/useGetAuthToken'
import { navigationItems } from './NavItemList'
import { useCheckEmail } from '../../hooks/useCheckEmail'
import { UnAuthorized } from '../un-authorized/UnAuthorized'
import { Error } from '../error-page/Error'
import { Loader } from '../../atoms/loader'

function Home({ logout }: IHomePropTypes): React.ReactElement {
  const { userName } = useGetAuthToken()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { isUserExists, isLoading, error } = useCheckEmail()

  /**
   * to call logout functionality of Azure
   */
  async function show(): Promise<void> {
    await showModal({
      title: 'test',
      content: <CustomModal logout={logout} />,
      centered: true,
      icon: 'about',
      size: 'sm',
    })
  }

  /**
   * Need to check if the user exists or not ?
   */
  if (error !== null) {
    return (
      <div>
        <Navigation
          logo={<SiemensLogo />}
          menuItems={navigationItems(navigate, show, pathname, userName)}
          applicationName={'Digital Contracts Cockpit'}
        />
        <div className={DefaultHomeContainerStyle}>
          <Error />
        </div>
      </div>
    )
  }

  /**
   * Loading ? then display Loader
   */

  if (error === null && !!isLoading) {
    return (
      <div>
        <Navigation
          logo={<SiemensLogo />}
          menuItems={navigationItems(navigate, show, pathname, userName)}
          applicationName={'Digital Contracts Cockpit'}
        />
        <div className={DefaultHomeContainerStyle}>
          <Loader className={HomeLoaderStyle} size={'large'} />
        </div>
      </div>
    )
  }

  /**
   * Not Loading ? then check User Onboarded ? if no redirect to UnAuthorized Page
   */

  if (error === null && !isLoading && !isUserExists) {
    return (
      <div>
        <Navigation
          logo={<SiemensLogo />}
          menuItems={navigationItems(navigate, show, pathname, userName)}
          applicationName={'Digital Contracts Cockpit'}
        />
        <div className={DefaultHomeContainerStyle}>
          <UnAuthorized />
        </div>
      </div>
    )
  }

  /**
   * Not Loading ? then check User Onboarded ? if yes redirect to Landing Page
   */

  return (
    <div>
      <Navigation
        logo={<SiemensLogo />}
        menuItems={navigationItems(navigate, show, pathname, userName)}
        applicationName={'Digital Contracts Cockpit'}
      />

      <div className={DefaultHomeContainerStyle}>
        {/**
         * display breadcrumbs based on route path
         */}

        {!!(pathname === '/') && (
          <div className={breadCrumbContainerStyle}>
            <Breadcrumb
              breadcrumbData={[{ label: 'Home', icon: 'home', pathname }]}
            />
          </div>
        )}
        {!!(pathname === '/factory-asset-list') && (
          <div className={breadCrumbContainerStyle}>
            <Breadcrumb
              breadcrumbData={[
                { label: 'Home', icon: 'home', pathname: '/' },
                {
                  label: 'Factory Asset List',
                  icon: 'scheduler',
                  pathname,
                },
              ]}
            />
          </div>
        )}

        <Outlet />
      </div>
    </div>
  )
}

export { Home }
