//@ts-nocheck
import React from 'react'
import { Home } from './Home'
// import { render } from '@testing-library/react'
// import { MemoryRouter, Routes, Route } from 'react-router-dom'
import { customRender } from '../../utils/testUtils'

import * as useGetAuthTokenMock from '../../hooks/useGetAuthToken'
import * as useCheckEmailmock from '../../hooks/useCheckEmail'

describe('Home Page Testing', () => {
  let useCheckEmail = null
  let logout = jest.fn()
  let useGetAuthToken = null

  beforeAll(() => {
    useCheckEmail = jest.spyOn(useCheckEmailmock, 'useCheckEmail')
    useGetAuthToken = jest.spyOn(useGetAuthTokenMock, 'useGetAuthToken')
  })

  beforeEach(() => {
    useCheckEmail.mockClear()
    useGetAuthToken.mockClear()
  })

  it('Check whether navigation component is rendering', () => {
    useCheckEmail.mockReturnValue({
      isUserExists: true,
      isLoading: true,
      error: null,
    })

    useGetAuthToken.mockReturnValue({
      userName: 'gowda.Nimith',
    })

    // const FakeComponent = () => <div>fake text</div>

    customRender(<Home logout={logout} />)
    // render(
    //   <MemoryRouter initialEntries={['/']}>
    //     <Routes>
    //       <Route element={<Home logout={logout} />}>
    //         <Route path="/" element={<FakeComponent />} />
    //       </Route>
    //     </Routes>
    //   </MemoryRouter>
    // )
  })
})
