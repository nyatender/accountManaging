import { IAppProps } from '../../../App'

export interface IHomePropTypes extends IAppProps {}
