import { NavigateFunction } from 'react-router-dom'
import { IMenuItemTypes } from '../../atoms/navigation/NavigationPropTypes'
import { getFirstLetterFromAzureUsername } from '../../utils/utils'

const navigationItems = (
  navigate: NavigateFunction,
  show: () => Promise<void>,
  pathname: string,
  userName: string = ''
): IMenuItemTypes[] => {
  return [
    {
      id: 1,
      icon: 'home',
      name: 'Home',
      onClick: () => navigate('/'),
      isActive: pathname === '/' ? true : false,
    },
    {
      id: 2,
      icon: `${
        (userName?.length && getFirstLetterFromAzureUsername(userName)) || ''
      }`,
      name: 'Profile',
      avatar: true,
    },

    {
      id: 3,
      icon: 'piechart',
      name: 'Chart',
    },

    {
      id: 4,
      icon: 'scheduler',
      name: 'Scheduler',
      onClick: () => navigate('/factory-asset-list'),
      isActive: pathname === '/factory-asset-list' ? true : false,
    },
    {
      id: 5,
      icon: 'user-management',
      name: 'Management',
    },
    {
      id: 99,
      icon: 'log-out',
      name: 'logout',
      slot: 'bottom',
      onClick: () => show(),
    },
  ]
}

export { navigationItems }
