//@ts-nocheck
import { CfoDashboard } from './CfoDashboard'
import { screen, act } from '@testing-library/react'
import { customRender } from '../../utils/testUtils'
import * as useCfoDashboardHook from '../../hooks/use-cfo-dashboard/useCfoDashboard'
import userEvent from '@testing-library/user-event'

describe('CFO dashboard', () => {
  let useCfoDashboard = null
  let useNavigate = jest.fn()
  beforeAll(() => {
    useCfoDashboard = jest.spyOn(useCfoDashboardHook, 'useCfoDashboard')
  })

  beforeEach(() => {
    useCfoDashboard.mockClear()
    useNavigate.mockClear()
  })
  it('To check When data is null. Whether Page is loading', async () => {
    useCfoDashboard.mockReturnValue({
      data: null,
      loading: true,
      error: null,
    })

    customRender(<CfoDashboard />)

    const container = await screen.findByTestId(/test-LoaderContainer/)
    expect(container).toBeInTheDocument()
  })

  it('To check when data is not null, Whether the chart  is rendered', async () => {
    useCfoDashboard.mockReturnValue({
      data: [
        {
          id: '1',
          label: 'Label',
          value: 20,
          color: 'color',
        },
      ],
      loading: false,
      error: null,
    })

    customRender(<CfoDashboard />)
    const container = await screen.findByTestId(/test-DonutContainer/)
    expect(container).toBeInTheDocument()
  })

  it('To check when ERROR is not null, Whether the Loading  is rendered', async () => {
    useCfoDashboard.mockReturnValue({
      data: null,
      loading: false,
      error: 'ERROR',
    })

    customRender(<CfoDashboard />)
    const container = await screen.findByTestId(/test-LoaderContainer/)
    expect(container).toBeInTheDocument()
  })

  it('To check whether the chart container is clickable and navigating to factory asset page', async () => {
    useCfoDashboard.mockReturnValue({
      data: [
        {
          id: '1',
          label: 'Label',
          value: 20,
          color: 'color',
        },
      ],
      loading: false,
      error: null,
    })

    customRender(<CfoDashboard />)
    const captureTile = screen.getByTestId('test-Tile1Container')
    // eslint-disable-next-line testing-library/no-unnecessary-act
    act(() => {
      userEvent.click(captureTile)
    })
    expect(window.location.pathname).toEqual('/factory-asset-list')
  })
})
