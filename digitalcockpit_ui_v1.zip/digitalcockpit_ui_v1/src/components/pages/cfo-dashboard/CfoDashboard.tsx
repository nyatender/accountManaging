import React, { ReactElement } from 'react'
import { Donut } from '../../atoms/donut/Donut'
import {
  LoaderStyle,
  assetContainerStyle,
  assetSpanStyle,
  chartContainerStyle,
  col1Row1Col1Style,
  col1Row1Col2Style,
  col1Row1Style,
  col1Row2Col1Style,
  col1Row2Col2Style,
  col1Row2Style,
  col1Row3Col1Style,
  col1Row3Col2Style,
  col1Row3Style,
  col2Row1Col1Style,
  col2Row1Col2Style,
  col2Row1Style,
  col2Row2Style,
  containerCol1Style,
  containerCol2Style,
  containerStyle,
  dashboardHeaderStyle,
  dashboardPageStyle,
  menuIconStyle,
} from './CfoDashboard.css'
import { IxIcon } from '@siemens/ix-react'
import { useNavigate } from 'react-router-dom'
import {
  CfoDashboardSubtitle,
  CfoDashboardTitle,
  CfoFactoryAssets,
} from '../../../constants'
import { ContentHeader } from '../../atoms/content-header'
import { useCfoDashboard } from '../../hooks/use-cfo-dashboard/useCfoDashboard'
import { Loader } from '../../atoms/loader/Loader'

/**
 *
 * @returns CfoDashboard Component which renders Home Page with Tiles ( Donut Chart )
 */
function CfoDashboard(): ReactElement {
  const {
    data: donutChartData,
    loading: isDonutChartLoading,
    error: isDonutChartError,
  } = useCfoDashboard()

  const navigate = useNavigate()

  return (
    <div
      className={dashboardPageStyle}
      data-testid="test-CfoDashboardContainer"
    >
      <div className={dashboardHeaderStyle}>
        <ContentHeader
          headerTitle={CfoDashboardTitle}
          headerSubtitle={CfoDashboardSubtitle}
        />
      </div>
      <div className={containerStyle}>
        <div className={containerCol1Style}>
          <div className={col1Row1Style}>
            <div
              data-testid="test-Tile1Container"
              className={col1Row1Col1Style}
              role="button"
              onClick={() => navigate('/factory-asset-list')}
            >
              <div className={assetContainerStyle}>
                <span className={assetSpanStyle}>{CfoFactoryAssets}</span>
                <div className={menuIconStyle} role="button">
                  <IxIcon size="16" name="context-menu"></IxIcon>
                </div>
              </div>
              <div className={chartContainerStyle}>
                {!!donutChartData?.length && !isDonutChartLoading && (
                  <div
                    data-testid="test-DonutContainer"
                    style={{ width: '100%', height: '100%' }}
                  >
                    <Donut chartData={donutChartData} />
                  </div>
                )}
                {(isDonutChartLoading || isDonutChartError) && (
                  <div
                    data-testid="test-LoaderContainer"
                    style={{ width: '100%', height: '100%' }}
                  >
                    <Loader className={LoaderStyle} />
                  </div>
                )}
              </div>
            </div>
            <div className={col1Row1Col2Style}></div>
          </div>
          <div className={col1Row2Style}>
            <div className={col1Row2Col1Style}></div>
            <div className={col1Row2Col2Style}></div>
          </div>
          <div className={col1Row3Style}>
            <div className={col1Row3Col1Style}></div>
            <div className={col1Row3Col2Style}></div>
          </div>
        </div>
        <div className={containerCol2Style}>
          <div className={col2Row1Style}>
            <div className={col2Row1Col1Style}></div>
            <div className={col2Row1Col2Style}></div>
          </div>
          <div className={col2Row2Style}></div>
        </div>
      </div>
    </div>
  )
}

export { CfoDashboard }
