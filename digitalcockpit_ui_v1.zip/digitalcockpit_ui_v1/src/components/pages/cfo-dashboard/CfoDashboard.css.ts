import { style } from '@vanilla-extract/css'
import { Font } from '../../styles/Font'

export const defaultWidthStyle = style({
  width: '100%',
  height: '100%',
})

export const greyBackground = style({
  background: '#F3F3F0',
})

export const whiteBackground = style({
  background: '#FFFFFF',
})

export const hoverEffect = style({
  ':hover': {
    transform: 'scale(1.1)',
    transition: 'all 1s',
  },
})

export const dashboardPageStyle = style([
  defaultWidthStyle,
  {
    height: '88%',
    paddingBottom: '2em',
  },
])

export const dashboardHeaderStyle = style([
  whiteBackground,
  {
    margin: '13px 0',
    display: 'flex',
    flexDirection: 'column',
    gap: '1%',
  },
])

export const containerStyle = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    flexDirection: 'row',
    gap: '1%',
  },
])

export const dashboardTitleStyle = style({
  fontFamily: 'Siemens Sans',
  fontStyle: 'normal',
  fontWeight: 700,
  fontSize: '20px',
  lineHeight: '145.5%',
  color: '#000028',
})

export const dashboardTitleDescriptionStyle = style({
  fontFamily: 'Siemens Sans',
  fontStyle: 'normal',
  fontWeight: 700,
  fontSize: '12px',
  lineHeight: '150%',
  color: 'rgba(0, 0, 40, 0.6)',
})

export const containerCol1Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    flexDirection: 'column',
    gap: '2%',
  },
])

export const containerCol2Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    flexDirection: 'column',
    gap: '2%',
  },
])

export const col1Row1Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    gap: '2%',
  },
])

export const col1Row2Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    gap: '2%',
  },
])

export const col1Row3Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    gap: '2%',
  },
])

export const col2Row1Style = style([
  defaultWidthStyle,
  whiteBackground,
  {
    display: 'flex',
    flex: 3,
    gap: '2%',
  },
])

export const col2Row2Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flex: 6,
    ':hover': {
      transform: 'scale(1.05)',
      transition: 'all 1s',
    },
  },
])

export const col1Row1Col1Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flexDirection: 'column',
  },
])

export const col1Row1Col2Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
])

export const assetContainerStyle = style({
  padding: '10px 0 0 10px',
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
})

export const assetSpanStyle = style({
  fontWeight: 700,
  color: '#000028',
  fontSize: Font['x-large'],
})
export const menuIconStyle = style({
  paddingRight: '10px',
})

export const chartContainerStyle = style([
  defaultWidthStyle,
  {
    display: 'flex',
  },
])

export const col1Row2Col1Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flex: 1,
  },
])

export const col1Row2Col2Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flex: 2,
  },
])

export const col1Row3Col1Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flex: 1,
  },
])

export const col1Row3Col2Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
  {
    display: 'flex',
    flex: 2,
  },
])

export const col2Row1Col1Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
])
export const col2Row1Col2Style = style([
  defaultWidthStyle,
  greyBackground,
  hoverEffect,
])

export const LoaderStyle = style({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
})
