import React from 'react'
import { customRender } from '../../utils/testUtils'
import { UnAuthorized } from './UnAuthorized'
import { screen } from '@testing-library/react'

describe('UnAuthorized Error Page', () => {
  it('test UnAuthorized Page Rendering eith Given Error Message', () => {
    customRender(<UnAuthorized />)
    const UnauthMessageRendered = screen.queryByTestId(
      /test-UnAuthHeaderContainer/
    )
    expect(UnauthMessageRendered).toHaveTextContent(
      /You are not authorized to see the page./i
    )
  })
})
