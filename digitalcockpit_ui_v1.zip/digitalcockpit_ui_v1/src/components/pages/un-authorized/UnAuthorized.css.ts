import { style } from '@vanilla-extract/css'

export const UnAuthorizedContainerStyle = style({
  position: 'fixed',
  top: '6em',
  marginLeft: '6em',
})
