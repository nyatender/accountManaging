//@ts-nocheck
import React, { useEffect } from 'react'
import './ThinkSuranceStyle.css'
import { useLocation } from 'react-router-dom'
function ThinkSurance() {
  const { state } = useLocation()
  useEffect(() => {
    ;(async () => {
      const data = await state

      window.ts.load(data)
    })()
  }, [state])
  return <div data-testid="test-ThinkSuranceContainer" id="thinkSurance"></div>
}

export { ThinkSurance }
