export interface ISearchInputPropTypes {
  placeholder?: string
  handleSubmit?: (value: string) => void
  handleChange: (value: string) => void
}
