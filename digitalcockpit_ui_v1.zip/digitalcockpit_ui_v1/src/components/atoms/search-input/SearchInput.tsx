import { IxIcon, IxIconButton, IxInputGroup } from '@siemens/ix-react'
import React, { useState } from 'react'
import { ISearchInputPropTypes } from './SearchInputPropTypes'

const SearchInput = ({
  placeholder = '',
  handleSubmit,
  handleChange,
}: ISearchInputPropTypes) => {
  const [inputValue, setInputValue] = useState('')

  function reset() {
    setInputValue('')
  }

  return (
    <form
      className="needs-validation m-2"
      onSubmit={(e) => {
        e.preventDefault()
        if (handleSubmit) {
          try {
            handleSubmit(inputValue)
          } catch (e) {
            console.log(e)
          } finally {
            reset()
          }
        }
      }}
    >
      <IxInputGroup>
        <span slot="input-start">
          <IxIcon name="search" size="16"></IxIcon>
        </span>
        <input
          id="input-string"
          type="string"
          className="form-control"
          onChange={(e) => {
            setInputValue(e.target.value)
            handleChange(e.target.value)
          }}
          value={inputValue}
          placeholder={placeholder}
        />
        <span slot="input-end">
          <IxIconButton
            onClick={() => {
              reset()
              handleChange('')
            }}
            id="clear-button"
            icon="clear"
            ghost
            size="16"
            style={{ display: 'block' }}
          ></IxIconButton>
        </span>
      </IxInputGroup>
    </form>
  )
}

export { SearchInput }
