interface ILoaderPropType {
  className?: string
  size?: large | medium
}

export { ILoaderPropType }
