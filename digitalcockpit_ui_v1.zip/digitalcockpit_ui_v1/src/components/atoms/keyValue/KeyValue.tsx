import React from 'react'
import { IxKeyValue } from '@siemens/ix-react'
import { IKeyValPropTypes } from './KeyValPropTypes'

function KeyValue({ label, value, className }: IKeyValPropTypes) {
  return (
    <IxKeyValue label={label} value={value} className={className}></IxKeyValue>
  )
}

export { KeyValue }
