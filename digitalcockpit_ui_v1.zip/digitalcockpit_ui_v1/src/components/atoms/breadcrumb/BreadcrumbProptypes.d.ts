export type BreadcrumbPropType = {
  label: string
  icon?: string
  pathname: string
}

export interface IBreadcrumbPropTypes {
  breadcrumbData: BreadcrumbPropType[]
}
