import React from 'react'
import { IxBreadcrumb, IxBreadcrumbItem } from '@siemens/ix-react'
import { IBreadcrumbPropTypes } from './BreadcrumbProptypes'
import { useNavigate } from 'react-router-dom'

const Breadcrumb = ({ breadcrumbData }: IBreadcrumbPropTypes) => {
  const navigate = useNavigate()
  const renderBreadcrumb = () =>
    breadcrumbData.map((eachBreadCrumb, index) => (
      <IxBreadcrumbItem
        data-testid={eachBreadCrumb.label}
        key={index}
        label={eachBreadCrumb.label}
        icon={eachBreadCrumb.icon || ''}
      ></IxBreadcrumbItem>
    ))

  return (
    <IxBreadcrumb
      data-testid="test-breadcrumbContainer"
      ghost
      onItemClick={() => navigate(breadcrumbData[0].pathname)}
    >
      {renderBreadcrumb()}
    </IxBreadcrumb>
  )
}

export { Breadcrumb }
