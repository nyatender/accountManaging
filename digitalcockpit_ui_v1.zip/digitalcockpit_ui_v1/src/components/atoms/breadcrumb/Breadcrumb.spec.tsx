import React from 'react'
import { customRender } from '../../utils/testUtils'
import { Breadcrumb } from './Breadcrumb'
import { screen, act } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('Breadcrumb test', () => {
  it('test whether Breadcrumb is rendering', () => {
    customRender(
      <Breadcrumb
        breadcrumbData={[{ label: 'Home', icon: 'home', pathname: '/' }]}
      />
    )
    const breadcrumbContainer = screen.queryByTestId(/test-breadcrumbContainer/)
    expect(breadcrumbContainer).toBeInTheDocument()
  })

  it('test Breadcrumb click is navigating', () => {
    customRender(
      <Breadcrumb
        breadcrumbData={[
          { label: 'Home', icon: 'home', pathname: '/' },
          {
            label: 'Factory Asset List',
            icon: 'scheduler',
            pathname: '/',
          },
        ]}
      />
    )
    const getHomeBreadcrumb = screen.getByTestId('Home')
    // eslint-disable-next-line testing-library/no-unnecessary-act
    act(() => {
      userEvent.click(getHomeBreadcrumb)
    })

    expect(window.location.pathname).toEqual('/')
  })
})
