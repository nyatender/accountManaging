import { useEffect } from 'react'

import { setToastPosition } from '@siemens/ix'
import { showToast } from '@siemens/ix-react'

function useToast(message: string) {
  useEffect(() => {
    setToastPosition('top-right')
  }, [])

  const callToast = () => showToast({ message: message })

  return { callToast }
}
export { useToast }
