import { MouseEventHandler, ReactElement } from 'react'

export interface IMenuItemTypes {
  id: number
  icon: string
  name: string
  slot?: string
  disabled?: boolean = false
  onClick?: MouseEventHandler<HTMLIxMenuItemElement>
  avatar?: boolean = false
  avatarLabel?: string[]
  isActive?: boolean
}
export interface INavigationPropTypes {
  logo?: ReactElement
  menuItems?: IMenuItemTypes[]
  hideHeader?: boolean = false
  applicationName?: string = 'Application Name'
  children?: ReactElement | null
}
