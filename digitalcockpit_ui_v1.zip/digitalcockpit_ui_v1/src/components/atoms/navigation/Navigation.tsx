import React from 'react'
import {
  IxBasicNavigation,
  IxMenu,
  IxMenuAvatar,
  IxMenuAvatarItem,
  IxMenuItem,
} from '@siemens/ix-react'
import { INavigationPropTypes } from './NavigationPropTypes'
import {
  NavigationHeaderStyles,
  NavigationSidebarStyles,
} from './NavigationStyles.css'
import './NavStyles.css'

/**
 *
 * @param param0
 * @returns Navigation pane and Header
 */
const Navigation = ({
  logo,
  menuItems,
  hideHeader,
  applicationName,
  children,
}: INavigationPropTypes): React.ReactElement => {
  return (
    <IxBasicNavigation
      applicationName={applicationName}
      hideHeader={hideHeader}
      className={NavigationHeaderStyles}
      style={{ zIndex: 1 }}
    >
      {!!logo && (
        <div
          className="placeholder-logo"
          slot="logo"
          data-testid="test-NavigationContainer"
        >
          {logo}
        </div>
      )}
      <IxMenu className={NavigationSidebarStyles}>
        {!!menuItems?.length &&
          menuItems
            .sort((begin, end) => begin.id - end.id)
            .map((item) => {
              return item.avatar ? (
                <IxMenuAvatar
                  key={item.id}
                  slot={item.slot ?? ''}
                  initials={item.icon}
                >
                  {item.avatarLabel?.length &&
                    item.avatarLabel?.map((mappedItem, index) => (
                      <IxMenuAvatarItem
                        key={index}
                        label={mappedItem}
                      ></IxMenuAvatarItem>
                    ))}
                </IxMenuAvatar>
              ) : (
                <IxMenuItem
                  data-testid="test-menuOptions"
                  key={item.id}
                  tab-icon={item.icon}
                  disabled={item.disabled}
                  onClick={item.onClick}
                  active={item.isActive}
                  slot={item.slot ?? ''}
                >
                  {item.name}
                </IxMenuItem>
              )
            })}
      </IxMenu>
      {!!children && <div>{children}</div>}
    </IxBasicNavigation>
  )
}

export { Navigation }
