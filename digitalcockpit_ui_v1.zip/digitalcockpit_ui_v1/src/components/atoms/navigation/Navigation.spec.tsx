import React from 'react'
import { customRender } from '../../utils/testUtils'
import { Navigation } from './Navigation'
import { screen } from '@testing-library/react'

describe('Testing navigation Component', () => {
  it('test if navigation Component is rendering', () => {
    customRender(<Navigation />)
    const NavContainer = screen.queryByTestId(/test-NavigationContainer/i)
    expect(NavContainer).toBeInTheDocument()
  })

  it('test if menu option is rendering', () => {
    customRender(
      <Navigation menuItems={[{ id: 1, icon: '123', name: 'any' }]} />
    )
    const MenuContainer = screen.queryByTestId(/test-menuOptions/i)
    expect(MenuContainer).toBeInTheDocument()
  })
})
