import React from 'react'
import { IxButton } from '@siemens/ix-react'
import { IButtonPropTypes } from './ButtonPropTypes'

const Button = ({
  buttonText,
  variant = 'Primary',
  isDisabled = false,
  isGhost = false,
  isOutLined = false,
  onClick,
}: IButtonPropTypes) => (
  <IxButton
    data-testid="test-buttonContainer"
    disabled={isDisabled}
    ghost={isGhost}
    variant={variant}
    outline={isOutLined}
    onClick={onClick}
  >
    {buttonText}
  </IxButton>
)

export { Button }
