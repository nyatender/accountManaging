import React from 'react'
import { customRender } from '../../utils/testUtils'
import { Button } from './Button'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('testing button component', () => {
  it('test whether button is rendering or not', () => {
    customRender(<Button buttonText="testButton" />)
    const getButtonContainer = screen.getByTestId('test-buttonContainer')
    expect(getButtonContainer).toBeInTheDocument()
  })

  it('test whether button is Clickable', () => {
    const clickableFn = jest.fn()
    customRender(<Button buttonText="testButton" onClick={clickableFn} />)
    const getButtonContainer = screen.getByTestId('test-buttonContainer')
    userEvent.click(getButtonContainer)
    expect(clickableFn).toHaveBeenCalled()
  })
})
