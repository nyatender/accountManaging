export interface IButtonPropTypes {
  buttonText: string
  variant?: 'Primary' | 'Secondary'
  isDisabled?: boolean
  isGhost?: boolean
  isOutLined?: boolean
  onClick?: () => void
}
