export type ChartData = {
  id: string
  label: string
  value: number
  color: string
}

export interface DonutPropTypes {
  chartData: ChartData[]
}
