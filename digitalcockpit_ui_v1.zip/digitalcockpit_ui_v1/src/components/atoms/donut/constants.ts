const marginTop = 10
const marginRight = 10
const marginBottom = 40
const marginLeft = 10
const innerRadius = 0.7
const padAngle = 0.7
const cornerRadius = 3
const activeOuterRadiusOffset = 8
const borderWidth = 1
const arcLinkLabelsSkipAngle = 10
const arcLabelsSkipAngle = 10
const translateX = 0
const translateY = 56
const itemsSpacing = 0
const itemWidth = 100
const itemHeight = 68
const itemOpacity = 1
const symbolSize = 18
export {
  marginTop,
  padAngle,
  marginRight,
  marginBottom,
  marginLeft,
  innerRadius,
  cornerRadius,
  activeOuterRadiusOffset,
  borderWidth,
  arcLinkLabelsSkipAngle,
  arcLabelsSkipAngle,
  translateX,
  translateY,
  itemsSpacing,
  itemWidth,
  itemHeight,
  itemOpacity,
  symbolSize,
}
