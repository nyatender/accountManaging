import React from 'react'
import { ResponsivePie } from '@nivo/pie'
import { DonutPropTypes } from './DonutPropTypes'
import {
  activeOuterRadiusOffset,
  arcLabelsSkipAngle,
  arcLinkLabelsSkipAngle,
  borderWidth,
  cornerRadius,
  innerRadius,
  itemHeight,
  itemOpacity,
  itemWidth,
  itemsSpacing,
  marginBottom,
  marginLeft,
  marginRight,
  marginTop,
  padAngle,
  symbolSize,
  translateX,
  translateY,
} from './constants'

function Donut({ chartData }: DonutPropTypes) {
  return (
    <ResponsivePie
      data-testid="donutComponent"
      data={chartData}
      margin={{
        top: marginTop,
        right: marginRight,
        bottom: marginBottom,
        left: marginLeft,
      }}
      colors={{ datum: 'data.color' }}
      innerRadius={innerRadius}
      padAngle={padAngle}
      cornerRadius={cornerRadius}
      activeOuterRadiusOffset={activeOuterRadiusOffset}
      borderWidth={borderWidth}
      borderColor={{
        from: 'color',
        modifiers: [['darker', 0.2]],
      }}
      arcLinkLabelsSkipAngle={arcLinkLabelsSkipAngle}
      arcLinkLabelsTextColor="none"
      arcLinkLabelsThickness={0}
      arcLinkLabelsColor={{ from: 'color' }}
      arcLabelsSkipAngle={arcLabelsSkipAngle}
      arcLabelsTextColor={{
        from: 'color',
        modifiers: [['darker', 2]],
      }}
      legends={[
        {
          anchor: 'bottom',
          direction: 'row',
          justify: false,
          translateX: translateX,
          translateY: translateY,
          itemsSpacing: itemsSpacing,
          itemWidth: itemWidth,
          itemHeight: itemHeight,
          itemTextColor: '#999',
          itemDirection: 'left-to-right',
          itemOpacity: itemOpacity,
          symbolSize: symbolSize,
          symbolShape: 'circle',
          effects: [
            {
              on: 'hover',
              style: {
                itemTextColor: '#000',
              },
            },
          ],
        },
      ]}
    />
  )
}

export { Donut }
