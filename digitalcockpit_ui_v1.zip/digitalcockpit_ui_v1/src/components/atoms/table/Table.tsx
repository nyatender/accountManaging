import React, { useMemo, useRef } from 'react'
import { GridOptions, RowEvent } from 'ag-grid-community'
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-alpine.css'
import '@siemens/ix-aggrid/dist/ix-aggrid/ix-aggrid.css'
import { ITablePropTypes } from './TablePropTypes'
import './TableStyle.css'
import { TableContainerStyle } from './TableStyles.css'

function Table({ rowData, columnDefs, onRowClicked }: ITablePropTypes) {
  const gridRef = useRef<AgGridReact<object[] | null>>(null)
  const defaultColDef = {
    resizable: true,
    sortable: true,
    filter: true,
    flex: 1,
    minWidth: 100,
  }
  const gridOptions = useMemo(() => {
    gridRef.current?.api?.setRowData(rowData)
    return {
      columnDefs: columnDefs,
      rowData: rowData,
      onRowClicked: (e: RowEvent) => {
        if (onRowClicked) {
          return onRowClicked(e.data)
        }
      },
      defaultColDef: defaultColDef,
      suppressCellFocus: true,
      rowHeight: 35,
      suppressBrowserResizeObserver: true,
    }
  }, [rowData]) as GridOptions

  return (
    <div
      className={`ag-theme-alpine-dark ag-theme-ix ag-theme-alpine ${TableContainerStyle}`}
    >
      <AgGridReact gridOptions={gridOptions} ref={gridRef} />
    </div>
  )
}

export { Table }
