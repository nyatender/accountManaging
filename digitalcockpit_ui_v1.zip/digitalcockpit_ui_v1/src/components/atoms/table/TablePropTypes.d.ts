export interface ITablePropTypes {
  rowData: GridOptions<TData>
  columnDefs: ColDef<TData, TValue>
  onRowClicked?: (event) => void
}
