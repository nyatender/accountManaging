import { style } from '@vanilla-extract/css'

export const TableContainerStyle = style({
  height: '26rem',
  border: '1px solid rgb(206, 206, 200)',
})
