import React from 'react'
import { IxContentHeader } from '@siemens/ix-react'
import {
  ContentHeaderVariant,
  IContentHeaderPropTypes,
} from './ContentHeaderPropTypes'

function ContentHeader({
  hasBackButton = false,
  headerSubtitle = '',
  headerTitle,
  variant = ContentHeaderVariant.primary,
  backButtonClick,
  className = '',
}: IContentHeaderPropTypes) {
  return (
    <IxContentHeader
      hasBackButton={hasBackButton}
      headerSubtitle={headerSubtitle}
      headerTitle={headerTitle}
      variant={variant}
      onBackButtonClick={backButtonClick}
      className={className}
    ></IxContentHeader>
  )
}

export { ContentHeader }
