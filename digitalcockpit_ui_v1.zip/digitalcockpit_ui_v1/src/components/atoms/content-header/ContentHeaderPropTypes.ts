export enum ContentHeaderVariant {
  primary = 'Primary',
  secondary = 'Secondary',
}

export interface IContentHeaderPropTypes {
  hasBackButton?: boolean
  headerSubtitle?: string
  headerTitle: string
  variant?: ContentHeaderVariant
  backButtonClick?: () => void
  className?: string
}
