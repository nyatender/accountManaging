import React from 'react'
import { customRender } from '../../utils/testUtils'
import CustomModal from './CustomModal'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('testing Modal component', () => {
  const logoutFn = jest.fn()
  const dismiss = jest.fn()
  it('test whether modal is rendering or not', () => {
    customRender(<CustomModal logout={logoutFn} />)
    const getButtonContainer = screen.getByTestId('test-Modal')
    expect(getButtonContainer).toBeInTheDocument()
  })

  it('test whether logout button is working', async () => {
    customRender(<CustomModal logout={logoutFn} />)

    const logoutButton = screen.getByTestId('test-logoutButton')
    const cancelbutton = screen.getByTestId('test-cancelMark')
    expect(cancelbutton).toBeInTheDocument()
    userEvent.click(logoutButton)
    await waitFor(() => {
      expect(logoutFn).toHaveBeenCalled()
    })
  })

  it('test whether cancel button is working', async () => {
    customRender(<CustomModal logout={logoutFn} />)

    const cancelbutton = screen.getByTestId('test-cancelMark')
    expect(cancelbutton).toBeInTheDocument()
    userEvent.click(cancelbutton)
    await waitFor(() => {
      expect(dismiss).toHaveBeenCalled()
    })
  })
})
