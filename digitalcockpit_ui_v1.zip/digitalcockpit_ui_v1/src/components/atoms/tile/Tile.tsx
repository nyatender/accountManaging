import React from 'react'
import { IxTile } from '@siemens/ix-react'
import { TilePropTypes } from './TilePropTypes'
function Tile({
  className,
  tileSize,
  tileHeader = '',
  tileContent,
}: TilePropTypes) {
  return (
    <IxTile size={tileSize} className={className} data-testid="test-tileHeader">
      <div slot="header">{tileHeader} </div>
      <div>{tileContent}</div>
    </IxTile>
  )
}

export { Tile }
