import React from 'react'
import { customRender } from '../../utils/testUtils'
import { Tile } from './Tile'
import { screen } from '@testing-library/react'

describe('Test Tile Component', () => {
  it('Is component rendering', () => {
    customRender(
      <Tile tileSize="medium" tileContent="123" tileHeader="header" />
    )
  })

  const TileTest = screen.queryByTestId(/test-tileHeader/)
  expect(TileTest).toBeNull()
})
