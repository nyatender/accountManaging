export interface TilePropTypes {
  className?: string
  tileSize: 'small' | 'medium'
  tileHeader?: string
  tileContent: string
}
