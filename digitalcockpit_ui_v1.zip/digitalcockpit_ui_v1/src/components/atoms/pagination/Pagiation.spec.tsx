import React from 'react'
import { screen } from '@testing-library/react'
import { customRender } from '../../utils/testUtils'
import { Pagination } from './Pagination'

describe('Testing Pagination Component', () => {
  let onItemCountChangeHandler = jest.fn()
  let onPageSelectedHandler = jest.fn()
  it('test if navigation Component is rendering', () => {
    customRender(
      <Pagination
        onItemCountChangeHandler={onItemCountChangeHandler}
        onPageSelectedHandler={onPageSelectedHandler}
      />
    )
    const PagContainer = screen.queryByTestId(/test-paginationContainer/)
    expect(PagContainer).toBeInTheDocument()
  })
})
