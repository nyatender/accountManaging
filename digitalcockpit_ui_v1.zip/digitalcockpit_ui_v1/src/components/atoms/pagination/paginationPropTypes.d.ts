interface IPaginationPropTypes {
  isAdvanced?: boolean
  showItemCount?: boolean
  count?: number
  className?: string
  currentPage?: number
  itemCount?: number
  onItemCountChangeHandler: (event: IxPaginationCustomEvent<number>) => void
  onPageSelectedHandler: (event: IxPaginationCustomEvent<number>) => void
}
