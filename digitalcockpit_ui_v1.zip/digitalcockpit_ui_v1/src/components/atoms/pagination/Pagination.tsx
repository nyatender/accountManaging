import React from 'react'
import { IxPagination } from '@siemens/ix-react'

function Pagination({
  isAdvanced,
  showItemCount,
  count,
  className,
  currentPage,
  itemCount,
  onItemCountChangeHandler,
  onPageSelectedHandler,
}: IPaginationPropTypes) {
  return (
    <div className={className} data-testid="test-paginationContainer">
      <IxPagination
        advanced={isAdvanced}
        showItemCount={showItemCount}
        count={count}
        selectedPage={currentPage}
        itemCount={itemCount}
        onItemCountChanged={(e) => onItemCountChangeHandler(e)}
        onPageSelected={(e) => onPageSelectedHandler(e)}
      />
    </div>
  )
}

export { Pagination }
