export const theme = {
  light: "theme-classic-light",
  dark: "theme-classic-dark",
};
