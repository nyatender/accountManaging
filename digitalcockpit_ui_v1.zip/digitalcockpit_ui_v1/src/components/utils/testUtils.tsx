import { render } from '@testing-library/react'
import { BrowserRouter } from 'react-router-dom'

const customRender = (component: React.ReactElement, options = {}) => {
  return render(<BrowserRouter>{component}</BrowserRouter>, options)
}

export { customRender }
