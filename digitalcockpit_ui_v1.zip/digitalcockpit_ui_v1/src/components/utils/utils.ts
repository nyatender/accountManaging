import { ICellRendererParams } from 'ag-grid-community'

export const getFirstLetterFromAzureUsername = (value: String) =>
  value.length ? value.split(', ')[1]?.trim()[0] : ''

export const factoryAssetListColumns = [
  { field: 'assetName', headerName: 'Asset Name' },
  { field: 'contractType', headerName: 'Contract Type' },
  { field: 'contractName', headerName: 'Contract Name' },
  {
    field: 'contractStatus',
    headerName: 'Contract Status',
    cellStyle: (params: ICellRendererParams) => {
      if (params.value === 'READY') return { color: 'red' }
    },
  },
  { field: 'customerName', headerName: 'Customer Name' },
  { field: 'assetStatus', headerName: 'Asset Status', hide: 'true' },
  { field: 'assetSerialId', headerName: 'Asset Serial Id', hide: 'true' },
  { field: 'assetId', headerName: 'Asset ID', hide: 'true' },
  { field: 'assetAddress', headerName: 'Asset Address', hide: 'true' },
  { field: 'selectedMetricName', headerName: 'Metric Name', hide: 'true' },
  {
    field: 'insurancePremiumVariable',
    headerName: 'insurance Premium',
    hide: 'true',
  },
  { field: 'startDate', headerName: 'Start Date', hide: 'true' },
  { field: 'endDate', headerName: 'End Date', hide: 'true' },

  { field: 'billingPeriod', headerName: 'Billing Period', hide: 'true' },
  { field: 'contractId', headerName: 'Contract Id', hide: 'true' },
  { field: 'contractOwnerId', headerName: 'Contract Owner Id', hide: 'true' },
  {
    field: 'contributionBasis',
    headerName: 'Contribution Basis',
    hide: 'true',
  },
  { field: 'currency', headerName: 'Currency', hide: 'true' },
  { field: 'customerId', headerName: 'Customer Id', hide: 'true' },
  { field: 'deductible', headerName: 'Deductible', hide: 'true' },
  { field: 'productionYear', headerName: 'Production Year', hide: 'true' },
  { field: 'typeNameList', headerName: 'Type Name List', hide: 'true' },
  { field: 'tsId', headerName: 'thinksurance Id', hide: 'true' },
  { field: 'policyId', headerName: 'Policy Id', hide: 'true' },
  { field: 'insuranceStatus', headerName: 'Insurance Status' },
]

export const ContractInfoKeys = [
  'startDate',
  'endDate',
  'contractType',
  'contractName',
  'contractStatus',
  'customerName',
]

export const AssetInfoKeys = [
  'assetId',
  'assetSerialId',
  'assetStatus',
  'assetAddress',
  'assetName',
]

export const MetricInfoKeys = ['selectedMetricName', 'insurancePremiumVariable']

export const infoKeyMappings = [
  {
    headerKeys: ContractInfoKeys,
    headerTitle: 'Contract Information :',
  },
  {
    headerKeys: AssetInfoKeys,
    headerTitle: 'Asset Information :',
  },
  {
    headerKeys: MetricInfoKeys,
    headerTitle: 'Metric Information :',
  },
]

export type contractApiResultTypes = {
  assetId: number
  assetStatus:
  'INIT'|
  'DRAFT'|
  'READY'|
  'WAITING_APPROVAL'|
  'APPROVED'|
  'REJECTED'|
  'INFRA_PRE'|
  'INFRA_ERROR'|
  'READY_FOR_COMMISSIONED'|
  'COMMISSIONED'|
  'STARTED'|
  'EXPIRED',
  billingPeriod: 'MONTHLY' | 'QUARTERLY' | 'SEMIANNUALLY' | 'ANNUALLY'
  contractId: number
  contractName: string
  contractOwnerId: number
  contractStatus: 'SAVED' | 'VALIDATION' | 'PUBLISHED' | 'REJECT'

  contributionBasis: number
  country: string
  currency: 'EUR' | 'USD'
  customerId: number
  customerName: string
  deductible: number
  endDate: string
  insurancePremiumVariable: number
  location: string
  productionYear: string
  road: string
  selectedAssetTypeName: string
  selectedMetricName: string
  serialId: string
  startDate: string
  sumInsured: number
  zipCode: string
  typeNameList: string
  tsId: number
  policyId: number
  insuranceStatus: string
}

export const ContractDataMapping = (data: contractApiResultTypes[]) => {
  return data.map((contract) => {
    const refinedData = {
      billingPeriod: contract?.billingPeriod,
      contractId: contract?.contractId,
      contractOwnerId: contract?.contractOwnerId,
      contributionBasis: contract?.contributionBasis,

      startDate: contract?.startDate,
      endDate: contract?.endDate,
      contractType: contract?.typeNameList,
      contractName: contract?.contractName,
      contractStatus: contract?.contractStatus,
      customerName: contract?.customerName,
      assetId: contract?.assetId,
      assetSerialId: contract?.serialId,
      assetStatus: contract?.assetStatus,
      assetName: contract?.selectedAssetTypeName,
      assetAddress:
        contract?.road +
        contract?.location +
        contract?.zipCode +
        contract?.country,
      selectedMetricName: contract?.selectedMetricName,
      insurancePremiumVariable: contract?.insurancePremiumVariable,
      thinksuranceId: contract?.tsId,
      policyId: contract?.policyId,
      insuranceStatus: contract?.insuranceStatus,
      currency: contract?.currency,
      customerId: contract?.customerId,
      deductible: contract?.deductible,
      productionYear: contract?.productionYear,
      sumInsured: contract?.sumInsured,
    }
    return refinedData
  })
}
