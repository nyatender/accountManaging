import { renderHook, act } from '@testing-library/react'
import { useLoadableWidget } from './useLoadableWidget'
import { serverMessages } from '../../services/axiosWrapper/errorMessages'

// Mock the dependencies (useNavigate, useToast, getAPI, etc.) here if needed

describe('useLoadableWidget', () => {
  jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn(),
  }))
  it('should navigate to /dashboard if positiveResult is true', async () => {
    // Mock the dependencies and set up necessary mocks/spies
    let navigate = jest.fn()
    let callToast = jest.fn()
    const { result } = renderHook(() => useLoadableWidget())

    await act(async () => {
      await result.current.isWidgetLoadEnabled()
    })

    expect(navigate).toHaveBeenCalledWith('/dashboard')
    expect(callToast).not.toHaveBeenCalled()
    expect(result.current.error).toBeNull()
    expect(result.current.loading).toBe(false)
  })

  it('should callToast if negativeResult is true', async () => {
    // Mock the dependencies and set up necessary mocks/spies
    let navigate = jest.fn()
    let callToast = jest.fn()
    const { result } = renderHook(() => useLoadableWidget())

    await act(async () => {
      await result.current.isWidgetLoadEnabled()
    })

    expect(navigate).not.toHaveBeenCalled()
    expect(callToast).toHaveBeenCalled()
    expect(result.current.error).toBeNull()
    expect(result.current.loading).toBe(false)
  })

  it('should set error if an error occurs during API calls', async () => {
    // Mock the dependencies and set up necessary mocks/spies
    let navigate = jest.fn()
    let callToast = jest.fn()
    const { result } = renderHook(() => useLoadableWidget())

    await act(async () => {
      await result.current.isWidgetLoadEnabled()
    })

    expect(navigate).not.toHaveBeenCalled()
    expect(callToast).not.toHaveBeenCalled()
    expect(result.current.error).toEqual(
      new Error(serverMessages?.widgetNotFound)
    )
    expect(result.current.loading).toBe(false)
  })
})
