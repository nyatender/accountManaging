import React, { useCallback, useId } from 'react'
import { KeyValue } from '../../atoms/keyValue'
import { keyValStyle } from '../../pages/factory-asset-list/FactoryAssetListStyle.css'
import { IFactoryAssetListTypes } from '../../pages/factory-asset-list/DrawerContentPropType'
import { ContentHeaderVariant } from '../../atoms/content-header/ContentHeaderPropTypes'
import { infoKeyMappings } from '../../utils/utils'
import { ContentHeader } from '../../atoms/content-header'
import { infoKeyStyle } from '../../pages/factory-asset-list/DrawerContentStyle.css'
import { useLoadableWidget } from './useLoadableWidget'
import { factoryAssetMapping } from '../../../constants'

function useGetDrawerContentData(drawerData: IFactoryAssetListTypes) {
  const { isWidgetLoadEnabled, loading, error } = useLoadableWidget()
  const keyId = useId()

  const handleGetInsuredClick = () => {
    isWidgetLoadEnabled()
  }

  /**
   * @returns group key value pairs as per drawer Title (Contract Info , Asset Info and Metric Status)
   */
  const renderInfoKeyValueBasedOnSubtitles = useCallback(
    (infoKeys: string | string[]) =>
      Object.entries(drawerData)
        .filter((eachItem) => infoKeys.includes(eachItem[0]))
        .map((assetData, index) => {
          //@ts-ignore
          const mappedLabel = factoryAssetMapping[assetData[0]]
          return (
            <KeyValue
              key={index}
              label={mappedLabel}
              value={assetData[1]?.toString() ?? ''}
              className={keyValStyle}
            />
          )
        }),
    [drawerData]
  )

  /**
   *
   * @returns Key-Value pair in Drawer Component
   */
  const renderKeyVal = () => {
    return infoKeyMappings.map((eachInfoKeyMapItem, index) => (
      <div className={infoKeyStyle} key={keyId + index}>
        <ContentHeader
          headerTitle={eachInfoKeyMapItem.headerTitle}
          variant={ContentHeaderVariant.secondary}
        />
        {renderInfoKeyValueBasedOnSubtitles(eachInfoKeyMapItem.headerKeys)}
      </div>
    ))
  }

  return {
    renderKeyVal,
    handleGetInsuredClick,
    loading,
    error,
  }
}

export { useGetDrawerContentData }
