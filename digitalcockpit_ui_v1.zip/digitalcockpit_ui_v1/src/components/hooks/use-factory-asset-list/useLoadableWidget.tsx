import { useState } from 'react'
import { getAPI } from '../../services/axiosWrapper'
import { getBrokerCodeAPI } from '../../services/api/get'
import { useNavigate } from 'react-router-dom'
import { useToast } from '../../atoms/toast/useToast'
import { serverMessages } from '../../services/axiosWrapper/errorMessages'
import { unLoadableWidgetAlertMessage } from '../../../constants'

function useLoadableWidget() {
  const [error, setError] = useState<Error | null>(null)
  const [loading, setLoading] = useState<boolean>(false)

  const navigate = useNavigate()
  const { callToast } = useToast(unLoadableWidgetAlertMessage)

  const getBrokerCode = async () => {
    setLoading(true)
    try {
      const { data }: { data: { bcodeToken: string } } = await getAPI(
        getBrokerCodeAPI
      )

      return {
        renderId: 'thinkSurance',
        brokerCode: data?.bcodeToken,
        productId: 153,
        professionAliasIds: [2987],
      }
    } catch (err) {
      return setError(new Error('Broker Code Failed'))
    } finally {
      setLoading(false)
    }
  }

  const isWidgetLoadEnabled = async () => {
    try {
      setLoading(true)
      const configData = await getBrokerCode()

      if (configData) navigate('/dashboard', { state: configData })
      else callToast()
    } catch (err) {
      setError(new Error(serverMessages?.widgetNotFound))
    } finally {
      setLoading(false)
    }
  }
  return { isWidgetLoadEnabled, error, loading }
}

export { useLoadableWidget }
