//@ts-nocheck
import { useGetFactoryAssetsData } from './useGetFactoryAssetsData'
import { renderHook } from '@testing-library/react'

describe('test useCfoDashboardHook', () => {
  it('check loading state is false,error is Error and data is null in factoryAssetList Page', async () => {
    const { result } = renderHook(() => useGetFactoryAssetsData())

    expect(result.current.isLoading).toBe(false)
    expect(result.current.data).toBe(null)
    expect(result.current.error).not.toBeNull()
  })

  //   it('check api is providing error from Server', () => {})
})
