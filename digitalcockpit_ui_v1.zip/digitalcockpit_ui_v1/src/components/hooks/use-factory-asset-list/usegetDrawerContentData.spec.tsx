//@ts-nocheck
import { useGetDrawerContentData } from './useGetDrawerContentData'
import { renderHook } from '@testing-library/react'

describe('test useCfoDashboardHook', () => {
  it('check loading state is false,error is Error and data is null in useGetDrawerContentData Page', async () => {
    const { result } = renderHook(() => useGetDrawerContentData())
    console.log(
      '🚀 ~ file: usegetDrawerContentData.spec.tsx:8 ~ it ~ result:',
      result
    )

    // expect(result.current.loading).toBe(false)
    // expect(result.current.renderKeyVal).toBe(null)
    // expect(result.current.error).not.toBeNull()
  })

  //   it('check api is providing error from Server', () => {})
})
