export interface IContractsDetailsDataType {
  startDate: string
  endDate: string
  contractType: string
  contractName: string
  contractStatus: string
  customerName: string
  assetId: number
  assetSerialId: string
  assetStatus: string
  assetAddress: string
  selectedMetricName: string
  insurancePremiumVariable: number
  assetName: string
}
