import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { serverMessages } from '../../services/axiosWrapper/errorMessages'
import { getAPI } from '../../services/axiosWrapper'
import { getContractsAPI } from '../../services/api/get'
import { IContractsDetailsDataType } from './useGetFactoryAssetsdataType'
import { ContractDataMapping, contractApiResultTypes } from '../../utils/utils'

function useGetFactoryAssetsData() {
  const [data, setData] = useState<IContractsDetailsDataType[] | null>(null)
  const apiData = useRef<IContractsDetailsDataType[] | null>(null)
  const [isLoading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<Error | null>(null)
  const pageSize = useRef(50)
  const startPage = useRef(0)

  useEffect(() => {
    getContractsData()
  }, [])

  /**
   *
   * @param value search value based on this, data in table renders
   */
  const handleChange = (value: string): void => {
    const searchedObj: IContractsDetailsDataType[] | null =
      apiData.current?.filter(
        (eachContractItem) =>
          (eachContractItem?.contractName ?? '')
            .toLowerCase()
            .indexOf(value.toLowerCase()) !== -1
      ) ?? null
    setData(searchedObj)
  }

  const getRefinedRowData = useMemo(
    () =>
      (data: contractApiResultTypes[]): IContractsDetailsDataType[] =>
        ContractDataMapping(data),
    []
  )

  /**
   * Calls API to get all contracts
   */
  const getContractsData = useCallback(async () => {
    try {
      const config = {
        maxBodyLength: Infinity,
        params: {
          pageSize: pageSize.current,
          page: startPage.current,
        },
      }
      const results: { data: contractApiResultTypes[] } = await getAPI(
        getContractsAPI,
        config
      )

      const resultantData: contractApiResultTypes[] = results?.data
      const reFinedContractData = getRefinedRowData(resultantData)

      apiData.current = reFinedContractData

      setData(apiData.current)
    } catch (err) {
      setError(new Error(serverMessages?.contractsDataNotFound))
    } finally {
      setLoading(false)
    }
  }, [])

  return { data, isLoading, error, handleChange }
}

export { useGetFactoryAssetsData }
