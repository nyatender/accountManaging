import { getAPI } from '../services/axiosWrapper'
import { toCheckValidOnboardedUser } from '../services/api/get'
import { useEffect, useState } from 'react'
import { serverMessages } from '../services/axiosWrapper/errorMessages'

const useCheckEmail = () => {
  const [isUserExists, setUserExist] = useState<boolean>(false)
  const [isLoading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<null | Error>(null)

  useEffect(() => {
    checkEmail()
  }, [])

  const checkEmail = async () => {
    try {
      const resultantData: boolean = await getAPI(toCheckValidOnboardedUser, {})
      setUserExist(resultantData)
    } catch (err) {
      setError(() => new Error(serverMessages?.chartDataNotFound))
    } finally {
      setLoading(false)
    }
  }

  return { isUserExists, isLoading, error }
}

export { useCheckEmail }
