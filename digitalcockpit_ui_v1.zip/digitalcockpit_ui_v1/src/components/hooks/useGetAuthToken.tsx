import { useEffect, useState } from 'react'
import { authProvider } from '../../authConfig'

const useGetAuthToken = () => {
  const [userName, setUsername] = useState<string>()
  useEffect(() => {
    const name = getAccountInfo()
    setUsername(name)
  }, [])

  const getAuthToken = async () => {
    const accessTokenRequest = {
      scopes: ['761f725a-8fb5-48ef-8d61-0e95a9b180c1/.default'],
    }
    try {
      const authToken = await authProvider.acquireTokenSilent(
        accessTokenRequest
      )

      // Call your API with this token
      return authToken
    } catch (error) {
      console.log(error)
    }
  }

  const getAccountInfo = () => {
    const { getAccountInfo } = authProvider
    const accountInfo = getAccountInfo()
    return accountInfo?.account.name || ''
  }

  return { getAuthToken, userName }
}

export { useGetAuthToken }
