import { useEffect, useState, useMemo, useCallback } from 'react'
import { getChartDataAPI } from '../../services/api/get'
import { getAPI } from '../../services/axiosWrapper'
import {
  IDonutDetailsRenderType,
  IDonutDetailsTypes,
} from './useCfoDashboardHookTypes'
import { DonutChartColors, DonutChartLabelsMapping } from '../../../constants'
import { serverMessages } from '../../services/axiosWrapper/errorMessages'

const useCfoDashboard = () => {
  const Colors = useMemo(() => DonutChartColors, [])

  const insetToDesiredData = (
    resultantArray: IDonutDetailsRenderType[],
    label: string,
    value: number,
    index: number,
    Colors: string[]
  ) =>
    resultantArray.push({
      id: DonutChartLabelsMapping[label],
      label: DonutChartLabelsMapping[label],
      value: value,
      color: Colors[index],
    })

  const [loading, setLoading] = useState<boolean>(true)
  const [data, setData] = useState<null | IDonutDetailsRenderType[]>(null)
  const [error, setError] = useState<null | Error>(null)

  useEffect(() => {
    getChartData()
  }, [])

  const getChartData = useCallback(async () => {
    let desiredData: IDonutDetailsRenderType[] = []

    try {
      const { data }: { data: IDonutDetailsTypes } = await getAPI(
        getChartDataAPI
      )
      const TotalSetOfChartData = Object.entries(data).length

      Object.entries(data)
        .filter((item) => item[0] !== 'totalAssets')
        .forEach((insuredStatus, index) => {
          if (index !== TotalSetOfChartData - 1)
            insetToDesiredData(
              desiredData,
              insuredStatus[0],
              insuredStatus[1],
              index,
              Colors
            )
        })

      setData(desiredData)
    } catch (err) {
      setError(() => new Error(serverMessages?.chartDataNotFound))
    } finally {
      setLoading(false)
    }
  }, [])

  return { loading, data, error }
}

export { useCfoDashboard }
