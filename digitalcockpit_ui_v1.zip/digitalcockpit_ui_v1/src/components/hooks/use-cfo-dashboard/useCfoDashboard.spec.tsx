//@ts-nocheck
import { useCfoDashboard } from './useCfoDashboard'
import { renderHook } from '@testing-library/react'
import * as axiosAPIWrapper from '../../services/axiosWrapper'

// getAPI
describe('test useCfoDashboardHook', () => {
  jest.mock('axiosAPIWrapper')

  it('check loading state is false,error is Error and data is null', async () => {
    const { result } = renderHook(() => useCfoDashboard())
    expect(result.current.loading).toBe(false)
    expect(result.current.data).toBe(null)
    expect(result.current.error).not.toBeNull()
  })
  it('check api is providing data from Server', async () => {
    axiosAPIWrapper.getAPI = jest.fn().mockImplementation(() =>
      Promise.resolve([
        { id: 'test', label: 'test', value: 3112, color: 'test' },
        { id: 'test', label: 'test', value: 1234, color: 'test' },
      ])
    )
    const data = await axiosAPIWrapper.getAPI()
    // const result = await data()
    expect(data).toStrictEqual([
      { id: 'test', label: 'test', value: 3112, color: 'test' },
      { id: 'test', label: 'test', value: 1234, color: 'test' },
    ])
  })
  //   it('check api is providing error from Server', () => {})
})
