interface IDonutDetailsTypes {
  insuredAssets: number
  tobeInsuredAssets: number
  totalAssets: number
}

interface IDonutDetailsRenderType {
  id: string
  label: string
  value: number
  color: string
}

export { IDonutDetailsTypes, IDonutDetailsRenderType }
