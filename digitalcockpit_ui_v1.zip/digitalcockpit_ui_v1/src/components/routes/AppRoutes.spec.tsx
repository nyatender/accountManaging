import React from 'react'
// import { Route, Routes } from 'react-router-dom'
// import { Home } from '../pages/home'
// import { ThinkSurance } from '../pages/thinksurance'
// import { CfoDashboard } from '../pages/cfo-dashboard'
// import { FactoryAssetList } from '../pages/factory-asset-list/FactoryAssetList'
// import { UnAuthorized } from '../pages/un-authorized/UnAuthorized'
// import { Error } from '../pages/error-page/Error'
// import App from '../../App'
import { customRender } from '../utils/testUtils'
// import { screen } from '@testing-library/react'
import { Home } from '../pages/home'

describe('Check AppRoutes', () => {
  const logout = jest.fn()
  it('Check Home Component is  Rendering', () => {
    customRender(<Home logout={logout} />)
  })
})
