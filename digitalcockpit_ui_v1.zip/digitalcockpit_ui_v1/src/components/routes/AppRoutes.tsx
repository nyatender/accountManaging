import React from 'react'
import { Route, Routes } from 'react-router-dom'
import { Home } from '../pages/home'
import { IAppProps } from '../../App'
import { ThinkSurance } from '../pages/thinksurance'
import { CfoDashboard } from '../pages/cfo-dashboard'
import { FactoryAssetList } from '../pages/factory-asset-list/FactoryAssetList'
import { UnAuthorized } from '../pages/un-authorized/UnAuthorized'
import { Error } from '../pages/error-page/Error'

function AppRoutes({ logout }: IAppProps): React.ReactElement {
  return (
    <Routes>
      <Route path="/" element={<Home logout={logout} />}>
        <Route index element={<CfoDashboard />} />
        <Route path="dashboard" element={<ThinkSurance />} />
        <Route path="factory-asset-list" element={<FactoryAssetList />} />
        <Route path="unAuthorized" element={<UnAuthorized />} />
        <Route path="error" element={<Error />} />
        <Route path="*" element={<Error />} />
      </Route>
    </Routes>
  )
}

export default AppRoutes
