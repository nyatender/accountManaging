package com.siemens.digitalcockpit.domain.ddx;

public class Constants {
    private Constants() {
    }
    public static final String INIT_VECTOR_KEY = "encryptionIntVec";
    public static final String ENCODING_ALGORITHM = "AES/CTR/NoPadding";
    public static final String ENCRYPTION_KEY = "aesEncryptionKey";
    public static final String AES = "AES";
    public static final String HASH = "hash";
    public static final String SECRET = "secret";
    public static final String TYPE = "type";
    public static final String BTOKEN = "bToken";
    public static final String ATOKEN = "aToken";
    public static final String LAST_DAYS = "lastDays";
    public static final String ATOKEN_VAL = "2dda0367c20116f6419f3bb5b7aed872";
    public static final String ATOKEN_VAL_ACCOUNT_IPN = "2dda0367c20116f6419f3bb5b7aed872";
    public static final String BFIRST_NAME = "bFirstName";
    public static final String BFIRST_NAME_VAL = "first";
    public static final String BZIP = "bZip";
    public static final String BSTREET = "bStreet";
    public static final String BSTREET_VAL = "textstreet";
    public static final String BSTREET_NUM = "bStreetNumber";
    public static final String BSTREET_NUM_VAL = "textstreetnumber";
    public static final String BZIP_VAL = "textZIP";
    public static final String BCITY = "bCity";
    public static final String BCITY_VAL = "textCITY";
    public static final String BPHONE = "bPhone";
    public static final String BPHONE_VAL = "textPhone";
    public static final String B_COMPANY_REG = "bCompanyRegNumber";
    public static final String B_COMPANY_REG_VAL = "1234";
    public static final String B_REG_NUMBER = "bRegNumber";
    public static final String B_REG_NUMBER_VAL = "5678";
    public static final String BTOKENVALUE = "4c45e6ae817dadb408882abd0";
    public static final String B_VAL = "4c45e6ae817dadb408882abd0";
    public static final String B_VAL_IPN = "4e078e316a5a38b95dc3bc399";
    public static final String BTOKENVALUEIPN = "4e078e316a5a38b95dc3bc399";
    public static final String I_ID = "iId";
    public static final String I_ID_VALUE = "1812251";
    public static final String BEXTERNALID = "bExternalId";
    public static final String BEXTERNALID_VAL = "ts5";
    public static final String BLASTNAME = "bLastName";
    public static final String BLASTNAME_VAL = "bentest5";
    public static final String BEMAIL = "bEmail";
    public static final String BEMAIL_VAL = "bentest5@test.de";
    public static final String BCOMPANY = "bCompany";
    public static final String BGENDER = "bGender";
    public static final String BCOMPANY_VAL = "testcompany3";
    public static final String CALLBACKURL = "callbackUrl";
    public static final String FULLCALLBACK = "fullCallback";
    public static final String MVCCALLBACKURL = "mvpCallbackUrl";
    public static final String MVPFULLCALLBACK = "mvpFullCallback";
    public static final String LOGIN_HEADER = "X-IOT-IAM-AUTH-KEY";
    public static final String ASSET_HEADER = "X-IOTAPP-AUTH-KEY";
    public static final String MINDSPEHERE_HEADER = "X-SPACE-AUTH-KEY";
    public static final String GRANT_TYPE = "grant_type";
    public static final String APP_NAME = "appName";
    public static final String APP_VERSION = "appVersion";
    public static final String HOST_TENANT = "hostTenant";
    public static final String USER_TENANT = "userTenant";
    public static final String AUTH_HEADER = "Authorization";
    public static final String BEARER = "Bearer ";
    public static final String FILTER_VALUE = "{ \"status\": {\n" +
            "\"in\": [\n" +
            "\"COMMISSIONED\"\n" +
            "]\n" +
            "}\n" +
            "}";
    public static final String ANSWER = "\"answers\": [";
    public static final String BROKER_FORWARD_PAYLOAD = "{\n" +
            "    \"type\": 1,\n" +
            "    \"bToken\": \"${bToken}\",\n" +
            "    \"cLastName\": \"TestRuV\",\n" +
            "    \"cEmail\": \"${cEmail}\",\n" +
            "    \"cExternalId\": \"${cExternalId}\",\n" +
            "    \"callbackUrl\": \"https://webhook.site/64842df0-6295-4527-9d1b-342ea7aa79dc\",\n" +
            "    \"qasCustProfile\": {\n" +
            "        \"categories\": [\n" +
            "            {\n" +
            "                \"id\": \"default\",\n" +
            "                \"questions\": [\n" +
            "{\n" +
            "                        \"id\": \"114080\",\n" +
            Constants.ANSWER +
            "                            \"${CompanyStreet}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"111056\",\n" +
            Constants.ANSWER +
            "                            \"${CompanyStreetNumber}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"111057\",\n" +
            Constants.ANSWER +
            "                            \"${ZipCode}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"City / 111058\",\n" +
            Constants.ANSWER +
            "                            \"${City}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114043\",\n" +
            Constants.ANSWER +
            "                            \"${MachineYearBuilt}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114044\",\n" +
            Constants.ANSWER +
            "                            \"Industries, possible answeres:\",\n" +
            "                            \"Metallworks / Metallverarbeitung\",\n" +
            "                            \"Woodworkss / Holzindustrie\",\n" +
            "                            \"Plastic and Chemistry / Kunststoffverarbeitung und Chemie\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114059\",\n" +
            Constants.ANSWER +
            "                            \"${Producer}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114060\",\n" +
            Constants.ANSWER +
            "                            \"${Modelname}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114061\",\n" +
            Constants.ANSWER +
            "                            \"${Serialnumber}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114063\",\n" +
            Constants.ANSWER +
            "                            \"${Listprice}\"\n" +
            "]\n" +
            "},\n" +
            "{\n" +
            "                        \"id\": \"114047\",\n" +
            Constants.ANSWER +
            "                            \"${Maschinetype}\"\n" +
            "]\n" +
            "                    }\n" +
            "                ]\n" +
            "            }\n" +
            "        ],\n" +
            "        \"source\": \"crm\"\n" +
            "    }\n" +
            "}\n";
}
