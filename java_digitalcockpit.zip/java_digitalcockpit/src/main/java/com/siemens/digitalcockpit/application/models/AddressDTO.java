package com.siemens.digitalcockpit.application.models;



import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO {

  private Long id;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Size(max = 255)
  private String road;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Size(max = 255)
  private String zipCode;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Size(max = 255)
  private String location;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Size(max = 255)
  private String country;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private boolean useCompanyAddress;

  private long assetInstanceId;
}
