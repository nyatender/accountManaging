package com.siemens.digitalcockpit.application.exceptions;


public class ClientException extends RuntimeException {
	private static final long serialVersionUID = -5755261679290616123L;
	private final int statusCode;
	private final String url;
	public ClientException(String url, int statusCode, Throwable cause) {
		super(cause);
		this.statusCode = statusCode;
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public int getStatusCode() {
		return statusCode;
	}
}
