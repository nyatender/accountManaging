package com.siemens.digitalcockpit.domain.thinksurance;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BrokerForward {
    private String url;
}
