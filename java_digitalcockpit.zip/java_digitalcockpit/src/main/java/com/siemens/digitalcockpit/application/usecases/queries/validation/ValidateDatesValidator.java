package com.siemens.digitalcockpit.application.usecases.queries.validation;


import com.siemens.digitalcockpit.application.exceptions.BusinessException;
import com.siemens.digitalcockpit.application.paging.DateUtil;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDates;
import org.springframework.http.HttpStatus;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

import static com.siemens.digitalcockpit.application.exceptions.ExceptionMessage.*;


public class ValidateDatesValidator
    implements ConstraintValidator<ValidateDatesValidation, ContractDates> {

  @Override
  public boolean isValid(ContractDates value, ConstraintValidatorContext context) {
    if (value.getStartDate() != null && value.getEndDate() != null) {
      isValidFormat(value.getEndDate());
      isValidFormat(value.getStartDate());
      if (DateUtil.toLocalDateTime(value.getStartDate())
          .isBefore(DateUtil.getNowAsUTC().with(LocalTime.MIN))) {
        throw new BusinessException(String.valueOf(HttpStatus.BAD_REQUEST), START_DATE_VALIDATION);
      }
      if (DateUtil.toLocalDateTime(value.getEndDate())
              .isAfter(DateUtil.toLocalDateTime(value.getStartDate()))
              && ChronoUnit.DAYS.between(
              DateUtil.toLocalDateTime(value.getStartDate()),
              DateUtil.toLocalDateTime(value.getEndDate()))
              >= 1) {
        return true;
      }
      throw new BusinessException(
          String.valueOf(HttpStatus.BAD_REQUEST), START_END_DATE_VALIDATION);
    }
    return true;
  }

  private void isValidFormat(String date) {
    if (!DateValidator.isValidFormat(date)) {
      throw new BusinessException(String.valueOf(HttpStatus.BAD_REQUEST), DATE_FORMAT_EXCEPTION);
    }
  }
}
