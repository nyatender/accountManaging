package com.siemens.digitalcockpit.domain.thinksurance;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Data {

    private int type;
    private String bToken;
    private String cLastName;
    private String cEmail;
    private String cExternalId;
    private String callbackUrl;
    private QasCustProfile qasCustProfile;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class QasCustProfile {
        private List<Category> categories;
        private String source;

        @Getter
        @Setter
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Category {
            private String id;
            private List<Question> questions;

            @Getter
            @Setter
            @NoArgsConstructor
            @AllArgsConstructor
            public static class Question {
                private String id;
                private List<String> answers;
            }
        }
    }
}
