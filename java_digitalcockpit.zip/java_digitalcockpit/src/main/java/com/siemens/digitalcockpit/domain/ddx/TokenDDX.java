package com.siemens.digitalcockpit.domain.ddx;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@Component
public class TokenDDX {
    private String token;
    private String companyId;
    private String companyName;
    private String userName;
}
