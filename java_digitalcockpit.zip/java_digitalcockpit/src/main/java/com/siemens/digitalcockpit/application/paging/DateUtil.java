package com.siemens.digitalcockpit.application.paging;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateUtil {
  private DateUtil() {
     }
  public static final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  public static String toISOString(LocalDateTime localDateTime) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_FORMAT);
    return localDateTime.atZone(ZoneOffset.UTC).format(formatter);
  }

  public static String toISOStringTruncateToMillis(LocalDateTime localDateTime) {
    return localDateTime.toInstant(ZoneOffset.UTC).truncatedTo(ChronoUnit.MILLIS).toString();
  }

  public static LocalDateTime toLocalDateTime(String isoDateTime) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_FORMAT);
    return LocalDateTime.parse(isoDateTime, formatter);
  }

  public static LocalDateTime getNowAsUTC() {
    return LocalDateTime.now(ZoneOffset.UTC);
  }

  public static String getFutureDateAsString(int days) {
    LocalDateTime localDateTime = LocalDateTime.now().plusDays(days);
    return localDateTime.toInstant(ZoneOffset.UTC).toString();
  }
}
