package com.siemens.digitalcockpit.application.usecases.queries.getaccountipn;

import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

public class GetAccountIPNQueryHandler {
    private final IThinksuranceService thinksuranceService;
    @Autowired
    public GetAccountIPNQueryHandler(IThinksuranceService thinksuranceService) {
        this.thinksuranceService = thinksuranceService;
    }
    public CompletableFuture<String> getAccountIPN() throws ConnectException {
        try {
            return this.thinksuranceService.getAccountIPN();
        } catch (Exception e) {
            throw new ConnectException("Error in get Account IPN Query Handler");
        }
    }
}
