package com.siemens.digitalcockpit.domain.common;

public enum Currency {

  EUR,
  USD
}
