package com.siemens.digitalcockpit.application.usecases.queries.validation;



import com.siemens.digitalcockpit.application.paging.DateUtil;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DateValidator implements ConstraintValidator<DateValidation, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
    return isValidFormat(value);
  }

  public static boolean isValidFormat(String value) {
    try {
      if (value != null) {
        DateUtil.toLocalDateTime(value);
      }
    } catch (Exception ex) {
      return false;
    }
    return true;
  }
}
