package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.siemens.digitalcockpit.application.models.BillingDTO;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class ContractDTO extends BaseContractDTO {
  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private List<@Valid AssetInstanceDTO> assetInstanceList;
  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Valid
  private BillingDTO billing;

}
