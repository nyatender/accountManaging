package com.siemens.digitalcockpit.application.usecases.command.brokercreate;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.application.mappings.BTokenMappings;
import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

public class CreateBrokerCommandHandler {
    private final IThinksuranceService iThinksuranceService;
    private final BTokenMappings bTokenMappings;
    @Autowired
    public CreateBrokerCommandHandler(IThinksuranceService iThinksuranceService,BTokenMappings bTokenMappings) {
        this.iThinksuranceService = iThinksuranceService;
        this.bTokenMappings = bTokenMappings;
    }

    public CompletableFuture<CreateBrokerCommand> createBroker(String uniqueName) throws ConnectException {
        try {
            CompletableFuture<JsonNode> resp = this.iThinksuranceService.brokerCreate(uniqueName);
            CompletableFuture<CreateBrokerCommand> response = this.bTokenMappings.mapToCreateBrokerCommand(resp.get());
            return response;
        } catch (Exception e) {
            throw new ConnectException("Error in Broker Create Query Handler");
        }
    }
}
