package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.models.Status;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import com.siemens.digitalcockpit.application.usecases.queries.validation.StatusValidation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor


@EqualsAndHashCode(callSuper=false)
public class BaseContractDTO extends ContractDates {
  private Long id;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private Long typeId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String typeName;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Size(min = 5, max = 250)
  private String name;

  @StatusValidation
  private String status = Status.DRAFT.toString();

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private Long providerNameId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private Long customerId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String customerName;

  private Long contractOwnerId;
}
