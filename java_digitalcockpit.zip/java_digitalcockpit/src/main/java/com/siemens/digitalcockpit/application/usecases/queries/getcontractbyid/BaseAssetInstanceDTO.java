package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;



import com.siemens.digitalcockpit.application.models.AssetInstanceStatus;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class BaseAssetInstanceDTO extends BaseAssetDetailResponseDTO {
  private Long id;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String serialId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private Long selectedAssetTypeId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String selectedAssetTypeName;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private BigDecimal sumInsured;

  private long contractId;

  private String status = AssetInstanceStatus.NOT_CONNECTED.toString();
}
