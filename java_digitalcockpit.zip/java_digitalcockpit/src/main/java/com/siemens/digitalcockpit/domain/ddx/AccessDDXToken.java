package com.siemens.digitalcockpit.domain.ddx;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Component
public class AccessDDXToken {
    private String accessToken;
    private String tokenType;
    private int expiresIn;
    private String scope;
    private String jti;
    private Long timestamp;
}
