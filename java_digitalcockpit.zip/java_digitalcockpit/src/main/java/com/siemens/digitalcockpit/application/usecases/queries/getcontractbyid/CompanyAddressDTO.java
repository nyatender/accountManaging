package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class CompanyAddressDTO {
  @Size(min = 1, max = 255)
  @NotNull
  private String road;
  @Size(min = 1)
  @NotNull
  private String zipCode;

  @Size(min = 1)
  @NotNull
  private String city;

  @Size(min = 1)
  @NotNull
  private String country;

  @Size(min = 1)
  @NotNull
  private String postalCountry;

  @Size(min = 1)
  @NotNull
  private String postalCity;

  @Size(min = 1)
  @NotNull
  private String postalRoad;

  @Size(min = 1)
  @NotNull
  private String postalZipCode;
}
