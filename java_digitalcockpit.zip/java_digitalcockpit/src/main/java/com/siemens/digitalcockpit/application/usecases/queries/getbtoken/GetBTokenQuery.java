package com.siemens.digitalcockpit.application.usecases.queries.getbtoken;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GetBTokenQuery {
    private String bCodeToken;
}
