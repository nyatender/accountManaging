package com.siemens.digitalcockpit.application.usecases.queries.validation;





import com.siemens.digitalcockpit.application.models.Status;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

public class StatusValidator implements ConstraintValidator<StatusValidation, String> {

  public static final List<String> statusEnumList =
      EnumSet.allOf(Status.class).stream().map(Status::name).collect(Collectors.toList());

  public boolean isValid(String status, ConstraintValidatorContext cxt) {
    return statusEnumList.contains(status);
  }
}
