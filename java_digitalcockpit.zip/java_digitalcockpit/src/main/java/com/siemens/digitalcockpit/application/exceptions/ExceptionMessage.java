package com.siemens.digitalcockpit.application.exceptions;


public class ExceptionMessage {
  private ExceptionMessage() {
  }
  public static final String CONTRACT_NOT_FOUND = "Contract not found!";
  public static final String CONTRACT_RESOURCE_DETAIL_NOT_FOUND =
      "Contract resource detail not found! for %s = %s";
  public static final String EMAIL_SENDING_FAILED = "Problem occurred while sending email.";
  public static final String PUBLISH_STATUS_ERROR_MESSAGE =
      "Contract status must be in 'WAITING APPROVAL' for Approval Status";
  public static final String CONTRACT_PASSWORD_ERROR_MESSAGE =
      "MachineLink's password is not valid";

  public static final String CONTRACT_DOWNLOAD_ERROR_MESSAGE =
      "Contract's status must be READY FOR COMMISSIONING";
  public static final String CONTRACT_NAME_ALREADY_EXISTS =
      "The naming of contract %s is already in use from another contract.";

  public static final String CONTRACT_TRACK_ID_ERROR_MESSAGE =
      "Contract's Track ID should be unique! This Track ID already has contract.";
  public static final String COMMISSION_STATUS_ERROR =
      "Contract status must be in 'READY FOR COMMISSIONING' to be able to commission the contract";
  public static final String CONTRACT_STATUS_ERROR =
      "Contract status is  %s. You can not change status as a %s";

  public static final String CONTRACT_STATUS_NOT_VALID_FOR_UPDATE =
      "You can update only DRAFT, READY & APPROVED contracts.";

  public static final String CONTRACT_STATUS_NOT_VALID_FOR_DELETE =
      "You can delete only DRAFT, READY, INFRA ERROR and READY FOR COMMISSIONING contracts.";

  public static final String ASSET_NOT_FOUND = "There is no such a asset!";
  public static final String METRIC_NOT_FOUND = "There is no such a metric!";
  public static final String METRIC_STATE_EXCEPTION =
      "Only PUBLISHED Metrics can be used in contract!";
  public static final String ASSET_STATE_EXCEPTION =
      "Only PUBLISHED Assets can be used in contract!";

  public static final String ASSET_AND_METRIC_VALIDATION_ERROR =
      "Problem occurred when checking asset and metric.";

  public static final String START_END_DATE_VALIDATION =
      "End of contract date must be greater than of commencement date. There must be at least one day between the contract end date and the start date.";

  public static final String DATE_FORMAT_EXCEPTION =
      "Invalid Date! Value: must be this format yyyy-MM-ddTHH:mm:ss.SSSZ";

  public static final String START_DATE_VALIDATION = "Start date cannot be earlier than today.";

  public static final String CONTRACT_NAME_BLANK_SPACE_ERROR =
      "Contract name must not contain blank space.";
}
