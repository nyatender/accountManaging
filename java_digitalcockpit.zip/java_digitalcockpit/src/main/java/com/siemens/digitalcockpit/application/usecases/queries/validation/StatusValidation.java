package com.siemens.digitalcockpit.application.usecases.queries.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;

@Target({FIELD, PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = StatusValidator.class)
public @interface StatusValidation {

  // error message
  public String message() default
      "Invalid status! Value: must be  one of the following types: [INIT, DRAFT, READY, WAITING_APPROVAL, APPROVED, REJECTED, INFRA_PRE,READY_FOR_COMMISSIONED,COMMISSIONED,STARTED,EXPIRED]";

  // represents group of constraints

  public Class<?>[] groups() default {};

  // represents additional information about annotation

  public Class<? extends Payload>[] payload() default {};
}
