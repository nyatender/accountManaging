package com.siemens.digitalcockpit.application.usecases.command.createbrokerforward;


import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.application.repositories.IDDXService;
import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import com.siemens.digitalcockpit.application.usecases.queries.getbtoken.GetBTokenQuery;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDTO;
import com.siemens.digitalcockpit.domain.ddx.Constants;
import com.siemens.digitalcockpit.domain.thinksurance.BrokerForward;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;


import java.math.BigDecimal;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
public class CreateBrokerForwardCommandHandler {
    private final IThinksuranceService thinksuranceService;
    private final IDDXService ddxService;

    private @Value("${thinksurance.callbackurl}") String callbackUrl;

    @Autowired
    public CreateBrokerForwardCommandHandler(IThinksuranceService thinksuranceService, IDDXService ddxService) {
        this.thinksuranceService = thinksuranceService;
        this.ddxService = ddxService;
    }

    public CompletableFuture<GetBTokenQuery> createBrokerForward(Long contractId, String uniqueName) throws ConnectException, InterruptedException, ExecutionException {
        try {
            String contactEmail = uniqueName;
            String callbackUrl = "";
            int type = 1;
            String serialId = null;
            int productionYear = 0;
            String manufacturer = null;
            String zipCode = null;
            String bToken = null;
            String road = null;
            String model = null;
            String assetType = null;
            BigDecimal sumInsured = BigDecimal.valueOf(1);
            String location = null;
            String template1 = Constants.BROKER_FORWARD_PAYLOAD;
            CompletableFuture<ContractDTO> contract = this.ddxService.getContractByID(uniqueName,contractId);
            log.info(String.valueOf(contract.get()));
            if (contract != null) {
                // contactEmail = uniqueName;
                if (contract.get().getAssetInstanceList() != null){
                    if (contract.get().getAssetInstanceList().get(0) != null){
                        if ( contract.get().getAssetInstanceList().get(0).getSerialId()!= null)
                        serialId = contract.get().getAssetInstanceList().get(0).getSerialId();
                        if ( contract.get().getAssetInstanceList().get(0).getProductionYear()!= 0)
                        productionYear = contract.get().getAssetInstanceList().get(0).getProductionYear();
                        if ( contract.get().getAssetInstanceList().get(0).getAddress().getRoad()!= null)
                        road = contract.get().getAssetInstanceList().get(0).getAddress().getRoad();
                        if (contract.get().getAssetInstanceList().get(0).getManufacturer() != null)
                        manufacturer = contract.get().getAssetInstanceList().get(0).getManufacturer();
                        if (contract.get().getAssetInstanceList().get(0).getModel() != null)
                        model = contract.get().getAssetInstanceList().get(0).getModel();
                        if (contract.get().getAssetInstanceList().get(0).getAssetType() != null)
                        assetType = contract.get().getAssetInstanceList().get(0).getAssetType();
                        if (contract.get().getAssetInstanceList().get(0).getAddress().getZipCode() != null)
                        zipCode = contract.get().getAssetInstanceList().get(0).getAddress().getZipCode();
                        if ( contract.get().getAssetInstanceList().get(0).getSumInsured() != null)
                        sumInsured = contract.get().getAssetInstanceList().get(0).getSumInsured();
                        if(contract.get().getAssetInstanceList().get(0).getAddress().getLocation() != null)
                        location = contract.get().getAssetInstanceList().get(0).getAddress().getLocation();
                        log.info("contactEmail {}", contactEmail);
                    }
                }
            }
            JsonNode node1 = this.thinksuranceService.brokerCreate(uniqueName).get();
            String btoken = node1.get("bToken").textValue();
            Map<String, Object> values2 = new HashMap<>();
            values2.put("type",type);
            values2.put("callbackUrl",callbackUrl);
            if (btoken != null) {
                values2.put("bToken", btoken);
            }
            if (contractId != null)
                values2.put("cExternalId", contractId);
            if (contactEmail != null)
                values2.put("cEmail", contactEmail);
            if (zipCode != null)
                values2.put("ZipCode", zipCode);
            if (road != null)
                values2.put("CompanyStreetNumber", road);
            if (productionYear != 0)
                values2.put("MachineYearBuilt", productionYear);
            if (road != null)
                values2.put("CompanyStreet", road);
            if (manufacturer != null)
                values2.put("Producer", manufacturer);
            if (model != null)
                values2.put("Modelname", model);
            if (serialId != null)
                values2.put("Serialnumber", serialId);
            if (sumInsured != null)
                values2.put("Listprice", sumInsured);
            if (assetType != null)
                values2.put("Maschinetype", assetType);
            if (location != null)
                values2.put("City", location);
            log.info("Converted Data: " + format(template1, values2).get());
            String req = format(template1, values2).get();
            try{
                CompletableFuture<BrokerForward> responseDTO = this.thinksuranceService.createBrokerForward(req);
                CreateBrokerForwardCommand resp = new ModelMapper().map(responseDTO.get(), CreateBrokerForwardCommand.class);
            } catch (Exception e){
                log.info(e.getMessage());
            }
            JsonNode node = thinksuranceService.getBCodeToken(uniqueName).get();
            GetBTokenQuery getBTokenQuery = new GetBTokenQuery();
            getBTokenQuery.setBCodeToken(node.get(0).get("bCode").textValue());
            return CompletableFuture.completedFuture(getBTokenQuery);
        } catch (InterruptedException ex) {
            log.warn("Interrupted");
            throw new InterruptedException("Interrupted");
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        }
    }

    public static CompletableFuture<String> format(String format, Map<String, Object> values) throws InterruptedException {
        try {
            StringBuilder formatter = new StringBuilder(format);
            List<Object> valueList = new ArrayList<>();
            Matcher matcher = Pattern.compile("\\$\\{(\\w+)}").matcher(format);
            while (matcher.find()) {
                String key = matcher.group(1);
                String formatKey = String.format("${%s}", key);
                int index = formatter.indexOf(formatKey);
                if (index != -1) {
                    formatter.replace(index, index + formatKey.length(), "%s");
                    valueList.add(values.get(key));
                }
            }
            return CompletableFuture.completedFuture(String.format(formatter.toString(), valueList.toArray()));
        } catch (Exception e) {
            log.warn(e.getMessage());
            throw new InterruptedException("Interrupted in format string method");
        }
    }
}
