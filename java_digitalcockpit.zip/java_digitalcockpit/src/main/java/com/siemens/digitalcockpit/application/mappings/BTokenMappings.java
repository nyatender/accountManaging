package com.siemens.digitalcockpit.application.mappings;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.application.exceptions.TokenNotFoundException;
import com.siemens.digitalcockpit.application.usecases.command.brokercreate.CreateBrokerCommand;
import com.siemens.digitalcockpit.application.usecases.queries.getbtoken.GetBTokenQuery;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.CompletableFuture;

@Slf4j
public class BTokenMappings {
    public CompletableFuture<GetBTokenQuery> mapToBTokenQuery(JsonNode bToken) throws TokenNotFoundException {
        try {
            if (bToken == null) {
                return null;
            }
            GetBTokenQuery getBTokenQuery = new GetBTokenQuery();
            getBTokenQuery.setBCodeToken(bToken.get(0).get("bCode").textValue());
            return CompletableFuture.completedFuture(getBTokenQuery);
        } catch (Exception e) {
            log.info("Error in BToken Mapping");
            throw new TokenNotFoundException("Error in BToken Mapping");
        }
    }

    public CompletableFuture<CreateBrokerCommand> mapToCreateBrokerCommand(JsonNode brokerCreate) throws TokenNotFoundException {
        try {
            if (brokerCreate == null) {
                return null;
            }
            CreateBrokerCommand createBrokerCommand = new CreateBrokerCommand();
            createBrokerCommand.setBToken(brokerCreate.get("bToken").textValue());
            createBrokerCommand.setStatus(brokerCreate.get("status").textValue());
            return CompletableFuture.completedFuture(createBrokerCommand);
        } catch (Exception e) {
            log.info("Error in BToken Mapping");
            throw new TokenNotFoundException("Error in BToken Mapping");
        }
    }
}
