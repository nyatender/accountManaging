package com.siemens.digitalcockpit.domain.ddx;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Contract {
    public boolean useCompanyAddress;
    public int contractOwnerId;
    public LocalDateTime startDate;
    public LocalDateTime endDate;

    public int id;
    public ArrayList<String> typeIdList;
    public ArrayList<String> typeNameList;

    public String name;

    public String status;
    public int customerId;
    public String customerName;
    public ArrayList<AssetInstanceList> assetInstanceList;
    public Billing billing;
}
