package com.siemens.digitalcockpit.application.exceptions;

public class BusinessException extends RuntimeException {
  private static final long serialVersionUID = 3L;

  public ApplicationError getApplicationError() {
    return applicationError;
  }

  private final ApplicationError applicationError;

  public BusinessException(String errorCode, String message) {
    super(message);
    this.applicationError = new ApplicationError(errorCode, message);
  }
}
