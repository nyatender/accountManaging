package com.siemens.digitalcockpit.application.paging;

public interface ParamConverter<T> {
  T fromString(String arg0);
}
