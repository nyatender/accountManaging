package com.siemens.digitalcockpit.application.paging;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
//import org.springframework.data.domain.Page;

import java.util.List;

@Value
@Builder
@AllArgsConstructor
public class PageResponseDTO<T> {
  List<T> items;
  int page;
  int pageSize;
  int totalPages;
  long totalElements;
  boolean hasNext;
  boolean hasPrevious;

}
