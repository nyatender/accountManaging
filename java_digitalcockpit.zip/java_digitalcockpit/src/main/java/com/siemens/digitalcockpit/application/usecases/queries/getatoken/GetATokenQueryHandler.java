package com.siemens.digitalcockpit.application.usecases.queries.getatoken;

import com.fasterxml.jackson.databind.JsonNode;

import com.siemens.digitalcockpit.application.mappings.ATokenMappings;
import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetATokenQueryHandler {
    private final IThinksuranceService thinksuranceService;
    private final ATokenMappings aTokenMappings;
    @Autowired
    public GetATokenQueryHandler(IThinksuranceService thinksuranceService,ATokenMappings aTokenMappings) {
        this.thinksuranceService = thinksuranceService;
        this.aTokenMappings = aTokenMappings;
    }
    public CompletableFuture<GetATokenQuery> getAToken() throws ConnectException {
        try{
            CompletableFuture<JsonNode> jsonNode = this.thinksuranceService.getAToken();
            CompletableFuture<GetATokenQuery> response = aTokenMappings.mapToATokenQuery(jsonNode.get());
            return response;
        } catch (Exception e) {
            throw new ConnectException("Error in get AToken Query Handler");
        }
    }
}
