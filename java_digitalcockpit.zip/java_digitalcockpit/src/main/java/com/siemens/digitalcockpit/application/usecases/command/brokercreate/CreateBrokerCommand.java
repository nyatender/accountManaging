package com.siemens.digitalcockpit.application.usecases.command.brokercreate;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@Component
public class CreateBrokerCommand {
    private String status;
    private String bToken;
}
