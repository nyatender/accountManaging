package com.siemens.digitalcockpit.application.usecases.queries.getipn;


import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetIPNQueryHandler {
    private final IThinksuranceService thinksuranceService;
    @Autowired
    public GetIPNQueryHandler(IThinksuranceService thinksuranceService) {
        this.thinksuranceService = thinksuranceService;
    }

    public CompletableFuture<String> getIPN(String uniqueName) throws ConnectException {
        try {
            return this.thinksuranceService.getIPN(uniqueName);
        } catch (Exception e) {
            log.info(e.getMessage());
            throw new ConnectException("Error in get IPN Query handler");
        }
    }
}
