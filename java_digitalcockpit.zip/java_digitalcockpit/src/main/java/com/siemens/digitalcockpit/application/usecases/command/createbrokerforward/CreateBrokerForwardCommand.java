package com.siemens.digitalcockpit.application.usecases.command.createbrokerforward;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Setter
public class CreateBrokerForwardCommand {
    private String url;
}
