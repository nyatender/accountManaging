package com.siemens.digitalcockpit.application.models;


import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class BaseMetricDTO extends MetricDetailDTO {
  private Long id;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private Long selectedMetricId;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String selectedMetricName;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private BigDecimal insurancePremiumVariable;

  private long assetInstanceId;
}
