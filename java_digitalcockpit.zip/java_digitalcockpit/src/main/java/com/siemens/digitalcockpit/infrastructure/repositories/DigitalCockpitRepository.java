package com.siemens.digitalcockpit.infrastructure.repositories;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.siemens.digitalcockpit.application.exceptions.ClientException;
import com.siemens.digitalcockpit.application.repositories.IDDXService;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.ContractsDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetAllContractsQuery;
import com.siemens.digitalcockpit.domain.ddx.AccessDDXToken;
import com.siemens.digitalcockpit.domain.ddx.Constants;
import com.siemens.digitalcockpit.domain.ddx.Contract;
import com.siemens.digitalcockpit.domain.ddx.TokenDDX;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.MessageFormat;

import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
@Slf4j
@SuppressWarnings("unchecked")
public class DigitalCockpitRepository implements IDDXService {
    private @Value("${ddx.getasseturi}") String assetUri;
    private @Value("${ddx.getcontractsuri}") String contractUri;
    private @Value("${ddx.retry.maxAttempts}") int maxAttempts;
    private @Value("${ddx.retry.backoffDelay}") int backoffDelay;
    private @Value("${thinksurance.hash}") String hash;
    private @Value("${thinksurance.secret}") String secret;
    private @Value("${thinksurance.tokenuri}") String tokenuri;
    private @Value("${thinksurance.uri}") String baseUri;
    private @Value("${ddx.getbothtoken}") String getTokensUri;
    private @Value("${azure.clientIdSecret}") String clientIdSecret;
    private @Value("${azure.token_Url}") String tokenUrl;
    private @Value("${azure.scope}") String scope;
    private @Value("${azure.grantType}") String grantType;
    private final AccessDDXToken accessDDXToken;
    private final TokenDDX tokenDDX;
    private final RestTemplate restTemplate;


    @Autowired
    public DigitalCockpitRepository(AccessDDXToken accessDDXToken, TokenDDX tokenDDX, RestTemplate restTemplate) {
        this.accessDDXToken = accessDDXToken;
        this.tokenDDX = tokenDDX;
        this.restTemplate = restTemplate;

    }

    @Override
    public CompletableFuture<List<ContractsDTO>> getContracts(String uniqueName, int pageSize, int page) throws ExecutionException, InterruptedException, ConnectException, UnsupportedEncodingException {
        String response = null;
        List<ContractsDTO> getAllContractsQuery = new ArrayList<>();
        List<ContractsDTO> contractsDTOS = null;
        try {

            HttpHeaders headers = getCommonRequestHeaders(uniqueName).get();
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(headers);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(contractUri)
                    .queryParam("pageSize", pageSize)
                    .queryParam("filter", encodeValue(Constants.FILTER_VALUE))
                    .queryParam("page", page);
            Map<String, Integer> paramsMap = new HashMap<>();
            paramsMap.put("pageSize", pageSize);
            paramsMap.put("page", page);
            log.info("contractUri", contractUri);
            ResponseEntity<String> responseEntity = restTemplate.exchange(builder.buildAndExpand(paramsMap).toUri(), HttpMethod.GET, httpEntity, String.class);
            response = responseEntity.getBody();
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response);
            int totalElements = jsonNode.get("totalElements").asInt();
            for (int i = 0; i < totalElements; i++) {

                if (jsonNode.get("items").get(i) != null) {
                    ContractsDTO contractsDTO = new ContractsDTO();
                    if (jsonNode.get("items").get(i).get("contractOwnerId") != null) {
                        int contractOwnerId = jsonNode.get("items").get(i).get("contractOwnerId").asInt();
                        if (contractOwnerId != 0)
                            contractsDTO.setContractOwnerId(contractOwnerId);
                    }
                    if (jsonNode.get("items").get(i).get("id") != null) {
                        int contractId = jsonNode.get("items").get(i).get("id").asInt();
                        if (contractId != 0)
                            contractsDTO.setContractId(contractId);
                    }
                    if (jsonNode.get("items").get(i).get("typeNameList") != null){
                        if (jsonNode.get("items").get(i).get("typeNameList").get(0) != null) {
                            String typeNameList = jsonNode.get("items").get(i).get("typeNameList").get(0).textValue();
                            if (typeNameList != null)
                                contractsDTO.setTypeNameList(typeNameList);
                        }
                    }

                    if (jsonNode.get("items").get(i).get("name")!= null) {
                        String contractName = jsonNode.get("items").get(i).get("name").asText();
                        if (contractName != null)
                            contractsDTO.setContractName(contractName);
                    }
                    if (jsonNode.get("items").get(i).get("status") != null) {
                        String contractStatus = jsonNode.get("items").get(i).get("status").asText();
                        if (contractStatus != null)
                            contractsDTO.setContractStatus(contractStatus);
                    }
                    if (jsonNode.get("items").get(i).get("customerId") != null) {
                        int customerId = jsonNode.get("items").get(i).get("customerId").asInt();
                        if (customerId != 0) {
                            contractsDTO.setCustomerId(customerId);
                        }
                    }
                    if (jsonNode.get("items").get(i).get("customerName") != null) {
                        String customerName = jsonNode.get("items").get(i).get("customerName").asText();
                        if (customerName != null)
                            contractsDTO.setCustomerName(customerName);
                    }

                    if (jsonNode.get("items").get(i).get("assetInstanceList") != null) {
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("productionYear") != null) {
                            int productionYear = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("productionYear").asInt();
                            contractsDTO.setProductionYear(productionYear);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("id") != null) {
                            int assetId = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("id").asInt();
                            if (assetId != 0)
                                contractsDTO.setAssetId(assetId);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("serialId") != null) {
                            String serialId = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("serialId").asText();
                            if (serialId != null)
                                contractsDTO.setSerialId(serialId);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("selectedAssetTypeName") != null) {
                            String selectedAssetTypeName = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("selectedAssetTypeName").asText();
                            if (selectedAssetTypeName != null)
                                contractsDTO.setSelectedAssetTypeName(selectedAssetTypeName);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("status") != null) {
                            String assetStatus = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("status").asText();
                            if (assetStatus != null)
                                contractsDTO.setAssetStatus(assetStatus);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("sumInsured") != null) {
                            int sumInsured = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("sumInsured").asInt();
                            if (sumInsured != 0)
                                contractsDTO.setSumInsured(sumInsured);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("road") != null) {
                            String road = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("road").asText();
                            if (road != null)
                                contractsDTO.setRoad(road);

                        }

                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("zipCode") != null) {
                            String zipCode = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("zipCode").asText();
                            if (zipCode != null)
                                contractsDTO.setZipCode(zipCode);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("location") != null) {
                            String location = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("location").asText();
                            if (location != null)
                                contractsDTO.setLocation(location);
                        }
                        if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("country") != null) {
                            String country = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("address").get("country").asText();
                            if (country != null)
                                contractsDTO.setCountry(country);
                        }
                    }

                    if (jsonNode.get("items").get(i).get("billing") != null) {
                        if (jsonNode.get("items").get(i).get("billing").get("billingPeriod") != null) {
                            String billingPeriod = jsonNode.get("items").get(i).get("billing").get("billingPeriod").asText();
                            if (billingPeriod != null)
                                contractsDTO.setBillingPeriod(billingPeriod);
                        }
                    }
                    if (jsonNode.get("items").get(i).get("billing") != null) {
                        if (jsonNode.get("items").get(i).get("billing").get("currency") != null) {
                            String currency = jsonNode.get("items").get(i).get("billing").get("currency").asText();
                            if (currency != null) {
                                contractsDTO.setCurrency(currency);
                            }
                        }
                    }

                    if (jsonNode.get("items").get(i).get("billing") != null) {
                        if (jsonNode.get("items").get(i).get("billing").get("contributionBasis") != null) {
                            int contributionBasis = jsonNode.get("items").get(i).get("billing").get("contributionBasis").asInt();
                            contractsDTO.setContributionBasis(contributionBasis);
                        }
                    }

                    if (jsonNode.get("items").get(i).get("billing") != null) {
                        if (jsonNode.get("items").get(i).get("billing").get("deductible") != null) {
                            int deductible = jsonNode.get("items").get(i).get("billing").get("deductible").asInt();
                            contractsDTO.setDeductible(deductible);
                        }
                    }

                    if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("metricList").get(0).get("selectedMetricName") != null) {
                        String selectedMetricName = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("metricList").get(0).get("selectedMetricName").asText();
                        if (selectedMetricName != null)
                            contractsDTO.setSelectedMetricName(selectedMetricName);
                    }
                    if (jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("metricList").get(0).get("insurancePremiumVariable") != null) {
                        int insurancePremiumVariable = jsonNode.get("items").get(i).get("assetInstanceList").get(0).get("metricList").get(0).get("insurancePremiumVariable").asInt();
                        contractsDTO.setInsurancePremiumVariable(insurancePremiumVariable);
                    }
                    if (jsonNode.get("items").get(i).get("startDate") != null) {
                        String startDate = jsonNode.get("items").get(i).get("startDate").asText();
                        LocalDateTime startDatelocalDateTime = convertToLocalDateTime(startDate);
                        contractsDTO.setStartDate(startDatelocalDateTime);
                    }
                    if (jsonNode.get("items").get(i).get("startDate") != null) {
                        String endDate = jsonNode.get("items").get(i).get("startDate").asText();
                        LocalDateTime endDatelocalDateTime = convertToLocalDateTime(endDate);
                        contractsDTO.setEndDate(endDatelocalDateTime);
                    }
                    getAllContractsQuery.add(contractsDTO);
                }
            }


        } catch (RestClientResponseException ex) {
            log.error("error while getting data from server.... {}", ex.toString());
            throw new ClientException(assetUri != null ? assetUri : "", ex.getRawStatusCode(), ex);
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedEncodingException(e.getMessage());
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return CompletableFuture.completedFuture(getAllContractsQuery);
    }

    private String encodeValue(String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
    }

    private LocalDateTime convertToLocalDateTime(String dateString) throws ConnectException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        try {
            LocalDateTime localDateTime = LocalDateTime.parse(dateString, formatter);
            return localDateTime;
        } catch (Exception e) {
            log.info("Error parsing the String: " + e.getMessage());
            throw new ConnectException("Error parsing the String");
        }
    }

    @Override
    public CompletableFuture<Boolean> updateDDXLoginToken(String uniqueName, AccessDDXToken accessDDXToken, TokenDDX tokenDDX) throws ConnectException, InterruptedException {
        try {
            HashMap<String, String> parameters = new HashMap<>();
            parameters.put("grant_type", grantType);
            parameters.put("scope", scope);
            String form = parameters.keySet().stream()
                    .map(key -> key + "=" + URLEncoder.encode(parameters.get(key), StandardCharsets.UTF_8))
                    .collect(Collectors.joining("&"));

            String encoding = java.util.Base64.getEncoder().encodeToString(clientIdSecret.getBytes());
            HttpClient client = HttpClient.newHttpClient();

            java.net.http.HttpRequest request = java.net.http.HttpRequest.newBuilder().uri(URI.create(tokenUrl))
                    .headers("Content-Type", "application/x-www-form-urlencoded", "Authorization", "Basic " + encoding)
                    .POST(java.net.http.HttpRequest.BodyPublishers.ofString(form)).build();
            HttpResponse<?> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            HttpHeaders headers = new HttpHeaders();
            StringBuilder sb = new StringBuilder();
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response.body().toString());
            if (Constants.BEARER != null) {
                sb.append(Constants.BEARER);
            }
            if (response.body().toString() != null) {
                sb.append(rootNode.get("access_token").textValue());
            }
            if (Constants.AUTH_HEADER != null) {
                headers.add(Constants.AUTH_HEADER, sb.toString());
            }
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(headers);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getTokensUri);
            stringBuilder.append("/companyConfig");
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(stringBuilder.toString())
                    .queryParam("emailAddress", uniqueName);

            Map<String, String> paramsMap = new HashMap<>();

            CompletableFuture<ResponseEntity<JsonNode>> responseEntity = CompletableFuture.completedFuture(restTemplate.exchange(builder.buildAndExpand(paramsMap).toUri(), HttpMethod.GET, httpEntity, JsonNode.class));

            String ddxToken = responseEntity.get().getBody().get("ddxToken").asText();

            String mindspheretoken = responseEntity.get().getBody().get("mindSphereToken").asText();

            log.info("ddxToken: {}", responseEntity.get().getBody().get("ddxToken").asText());
            log.info(MessageFormat.format("mindSphereToken:{0}", responseEntity.get().getBody().get("mindSphereToken").asText()));
            accessDDXToken.setAccessToken(mindspheretoken);
            tokenDDX.setToken(ddxToken);
            return CompletableFuture.completedFuture(true);

        } catch (InterruptedException ex) {
            log.warn("Interrupted in update ddx login token");
            throw new InterruptedException("Interrupted in update ddx login token");
        } catch (Exception e) {
            log.error("Error while creating Public API token: {}", e.getMessage());
            throw new ConnectException("Error while creating ddx token.");
        }
    }

    @Override
    public CompletableFuture<ContractDTO> getContractByID(String uniqueName, Long contractid) throws ExecutionException, InterruptedException, ConnectException {
        ContractDTO response = null;
        try {
            log.info("Into get contact by id");
            HttpHeaders headers = getCommonRequestHeaders(uniqueName).get();
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(headers);
            StringBuilder sb = new StringBuilder();
            sb.append(contractUri);
            sb.append("/");
            sb.append(String.valueOf(contractid));
            CompletableFuture<ResponseEntity<ContractDTO>> responseEntity = CompletableFuture.completedFuture(restTemplate.exchange(sb.toString(), HttpMethod.GET, httpEntity, ContractDTO.class));
            response = responseEntity.get().getBody();
        } catch (RestClientResponseException ex) {
            log.error("error while getting data from server.... {}", ex.toString());
            throw new ClientException(contractUri != null ? contractUri : "", ex.getRawStatusCode(), ex);
        }
        return CompletableFuture.completedFuture(response);
    }

    @Override
    public CompletableFuture<Boolean> getTrue() throws ExecutionException, InterruptedException, ConnectException {
        return CompletableFuture.completedFuture(true);
    }

    @Override
    public CompletableFuture<Boolean> getFalse() throws ExecutionException, InterruptedException, ConnectException {
        return CompletableFuture.completedFuture(false);
    }

    @Override
    public CompletableFuture<DashboardDataDTO> getDashboardData() throws ExecutionException, InterruptedException, ConnectException {
        DashboardDataDTO dashboardData = new DashboardDataDTO();
        try {
            dashboardData.setTotalAssets(24L);
            dashboardData.setInsuredAssets(10L);
            dashboardData.setTobeInsuredAssets(14L);
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return CompletableFuture.completedFuture(dashboardData);
    }

    CompletableFuture<HttpHeaders> getCommonRequestHeaders(String uniqueName) throws ConnectException, ExecutionException, InterruptedException {
        HttpHeaders headers = new HttpHeaders();
        if (this.updateDDXLoginToken(uniqueName, accessDDXToken, tokenDDX).get()) {
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            StringBuilder sb = new StringBuilder();
            if (Constants.BEARER != null) {
                sb.append(Constants.BEARER);
                //  sb.append(accessDDXToken.getAccessToken());
            }
            if (accessDDXToken.getAccessToken() != null) {
                sb.append(accessDDXToken.getAccessToken());
            }
            headers.add(Constants.AUTH_HEADER, sb.toString());
            tokenDDX.setToken(tokenDDX.getToken());
            headers.add(Constants.ASSET_HEADER, tokenDDX.getToken());
        }
        return CompletableFuture.completedFuture(headers);
    }

    @Recover
    public void recover(SQLException e, String sql) {
        log.info("Database is down!");
    }

}
