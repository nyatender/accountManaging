package com.siemens.digitalcockpit.api.config;



import com.siemens.digitalcockpit.application.mappings.ATokenMappings;
import com.siemens.digitalcockpit.application.mappings.BTokenMappings;
import com.siemens.digitalcockpit.application.repositories.IDDXService;
import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import com.siemens.digitalcockpit.application.usecases.command.brokercreate.CreateBrokerCommandHandler;
import com.siemens.digitalcockpit.application.usecases.command.createbrokerforward.CreateBrokerForwardCommandHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getatoken.GetATokenQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getbtoken.GetBTokenQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.GetContractByIdQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetContractsQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getinquiries.GetInquiriesQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getipn.GetIPNQueryHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration

public class ApplicationConfiguration {
    @Bean
    GetContractByIdQueryHandler standardTodosApi5(IDDXService repository) {
        return new GetContractByIdQueryHandler(repository);
    }

    @Bean
    GetContractsQueryHandler standardTodosApi6(IDDXService repository) {
        return new GetContractsQueryHandler(repository);
    }

    @Bean
    CreateBrokerForwardCommandHandler standardTodosApi7(IThinksuranceService repository, IDDXService ddxrepository){
        return new CreateBrokerForwardCommandHandler(repository,ddxrepository);
    }

    @Bean
    GetIPNQueryHandler standardTodosApi8(IThinksuranceService repository){
        return new GetIPNQueryHandler(repository);
    }
    @Bean
    GetInquiriesQueryHandler standardTodosApi(IThinksuranceService repository){
        return new GetInquiriesQueryHandler(repository);
    }

    @Bean
    CreateBrokerCommandHandler standardTodosApi2(IThinksuranceService repository){
        return new CreateBrokerCommandHandler(repository,new BTokenMappings());
    }

    @Bean
    GetATokenQueryHandler standardTodosApi9(IThinksuranceService repository){
        return new GetATokenQueryHandler(repository,new ATokenMappings());
    }
    @Bean
    GetBTokenQueryHandler standardTodosApi10(IThinksuranceService repository){
        return new GetBTokenQueryHandler(repository,new BTokenMappings());
    }
}
