package com.siemens.digitalcockpit.domain.common;

public enum BillingPeriod {
  MONTHLY,
  QUARTERLY,
  SEMIANNUALLY,
  ANNUALLY
}
