package com.siemens.digitalcockpit.application.usecases.queries.getinquiries;


import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import lombok.extern.slf4j.Slf4j;
import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetInquiriesQueryHandler {
    private final IThinksuranceService thinksuranceService;
    public GetInquiriesQueryHandler(IThinksuranceService thinksuranceService) {
        this.thinksuranceService = thinksuranceService;
    }
    public CompletableFuture<String> getInquiries(String uniqueName) throws ConnectException{
        try{
            return this.thinksuranceService.getInquiries(uniqueName);
        } catch (Exception e) {
            log.info(e.getMessage());
            throw new ConnectException("Error in get Inquiries Query handler");
        }
    }
}
