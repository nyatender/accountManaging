package com.siemens.digitalcockpit.application.usecases.queries.getcontracts;


import com.siemens.digitalcockpit.application.repositories.IDDXService;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
@SuppressWarnings("unchecked")
public class GetContractsQueryHandler {
    private final IDDXService userAsyncRepository;
    @Autowired
    public GetContractsQueryHandler(IDDXService userAsyncRepository) {
        this.userAsyncRepository = userAsyncRepository;
    }

    public CompletableFuture<List<ContractsDTO>> readContracts(String uniqueName,int pageSize, int page) throws ConnectException, InterruptedException, UnsupportedEncodingException, ExecutionException {
        try {
            return CompletableFuture.completedFuture(this.userAsyncRepository.getContracts(uniqueName,pageSize,page).get());
        } catch (ExecutionException e) {
            log.info(e.getMessage());
            throw new ExecutionException(e);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in read Contracts ");
            throw new InterruptedException("Interrupted in read Contracts");
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedEncodingException(e.getMessage());
        }
    }

    public CompletableFuture<Boolean> getTrue() throws ConnectException, InterruptedException {
        try {
            return CompletableFuture.completedFuture(this.userAsyncRepository.getTrue().get());
        } catch (InterruptedException ex) {
            log.warn("Interrupted in get true method");
            throw new InterruptedException("Interrupted in get true method");
        } catch (ConnectException | ExecutionException e) {
            throw new ConnectException(e.getMessage());
        }
    }


    public CompletableFuture<Boolean> getFalse() throws ConnectException, InterruptedException, ExecutionException {
        try {
            return CompletableFuture.completedFuture(this.userAsyncRepository.getFalse().get());
        } catch (ExecutionException e) {
            log.info(e.getMessage());
            throw new ExecutionException(e);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in get false");
            throw new InterruptedException("Interrupted in get false");
        }
    }


    public CompletableFuture<DashboardDataDTO> getDashBoardData() throws ConnectException, InterruptedException {
        try {
            return CompletableFuture.completedFuture(this.userAsyncRepository.getDashboardData().get());
        } catch (ConnectException e) {
            log.info(e.getMessage());
            throw new ConnectException(e.getMessage());
        }catch (InterruptedException | ExecutionException ex) {
            log.warn("Interrupted in get dashboard");
            throw new InterruptedException("Interrupted in get dashboard");
        }
    }
}
