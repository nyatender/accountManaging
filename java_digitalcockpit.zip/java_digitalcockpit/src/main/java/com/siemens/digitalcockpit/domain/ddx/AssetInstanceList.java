package com.siemens.digitalcockpit.domain.ddx;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssetInstanceList {
    public int productionYear;

    public int id;
    public String serialId;
    public int selectedAssetTypeId;
    public String selectedAssetTypeName;
    public int sumInsured;
    public int contractId;

    public String status;
    public ArrayList<MetricList> metricList;
    public Address address;
}
