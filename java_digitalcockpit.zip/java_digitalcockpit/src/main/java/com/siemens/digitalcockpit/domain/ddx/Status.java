package com.siemens.digitalcockpit.domain.ddx;

public enum Status {
  INIT,
  DRAFT,
  READY,
  WAITING_APPROVAL,
  APPROVED,
  REJECTED,
  INFRA_PRE,
  INFRA_ERROR,
  READY_FOR_COMMISSIONED,
  COMMISSIONED,
  STARTED,
  EXPIRED;
}
