package com.siemens.digitalcockpit.application.usecases.queries.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.siemens.digitalcockpit.application.exceptions.ExceptionMessage.START_END_DATE_VALIDATION;


@Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidateDatesValidator.class)
public @interface ValidateDatesValidation {
  String message() default START_END_DATE_VALIDATION;

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
