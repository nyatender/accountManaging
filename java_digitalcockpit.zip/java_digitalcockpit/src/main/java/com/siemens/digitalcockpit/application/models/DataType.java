package com.siemens.digitalcockpit.application.models;

public enum DataType {
  INT,
  DOUBLE,
  STRING,
  BOOLEAN,
  TIMESTAMP,
  BIG_STRING,
  LONG
}
