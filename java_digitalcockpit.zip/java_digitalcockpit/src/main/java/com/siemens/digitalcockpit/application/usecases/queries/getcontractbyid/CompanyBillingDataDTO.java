package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class CompanyBillingDataDTO {

  private String invoiceEmail;

  private String shippingMethod;

  private String bankName;

  private String accountName;

  private String iban;

  private String swiftCode;

  private Currency currency;
}
