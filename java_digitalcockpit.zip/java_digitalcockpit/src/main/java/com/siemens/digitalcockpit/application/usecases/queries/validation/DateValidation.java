package com.siemens.digitalcockpit.application.usecases.queries.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/** Validate that the annotated string is in yyyy-MM-ddTHH:mm:ss.SSSZ Date format */
@Target({FIELD, PARAMETER})
@Retention(RUNTIME)
@Constraint(validatedBy = DateValidator.class)
public @interface DateValidation {
  // error message
  String message() default "Invalid Date! Value: must be this format yyyy-MM-ddTHH:mm:ss.SSSZ";
  // represents group of constraints
  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
