package com.siemens.digitalcockpit;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableRetry
@EnableAsync
@EnableWebMvc
@Slf4j
public class DigitalcockpitApplication {
	public static void main(String[] args) {
		SpringApplication.run(DigitalcockpitApplication.class, args);
		log.info("Application Started ....");
	}
}
