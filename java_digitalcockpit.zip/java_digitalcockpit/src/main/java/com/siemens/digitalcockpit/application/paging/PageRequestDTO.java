package com.siemens.digitalcockpit.application.paging;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;


import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PageRequestDTO {
  private static final Integer DEFAULT_PAGE_SIZE = 30;
  private static final Integer DEFAULT_PAGE_NUMBER = 0;

  @Min(0)
  @Builder.Default
  private Integer page = DEFAULT_PAGE_NUMBER;

  @Min(1)
  @Max(1000)
  @Builder.Default
  private Integer pageSize = DEFAULT_PAGE_SIZE;

  @Size(min = 1)
  private String sort;


}
