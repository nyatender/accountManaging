package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;



import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import com.siemens.digitalcockpit.application.usecases.queries.validation.DateValidation;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ValidateDatesValidation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor

@ValidateDatesValidation
@EqualsAndHashCode(callSuper=false)
public class ContractDates extends CompanyDetailResponseDTO {

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @DateValidation
  private String startDate;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @DateValidation
  private String endDate;
}
