package com.siemens.digitalcockpit.application.exceptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationError implements Serializable {
  private static final long serialVersionUID = 1L;
  private String status;
  private String message;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<Notification> fieldErrors = new ArrayList<>();

  @Builder
  public ApplicationError(String status, String message) {
    this.status = status;
    this.message = message;
  }

}
