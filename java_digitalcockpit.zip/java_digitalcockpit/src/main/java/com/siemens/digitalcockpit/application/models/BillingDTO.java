package com.siemens.digitalcockpit.application.models;



import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.Currency;
import com.siemens.digitalcockpit.application.usecases.queries.validation.BillingPeriodValidation;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class BillingDTO {

  private Long id;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @BillingPeriodValidation
  private String billingPeriod;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private String currency = Currency.EUR.toString();

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private BigDecimal contributionBasis;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  private BigDecimal deductible;

  private long contractId;
}
