//package com.siemens.digitalcockpit.infrastructure.persistence;
//
//
//import com.siemens.digitalcockpit.infrastructure.model.MindSphereEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ContractContext extends JpaRepository<MindSphereEntity, Long> {
//
//}
