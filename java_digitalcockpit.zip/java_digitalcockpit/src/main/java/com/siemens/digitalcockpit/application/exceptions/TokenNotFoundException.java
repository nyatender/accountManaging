package com.siemens.digitalcockpit.application.exceptions;

public class TokenNotFoundException extends Exception {

    public TokenNotFoundException(String message) {
        super(message);
    }
}
