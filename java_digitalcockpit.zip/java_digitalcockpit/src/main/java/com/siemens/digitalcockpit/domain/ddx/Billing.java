package com.siemens.digitalcockpit.domain.ddx;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Billing {

    public int id;
    public String billingPeriod;
    public String currency;
    public int contributionBasis;
    public int deductible;
    public int contractId;
}
