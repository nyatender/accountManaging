package com.siemens.digitalcockpit.application.usecases.queries.validation;



import com.siemens.digitalcockpit.domain.common.BillingPeriod;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

public class BillingPeriodValidator
    implements ConstraintValidator<BillingPeriodValidation, String> {
  protected static final List<String> billingPeriodEnumList =
      EnumSet.allOf(BillingPeriod.class).stream()
          .map(BillingPeriod::name)
          .collect(Collectors.toList());

  public boolean isValid(String billingPeriod, ConstraintValidatorContext cxt) {
    return StringUtils.isEmpty(billingPeriod)
        ? true
        : billingPeriodEnumList.contains(billingPeriod);
  }
}
