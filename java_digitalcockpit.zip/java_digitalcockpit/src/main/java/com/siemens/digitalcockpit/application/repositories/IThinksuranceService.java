package com.siemens.digitalcockpit.application.repositories;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.domain.thinksurance.BrokerForward;
import com.siemens.digitalcockpit.domain.thinksurance.TokenThinksurance;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public interface IThinksuranceService {
    public CompletableFuture<Boolean> updateThinksuranceLoginToken(TokenThinksurance tokenThinksurance) throws ConnectException, InterruptedException;
    public CompletableFuture<BrokerForward> createBrokerForward(String request) throws ConnectException, InterruptedException, ExecutionException;
    public CompletableFuture<String> getIPN(String uniqueName) throws ConnectException;
    public CompletableFuture<String> getInquiries(String uniqueName) throws ConnectException;
    public CompletableFuture<JsonNode> getBCodeToken(String uniqueName) throws ConnectException;
    public CompletableFuture<JsonNode> getAToken() throws ConnectException, InterruptedException;
    public CompletableFuture<JsonNode> brokerCreate(String uniqueName) throws ConnectException;
    public CompletableFuture<String> getAccountIPN() throws ConnectException;

}
