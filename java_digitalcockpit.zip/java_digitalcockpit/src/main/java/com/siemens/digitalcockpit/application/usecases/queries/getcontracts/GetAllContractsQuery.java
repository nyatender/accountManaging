package com.siemens.digitalcockpit.application.usecases.queries.getcontracts;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class GetAllContractsQuery {
    public List<ContractsDTO> contractsDTOList;
}
