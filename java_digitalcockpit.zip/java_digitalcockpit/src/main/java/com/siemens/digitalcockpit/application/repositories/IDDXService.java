package com.siemens.digitalcockpit.application.repositories;



import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.ContractsDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetAllContractsQuery;
import com.siemens.digitalcockpit.domain.ddx.AccessDDXToken;
import com.siemens.digitalcockpit.domain.ddx.TokenDDX;

import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public interface IDDXService {
    public CompletableFuture<List<ContractsDTO>> getContracts(String uniqueName,int pageSize, int page) throws ExecutionException, InterruptedException, ConnectException, UnsupportedEncodingException;
    public CompletableFuture<ContractDTO> getContractByID(String uniqueName,Long contractid) throws ExecutionException, InterruptedException, ConnectException;
    public CompletableFuture<Boolean> updateDDXLoginToken(String uniqueName,AccessDDXToken accessDDXToken, TokenDDX tokenDDX) throws ConnectException, InterruptedException;
    public CompletableFuture<Boolean> getTrue() throws ExecutionException, InterruptedException, ConnectException;
    public CompletableFuture<Boolean> getFalse() throws ExecutionException, InterruptedException, ConnectException;
    public CompletableFuture<DashboardDataDTO> getDashboardData() throws ExecutionException, InterruptedException, ConnectException;
}
