package com.siemens.digitalcockpit.domain.ddx;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Address {

    public int id;
    public String road;
    public String zipCode;
    public String location;
    public String country;
    public boolean useCompanyAddress;
    public int assetInstanceId;
}
