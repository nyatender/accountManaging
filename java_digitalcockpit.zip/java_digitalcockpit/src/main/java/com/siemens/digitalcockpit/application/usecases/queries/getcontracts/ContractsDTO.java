package com.siemens.digitalcockpit.application.usecases.queries.getcontracts;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractsDTO {
    public int contractOwnerId;
    @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
    public LocalDateTime startDate;
    @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
    public LocalDateTime endDate;
    public int contractId;
    public String typeNameList;
    public String contractName;
    public String contractStatus;
    public int customerId;
    public String customerName;
    public int productionYear;
    public int assetId;
    public String serialId;
    public String selectedAssetTypeName;
    public String assetStatus;
    public int sumInsured;
    public String road;
    public String zipCode;
    public String location;
    public String country;
    public String billingPeriod;

    public String currency;
    public int contributionBasis;
    public int deductible;
    public String selectedMetricName;
    public int insurancePremiumVariable;
    public String insuranceStatus;
    public String policyId;
    public String tsId;
}
