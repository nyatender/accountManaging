package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.siemens.digitalcockpit.application.repositories.IDDXService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;


import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetContractByIdQueryHandler {
    private final IDDXService userAsyncRepository;
    @Autowired
    public GetContractByIdQueryHandler(IDDXService userAsyncRepository) {
        this.userAsyncRepository = userAsyncRepository;
    }


    public CompletableFuture<ContractDTO> readContractById(String uniqueName,Long id) throws ConnectException, InterruptedException {
        try {
            return CompletableFuture.completedFuture(this.userAsyncRepository.getContractByID(uniqueName,id).get());
        } catch (ConnectException e) {
            log.info(e.getMessage());
            throw new ConnectException(e.getMessage());
        } catch (InterruptedException | ExecutionException ex) {
            log.warn("Interrupted in get contract by Id method");
            throw new InterruptedException("Interrupted in get contract by Id method");
        }
    }
}
