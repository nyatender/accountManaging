package com.siemens.digitalcockpit.application.usecases.queries.validation;

public class ContractValidationGroup {
  // Define validation group to check your DTO validation security with annotation
  public interface OnCreate {}

  public interface OnUpdate {}
}
