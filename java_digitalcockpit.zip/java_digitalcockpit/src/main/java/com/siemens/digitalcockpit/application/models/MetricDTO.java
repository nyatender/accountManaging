package com.siemens.digitalcockpit.application.models;

import lombok.*;


@Getter
@Setter
@ToString
@NoArgsConstructor

public class MetricDTO extends BaseMetricDTO {

}
