package com.siemens.digitalcockpit.domain.thinksurance;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Professions {
    private List<Profession> professionList;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Profession {
        private int id;
        private String name;
    }
}
