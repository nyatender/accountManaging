package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class CompanyDetailResponseDTO {
  private String contactEmail;
  private String companyName;
  private boolean useCompanyAddress;
  private String description;
  private Long contractOwnerId;
  private CompanyAddressDTO companyAddress;
  private CompanyBillingDataDTO companyBillingData;
}
