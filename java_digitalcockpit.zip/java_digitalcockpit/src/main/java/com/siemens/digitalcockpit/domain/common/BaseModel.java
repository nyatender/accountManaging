package com.siemens.digitalcockpit.domain.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class BaseModel implements Serializable {

  @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
  private LocalDateTime creationDate;

  @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
  private LocalDateTime updatedDate;

  private String createdBy;

  private String updatedBy;
}
