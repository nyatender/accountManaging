package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor

@EqualsAndHashCode(callSuper=false)
public class BaseAssetDetailResponseDTO {
  private Long assetId;
  private String name;
  private String manufacturer;
  private String model;
  private String firmwareVersion;
  private int productionYear;
  private String iacCode;
  private String assetType;
  private String uuid;
}
