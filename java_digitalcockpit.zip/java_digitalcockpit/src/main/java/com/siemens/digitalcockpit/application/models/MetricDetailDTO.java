package com.siemens.digitalcockpit.application.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
public class MetricDetailDTO {
  private Long metricId;
  private String script;
  private String description;
  private String name;
  private DataType dataType;
  private boolean optional;
  private String unit;
  private String iotMetricDefinitionDescription;
}
