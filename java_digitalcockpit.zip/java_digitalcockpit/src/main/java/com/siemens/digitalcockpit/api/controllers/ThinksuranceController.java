package com.siemens.digitalcockpit.api.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.siemens.digitalcockpit.application.usecases.command.brokercreate.CreateBrokerCommand;
import com.siemens.digitalcockpit.application.usecases.command.brokercreate.CreateBrokerCommandHandler;

import com.siemens.digitalcockpit.application.usecases.command.createbrokerforward.CreateBrokerForwardCommandHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getatoken.GetATokenQuery;
import com.siemens.digitalcockpit.application.usecases.queries.getatoken.GetATokenQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getbtoken.GetBTokenQuery;
import com.siemens.digitalcockpit.application.usecases.queries.getbtoken.GetBTokenQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getinquiries.GetInquiriesQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getipn.GetIPNQueryHandler;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
@RestController
@RequestMapping("api/v1")
@CrossOrigin(origins = "http://localhost:3001", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@CircuitBreaker(name = "basic_circuit_breaker")
@RateLimiter(name = "basic")
public class ThinksuranceController {
    private final CreateBrokerForwardCommandHandler createBrokerForwardCommandHandler;
    private final GetIPNQueryHandler getIPNQueryHandler;
    private final GetInquiriesQueryHandler getInquiriesQueryHandler;
    private final GetATokenQueryHandler getATokenQueryHandler;
    private final GetBTokenQueryHandler getBTokenQueryHandler;
    private final CreateBrokerCommandHandler createBrokerCommandHandler;

    @Autowired
    public ThinksuranceController(CreateBrokerForwardCommandHandler createBrokerForwardCommandHandler, GetIPNQueryHandler getIPNQueryHandler, GetInquiriesQueryHandler getInquiriesQueryHandler,
                                  GetATokenQueryHandler getATokenQueryHandler, GetBTokenQueryHandler getBTokenQueryHandler, CreateBrokerCommandHandler createBrokerCommandHandler) {
        this.createBrokerForwardCommandHandler = createBrokerForwardCommandHandler;
        this.getIPNQueryHandler = getIPNQueryHandler;
        this.getInquiriesQueryHandler = getInquiriesQueryHandler;
        this.getATokenQueryHandler = getATokenQueryHandler;
        this.getBTokenQueryHandler = getBTokenQueryHandler;
        this.createBrokerCommandHandler = createBrokerCommandHandler;
    }


    @PostMapping(value = "/brokerforward", produces = "application/json")
    @Retryable(value = ConnectException.class, maxAttemptsExpression = "${ddx.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${ddx.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<GetBTokenQuery>> brokerForward(@RequestParam Long contractId, @RequestHeader Map<String, String> headers) throws ConnectException, ExecutionException, InterruptedException, JsonProcessingException {
        CompletableFuture<GetBTokenQuery> response = null;
        //   String uniqueName = "tathagat.kumar3@gmail.com";
        String uniqueName = getUniqueNameFromAccessToken(headers);
        try {
            response = this.createBrokerForwardCommandHandler.createBrokerForward(contractId, uniqueName);
            log.info("Response:{}", response.get());
            if (response != null) {
                return CompletableFuture.completedFuture(new ResponseEntity<>(response.get(), HttpStatus.OK));
            } else
                return CompletableFuture.completedFuture(new ResponseEntity<>(response.get(), HttpStatus.CONFLICT));
        } catch (InterruptedException ex) {
            log.warn("Interrupted in broker forward Controller");
            throw new InterruptedException("Interrupted in broker forward Controller");
        } catch (Exception ex) {
            log.error("Error in broker forward Controller {}", ex.getMessage());
            throw new ConnectException("Error while creating Broker forward" + ex.getMessage() + new ResponseEntity<>(response.get(), HttpStatus.CONFLICT));
        }
    }

    private String getUniqueNameFromAccessToken(Map<String, String> headers) throws JsonProcessingException {
        String accessToken = getAccessToken(headers);
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String[] jwtToken = accessToken.split("\\.");
        String body = new String(decoder.decode(jwtToken[1]));
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(body);
        if (rootNode == null) {
            return null;
        }
        return rootNode.get("unique_name").textValue();
    }

    String getAccessToken(Map<String, String> headers) {
        String bearerToken = headers.get("authorization");
        return bearerToken.substring(7);
    }

    @Recover
    public void recover(SQLException e, String sql) {
        log.info("Database is down!");
    }
}
