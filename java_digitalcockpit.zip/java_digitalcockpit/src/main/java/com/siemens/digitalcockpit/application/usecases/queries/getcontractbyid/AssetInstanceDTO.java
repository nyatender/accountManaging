package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.models.AddressDTO;
import com.siemens.digitalcockpit.application.models.MetricDTO;
import com.siemens.digitalcockpit.application.usecases.queries.validation.ContractValidationGroup;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class AssetInstanceDTO extends BaseAssetInstanceDTO {

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Valid
  private List<MetricDTO> metricList;

  @NotNull(groups = ContractValidationGroup.OnCreate.class)
  @Valid
  private AddressDTO address;
}
