package com.siemens.digitalcockpit.domain.ddx;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MetricList {
    public boolean optional;

    public int id;
    public int selectedMetricId;
    public String selectedMetricName;
    public int insurancePremiumVariable;
    public int assetInstanceId;
}
