package com.siemens.digitalcockpit.application.usecases.queries.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;

@Target({FIELD, PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = BillingPeriodValidator.class)
public @interface BillingPeriodValidation {

  // error message
  public String message() default
      "Invalid billing period! Value: must be  one of the following types: [MONTHLY,QUARTERLY,SEMIANNUALLY,ANNUALLY]";

  // represents group of constraints

  public Class<?>[] groups() default {};

  // represents additional information about annotation

  public Class<? extends Payload>[] payload() default {};
}
