package com.siemens.digitalcockpit.infrastructure.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@NoArgsConstructor
@Getter
@Setter
@Data
public class BaseModel {

  @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
  public LocalDateTime creationDate;


  @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
  public LocalDateTime updatedDate;

  public String createdBy;

  public String updatedBy;
}
