package com.siemens.digitalcockpit.domain.common;



public enum State {
  SAVED,
  VALIDATION,
  PUBLISHED,
  REJECT;

}
