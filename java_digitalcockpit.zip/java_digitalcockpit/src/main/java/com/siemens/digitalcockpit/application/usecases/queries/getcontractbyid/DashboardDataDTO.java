package com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DashboardDataDTO {
    private Long totalAssets;
    private Long insuredAssets;
    private Long tobeInsuredAssets;
}
