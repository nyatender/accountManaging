package com.siemens.digitalcockpit.domain.thinksurance;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@NoArgsConstructor
public class BTokens {
    BToken[] bTokens = new BToken[1];
    @Getter
    @Setter
    @Component
    @NoArgsConstructor
    public static class BToken {
        private String bToken;
        private String bLastName;
        private String bCompany;
    }
}

