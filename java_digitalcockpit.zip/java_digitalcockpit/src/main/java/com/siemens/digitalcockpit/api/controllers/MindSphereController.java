package com.siemens.digitalcockpit.api.controllers;


import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.GetContractByIdQueryHandler;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.ContractsDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetContractsQueryHandler;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
@RestController
@RequestMapping("api/v1")
@CrossOrigin(origins = "http://localhost:3001", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@CircuitBreaker(name = "basic_circuit_breaker")
@RateLimiter(name = "basic")
public class MindSphereController {

    public static final String ERROR_MSG = "Error in fetching response from the server";
    private final GetContractsQueryHandler getContractsQueryHandler;
    private final GetContractByIdQueryHandler getContractByIdQueryHandler;

    @Autowired
    public MindSphereController(GetContractsQueryHandler getContractsQueryHandler,
                                GetContractByIdQueryHandler getContractByIdQueryHandler) {
        this.getContractsQueryHandler = getContractsQueryHandler;
        this.getContractByIdQueryHandler = getContractByIdQueryHandler;
    }

    @GetMapping(value = "/contracts", produces = "application/json")
    @Retryable(value = ConnectException.class, maxAttempts = 5, backoff = @Backoff(delay = 2000))
    @Async
    public CompletableFuture<ResponseEntity<List<ContractsDTO>>> getContract(@RequestParam(required = false) int pageSize, @RequestParam(required = false) int page) throws ConnectException, JsonProcessingException, InterruptedException {
        log.info("Into Get Contract Controller !");
     //   String uniqueName = getUniqueNameFromAccessToken(headers);
        String uniqueName = "tathagat.kumar@siemens.com";
        CompletableFuture<List<ContractsDTO>> response;
        try {
            response = this.getContractsQueryHandler.readContracts(uniqueName,pageSize, page);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in read Contracts ");
            throw new InterruptedException("Interrupted in read Contracts");
        } catch (Exception e) {
            throw new ConnectException("Contract not found {}");
        }
        return response.thenApplyAsync(ResponseEntity.ok()::body);
    }

    @GetMapping(value = "/contracts/{id}", produces = "application/json")
    @Retryable(value = ConnectException.class, maxAttempts = 5, backoff = @Backoff(delay = 2000))
    @Async
    public CompletableFuture<ResponseEntity<ContractDTO>> getContract(@RequestHeader Map<String, String> headers,@PathVariable Long id) throws ConnectException, InterruptedException, JsonProcessingException {
        String uniqueName = getUniqueNameFromAccessToken(headers);
        log.info("Into Get Contract Controller !");
        CompletableFuture<ContractDTO> response;
        try {
            response = this.getContractByIdQueryHandler.readContractById(uniqueName,id);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in read Contracts ");
            throw new InterruptedException("Interrupted in read Contracts");
        } catch (Exception e) {
            throw new ConnectException("Contract not found {}");
        }
        return response.thenApplyAsync(ResponseEntity.ok()::body);
    }


    @GetMapping(value = "/dashboard", produces = "application/json")
    @Retryable(value = ConnectException.class, maxAttemptsExpression = "${ddx.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${ddx.retry.maxAttempts}"))
    public CompletableFuture<ResponseEntity<DashboardDataDTO>> getDashboardData() throws ConnectException, ExecutionException, InterruptedException {
        CompletableFuture<DashboardDataDTO> resp = null;
        try {
            resp = this.getContractsQueryHandler.getDashBoardData();
            if (resp.get() != null)
                return CompletableFuture.completedFuture(new ResponseEntity<>(resp.get(), HttpStatus.OK));
            else
                CompletableFuture.completedFuture(new ResponseEntity<>(ERROR_MSG, HttpStatus.CONFLICT));
        } catch (InterruptedException ex) {
            log.warn("Interrupted in dashboard controller");
            throw new InterruptedException("Interrupted in dashboard controller");
        } catch (Exception e) {
            log.error("Error in getting data from dashboard: {}", e.getMessage());
            throw new ConnectException(e.getMessage() + new ResponseEntity<>(resp.get(), HttpStatus.CONFLICT));
        }
        return CompletableFuture.completedFuture(new ResponseEntity<>(resp.get(), HttpStatus.OK));
    }

    private String getUniqueNameFromAccessToken(Map<String, String> headers) throws JsonProcessingException {
        String accessToken = getAccessToken(headers);
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String[] jwtToken = accessToken.split("\\.");
        String body = new String(decoder.decode(jwtToken[1]));
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(body);
        if (rootNode == null) {
            return null;
        }
        return rootNode.get("unique_name").textValue();
    }

    String getAccessToken(Map<String, String> headers) {
        String bearerToken = headers.get("authorization");
        return bearerToken.substring(7);
    }

    @Recover
    public void recover(SQLException e, String sql) {
        log.info("Database is down!");
    }
}
