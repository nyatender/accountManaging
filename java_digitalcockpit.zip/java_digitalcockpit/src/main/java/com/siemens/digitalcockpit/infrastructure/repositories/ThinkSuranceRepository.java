package com.siemens.digitalcockpit.infrastructure.repositories;


import com.fasterxml.jackson.databind.JsonNode;

import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import com.siemens.digitalcockpit.domain.ddx.Constants;
import com.siemens.digitalcockpit.domain.thinksurance.AToken;
import com.siemens.digitalcockpit.domain.thinksurance.BrokerForward;
import com.siemens.digitalcockpit.domain.thinksurance.TokenThinksurance;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j

public class ThinkSuranceRepository implements IThinksuranceService {
    private @Value("${thinksurance.brokerforward}") String brokerforwarduri;
    private @Value("${thinksurance.hash}") String hash;
    private @Value("${thinksurance.secret}") String secret;
    private @Value("${thinksurance.tokenuri}") String tokenuri;
    private @Value("${thinksurance.uri}") String baseUri;
    private @Value("${ddx.getcontractsuri}") String contractUri;
    private @Value("${thinksurance.getipn}") String getIPNUri;
    private @Value("${thinksurance.getinquiries}") String getInquiriesUri;
    private @Value("${thinksurance.getbtoken}") String getbTokenUri;
    private @Value("${thinksurance.getatoken}") String getaTokenUri;
    private @Value("${thinksurance.getaccountipn}") String getAccountIPNUri;
    private @Value("${thinksurance.getbrokercreate}") String getBrokerCreateUri;
    private final RestTemplate restTemplate;
    private final TokenThinksurance tokenThinksurance;
    @Autowired
    private AToken aToken;

    public ThinkSuranceRepository(RestTemplate restTemplate, TokenThinksurance tokenThinksurance) {
        this.restTemplate = restTemplate;
        this.tokenThinksurance = tokenThinksurance;
    }

    @Override
    public CompletableFuture<Boolean> updateThinksuranceLoginToken(TokenThinksurance tokenThinksurance) throws ConnectException, InterruptedException {
        try {
            MultiValueMap<String, String> valueMap = new LinkedMultiValueMap<>();
            if (Constants.HASH != null && Constants.SECRET != null) {
                valueMap.add(Constants.HASH, decryptPassword(hash).get());
                valueMap.add(Constants.SECRET, decryptPassword(secret).get());
            }
            log.info("hash: {}",decryptPassword(hash).get());
            log.info("secret: {}",decryptPassword(secret).get());
            JsonNode responseToken = this.handleThinksuranceToken(valueMap, tokenuri, JsonNode.class).get();
            tokenThinksurance.setToken(responseToken.get("token").textValue());
            return CompletableFuture.completedFuture(true);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in update thinksurance login token");
            throw new InterruptedException("Interrupted in update thinksurance login token");
        } catch (Exception ex) {
            log.error("Error while creating thinksurance token: {}", ex.getMessage());
            throw new ConnectException("Error while creating thinksurance token.");
        }
    }

    @Override
    @Retryable(value = ConnectException.class, maxAttemptsExpression = "${ddx.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${ddx.retry.maxAttempts}"))
    public CompletableFuture<BrokerForward> createBrokerForward(String request) throws ConnectException, InterruptedException, ExecutionException {
        try {
            log.info("Into Broker forward");
            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(brokerforwarduri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(request, sb.toString(), BrokerForward.class)).get();
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException ex) {
            log.warn("Interrupted in create broker forward");
            throw new InterruptedException("Interrupted in create broker forward");
        } catch (Exception ex) {
            throw new ConnectException("Error while connecting to backend" + ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<String> getIPN(String uniqueName) throws ConnectException {
        try {
            log.info("Into Get IPN");
            MultiValueMap<String, String> valueMap = new LinkedMultiValueMap<>();
            JsonNode jsonNode = this.getBCodeToken(uniqueName).get();
            String bToken = String.valueOf(jsonNode.get("bToken").textValue());
            valueMap.add(Constants.BTOKEN, bToken);
            valueMap.add(Constants.I_ID, Constants.I_ID_VALUE);
            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getIPNUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(valueMap, sb.toString(), String.class).get());
        } catch (Exception ex) {
            throw new ConnectException("Error while connecting to backend" + ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<String> getInquiries(String uniqueName) throws ConnectException {
        try {
            log.info("Into Get Inquiries");
            MultiValueMap<String, String> valueMap = new LinkedMultiValueMap<>();
            JsonNode jsonNode = this.getBCodeToken(uniqueName).get();
            String bToken = String.valueOf(jsonNode.get("bToken").textValue());
            valueMap.add(Constants.BTOKEN, bToken);
            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getInquiriesUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(valueMap, sb.toString(), String.class).get());
        } catch (Exception ex) {
            throw new ConnectException("Error while connecting to backend" + ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<JsonNode> getBCodeToken(String uniqueName) throws ConnectException {
        try{
            log.info("Into get B token");
            Map<String,String> valueMap = new HashMap<>();
            JsonNode jsonNode = this.getAToken().get();

            String aToken1 = jsonNode.get(0).get("aToken").asText();
            valueMap.put(Constants.ATOKEN, aToken1);
            valueMap.put(Constants.TYPE, "1");
            valueMap.put(Constants.BEXTERNALID,uniqueName);
            valueMap.put(Constants.BLASTNAME, Constants.BLASTNAME_VAL);
            valueMap.put(Constants.BEMAIL,uniqueName);
            valueMap.put(Constants.BCOMPANY,Constants.BCOMPANY_VAL);
            valueMap.put(Constants.BGENDER, "1");
            valueMap.put(Constants.BSTREET,Constants.BSTREET_VAL);
            valueMap.put(Constants.BFIRST_NAME,Constants.BFIRST_NAME_VAL);
            valueMap.put(Constants.BSTREET_NUM,Constants.BSTREET_NUM_VAL);
            valueMap.put(Constants.BZIP,Constants.BZIP_VAL);
            valueMap.put(Constants.BCITY,Constants.BCITY_VAL);
            valueMap.put(Constants.BPHONE,Constants.BPHONE_VAL);
            valueMap.put(Constants.B_COMPANY_REG,Constants.B_COMPANY_REG_VAL);
            valueMap.put(Constants.B_REG_NUMBER,Constants.B_REG_NUMBER_VAL);
            log.info(valueMap.toString());
            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getbTokenUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(valueMap, sb.toString(), JsonNode.class).get());
        } catch (Exception ex) {
            throw new ConnectException("Error while connecting to backend" + ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<JsonNode> getAToken() throws ConnectException {
        try {
            log.info("Into get A token");
            MultiValueMap<String, Object> valueMap = new LinkedMultiValueMap<>();
            valueMap.add("","");
            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getaTokenUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            CompletableFuture<JsonNode> node = this.handleGetEntity(valueMap, sb.toString(), JsonNode.class);
            AToken aToken = new AToken();
            aToken.setAToken(String.valueOf(node.get().get(0).get("aToken").textValue()));
            aToken.setName(String.valueOf(node.get().get(0).get("name").textValue()));
            return CompletableFuture.completedFuture(node.get());
        } catch (Exception ex) {
            throw new ConnectException("Error while connecting to backend" + ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<JsonNode> brokerCreate(String uniqueName) throws ConnectException {

        try{
            log.info("Into Broker Create");
            Map<String,Object> valueMap = new HashMap<>();
            JsonNode jsonNode = this.getAToken().get();
            String aTokenBrokerCreate = jsonNode.get(0).get("aToken").asText();
            valueMap.put(Constants.ATOKEN, aTokenBrokerCreate);
            valueMap.put(Constants.TYPE,1);
            valueMap.put(Constants.BEXTERNALID,uniqueName);
            valueMap.put(Constants.BLASTNAME, Constants.BLASTNAME_VAL);
            valueMap.put(Constants.BEMAIL,uniqueName);
            valueMap.put(Constants.BCOMPANY,Constants.BCOMPANY_VAL);
            valueMap.put(Constants.BGENDER,1);
            valueMap.put(Constants.BSTREET,Constants.BSTREET_VAL);
            valueMap.put(Constants.BFIRST_NAME,Constants.BFIRST_NAME_VAL);
            valueMap.put(Constants.BSTREET_NUM,Constants.BSTREET_NUM_VAL);
            valueMap.put(Constants.BZIP,Constants.BZIP_VAL);
            valueMap.put(Constants.BCITY,Constants.BCITY_VAL);
            valueMap.put(Constants.BPHONE,Constants.BPHONE_VAL);
            valueMap.put(Constants.B_COMPANY_REG,Constants.B_COMPANY_REG_VAL);
            valueMap.put(Constants.B_REG_NUMBER,Constants.B_REG_NUMBER_VAL);

            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getBrokerCreateUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(valueMap, sb.toString(), JsonNode.class).get());

        } catch (Exception e) {
            log.error(e.getMessage());
            throw new ConnectException();
        }

    }

    @Override
    public CompletableFuture<String> getAccountIPN() throws ConnectException {
        try{
            log.info("Into Broker Create");
            MultiValueMap<String, Object> valueMap = new LinkedMultiValueMap<>();
            valueMap.add(Constants.LAST_DAYS,13);
            valueMap.add(Constants.ATOKEN, Constants.ATOKEN_VAL);

            this.updateThinksuranceLoginToken(tokenThinksurance);
            StringBuilder sb = new StringBuilder();
            sb.append(getAccountIPNUri);
            if (tokenThinksurance != null) {
                sb.append(tokenThinksurance.getToken());
            }
            return CompletableFuture.completedFuture(this.handlePostEntity(valueMap, sb.toString(), String.class).get());
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new ConnectException();
        }
    }

    public <R, T> CompletableFuture<T> handleThinksuranceToken(R request, String uri, Class<T> responseType) throws InterruptedException {
        T response = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<R> httpEntity = new HttpEntity<>(request, headers);
            String fullUrl = null;
                fullUrl = this.buildURI(uri).get();
                CompletableFuture<ResponseEntity<T>> responseEntity = CompletableFuture.completedFuture(restTemplate.postForEntity(fullUrl, httpEntity, responseType));
                response = responseEntity.get().getBody();
        } catch (Exception ex) {
            log.warn("Interrupted in handle thinksurance token");
            throw new InterruptedException("Interrupted in handle thinksurance token");
        }
        return CompletableFuture.completedFuture(response);
    }

    public <R, T> CompletableFuture<T> handlePostEntity(R request, String uri, Class<T> responseType) throws ExecutionException, InterruptedException, ConnectException {
        T response = null;
        try {
            HttpHeaders headers = this.getCommonRequestHeaders().get();
            HttpEntity<R> httpEntity = new HttpEntity<>(request, headers);
            String fullUrl = null;

                fullUrl = this.buildURI(uri).get();
                CompletableFuture<ResponseEntity<T>> responseEntity = null;
                log.info(fullUrl);
                if (fullUrl != null) {
                    responseEntity = CompletableFuture.completedFuture(this.restTemplate.postForEntity(fullUrl, httpEntity, responseType));
                }
                if (responseEntity.get().getStatusCode().value() == 200) {
                    response = responseEntity.get().getBody();
                } else {
                    log.error("Message not posted to Cache");
                }
        } catch (ExecutionException | ConnectException e) {
            log.error(e.getMessage());
            throw new ConnectException(e.getMessage());
        }
        return CompletableFuture.completedFuture(response);
    }

    public <R, T> CompletableFuture<T> handleGetEntity(R request, String uri, Class<T> responseType) throws InterruptedException, ConnectException {
        T response = null;
        try {
            HttpHeaders headers = this.getCommonRequestHeaders().get();
            HttpEntity<R> httpEntity = new HttpEntity<>(request, headers);
            String fullUrl = null;

            fullUrl = this.buildURI(uri).get();
            CompletableFuture<ResponseEntity<T>> responseEntity = null;
            CompletableFuture<ResponseEntity<T>> responseEntity1 = null;
            log.info(fullUrl);
            if (fullUrl != null) {
                responseEntity1 = CompletableFuture.completedFuture(this.restTemplate.getForEntity(fullUrl,responseType));
               // responseEntity = CompletableFuture.completedFuture(this.restTemplate.exchange(fullUrl,HttpMethod.GET, httpEntity, responseType));
            }
            if (responseEntity1.get().getStatusCode().value() == 200) {
                response = responseEntity1.get().getBody();
            } else {
                log.error("Message not posted to Cache");
            }
        } catch (ExecutionException | ConnectException e) {
            log.error(e.getMessage());
            throw new ConnectException(e.getMessage());
        }
        return CompletableFuture.completedFuture(response);
    }

    CompletableFuture<String> buildURI(String apiPath) throws ConnectException {
        try {
            StringBuilder builder = new StringBuilder();
            if (baseUri != null && apiPath != null) {
                builder.append(baseUri);
                builder.append(apiPath);
            }
            return CompletableFuture.completedFuture(builder.toString());
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ConnectException("Error in ddx header.");
        }
    }

    public CompletableFuture<HttpHeaders> getCommonRequestHeaders() throws ConnectException {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            return CompletableFuture.completedFuture(headers);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new ConnectException();
        }
    }

    CompletableFuture<String> decryptPassword(String value) throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] actualPassword = null;

        try {
            IvParameterSpec iv = new IvParameterSpec(Constants.INIT_VECTOR_KEY.getBytes(StandardCharsets.UTF_8));
            SecretKeySpec keySpec = new SecretKeySpec(Constants.ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8), Constants.AES);
            Cipher cipher = Cipher.getInstance(Constants.ENCODING_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, iv);
            actualPassword = cipher.doFinal(Base64.decodeBase64(value));
        } catch (InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException |
                 BadPaddingException e1) {
            log.error("exception in catch1: {}", e1.toString());
        } catch (NoSuchPaddingException e2) {
            log.error("exception in catch2: {}", e2.toString());
        } catch (NoSuchAlgorithmException e3) {
            log.error("exception in catch3: {}", e3.toString());
        }
        return CompletableFuture.completedFuture(new String(actualPassword));
    }
}
