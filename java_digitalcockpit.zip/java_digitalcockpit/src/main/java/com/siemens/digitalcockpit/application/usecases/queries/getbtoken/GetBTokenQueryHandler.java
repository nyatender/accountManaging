package com.siemens.digitalcockpit.application.usecases.queries.getbtoken;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.application.mappings.BTokenMappings;
import com.siemens.digitalcockpit.application.repositories.IThinksuranceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetBTokenQueryHandler {
    private final IThinksuranceService thinksuranceService;
    private final BTokenMappings bTokenMappings;
    @Autowired
    public GetBTokenQueryHandler(IThinksuranceService thinksuranceService,BTokenMappings bTokenMappings) {
        this.thinksuranceService = thinksuranceService;
        this.bTokenMappings = bTokenMappings;
    }
    public CompletableFuture<GetBTokenQuery> getBToken(String uniqueName) throws ConnectException {
        try {
            CompletableFuture<JsonNode> bToken = this.thinksuranceService.getBCodeToken(uniqueName);
            CompletableFuture<GetBTokenQuery> getBTokenQuery = bTokenMappings.mapToBTokenQuery(bToken.get());
            return getBTokenQuery;
        } catch (Exception e) {
            log.info(e.getMessage());
            throw new ConnectException("Error in get get BToken Query handler");
        }
    }
}
