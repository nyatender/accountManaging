package com.siemens.digitalcockpit.application.models;

public enum AssetInstanceStatus {
  CONNECTED,
  NOT_CONNECTED
}
