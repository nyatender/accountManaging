package com.siemens.digitalcockpit.application.mappings;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.digitalcockpit.application.exceptions.TokenNotFoundException;
import com.siemens.digitalcockpit.application.usecases.queries.getatoken.GetATokenQuery;
import com.siemens.digitalcockpit.domain.thinksurance.AToken;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.CompletableFuture;

@Slf4j
public class ATokenMappings {
    public CompletableFuture<GetATokenQuery> mapToATokenQuery(JsonNode aToken) throws TokenNotFoundException {
        try {
            if (aToken == null) {
                return null;
            }
           // AToken aToken1 = new AToken();
            GetATokenQuery getATokenQuery = new GetATokenQuery();
            getATokenQuery.setAToken(String.valueOf(aToken.get(0).get("aToken").textValue()));
            getATokenQuery.setName(String.valueOf(aToken.get(0).get("name").textValue()));
            return CompletableFuture.completedFuture(getATokenQuery);
        } catch (Exception e) {
            log.info("Error in BToken Mapping");
            throw new TokenNotFoundException("Error in BToken Mapping");
        }
    }
}
