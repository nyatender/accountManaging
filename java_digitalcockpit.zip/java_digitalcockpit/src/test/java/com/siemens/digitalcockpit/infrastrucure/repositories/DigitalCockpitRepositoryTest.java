package com.siemens.digitalcockpit.infrastrucure.repositories;

//import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
//import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.ContractsDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetAllContractsQuery;
import com.siemens.digitalcockpit.domain.ddx.AccessDDXToken;
import com.siemens.digitalcockpit.domain.ddx.TokenDDX;
//import com.siemens.digitalcockpit.infrastructure.persistence.ContractContext;
import com.siemens.digitalcockpit.infrastructure.repositories.DigitalCockpitRepository;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestTemplate;


//
//import static jdk.internal.org.jline.reader.impl.LineReaderImpl.CompletionType.List;


class DigitalCockpitRepositoryTest {
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private AccessDDXToken accessDDXToken;
    @Mock
    private TokenDDX tokenDDX;
//    @Mock
//    private ContractContext assetRepository;

    @Mock
    private GetAllContractsQuery getAllContractsQuery;

    @InjectMocks
    private DigitalCockpitRepository digitalCockpitRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }



//    @Test
//     void testGetTrue() throws ConnectException, InterruptedException, ExecutionException {
//        DigitalCockpitRepository repository = new DigitalCockpitRepository(accessDDXToken, tokenDDX, restTemplate,List< ContractsDTO >);
//
//        CompletableFuture<Boolean> result = repository.getTrue();
//        Assertions.assertTrue(result.get());
//    }
//
//    @Test
//     void testGetFalse() throws ConnectException, InterruptedException, ExecutionException {
//        DigitalCockpitRepository repository = new DigitalCockpitRepository(accessDDXToken, tokenDDX, restTemplate,getAllContractsQuery);
//
//        CompletableFuture<Boolean> result = repository.getFalse();
//        Assertions.assertFalse(result.get());
//    }
//
//    @Test
//     void testGetDashboardData() throws ConnectException, InterruptedException, ExecutionException {
//        DigitalCockpitRepository repository = new DigitalCockpitRepository(accessDDXToken, tokenDDX, restTemplate, getAllContractsQuery);
//
//        CompletableFuture<DashboardDataDTO> result = repository.getDashboardData();
//        DashboardDataDTO dashboardData = result.get();
//        Assertions.assertEquals(24L, dashboardData.getTotalAssets());
//        Assertions.assertEquals(10L, dashboardData.getInsuredAssets());
//        Assertions.assertEquals(14L, dashboardData.getTobeInsuredAssets());
//    }
}