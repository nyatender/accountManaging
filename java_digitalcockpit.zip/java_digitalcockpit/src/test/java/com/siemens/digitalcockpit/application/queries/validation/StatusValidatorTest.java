//package com.siemens.digitalcockpit.application.queries.validation;
//
//
//import com.siemens.digitalcockpit.application.usecases.queries.validation.StatusValidator;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import javax.validation.ConstraintValidatorContext;
//import java.util.Arrays;
//import java.util.List;
//
// class StatusValidatorTest {
//    private StatusValidator validator;
//
//    @Mock
//    private ConstraintValidatorContext context;
//
//    @BeforeEach
//     void setup() {
//        MockitoAnnotations.initMocks(this);
//        validator = new StatusValidator();
//    }
//
//    @Test
//     void testValidStatus() {
//        String status = "READY";
//
//        boolean isValid = validator.isValid(status, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testInvalidStatus() {
//        String status = "INVALID";
//
//        boolean isValid = validator.isValid(status, context);
//
//        Assertions.assertFalse(isValid);
//    }
//
//    @Test
//     void testNullStatus() {
//        String status = "READY";
//
//        boolean isValid = validator.isValid(status, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testEmptyStatus() {
//        String status = "";
//
//        boolean isValid = validator.isValid(status, context);
//
//        Assertions.assertFalse(isValid);
//    }
//
//    @Test
//     void testMultipleStatuses() {
//        List<String> statuses = Arrays.asList("INIT", "DRAFT", "READY");
//
//        for (String status : statuses) {
//            boolean isValid = validator.isValid(status, context);
//            Assertions.assertTrue(isValid);
//        }
//    }
//}