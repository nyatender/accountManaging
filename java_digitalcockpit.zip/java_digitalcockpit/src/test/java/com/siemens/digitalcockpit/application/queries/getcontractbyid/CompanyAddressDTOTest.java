package com.siemens.digitalcockpit.application.queries.getcontractbyid;

import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyAddressDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

 class CompanyAddressDTOTest {
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = validatorFactory.getValidator();

    @Test
     void testGettersAndSetters() {
        String road = "Example Road";
        String zipCode = "12345";
        String city = "Example City";
        String country = "Example Country";
        String postalCountry = "Postal Country";
        String postalCity = "Postal City";
        String postalRoad = "Postal Road";
        String postalZipCode = "54321";

        CompanyAddressDTO dto = new CompanyAddressDTO();
        dto.setRoad(road);
        dto.setZipCode(zipCode);
        dto.setCity(city);
        dto.setCountry(country);
        dto.setPostalCountry(postalCountry);
        dto.setPostalCity(postalCity);
        dto.setPostalRoad(postalRoad);
        dto.setPostalZipCode(postalZipCode);

        Assertions.assertEquals(road, dto.getRoad());
        Assertions.assertEquals(zipCode, dto.getZipCode());
        Assertions.assertEquals(city, dto.getCity());
        Assertions.assertEquals(country, dto.getCountry());
        Assertions.assertEquals(postalCountry, dto.getPostalCountry());
        Assertions.assertEquals(postalCity, dto.getPostalCity());
        Assertions.assertEquals(postalRoad, dto.getPostalRoad());
        Assertions.assertEquals(postalZipCode, dto.getPostalZipCode());
    }

    @Test
     void testEqualsAndHashCode() {
        CompanyAddressDTO dto1 = new CompanyAddressDTO();
        dto1.setRoad("Example Road");

        CompanyAddressDTO dto2 = new CompanyAddressDTO();
        dto2.setRoad("Example Road");

        CompanyAddressDTO dto3 = new CompanyAddressDTO();
        dto3.setRoad("Another Road");

        Assertions.assertEquals(dto1, dto2);
        Assertions.assertNotEquals(dto1, dto3);

        Assertions.assertEquals(dto1.hashCode(), dto2.hashCode());
        Assertions.assertNotEquals(dto1.hashCode(), dto3.hashCode());
    }

    @Test
     void testValidation() {
        CompanyAddressDTO dto = new CompanyAddressDTO();

        Set<ConstraintViolation<CompanyAddressDTO>> violations = validator.validate(dto);

        Assertions.assertEquals(8, violations.size());
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("road")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("zipCode")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("city")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("country")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("postalCountry")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("postalCity")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("postalRoad")));
        Assertions.assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("postalZipCode")));
    }

}