package com.siemens.digitalcockpit.application.queries.getcontractbyid;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

class ContractDTOTest {

    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = validatorFactory.getValidator();

//    @Test
//     void testGettersAndSetters() {
//        Long contractOwnerId = 123L;
//        String contractName = "Contract Name";
//        List<AssetInstanceDTO> assetInstanceList = new ArrayList<>();
//        BillingDTO billing = new BillingDTO();
//
//        ContractDTO dto = new ContractDTO();
//        dto.setContractOwnerId(contractOwnerId);
//        dto.setAssetInstanceList(assetInstanceList);
//        dto.setBilling(billing);
//
//
//        Assertions.assertEquals(contractOwnerId, dto.getContractOwnerId());
//        Assertions.assertEquals(contractName, dto.getCustomerName());
//        Assertions.assertEquals(assetInstanceList, dto.getAssetInstanceList());
//        Assertions.assertEquals(billing, dto.getBilling());
//    }

//    @Test
//     void testEqualsAndHashCode() {
//        ContractDTO dto1 = new ContractDTO();
//                dto1.setContractOwnerId(123L);
//
//
//        ContractDTO dto2 = new ContractDTO();
//        dto2.setContractOwnerId(123L);
//
//        ContractDTO dto3 = new ContractDTO();
//        dto3.setContractOwnerId(456L);
//
//        Assertions.assertEquals(dto1, dto2);
//        Assertions.assertNotEquals(dto1, dto3);
//
//        Assertions.assertEquals(dto1.hashCode(), dto2.hashCode());
//        Assertions.assertNotEquals(dto1.hashCode(), dto3.hashCode());
//    }

}