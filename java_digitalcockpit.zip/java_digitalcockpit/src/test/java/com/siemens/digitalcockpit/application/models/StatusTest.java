package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

 class StatusTest {


    @Test
     void testInitStatus() {
        Status status = Status.INIT;
        assertEquals("INIT", status.name());
        assertEquals(0, status.ordinal());
    }

    @Test
     void testDraftStatus() {
        Status status = Status.DRAFT;
        assertEquals("DRAFT", status.name());
        assertEquals(1, status.ordinal());
    }

    @Test
     void testReadyStatus() {
        Status status = Status.READY;
        assertEquals("READY", status.name());
        assertEquals(2, status.ordinal());
    }

    @Test
     void testWaitingApprovalStatus() {
        Status status = Status.WAITING_APPROVAL;
        assertEquals("WAITING_APPROVAL", status.name());
        assertEquals(3, status.ordinal());
    }

    @Test
     void testApprovedStatus() {
        Status status = Status.APPROVED;
        assertEquals("APPROVED", status.name());
        assertEquals(4, status.ordinal());
    }

    @Test
     void testRejectedStatus() {
        Status status = Status.REJECTED;
        assertEquals("REJECTED", status.name());
        assertEquals(5, status.ordinal());
    }

    @Test
     void testInfraPreStatus() {
        Status status = Status.INFRA_PRE;
        assertEquals("INFRA_PRE", status.name());
        assertEquals(6, status.ordinal());
    }

    @Test
     void testInfraErrorStatus() {
        Status status = Status.INFRA_ERROR;
        assertEquals("INFRA_ERROR", status.name());
        assertEquals(7, status.ordinal());
    }

    @Test
     void testReadyForCommissionedStatus() {
        Status status = Status.READY_FOR_COMMISSIONED;
        assertEquals("READY_FOR_COMMISSIONED", status.name());
        assertEquals(8, status.ordinal());
    }

    @Test
     void testCommissionedStatus() {
        Status status = Status.COMMISSIONED;
        assertEquals("COMMISSIONED", status.name());
        assertEquals(9, status.ordinal());
    }

    @Test
     void testStartedStatus() {
        Status status = Status.STARTED;
        assertEquals("STARTED", status.name());
        assertEquals(10, status.ordinal());
    }

    @Test
     void testExpiredStatus() {
        Status status = Status.EXPIRED;
        assertEquals("EXPIRED", status.name());
        assertEquals(11, status.ordinal());
    }
}