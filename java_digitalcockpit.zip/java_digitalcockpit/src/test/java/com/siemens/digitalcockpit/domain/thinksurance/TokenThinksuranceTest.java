package com.siemens.digitalcockpit.domain.thinksurance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TokenThinksuranceTest {
    private TokenThinksurance tokenThinksurance;
    @BeforeEach
    void setUp() {
        tokenThinksurance = new TokenThinksurance();
    }

    @Test
     void testTokenGetterAndSetter() {
        String expectedToken = "myToken";
        tokenThinksurance.setToken(expectedToken);
        assertEquals(expectedToken, tokenThinksurance.getToken());
    }

    @Test
     void testTokenAllArgsConstructor() {
        String expectedToken = "myToken";
        LocalDateTime expectedExpired = LocalDateTime.now();

        tokenThinksurance = new TokenThinksurance(expectedToken, expectedExpired);
        assertEquals(expectedToken, tokenThinksurance.getToken());
        assertEquals(expectedExpired, tokenThinksurance.getExpired());
    }

    @Test
     void testTokenNoArgsConstructor() {
        assertNotNull(new TokenThinksurance());
    }


}