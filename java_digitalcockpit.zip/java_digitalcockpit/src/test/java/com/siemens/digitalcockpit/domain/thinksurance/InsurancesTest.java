package com.siemens.digitalcockpit.domain.thinksurance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class InsurancesTest {
    private Insurances insurances;
    @BeforeEach
    void setUp() {
        insurances = new Insurances();
    }

    @Test
     void testInsurancesGetterAndSetter() {
        List<Insurances.Insurance> expectedInsuranceList = new ArrayList<>();
        insurances.setInsuranceList(expectedInsuranceList);
        assertEquals(expectedInsuranceList, insurances.getInsuranceList());
    }

    @Test
     void testInsurancesAllArgsConstructor() {
        List<Insurances.Insurance> expectedInsuranceList = new ArrayList<>();
        expectedInsuranceList.add(new Insurances.Insurance(1, "Insurance 1", "BAFIN1"));
        expectedInsuranceList.add(new Insurances.Insurance(2, "Insurance 2", "BAFIN2"));

        insurances = new Insurances(expectedInsuranceList);
        assertEquals(expectedInsuranceList, insurances.getInsuranceList());
    }

    @Test
     void testInsurancesNoArgsConstructor() {
        assertNotNull(new Insurances());
    }

    @Test
     void testInsuranceGetterAndSetter() {
        int expectedId = 1;
        String expectedName = "Insurance";
        String expectedBafin = "BAFIN";
        Insurances.Insurance insurance = new Insurances.Insurance();

        insurance.setId(expectedId);
        insurance.setName(expectedName);
        insurance.setBafin(expectedBafin);

        assertEquals(expectedId, insurance.getId());
        assertEquals(expectedName, insurance.getName());
        assertEquals(expectedBafin, insurance.getBafin());
    }

    @Test
     void testInsuranceAllArgsConstructor() {
        int expectedId = 1;
        String expectedName = "Insurance";
        String expectedBafin = "BAFIN";

        Insurances.Insurance insurance = new Insurances.Insurance(expectedId, expectedName, expectedBafin);

        assertEquals(expectedId, insurance.getId());
        assertEquals(expectedName, insurance.getName());
        assertEquals(expectedBafin, insurance.getBafin());
    }

    @Test
     void testInsuranceNoArgsConstructor() {
        assertNotNull(new Insurances.Insurance());
    }

}