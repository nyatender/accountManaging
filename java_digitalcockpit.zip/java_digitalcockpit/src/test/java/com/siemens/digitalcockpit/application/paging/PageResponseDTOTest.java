//package com.siemens.digitalcockpit.application.paging;
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//
//import java.util.Arrays;
//import java.util.List;
//
// class PageResponseDTOTest {
//    @Test
//     void testPageResponseDTO() {
//        List<String> items = Arrays.asList("item1", "item2", "item3");
//        int page = 0;
//        int pageSize = 10;
//        int totalPages = 1;
//        long totalElements = 3;
//        boolean hasNext = false;
//        boolean hasPrevious = false;
//
//        Page<String> pageResult = new PageImpl<>(items, PageRequest.of(page, pageSize), totalElements);
//
//        PageResponseDTO<String> pageResponseDTO = PageResponseDTO.of(pageResult);
//
//        Assertions.assertEquals(items, pageResponseDTO.getItems());
//        Assertions.assertEquals(page, pageResponseDTO.getPage());
//        Assertions.assertEquals(pageSize, pageResponseDTO.getPageSize());
//        Assertions.assertEquals(totalPages, pageResponseDTO.getTotalPages());
//        Assertions.assertEquals(totalElements, pageResponseDTO.getTotalElements());
//        Assertions.assertEquals(hasNext, pageResponseDTO.isHasNext());
//        Assertions.assertEquals(hasPrevious, pageResponseDTO.isHasPrevious());
//    }
//}