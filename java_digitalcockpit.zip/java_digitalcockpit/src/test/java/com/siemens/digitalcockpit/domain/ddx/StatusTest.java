package com.siemens.digitalcockpit.domain.ddx;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

class StatusTest {

    @Test
     void testInitEnum() {
        Status status = Status.INIT;
        assertNotNull(status);
        assertEquals("INIT", status.name());
        assertEquals(0, status.ordinal());
    }

    @Test
     void testDraftEnum() {
        Status status = Status.DRAFT;
        assertNotNull(status);
        assertEquals("DRAFT", status.name());
        assertEquals(1, status.ordinal());
    }

    @Test
     void testReadyEnum() {
        Status status = Status.READY;
        assertNotNull(status);
        assertEquals("READY", status.name());
        assertEquals(2, status.ordinal());
    }

    @Test
     void testWaitingApprovalEnum() {
        Status status = Status.WAITING_APPROVAL;
        assertNotNull(status);
        assertEquals("WAITING_APPROVAL", status.name());
        assertEquals(3, status.ordinal());
    }

    @Test
     void testApprovedEnum() {
        Status status = Status.APPROVED;
        assertNotNull(status);
        assertEquals("APPROVED", status.name());
        assertEquals(4, status.ordinal());
    }

    @Test
     void testRejectedEnum() {
        Status status = Status.REJECTED;
        assertNotNull(status);
        assertEquals("REJECTED", status.name());
        assertEquals(5, status.ordinal());
    }

    @Test
     void testInfraPreEnum() {
        Status status = Status.INFRA_PRE;
        assertNotNull(status);
        assertEquals("INFRA_PRE", status.name());
        assertEquals(6, status.ordinal());
    }

    @Test
     void testInfraErrorEnum() {
        Status status = Status.INFRA_ERROR;
        assertNotNull(status);
        assertEquals("INFRA_ERROR", status.name());
        assertEquals(7, status.ordinal());
    }

    @Test
     void testReadyForCommissionedEnum() {
        Status status = Status.READY_FOR_COMMISSIONED;
        assertNotNull(status);
        assertEquals("READY_FOR_COMMISSIONED", status.name());
        assertEquals(8, status.ordinal());
    }

    @Test
     void testCommissionedEnum() {
        Status status = Status.COMMISSIONED;
        assertNotNull(status);
        assertEquals("COMMISSIONED", status.name());
        assertEquals(9, status.ordinal());
    }

    @Test
     void testStartedEnum() {
        Status status = Status.STARTED;
        assertNotNull(status);
        assertEquals("STARTED", status.name());
        assertEquals(10, status.ordinal());
    }

    @Test
     void testExpiredEnum() {
        Status status = Status.EXPIRED;
        assertNotNull(status);
        assertEquals("EXPIRED", status.name());
        assertEquals(11, status.ordinal());
    }
}