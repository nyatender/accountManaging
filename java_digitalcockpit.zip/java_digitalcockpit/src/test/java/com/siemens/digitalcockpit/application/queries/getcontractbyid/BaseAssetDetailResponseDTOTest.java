package com.siemens.digitalcockpit.application.queries.getcontractbyid;

import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.BaseAssetDetailResponseDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


 class BaseAssetDetailResponseDTOTest {
    @Test
     void testGettersAndSetters() {
        Long assetId = 123L;
        String name = "Asset Name";
        String manufacturer = "Manufacturer";
        String model = "Model";
        String firmwareVersion = "1.0";
        int productionYear = 2022;
        String iacCode = "ABC123";
        String assetType = "Asset Type";
        String uuid = "UUID123";

        BaseAssetDetailResponseDTO dto = new BaseAssetDetailResponseDTO();
        dto.setAssetId(assetId);
        dto.setName(name);
        dto.setManufacturer(manufacturer);
        dto.setModel(model);
        dto.setFirmwareVersion(firmwareVersion);
        dto.setProductionYear(productionYear);
        dto.setIacCode(iacCode);
        dto.setAssetType(assetType);
        dto.setUuid(uuid);

        Assertions.assertEquals(assetId, dto.getAssetId());
        Assertions.assertEquals(name, dto.getName());
        Assertions.assertEquals(manufacturer, dto.getManufacturer());
        Assertions.assertEquals(model, dto.getModel());
        Assertions.assertEquals(firmwareVersion, dto.getFirmwareVersion());
        Assertions.assertEquals(productionYear, dto.getProductionYear());
        Assertions.assertEquals(iacCode, dto.getIacCode());
        Assertions.assertEquals(assetType, dto.getAssetType());
        Assertions.assertEquals(uuid, dto.getUuid());
    }

    @Test
     void testEqualsAndHashCode() {
        BaseAssetDetailResponseDTO dto1 = new BaseAssetDetailResponseDTO();
        dto1.setAssetId(123L);

        BaseAssetDetailResponseDTO dto2 = new BaseAssetDetailResponseDTO();
        dto2.setAssetId(123L);

        BaseAssetDetailResponseDTO dto3 = new BaseAssetDetailResponseDTO();
        dto3.setAssetId(456L);

        Assertions.assertEquals(dto1, dto2);
        Assertions.assertNotEquals(dto1, dto3);

        Assertions.assertEquals(dto1.hashCode(), dto2.hashCode());
        Assertions.assertNotEquals(dto1.hashCode(), dto3.hashCode());
    }

}