package com.siemens.digitalcockpit.application.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyAddressDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyBillingDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDates;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

 class ContractDatesTest {
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = validatorFactory.getValidator();

    @Test
     void testGettersAndSetters() {
        String contactEmail = "contact@example.com";
        String companyName = "Example Company";
        boolean useCompanyAddress = true;
        String description = "Example Description";
        Long contractOwnerId = 123L;
        CompanyAddressDTO companyAddress = new CompanyAddressDTO();
        CompanyBillingDataDTO companyBillingData = new CompanyBillingDataDTO();
        String startDate = "2022-01-01";
        String endDate = "2022-12-31";

        ContractDates dto = new ContractDates();
              dto.setContactEmail(contactEmail);
              dto.setCompanyAddress(companyAddress);
              dto.setCompanyName(companyName);
              dto.setUseCompanyAddress(useCompanyAddress);
              dto.setDescription(description);
              dto.setContractOwnerId(contractOwnerId);
              dto.setCompanyBillingData(companyBillingData);
              dto.setStartDate(startDate);
              dto.setEndDate(endDate);

        Assertions.assertEquals(contactEmail, dto.getContactEmail());
        Assertions.assertEquals(companyName, dto.getCompanyName());
        Assertions.assertEquals(useCompanyAddress, dto.isUseCompanyAddress());
        Assertions.assertEquals(description, dto.getDescription());
        Assertions.assertEquals(contractOwnerId, dto.getContractOwnerId());
        Assertions.assertEquals(companyAddress, dto.getCompanyAddress());
        Assertions.assertEquals(companyBillingData, dto.getCompanyBillingData());
        Assertions.assertEquals(startDate, dto.getStartDate());
        Assertions.assertEquals(endDate, dto.getEndDate());
    }


}