package com.siemens.digitalcockpit.application.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.models.AssetInstanceStatus;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.BaseAssetInstanceDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.math.BigDecimal;

class BaseAssetInstanceDTOTest {
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = validatorFactory.getValidator();

    @Test
     void testGettersAndSetters() {
        Long assetId = 123L;
        String name = "Asset Name";
        String manufacturer = "Manufacturer";
        String model = "Model";
        String firmwareVersion = "1.0";
        int productionYear = 2022;
        String iacCode = "ABC123";
        String assetType = "Asset Type";
        String uuid = "UUID123";
        Long id = 456L;
        String serialId = "Serial123";
        Long selectedAssetTypeId = 789L;
        String selectedAssetTypeName = "Selected Asset Type";
        BigDecimal sumInsured = BigDecimal.valueOf(1000);
        long contractId = 987L;
        String status = AssetInstanceStatus.NOT_CONNECTED.toString();

        BaseAssetInstanceDTO dto1 = new BaseAssetInstanceDTO();
        dto1.setAssetId(assetId);
        dto1.setName(name);
        dto1.setManufacturer(manufacturer);
        dto1.setModel(model);
        dto1.setFirmwareVersion(firmwareVersion);
        dto1.setProductionYear(productionYear);
        dto1.setIacCode(iacCode);
        dto1.setAssetType(assetType);
        dto1.setUuid(uuid);
        dto1.setId(id);
        dto1.setSerialId(serialId);
        dto1.setSelectedAssetTypeId(selectedAssetTypeId);
        dto1.setSelectedAssetTypeName(selectedAssetTypeName);
        dto1.setSumInsured(sumInsured);
        dto1.setContractId(contractId);
        dto1.setStatus(status);


        Assertions.assertEquals(assetId, dto1.getAssetId());
        Assertions.assertEquals(name, dto1.getName());
        Assertions.assertEquals(manufacturer, dto1.getManufacturer());
        Assertions.assertEquals(model, dto1.getModel());
        Assertions.assertEquals(firmwareVersion, dto1.getFirmwareVersion());
        Assertions.assertEquals(productionYear, dto1.getProductionYear());
        Assertions.assertEquals(iacCode, dto1.getIacCode());
        Assertions.assertEquals(assetType, dto1.getAssetType());
        Assertions.assertEquals(uuid, dto1.getUuid());
        Assertions.assertEquals(id, dto1.getId());
        Assertions.assertEquals(serialId, dto1.getSerialId());
        Assertions.assertEquals(selectedAssetTypeId, dto1.getSelectedAssetTypeId());
        Assertions.assertEquals(selectedAssetTypeName, dto1.getSelectedAssetTypeName());
        Assertions.assertEquals(sumInsured, dto1.getSumInsured());
        Assertions.assertEquals(contractId, dto1.getContractId());
        Assertions.assertEquals(status, dto1.getStatus());
    }


}