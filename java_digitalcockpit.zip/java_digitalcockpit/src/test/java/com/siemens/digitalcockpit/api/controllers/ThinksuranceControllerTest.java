//package com.siemens.digitalcockpit.api.controllers;
//
//
//import com.siemens.digitalcockpit.application.usecases.command.createbrokerforward.CreateBrokerForwardCommand;
//import com.siemens.digitalcockpit.application.usecases.command.createbrokerforward.CreateBrokerForwardCommandHandler;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.ResponseEntity;
//
//import java.net.ConnectException;
//import java.util.concurrent.CompletableFuture;
//import java.util.concurrent.ExecutionException;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//
//
//class ThinksuranceControllerTest {
//    @InjectMocks
//    private ThinksuranceController thinksuranceController;
//    @Mock
//    private CreateBrokerForwardCommandHandler createBrokerForwardCommandHandler;
//    @BeforeEach
//     void setup() {
//        MockitoAnnotations.initMocks(this);
//    }
//    @Test
//     void testBrokerForward_Positive() throws ConnectException, ExecutionException, InterruptedException {
//        CompletableFuture<CreateBrokerForwardCommand> futureResponse = CompletableFuture.completedFuture(new CreateBrokerForwardCommand());
//        ResponseEntity<CreateBrokerForwardCommand> expectedResponseEntity = ResponseEntity.ok(new CreateBrokerForwardCommand());
//        when(createBrokerForwardCommandHandler.createBrokerForward(2037L,"tathagat.kumar3@gmail.com")).thenReturn(futureResponse);
//        CompletableFuture<ResponseEntity<CreateBrokerForwardCommand>> futureResponseEntity = thinksuranceController.brokerForward(2037L);
//        assertNotNull(futureResponseEntity);
//        ResponseEntity<CreateBrokerForwardCommand> actualResponseEntity = futureResponseEntity.join();
//        assertNotNull(actualResponseEntity);
//
//        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
//        verify(createBrokerForwardCommandHandler).createBrokerForward(2037L,"tathagat.kumar3@gmail.com");
//    }
//
//    @Test
//     void testBrokerForward_Negative() throws ConnectException, ExecutionException, InterruptedException {
//        when(createBrokerForwardCommandHandler.createBrokerForward(2037L,"tathagat.kumar3@gmail.com")).thenThrow(new InterruptedException());
//        assertThrows(InterruptedException.class, () -> thinksuranceController.brokerForward(2037L));
//        verify(createBrokerForwardCommandHandler).createBrokerForward(2037L,"tathagat.kumar3@gmail.com");
//    }
//
//}