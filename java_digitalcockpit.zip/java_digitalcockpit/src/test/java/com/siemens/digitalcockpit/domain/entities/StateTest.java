package com.siemens.digitalcockpit.domain.entities;

import com.siemens.digitalcockpit.domain.common.State;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class StateTest {

    @Test
     void testSavedEnum() {
        State state = State.SAVED;
        assertNotNull(state);
        assertEquals("SAVED", state.name());
        assertEquals(0, state.ordinal());
    }

    @Test
     void testValidationEnum() {
        State state = State.VALIDATION;
        assertNotNull(state);
        assertEquals("VALIDATION", state.name());
        assertEquals(1, state.ordinal());
    }

    @Test
     void testPublishedEnum() {
        State state = State.PUBLISHED;
        assertNotNull(state);
        assertEquals("PUBLISHED", state.name());
        assertEquals(2, state.ordinal());
    }

    @Test
     void testRejectEnum() {
        State state = State.REJECT;
        assertNotNull(state);
        assertEquals("REJECT", state.name());
        assertEquals(3, state.ordinal());
    }
}