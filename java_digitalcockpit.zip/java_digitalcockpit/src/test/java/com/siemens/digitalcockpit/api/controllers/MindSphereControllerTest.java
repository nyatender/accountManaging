//package com.siemens.digitalcockpit.api.controllers;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//
//import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDTO;
//import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
//import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.GetContractByIdQueryHandler;
//import com.siemens.digitalcockpit.application.usecases.queries.getcontracts.GetContractsQueryHandler;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.ResponseEntity;
//
//import java.io.UnsupportedEncodingException;
//import java.net.ConnectException;
//import java.util.concurrent.CompletableFuture;
//import java.util.concurrent.ExecutionException;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//class MindSphereControllerTest {
//
//    @Mock
//    private GetContractsQueryHandler getContractsQueryHandler;
//
//    @Mock
//    private GetContractByIdQueryHandler getContractByIdQueryHandler;
//
//
//    @InjectMocks
//    private MindSphereController mindSphereController;
//
//    @BeforeEach
//     void setup() {
//        MockitoAnnotations.initMocks(this);
//    }
//
////    @Test
////     void testGetContractByPageSizeAndPage_Positive() throws ConnectException, JsonProcessingException, InterruptedException, UnsupportedEncodingException, ExecutionException {
////        int expectedPageSize = 10;
////        int expectedPage = 1;
////        String expectedResponseBody = "response body";
////
////        CompletableFuture<String> futureResponse = CompletableFuture.completedFuture(expectedResponseBody);
////        ResponseEntity<String> expectedResponseEntity = ResponseEntity.ok(expectedResponseBody);
////
////        when(getContractsQueryHandler.readContracts(expectedPageSize, expectedPage)).thenReturn(futureResponse);
////
////        CompletableFuture<ResponseEntity<String>> futureResponseEntity = mindSphereController.getContract(expectedPageSize, expectedPage);
////        assertNotNull(futureResponseEntity);
////
////        ResponseEntity<String> actualResponseEntity = futureResponseEntity.join();
////        assertNotNull(actualResponseEntity);
////
////        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
////        assertEquals(expectedResponseEntity.getBody(), actualResponseEntity.getBody());
////
////        verify(getContractsQueryHandler).readContracts(expectedPageSize, expectedPage);
////    }
//
//    @Test
//     void testGetContractByPageSizeAndPage_Negative() throws ConnectException, JsonProcessingException, InterruptedException, UnsupportedEncodingException, ExecutionException {
//        int expectedPageSize = 10;
//        int expectedPage = 1;
//        when(getContractsQueryHandler.readContracts(expectedPageSize, expectedPage)).thenThrow(new ConnectException());
//        assertThrows(ConnectException.class, () -> mindSphereController.getContract(expectedPageSize, expectedPage));
//        verify(getContractsQueryHandler).readContracts(expectedPageSize, expectedPage);
//    }
//
//    @Test
//     void testGetContractByPageSizeAndPage_Negative_Inrerruted() throws ConnectException, JsonProcessingException, InterruptedException, UnsupportedEncodingException, ExecutionException {
//        int expectedPageSize = 10;
//        int expectedPage = 1;
//        when(getContractsQueryHandler.readContracts(expectedPageSize, expectedPage)).thenThrow(new InterruptedException());
//        assertThrows(InterruptedException.class, () -> mindSphereController.getContract(expectedPageSize, expectedPage));
//        verify(getContractsQueryHandler).readContracts(expectedPageSize, expectedPage);
//    }
//
//    @Test
//     void testGetContractById_Positive() throws ConnectException, JsonProcessingException, InterruptedException {
//        Long expectedId = 123L;
//        ContractDTO expectedResponseBody = new ContractDTO();
//
//        CompletableFuture<ContractDTO> futureResponse = CompletableFuture.completedFuture(expectedResponseBody);
//        ResponseEntity<ContractDTO> expectedResponseEntity = ResponseEntity.ok(expectedResponseBody);
//
//        when(getContractByIdQueryHandler.readContractById(expectedId)).thenReturn(futureResponse);
//
//        CompletableFuture<ResponseEntity<ContractDTO>> futureResponseEntity = mindSphereController.getContract(expectedId);
//        assertNotNull(futureResponseEntity);
//
//        ResponseEntity<ContractDTO> actualResponseEntity = futureResponseEntity.join();
//        assertNotNull(actualResponseEntity);
//
//        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
//        assertEquals(expectedResponseEntity.getBody(), actualResponseEntity.getBody());
//
//        verify(getContractByIdQueryHandler).readContractById(expectedId);
//    }
//
//    @Test
//     void testGetContractById_Negative() throws ConnectException, InterruptedException {
//        Long expectedId = 123L;
//
//        when(getContractByIdQueryHandler.readContractById(expectedId)).thenThrow(new ConnectException());
//
//        assertThrows(ConnectException.class, () -> mindSphereController.getContract(expectedId));
//
//        verify(getContractByIdQueryHandler).readContractById(expectedId);
//    }
//
//    @Test
//     void testGetContractById_Negative_Interrupted() throws ConnectException, JsonProcessingException, InterruptedException {
//        Long expectedId = 123L;
//
//        when(getContractByIdQueryHandler.readContractById(expectedId)).thenThrow(new InterruptedException());
//
//        assertThrows(InterruptedException.class, () -> mindSphereController.getContract(expectedId));
//
//        verify(getContractByIdQueryHandler).readContractById(expectedId);
//    }
//
//    @Test
//     void testGetDashboardData_Negative() throws ConnectException, ExecutionException, InterruptedException {
//        when(getContractsQueryHandler.getDashBoardData()).thenThrow(new InterruptedException());
//
//        assertThrows(InterruptedException.class, () -> mindSphereController.getDashboardData());
//
//        verify(getContractsQueryHandler).getDashBoardData();
//    }
//
//    @Test
//     void testGetTrue_Positive() throws ConnectException, ExecutionException, InterruptedException {
//        CompletableFuture<Boolean> futureResponse = CompletableFuture.completedFuture(true);
//        ResponseEntity<Boolean> expectedResponseEntity = ResponseEntity.ok(true);
//
//        when(getContractsQueryHandler.getTrue()).thenReturn(futureResponse);
//
//        CompletableFuture<ResponseEntity<Boolean>> futureResponseEntity = mindSphereController.getTrue();
//        assertNotNull(futureResponseEntity);
//
//        ResponseEntity<Boolean> actualResponseEntity = futureResponseEntity.join();
//        assertNotNull(actualResponseEntity);
//
//        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
//        assertEquals(expectedResponseEntity.getBody(), actualResponseEntity.getBody());
//
//        verify(getContractsQueryHandler).getTrue();
//    }
//
//    @Test
//     void testGetTrue_Negative() throws ConnectException, ExecutionException, InterruptedException {
//        when(getContractsQueryHandler.getTrue()).thenThrow(new InterruptedException());
//
//        assertThrows(InterruptedException.class, () -> mindSphereController.getTrue());
//
//        verify(getContractsQueryHandler).getTrue();
//    }
//
//    @Test
//     void testGetFalse_Positive() throws ConnectException, ExecutionException, InterruptedException {
//        CompletableFuture<Boolean> futureResponse = CompletableFuture.completedFuture(false);
//        ResponseEntity<Boolean> expectedResponseEntity = ResponseEntity.ok(false);
//
//        when(getContractsQueryHandler.getFalse()).thenReturn(futureResponse);
//
//        CompletableFuture<ResponseEntity<Boolean>> futureResponseEntity = mindSphereController.getFalse();
//        assertNotNull(futureResponseEntity);
//
//        ResponseEntity<Boolean> actualResponseEntity = futureResponseEntity.join();
//        assertNotNull(actualResponseEntity);
//
//        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
//        assertEquals(expectedResponseEntity.getBody(), actualResponseEntity.getBody());
//
//        verify(getContractsQueryHandler).getFalse();
//    }
//
//    @Test
//     void testGetFalse_Negative() throws ConnectException, ExecutionException, InterruptedException {
//        when(getContractsQueryHandler.getFalse()).thenThrow(new InterruptedException());
//
//        assertThrows(InterruptedException.class, () -> mindSphereController.getFalse());
//
//        verify(getContractsQueryHandler).getFalse();
//    }
//
//    @Test
//     void testGetDashboardData_Positive() throws ConnectException, ExecutionException, InterruptedException {
//        CompletableFuture<DashboardDataDTO> futureResponse = CompletableFuture.completedFuture(new DashboardDataDTO());
//        ResponseEntity<DashboardDataDTO> expectedResponseEntity = ResponseEntity.ok(new DashboardDataDTO());
//
//        when(getContractsQueryHandler.getDashBoardData()).thenReturn(futureResponse);
//
//        CompletableFuture<ResponseEntity<DashboardDataDTO>> futureResponseEntity = mindSphereController.getDashboardData();
//        assertNotNull(futureResponseEntity);
//
//        ResponseEntity<DashboardDataDTO> actualResponseEntity = futureResponseEntity.join();
//        assertNotNull(actualResponseEntity);
//
//        assertEquals(expectedResponseEntity.getStatusCode(), actualResponseEntity.getStatusCode());
//
//        verify(getContractsQueryHandler).getDashBoardData();
//    }
//
//
//
//}