package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.Assert.*;

 class MetricDetailDTOTest {
    @Test
     void testGetterAndSetter() {
        MetricDetailDTO metricDetail = new MetricDetailDTO();
        metricDetail.setMetricId(1L);
        metricDetail.setScript("script");
        metricDetail.setDescription("description");
        metricDetail.setName("name");
        metricDetail.setDataType(DataType.STRING);
        metricDetail.setOptional(true);
        metricDetail.setUnit("unit");
        metricDetail.setIotMetricDefinitionDescription("iot metric definition description");

        assertEquals(Optional.of(1L), Optional.of(metricDetail.getMetricId()));
        assertEquals("script", metricDetail.getScript());
        assertEquals("description", metricDetail.getDescription());
        assertEquals("name", metricDetail.getName());
        assertEquals(DataType.STRING, metricDetail.getDataType());
        assertTrue(metricDetail.isOptional());
        assertEquals("unit", metricDetail.getUnit());
        assertEquals("iot metric definition description", metricDetail.getIotMetricDefinitionDescription());
    }

    @Test
     void testNoArgsConstructor() {
        MetricDetailDTO metricDetail = new MetricDetailDTO();

        assertNull(metricDetail.getMetricId());
        assertNull(metricDetail.getScript());
        assertNull(metricDetail.getDescription());
        assertNull(metricDetail.getName());
        assertNull(metricDetail.getDataType());
        assertFalse(metricDetail.isOptional());
        assertNull(metricDetail.getUnit());
        assertNull(metricDetail.getIotMetricDefinitionDescription());
    }

    @Test
     void testAllArgsConstructor() {
        Long metricId = 1L;
        String script = "script";
        String description = "description";
        String name = "name";
        DataType dataType = DataType.STRING;
        boolean optional = true;
        String unit = "unit";
        String iotMetricDefinitionDescription = "iot metric definition description";

        MetricDetailDTO metricDetail = new MetricDetailDTO(metricId, script, description, name, dataType, optional, unit, iotMetricDefinitionDescription);

        assertEquals(metricId, metricDetail.getMetricId());
        assertEquals(script, metricDetail.getScript());
        assertEquals(description, metricDetail.getDescription());
        assertEquals(name, metricDetail.getName());
        assertEquals(dataType, metricDetail.getDataType());
        assertEquals(optional, metricDetail.isOptional());
        assertEquals(unit, metricDetail.getUnit());
        assertEquals(iotMetricDefinitionDescription, metricDetail.getIotMetricDefinitionDescription());
    }

    @Test
     void testEqualsAndHashCode() {
        MetricDetailDTO metricDetail1 = new MetricDetailDTO(1L, "script", "description", "name", DataType.STRING, true, "unit", "iot metric definition description");
        MetricDetailDTO metricDetail2 = new MetricDetailDTO(1L, "script", "description", "name", DataType.STRING, true, "unit", "iot metric definition description");
        MetricDetailDTO metricDetail3 = new MetricDetailDTO(2L, "script2", "description2", "name2", DataType.INT, false, "unit2", "iot metric definition description2");

        assertEquals(metricDetail1, metricDetail2);
        assertNotEquals(metricDetail1, metricDetail3);

        assertEquals(metricDetail1.hashCode(), metricDetail2.hashCode());
        assertNotEquals(metricDetail1.hashCode(), metricDetail3.hashCode());
    }

    @Test
     void testToString() {
        MetricDetailDTO metricDetail = new MetricDetailDTO(1L, "script", "description", "name", DataType.STRING, true, "unit", "iot metric definition description");

        String expectedToString = "MetricDetailDTO(metricId=1, script=script, description=description, name=name, dataType=STRING, optional=true, unit=unit, iotMetricDefinitionDescription=iot metric definition description)";
        assertEquals(expectedToString, metricDetail.toString());
    }


}