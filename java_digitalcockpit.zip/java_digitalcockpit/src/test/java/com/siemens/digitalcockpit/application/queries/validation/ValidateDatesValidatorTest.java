//package com.siemens.digitalcockpit.application.queries.validation;
//
//
//
//
//import com.siemens.digitalcockpit.application.exceptions.BusinessException;
//import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.ContractDates;
//import com.siemens.digitalcockpit.application.usecases.queries.validation.ValidateDatesValidator;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import javax.validation.ConstraintValidatorContext;
//
// class ValidateDatesValidatorTest {
//
//    private ValidateDatesValidator validator;
//
//    @Mock
//    private ConstraintValidatorContext context;
//
//    @BeforeEach
//     void setup() {
//        MockitoAnnotations.initMocks(this);
//        validator = new ValidateDatesValidator();
//    }
//
//    @Test
//     void testValidDates() {
//        ContractDates contractDates = new ContractDates();
//        contractDates.setStartDate("2024-01-01T00:00:00.000Z");
//        contractDates.setEndDate("2024-01-31T23:59:59.999Z");
//
//        boolean isValid = validator.isValid(contractDates, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testNullDates() {
//        ContractDates contractDates = new ContractDates();
//
//        boolean isValid = validator.isValid(contractDates, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testInvalidStartDate() {
//        ContractDates contractDates = new ContractDates();
//        contractDates.setStartDate("2022-01-01T00:00:00.000Z");
//        contractDates.setEndDate("2022-01-31T23:59:59.999Z");
//
//        try {
//            validator.isValid(contractDates, context);
//            Assertions.fail("BusinessException should have been thrown");
//        } catch (BusinessException ex) {
//           // Assertions.assertEquals(BAD_REQUEST, 400);
//            Assertions.assertEquals("Start date cannot be earlier than today.", ex.getMessage());
//        }
//    }
//
//    @Test
//     void testInvalidEndDate() {
//        ContractDates contractDates = new ContractDates();
//        contractDates.setStartDate("2022-01-01T00:00:00.000Z");
//        contractDates.setEndDate("2022-01-31T23:59:59.999Z");
//
//        try {
//            validator.isValid(contractDates, context);
//            Assertions.fail("BusinessException should have been thrown");
//        } catch (BusinessException ex) {
//        //    Assertions.assertEquals(BAD_REQUEST, BAD_REQUEST);
//            Assertions.assertEquals("Start date cannot be earlier than today.", ex.getMessage());
//        }
//    }
//
//}