//package com.siemens.digitalcockpit.application.paging;
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//
// class PageRequestDTOTest {
//    @Test
//     void testGetPageableWithSort() {
//        String sort = "name,asc";
//
//        PageRequestDTO pageRequestDTO = PageRequestDTO.builder()
//                .page(0)
//                .pageSize(30)
//                .sort(sort)
//                .build();
//
//        Pageable pageable = pageRequestDTO.getPageable();
//
//        Assertions.assertEquals(0, pageable.getPageNumber());
//        Assertions.assertEquals(30, pageable.getPageSize());
//        Assertions.assertTrue(pageable.getSort().isSorted());
//        Assertions.assertEquals(Sort.Direction.ASC, pageable.getSort().getOrderFor("name").getDirection());
//    }
//
//    @Test
//     void testGetPageableWithoutSort() {
//        PageRequestDTO pageRequestDTO = PageRequestDTO.builder()
//                .page(0)
//                .pageSize(30)
//                .build();
//
//        Pageable pageable = pageRequestDTO.getPageable();
//
//        Assertions.assertEquals(0, pageable.getPageNumber());
//        Assertions.assertEquals(30, pageable.getPageSize());
//        Assertions.assertFalse(pageable.getSort().isSorted());
//    }
//}