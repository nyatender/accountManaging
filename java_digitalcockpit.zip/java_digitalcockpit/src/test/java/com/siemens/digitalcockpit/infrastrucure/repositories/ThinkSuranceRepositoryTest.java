package com.siemens.digitalcockpit.infrastrucure.repositories;

import com.siemens.digitalcockpit.infrastructure.repositories.ThinkSuranceRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.concurrent.CompletableFuture;


 class ThinkSuranceRepositoryTest {

    @InjectMocks
    private ThinkSuranceRepository thinkSuranceRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
     void testGetCommonRequestHeaders() throws Exception {
        // Act
        CompletableFuture<HttpHeaders> result = thinkSuranceRepository.getCommonRequestHeaders();

        // Assert
        HttpHeaders headers = result.get();
        Assertions.assertEquals(MediaType.APPLICATION_JSON_VALUE, headers.getFirst(HttpHeaders.CONTENT_TYPE));
        Assertions.assertEquals(MediaType.APPLICATION_JSON_VALUE, headers.getFirst(HttpHeaders.ACCEPT));
    }

}