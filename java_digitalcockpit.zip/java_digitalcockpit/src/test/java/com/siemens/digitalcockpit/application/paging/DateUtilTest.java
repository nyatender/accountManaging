package com.siemens.digitalcockpit.application.paging;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
 class DateUtilTest {
    @Test
     void testToISOString() {
        LocalDateTime localDateTime = LocalDateTime.of(2023, 7, 13, 10, 30, 0);

        String isoString = DateUtil.toISOString(localDateTime);

        Assertions.assertEquals("2023-07-13T10:30:00.000Z", isoString);
    }

    @Test
     void testToISOStringTruncateToMillis() {
        LocalDateTime localDateTime = LocalDateTime.of(2023, 7, 13, 10, 30, 15, 500_000);

        String isoString = DateUtil.toISOStringTruncateToMillis(localDateTime);

        Assertions.assertEquals("2023-07-13T10:30:15Z", isoString);
    }

    @Test
     void testToLocalDateTime() {
        String isoDateTime = "2023-07-13T10:30:00.000Z";

        LocalDateTime localDateTime = DateUtil.toLocalDateTime(isoDateTime);

        Assertions.assertEquals(LocalDateTime.of(2023, 7, 13, 10, 30, 0), localDateTime);
    }

    @Test
     void testGetNowAsUTC() {
        LocalDateTime now = DateUtil.getNowAsUTC();

        Assertions.assertNotNull(now);
    }

    @Test
     void testGetFutureDateAsString() {
        int days = 5;

        String futureDate = DateUtil.getFutureDateAsString(days);

        Assertions.assertNotNull(futureDate);
    }
}