package com.siemens.digitalcockpit.domain.ddx;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TokenThinksuranceDDXTest {
    private TokenDDX tokenDDX;
    @BeforeEach
    void setUp() {
        tokenDDX = new TokenDDX();
    }
    @Test
     void testTokenGetterAndSetter() {
        String expectedToken = "myToken";
        tokenDDX.setToken(expectedToken);
        assertEquals(expectedToken, tokenDDX.getToken());
    }

    @Test
     void testCompanyIdGetterAndSetter() {
        String expectedCompanyId = "123";
        tokenDDX.setCompanyId(expectedCompanyId);
        assertEquals(expectedCompanyId, tokenDDX.getCompanyId());
    }

    @Test
     void testCompanyNameGetterAndSetter() {
        String expectedCompanyName = "MyCompany";
        tokenDDX.setCompanyName(expectedCompanyName);
        assertEquals(expectedCompanyName, tokenDDX.getCompanyName());
    }

    @Test
     void testUserNameGetterAndSetter() {
        String expectedUserName = "JohnDoe";
        tokenDDX.setUserName(expectedUserName);
        assertEquals(expectedUserName, tokenDDX.getUserName());
    }

    @Test
     void testTokenDDXNoArgsConstructor() {
        assertNotNull(new TokenDDX());
    }
}