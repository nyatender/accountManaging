package com.siemens.digitalcockpit.domain.thinksurance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class DataTest {
    private Data data;

    @BeforeEach
     void setup() {
        data = new Data();
    }

    @Test
     void testDataGettersAndSetters() {
        int expectedType = 1;
        String expectedBToken = "bToken";
        String expectedCLastName = "cLastName";
        String expectedCEmail = "cEmail";
        String expectedCExternalId = "cExternalId";
        String expectedCallbackUrl = "callbackUrl";
        Data.QasCustProfile expectedQasCustProfile = new Data.QasCustProfile();

        data.setType(expectedType);
        data.setBToken(expectedBToken);
        data.setCLastName(expectedCLastName);
        data.setCEmail(expectedCEmail);
        data.setCExternalId(expectedCExternalId);
        data.setCallbackUrl(expectedCallbackUrl);
        data.setQasCustProfile(expectedQasCustProfile);

        assertEquals(expectedType, data.getType());
        assertEquals(expectedBToken, data.getBToken());
        assertEquals(expectedCLastName, data.getCLastName());
        assertEquals(expectedCEmail, data.getCEmail());
        assertEquals(expectedCExternalId, data.getCExternalId());
        assertEquals(expectedCallbackUrl, data.getCallbackUrl());
        assertEquals(expectedQasCustProfile, data.getQasCustProfile());
    }

    @Test
     void testQasCustProfileGettersAndSetters() {
        List<Data.QasCustProfile.Category> expectedCategories = new ArrayList<>();
        String expectedSource = "source";
        Data.QasCustProfile qasCustProfile = new Data.QasCustProfile();

        qasCustProfile.setCategories(expectedCategories);
        qasCustProfile.setSource(expectedSource);

        assertEquals(expectedCategories, qasCustProfile.getCategories());
        assertEquals(expectedSource, qasCustProfile.getSource());
    }

    @Test
     void testCategoryGettersAndSetters() {
        String expectedId = "id";
        List<Data.QasCustProfile.Category.Question> expectedQuestions = new ArrayList<>();
        Data.QasCustProfile.Category category = new Data.QasCustProfile.Category();
        category.setId(expectedId);
        category.setQuestions(expectedQuestions);
        assertEquals(expectedId, category.getId());
        assertEquals(expectedQuestions, category.getQuestions());
    }

    @Test
     void testQuestionGettersAndSetters() {
        String expectedId = "id";
        List<String> expectedAnswers = Arrays.asList("answer1", "answer2");
        Data.QasCustProfile.Category.Question question = new Data.QasCustProfile.Category.Question();
        question.setId(expectedId);
        question.setAnswers(expectedAnswers);
        assertEquals(expectedId, question.getId());
        assertEquals(expectedAnswers, question.getAnswers());
    }

    @Test
     void testQasCustProfileNotNull() {
        assertNotNull(new Data.QasCustProfile());
    }

    @Test
     void testCategoryNotNull() {
        assertNotNull(new Data.QasCustProfile.Category());
    }

    @Test
     void testQuestionNotNull() {
        assertNotNull(new Data.QasCustProfile.Category.Question());
    }
}