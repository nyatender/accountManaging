package com.siemens.digitalcockpit.domain.ddx;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ConstantsTest {
    @Test
     void testContractNotFoundMessage() {
        String expectedMessage = "AES";
        Assertions.assertEquals( Constants.AES,expectedMessage);
    }
}