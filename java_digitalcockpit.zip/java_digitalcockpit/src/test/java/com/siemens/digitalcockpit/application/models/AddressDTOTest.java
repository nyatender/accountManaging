package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static org.junit.Assert.*;

 class AddressDTOTest {

    @Test
     void testNoArgsConstructor() {
        AddressDTO addressDTO = new AddressDTO();

        assertNull(addressDTO.getId());
        assertNull(addressDTO.getRoad());
        assertNull(addressDTO.getZipCode());
        assertNull(addressDTO.getLocation());
        assertNull(addressDTO.getCountry());
        assertFalse(addressDTO.isUseCompanyAddress());
        assertEquals(0, addressDTO.getAssetInstanceId());
    }

    @Test
     void testAllArgsConstructor() {
        Long id = 1L;
        String road = "Main Street";
        String zipCode = "12345";
        String location = "City";
        String country = "Country";
        boolean useCompanyAddress = true;
        long assetInstanceId = 2L;

        AddressDTO addressDTO = new AddressDTO(id, road, zipCode, location, country, useCompanyAddress, assetInstanceId);

        assertEquals(id, addressDTO.getId());
        assertEquals(road, addressDTO.getRoad());
        assertEquals(zipCode, addressDTO.getZipCode());
        assertEquals(location, addressDTO.getLocation());
        assertEquals(country, addressDTO.getCountry());
        assertTrue(addressDTO.isUseCompanyAddress());
        assertEquals(assetInstanceId, addressDTO.getAssetInstanceId());
    }

    @Test
     void testGetterAndSetterId() {
        AddressDTO addressDTO = new AddressDTO();
        assertNull(addressDTO.getId());

        Long id = 1L;
        addressDTO.setId(id);
        assertEquals(id, addressDTO.getId());
    }

    @Test
     void testGetterAndSetterRoad() {
        AddressDTO addressDTO = new AddressDTO();
        assertNull(addressDTO.getRoad());

        String road = "Main Street";
        addressDTO.setRoad(road);
        assertEquals(road, addressDTO.getRoad());
    }

    @Test
     void testGetterAndSetterZipCode() {
        AddressDTO addressDTO = new AddressDTO();
        assertNull(addressDTO.getZipCode());

        String zipCode = "12345";
        addressDTO.setZipCode(zipCode);
        assertEquals(zipCode, addressDTO.getZipCode());
    }

    @Test
     void testGetterAndSetterLocation() {
        AddressDTO addressDTO = new AddressDTO();
        assertNull(addressDTO.getLocation());

        String location = "City";
        addressDTO.setLocation(location);
        assertEquals(location, addressDTO.getLocation());
    }

    @Test
     void testGetterAndSetterCountry() {
        AddressDTO addressDTO = new AddressDTO();
        assertNull(addressDTO.getCountry());

        String country = "Country";
        addressDTO.setCountry(country);
        assertEquals(country, addressDTO.getCountry());
    }

    @Test
     void testGetterAndSetterUseCompanyAddress() {
        AddressDTO addressDTO = new AddressDTO();
        assertFalse(addressDTO.isUseCompanyAddress());

        boolean useCompanyAddress = true;
        addressDTO.setUseCompanyAddress(useCompanyAddress);
        assertTrue(addressDTO.isUseCompanyAddress());
    }

    @Test
     void testGetterAndSetterAssetInstanceId() {
        AddressDTO addressDTO = new AddressDTO();
        assertEquals(0, addressDTO.getAssetInstanceId());

        long assetInstanceId = 2L;
        addressDTO.setAssetInstanceId(assetInstanceId);
        assertEquals(assetInstanceId, addressDTO.getAssetInstanceId());
    }

    @Test
     void testValidationConstraints() throws NoSuchFieldException {
        AddressDTO addressDTO = new AddressDTO();


        assertNotNull(addressDTO.getClass().getDeclaredField("road").getDeclaredAnnotation(NotNull.class));
        assertNotNull(addressDTO.getClass().getDeclaredField("road").getDeclaredAnnotation(Size.class));
        assertEquals(255, addressDTO.getClass().getDeclaredField("road").getDeclaredAnnotation(Size.class).max());

        assertNotNull(addressDTO.getClass().getDeclaredField("zipCode").getDeclaredAnnotation(NotNull.class));
        assertNotNull(addressDTO.getClass().getDeclaredField("zipCode").getDeclaredAnnotation(Size.class));
        assertEquals(255, addressDTO.getClass().getDeclaredField("zipCode").getDeclaredAnnotation(Size.class).max());

        assertNotNull(addressDTO.getClass().getDeclaredField("location").getDeclaredAnnotation(NotNull.class));
        assertNotNull(addressDTO.getClass().getDeclaredField("location").getDeclaredAnnotation(Size.class));
        assertEquals(255, addressDTO.getClass().getDeclaredField("location").getDeclaredAnnotation(Size.class).max());

        assertNotNull(addressDTO.getClass().getDeclaredField("country").getDeclaredAnnotation(NotNull.class));
        assertNotNull(addressDTO.getClass().getDeclaredField("country").getDeclaredAnnotation(Size.class));
        assertEquals(255, addressDTO.getClass().getDeclaredField("country").getDeclaredAnnotation(Size.class).max());

        assertNotNull(addressDTO.getClass().getDeclaredField("useCompanyAddress").getDeclaredAnnotation(NotNull.class));

        assertNull(addressDTO.getClass().getDeclaredField("assetInstanceId").getDeclaredAnnotation(NotNull.class));
    }
}