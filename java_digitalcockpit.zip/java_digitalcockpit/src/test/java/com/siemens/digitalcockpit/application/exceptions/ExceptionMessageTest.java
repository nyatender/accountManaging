package com.siemens.digitalcockpit.application.exceptions;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ExceptionMessageTest {
    @Test
     void testContractNotFoundMessage() {
        String expectedMessage = "Contract not found!";
        Assertions.assertEquals( ExceptionMessage.CONTRACT_NOT_FOUND,expectedMessage);
    }

    @Test
     void testContractResourceDetailNotFoundMessage() {
        String expectedMessage = "Contract resource detail not found! for %s = %s";
        Assertions.assertEquals( ExceptionMessage.CONTRACT_RESOURCE_DETAIL_NOT_FOUND,expectedMessage);
    }

    @Test
     void testEmailSendingFailedMessage() {
        String expectedMessage = "Problem occurred while sending email.";
        Assertions.assertEquals( ExceptionMessage.EMAIL_SENDING_FAILED,expectedMessage);
    }
}