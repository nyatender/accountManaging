package com.siemens.digitalcockpit.application.queries.getcontractbyid;

import com.siemens.digitalcockpit.domain.common.Currency;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CurrencyTest {
    @Test
     void testEURCurrency() {
        Currency currency = Currency.EUR;
        assertNotNull(currency);
        assertEquals("EUR", currency.name());
        assertEquals(0, currency.ordinal());
    }

    @Test
     void testUSDCurrency() {
        Currency currency = Currency.USD;
        assertNotNull(currency);
        assertEquals("USD", currency.name());
        assertEquals(1, currency.ordinal());
    }
}