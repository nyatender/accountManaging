package com.siemens.digitalcockpit.infrastrucure.model;

import com.siemens.digitalcockpit.infrastructure.model.BaseModel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

 class BaseModelTest {
    @Test
     void testGettersAndSetters() {
        LocalDateTime creationDate = LocalDateTime.of(2022, 1, 1, 0, 0, 0);
        LocalDateTime updatedDate = LocalDateTime.of(2022, 1, 2, 0, 0, 0);
        String createdBy = "John";
        String updatedBy = "Jane";

        BaseModel model = new BaseModel();
        model.setCreationDate(creationDate);
        model.setUpdatedDate(updatedDate);
        model.setCreatedBy(createdBy);
        model.setUpdatedBy(updatedBy);

        Assertions.assertEquals(creationDate, model.getCreationDate());
        Assertions.assertEquals(updatedDate, model.getUpdatedDate());
        Assertions.assertEquals(createdBy, model.getCreatedBy());
        Assertions.assertEquals(updatedBy, model.getUpdatedBy());
    }

    @Test
     void testEqualsAndHashCode() {
        BaseModel model1 = new BaseModel();
        model1.setCreatedBy("John");

        BaseModel model2 = new BaseModel();
        model2.setCreatedBy("John");

        BaseModel model3 = new BaseModel();
        model3.setCreatedBy("Jane");

        Assertions.assertEquals(model1, model2);
        Assertions.assertNotEquals(model1, model3);

        Assertions.assertEquals(model1.hashCode(), model2.hashCode());
        Assertions.assertNotEquals(model1.hashCode(), model3.hashCode());
    }
}