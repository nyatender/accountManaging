package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

 class DataTypeTest {
    @Test
     void testIntDataType() {
        DataType dataType = DataType.INT;
        assertEquals("INT", dataType.name());
        assertEquals(0, dataType.ordinal());
    }

    @Test
     void testDoubleDataType() {
        DataType dataType = DataType.DOUBLE;
        assertEquals("DOUBLE", dataType.name());
        assertEquals(1, dataType.ordinal());
    }

    @Test
     void testStringDataType() {
        DataType dataType = DataType.STRING;
        assertEquals("STRING", dataType.name());
        assertEquals(2, dataType.ordinal());
    }

    @Test
     void testBooleanDataType() {
        DataType dataType = DataType.BOOLEAN;
        assertEquals("BOOLEAN", dataType.name());
        assertEquals(3, dataType.ordinal());
    }

    @Test
     void testTimestampDataType() {
      DataType dataType = DataType.TIMESTAMP;
      assertEquals("TIMESTAMP",dataType.name());
      assertEquals(4,dataType.ordinal());
    }

    @Test
     void testBigStringDataType() {
        DataType dataType = DataType.BIG_STRING;
        assertEquals("BIG_STRING",dataType.name());
        assertEquals(5,dataType.ordinal());
    }
    @Test
     void testLongDataType() {
        DataType dataType = DataType.LONG;
        assertEquals("LONG",dataType.name());
        assertEquals(6,dataType.ordinal());
    }

}