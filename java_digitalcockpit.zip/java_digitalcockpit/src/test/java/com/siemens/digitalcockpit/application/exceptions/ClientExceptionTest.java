package com.siemens.digitalcockpit.application.exceptions;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ClientExceptionTest {
    @Test
     void testConstructorAndGetters() {
        String url = "https://example.com/api";
        int statusCode = 404;
        Throwable cause = new RuntimeException("Not found");

        ClientException clientException = new ClientException(url, statusCode, cause);

        Assertions.assertEquals(cause, clientException.getCause());
        Assertions.assertEquals(statusCode,clientException.getStatusCode());
        Assertions.assertEquals(url,clientException.getUrl());
    }
}