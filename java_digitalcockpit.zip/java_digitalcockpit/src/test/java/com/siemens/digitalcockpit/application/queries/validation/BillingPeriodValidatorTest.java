//package com.siemens.digitalcockpit.application.queries.validation;
//
//import com.siemens.digitalcockpit.application.usecases.queries.validation.BillingPeriodValidator;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import javax.validation.ConstraintValidatorContext;
//import java.util.Arrays;
//import java.util.List;
//
// class BillingPeriodValidatorTest {
//    private BillingPeriodValidator validator;
//
//    @Mock
//    private ConstraintValidatorContext context;
//
//    @BeforeEach
//     void setup() {
//        MockitoAnnotations.initMocks(this);
//        validator = new BillingPeriodValidator();
//    }
//
//    @Test
//     void testValidBillingPeriod() {
//        String billingPeriod = "MONTHLY";
//
//        boolean isValid = validator.isValid(billingPeriod, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testInvalidBillingPeriod() {
//        String billingPeriod = "INVALID";
//
//        boolean isValid = validator.isValid(billingPeriod, context);
//
//        Assertions.assertFalse(isValid);
//    }
//
//    @Test
//     void testNullBillingPeriod() {
//        String billingPeriod = null;
//
//        boolean isValid = validator.isValid(billingPeriod, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testEmptyBillingPeriod() {
//        String billingPeriod = "";
//
//        boolean isValid = validator.isValid(billingPeriod, context);
//
//        Assertions.assertTrue(isValid);
//    }
//
//    @Test
//     void testMultipleBillingPeriods() {
//        List<String> billingPeriods = Arrays.asList("MONTHLY", "QUARTERLY", "ANNUALLY");
//
//        for (String billingPeriod : billingPeriods) {
//            boolean isValid = validator.isValid(billingPeriod, context);
//            Assertions.assertTrue(isValid);
//        }
//    }
//}