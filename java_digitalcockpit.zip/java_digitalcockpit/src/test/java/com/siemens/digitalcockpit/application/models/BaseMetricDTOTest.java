package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;


 class BaseMetricDTOTest {

    @Test
     void testGetterAndSetter() {
        BaseMetricDTO baseMetric = new BaseMetricDTO();
        baseMetric.setId(1L);
        baseMetric.setSelectedMetricId(2L);
        baseMetric.setSelectedMetricName("metric name");
        baseMetric.setInsurancePremiumVariable(BigDecimal.valueOf(10.5));
        baseMetric.setAssetInstanceId(3L);

        assertEquals(Optional.of(1L), Optional.of(baseMetric.getId()));
        assertEquals(Optional.of(2L), Optional.of(baseMetric.getSelectedMetricId()));
        assertEquals("metric name", baseMetric.getSelectedMetricName());
        assertEquals(BigDecimal.valueOf(10.5), baseMetric.getInsurancePremiumVariable());
        assertEquals(3L, baseMetric.getAssetInstanceId());
    }

    @Test
     void testNoArgsConstructor() {
        BaseMetricDTO baseMetric = new BaseMetricDTO();

        assertNull(baseMetric.getId());
        assertNull(baseMetric.getSelectedMetricId());
        assertNull(baseMetric.getSelectedMetricName());
        assertNull(baseMetric.getInsurancePremiumVariable());
        assertEquals(0L, baseMetric.getAssetInstanceId());
    }

    @Test
     void testAllArgsConstructor() {
        Long id = 1L;
        Long selectedMetricId = 2L;
        String selectedMetricName = "metric name";
        BigDecimal insurancePremiumVariable = BigDecimal.valueOf(10.5);
        long assetInstanceId = 3L;

        BaseMetricDTO baseMetric = new BaseMetricDTO(id, selectedMetricId, selectedMetricName, insurancePremiumVariable, assetInstanceId);

        assertEquals(id, baseMetric.getId());
        assertEquals(selectedMetricId, baseMetric.getSelectedMetricId());
        assertEquals(selectedMetricName, baseMetric.getSelectedMetricName());
        assertEquals(insurancePremiumVariable, baseMetric.getInsurancePremiumVariable());
        assertEquals(assetInstanceId, baseMetric.getAssetInstanceId());
    }

    @Test
     void testToString() {
        BaseMetricDTO baseMetric = new BaseMetricDTO(1L, 2L, "metric name", BigDecimal.valueOf(10.5), 3L);

        String expectedToString = "BaseMetricDTO(id=1, selectedMetricId=2, selectedMetricName=metric name, insurancePremiumVariable=10.5, assetInstanceId=3)";
        assertEquals(expectedToString, baseMetric.toString());
    }

}