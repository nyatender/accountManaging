package com.siemens.digitalcockpit.domain.ddx;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class AccessDDXTokenThinksuranceTest {
    private AccessDDXToken accessDDXToken;
    @BeforeEach
    void setUp() {
        accessDDXToken = new AccessDDXToken();
    }

    @Test
     void testAccessTokenGetterAndSetter() {
        String expectedAccessToken = "myAccessToken";
        accessDDXToken.setAccessToken(expectedAccessToken);
        assertEquals(expectedAccessToken, accessDDXToken.getAccessToken());
    }

    @Test
     void testTokenTypeGetterAndSetter() {
        String expectedTokenType = "Bearer";
        accessDDXToken.setTokenType(expectedTokenType);
        assertEquals(expectedTokenType, accessDDXToken.getTokenType());
    }

    @Test
     void testExpiresInGetterAndSetter() {
        int expectedExpiresIn = 3600;
        accessDDXToken.setExpiresIn(expectedExpiresIn);
        assertEquals(expectedExpiresIn, accessDDXToken.getExpiresIn());
    }

    @Test
     void testScopeGetterAndSetter() {
        String expectedScope = "read write";
        accessDDXToken.setScope(expectedScope);
        assertEquals(expectedScope, accessDDXToken.getScope());
    }

    @Test
     void testJtiGetterAndSetter() {
        String expectedJti = "myJti";
        accessDDXToken.setJti(expectedJti);
        assertEquals(expectedJti, accessDDXToken.getJti());
    }

    @Test
     void testTimestampGetterAndSetter() {
        Long expectedTimestamp = System.currentTimeMillis();
        accessDDXToken.setTimestamp(expectedTimestamp);
        assertEquals(expectedTimestamp, accessDDXToken.getTimestamp());
    }

    @Test
     void testAccessTokenAllArgsConstructor() {
        String expectedAccessToken = "myAccessToken";
        String expectedTokenType = "Bearer";
        int expectedExpiresIn = 3600;
        String expectedScope = "read write";
        String expectedJti = "myJti";
        Long expectedTimestamp = System.currentTimeMillis();

        accessDDXToken = new AccessDDXToken(expectedAccessToken, expectedTokenType, expectedExpiresIn, expectedScope,
                expectedJti, expectedTimestamp);

        assertEquals(expectedAccessToken, accessDDXToken.getAccessToken());
        assertEquals(expectedTokenType, accessDDXToken.getTokenType());
        assertEquals(expectedExpiresIn, accessDDXToken.getExpiresIn());
        assertEquals(expectedScope, accessDDXToken.getScope());
        assertEquals(expectedJti, accessDDXToken.getJti());
        assertEquals(expectedTimestamp, accessDDXToken.getTimestamp());
    }

    @Test
     void testAccessTokenNoArgsConstructor() {
        assertNotNull(new AccessDDXToken());
    }
}