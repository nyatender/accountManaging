package com.siemens.digitalcockpit.domain.thinksurance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ProfessionsTest {
   private Professions professions;
    @BeforeEach
    void setUp() {
        professions = new Professions();
    }

    @Test
     void testProfessionsGetterAndSetter() {
        List<Professions.Profession> expectedProfessionList = new ArrayList<>();
        professions.setProfessionList(expectedProfessionList);
        assertEquals(expectedProfessionList, professions.getProfessionList());
    }

    @Test
     void testProfessionsAllArgsConstructor() {
        List<Professions.Profession> expectedProfessionList = new ArrayList<>();
        expectedProfessionList.add(new Professions.Profession(1, "Profession 1"));
        expectedProfessionList.add(new Professions.Profession(2, "Profession 2"));

        professions = new Professions(expectedProfessionList);
        assertEquals(expectedProfessionList, professions.getProfessionList());
    }

    @Test
     void testProfessionsNoArgsConstructor() {
        assertNotNull(new Professions());
    }

    @Test
     void testProfessionGetterAndSetter() {
        int expectedId = 1;
        String expectedName = "Profession";
        Professions.Profession profession = new Professions.Profession();

        profession.setId(expectedId);
        profession.setName(expectedName);

        assertEquals(expectedId, profession.getId());
        assertEquals(expectedName, profession.getName());
    }

    @Test
     void testProfessionAllArgsConstructor() {
        int expectedId = 1;
        String expectedName = "Profession";

        Professions.Profession profession = new Professions.Profession(expectedId, expectedName);

        assertEquals(expectedId, profession.getId());
        assertEquals(expectedName, profession.getName());
    }

    @Test
     void testProfessionNoArgsConstructor() {
        assertNotNull(new Professions.Profession());
    }
}