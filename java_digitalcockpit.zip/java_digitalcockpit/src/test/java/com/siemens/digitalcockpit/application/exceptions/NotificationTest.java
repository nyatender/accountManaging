package com.siemens.digitalcockpit.application.exceptions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;

 class NotificationTest {
    @Test
     void testSerialization() throws JsonProcessingException {
        Notification notification = new Notification("field1", "message1");

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(notification);

        String expectedJson = "{\"field\":\"field1\",\"message\":\"message1\"}";
        Assertions.assertEquals(expectedJson, json);
    }

    @Test
     void testDeserialization() throws IOException {
        String json = "{\"field\":\"field2\",\"message\":\"message2\"}";

        ObjectMapper objectMapper = new ObjectMapper();
        Notification notification = objectMapper.readValue(json, Notification.class);

        Notification expectedNotification = new Notification("field2", "message2");
        Assertions.assertEquals(expectedNotification, notification);
    }

    @Test
     void testEqualsAndHashCode() {
        Notification notification1 = new Notification("field3", "message3");
        Notification notification2 = new Notification("field3", "message3");

        Assertions.assertEquals(notification1, notification2);
        Assertions.assertEquals(notification1.hashCode(), notification2.hashCode());
    }

    @Test
     void testToString() {
        Notification notification = new Notification("field4", "message4");

        String expectedToString = "Notification(field=field4, message=message4)";
        Assertions.assertEquals(expectedToString, notification.toString());
    }
}