package com.siemens.digitalcockpit.application.queries.getcontractbyid;

import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyAddressDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyBillingDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyDetailResponseDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

 class CompanyDetailResponseDTOTest {
    @Test
     void testGettersAndSetters() {
        String contactEmail = "contact@example.com";
        String companyName = "Example Company";
        boolean useCompanyAddress = true;
        String description = "Example Description";
        Long contractOwnerId = 123L;
        CompanyAddressDTO companyAddress = new CompanyAddressDTO();
        CompanyBillingDataDTO companyBillingData = new CompanyBillingDataDTO();

        CompanyDetailResponseDTO dto = new CompanyDetailResponseDTO();
        dto.setContactEmail(contactEmail);
        dto.setCompanyName(companyName);
        dto.setUseCompanyAddress(useCompanyAddress);
        dto.setDescription(description);
        dto.setContractOwnerId(contractOwnerId);
        dto.setCompanyAddress(companyAddress);
        dto.setCompanyBillingData(companyBillingData);

        Assertions.assertEquals(contactEmail, dto.getContactEmail());
        Assertions.assertEquals(companyName, dto.getCompanyName());
        Assertions.assertEquals(useCompanyAddress, dto.isUseCompanyAddress());
        Assertions.assertEquals(description, dto.getDescription());
        Assertions.assertEquals(contractOwnerId, dto.getContractOwnerId());
        Assertions.assertEquals(companyAddress, dto.getCompanyAddress());
        Assertions.assertEquals(companyBillingData, dto.getCompanyBillingData());
    }

    @Test
     void testEqualsAndHashCode() {
        CompanyDetailResponseDTO dto1 = new CompanyDetailResponseDTO();
        dto1.setContactEmail("contact@example.com");

        CompanyDetailResponseDTO dto2 = new CompanyDetailResponseDTO();
        dto2.setContactEmail("contact@example.com");

        CompanyDetailResponseDTO dto3 = new CompanyDetailResponseDTO();
        dto3.setContactEmail("another@example.com");

        Assertions.assertEquals(dto1, dto2);
        Assertions.assertNotEquals(dto1, dto3);

        Assertions.assertEquals(dto1.hashCode(), dto2.hashCode());
        Assertions.assertNotEquals(dto1.hashCode(), dto3.hashCode());
    }
}