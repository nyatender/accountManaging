package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

 class BaseModelDTOTest {

     BaseModelDTO baseModelDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        baseModelDTO = new BaseModelDTO();
    }
    @Test
     void testNoArgsConstructor() {
        BaseModelDTO baseModel = new BaseModelDTO();

        assertNull(baseModel.getId());
        assertNull(baseModel.getCreationDate());
        assertNull(baseModel.getUpdatedDate());
        assertNull(baseModel.getCreatedBy());
        assertNull(baseModel.getUpdatedBy());
    }

    @Test
     void testAllArgsConstructor() {
        Long id = 1L;
        LocalDateTime creationDate = LocalDateTime.now();
        LocalDateTime updatedDate = LocalDateTime.now();
        String createdBy = "John";
        String updatedBy = "Jane";

        BaseModelDTO baseModel = new BaseModelDTO(id, creationDate, updatedDate, createdBy, updatedBy);

        assertEquals(id, baseModel.getId());
        assertEquals(creationDate, baseModel.getCreationDate());
        assertEquals(updatedDate, baseModel.getUpdatedDate());
        assertEquals(createdBy, baseModel.getCreatedBy());
        assertEquals(updatedBy, baseModel.getUpdatedBy());
    }

    @Test
    void testSetCreationDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModelDTO.setCreationDate(expectedDateTime);
        assertEquals(expectedDateTime, baseModelDTO.getCreationDate());
    }

    @Test
    void testGetUpdatedDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModelDTO.setUpdatedDate(expectedDateTime);
        LocalDateTime actualDateTime = baseModelDTO.getUpdatedDate();
        assertEquals(expectedDateTime, actualDateTime);
    }

    @Test
    void testSetUpdatedDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModelDTO.setUpdatedDate(expectedDateTime);
        assertEquals(expectedDateTime, baseModelDTO.getUpdatedDate());
    }

    @Test
    void testGetCreatedBy() {
        String expectedCreatedBy = "John";
        baseModelDTO.setCreatedBy(expectedCreatedBy);
        String actualCreatedBy = baseModelDTO.getCreatedBy();
        assertEquals(expectedCreatedBy, actualCreatedBy);
    }

    @Test
    void testSetCreatedBy() {
        String expectedCreatedBy = "John";
        baseModelDTO.setCreatedBy(expectedCreatedBy);
        assertEquals(expectedCreatedBy, baseModelDTO.getCreatedBy());
    }

    @Test
    void testGetUpdatedBy() {
        String expectedUpdatedBy = "Jane";
        baseModelDTO.setUpdatedBy(expectedUpdatedBy);
        String actualUpdatedBy = baseModelDTO.getUpdatedBy();
        assertEquals(expectedUpdatedBy, actualUpdatedBy);
    }

    @Test
    void testSetUpdatedBy() {
        String expectedUpdatedBy = "Jane";
        baseModelDTO.setUpdatedBy(expectedUpdatedBy);
        assertEquals(expectedUpdatedBy, baseModelDTO.getUpdatedBy());
    }

}