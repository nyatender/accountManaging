package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
 class AssetInstanceStatusTest {

    @Test
     void testConnectedStatus() {
        AssetInstanceStatus status = AssetInstanceStatus.CONNECTED;
        assertEquals("CONNECTED", status.name());
        assertEquals(0, status.ordinal());
    }

    @Test
     void testNotConnectedStatus() {
        AssetInstanceStatus status = AssetInstanceStatus.NOT_CONNECTED;
        assertEquals("NOT_CONNECTED", status.name());
        assertEquals(1, status.ordinal());
    }
}