package com.siemens.digitalcockpit.application.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.DashboardDataDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

 class DashboardDataDTOTest {
    @Test
     void testGettersAndSetters() {
        Long totalAssets = 100L;
        Long insuredAssets = 50L;
        Long tobeInsuredAssets = 25L;

        DashboardDataDTO dto = new DashboardDataDTO();
        dto.setTotalAssets(totalAssets);
        dto.setInsuredAssets(insuredAssets);
        dto.setTobeInsuredAssets(tobeInsuredAssets);

        Assertions.assertEquals(totalAssets, dto.getTotalAssets());
        Assertions.assertEquals(insuredAssets, dto.getInsuredAssets());
        Assertions.assertEquals(tobeInsuredAssets, dto.getTobeInsuredAssets());
    }

}