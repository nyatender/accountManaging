package com.siemens.digitalcockpit.application.queries.getcontractbyid;


import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.CompanyBillingDataDTO;
import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.Currency;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

 class CompanyBillingDataDTOTest {

    @Test
     void testGettersAndSetters() {
        String invoiceEmail = "billing@example.com";
        String shippingMethod = "Express";
        String bankName = "Example Bank";
        String accountName = "Example Account";
        String IBAN = "123456789";
        String swiftCode = "SWIFT123";
        Currency currency = Currency.USD;

        CompanyBillingDataDTO dto = new CompanyBillingDataDTO();
        dto.setInvoiceEmail(invoiceEmail);
        dto.setShippingMethod(shippingMethod);
        dto.setBankName(bankName);
        dto.setAccountName(accountName);
        dto.setIban(IBAN);
        dto.setSwiftCode(swiftCode);
        dto.setCurrency(currency);

        Assertions.assertEquals(invoiceEmail, dto.getInvoiceEmail());
        Assertions.assertEquals(shippingMethod, dto.getShippingMethod());
        Assertions.assertEquals(bankName, dto.getBankName());
        Assertions.assertEquals(accountName, dto.getAccountName());
        Assertions.assertEquals(IBAN, dto.getIban());
        Assertions.assertEquals(swiftCode, dto.getSwiftCode());
        Assertions.assertEquals(currency, dto.getCurrency());
    }

    @Test
     void testEqualsAndHashCode() {
        CompanyBillingDataDTO dto1 = new CompanyBillingDataDTO();
        dto1.setInvoiceEmail("billing@example.com");

        CompanyBillingDataDTO dto2 = new CompanyBillingDataDTO();
        dto2.setInvoiceEmail("billing@example.com");

        CompanyBillingDataDTO dto3 = new CompanyBillingDataDTO();
        dto3.setInvoiceEmail("billing2@example.com");

        Assertions.assertEquals(dto1, dto2);
        Assertions.assertNotEquals(dto1, dto3);

        Assertions.assertEquals(dto1.hashCode(), dto2.hashCode());
        Assertions.assertNotEquals(dto1.hashCode(), dto3.hashCode());
    }
}