//package com.siemens.digitalcockpit.infrastrucure.model;
//
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//import java.time.LocalDateTime;
//
// class MindSphereEntityTest {
//    @Test
//     void testGettersAndSetters() {
//        Long id = 123L;
//        String name = "Entity Name";
//        LocalDateTime creationDate = LocalDateTime.of(2022, 1, 1, 0, 0, 0);
//        LocalDateTime updatedDate = LocalDateTime.of(2022, 1, 2, 0, 0, 0);
//        String createdBy = "John";
//        String updatedBy = "Jane";
//
//        MindSphereEntity entity = new MindSphereEntity();
//        entity.setId(id);
//        entity.setName(name);
//        entity.setCreationDate(creationDate);
//        entity.setUpdatedDate(updatedDate);
//        entity.setCreatedBy(createdBy);
//        entity.setUpdatedBy(updatedBy);
//
//        Assertions.assertEquals(id, entity.getId());
//        Assertions.assertEquals(name, entity.getName());
//        Assertions.assertEquals(creationDate, entity.getCreationDate());
//        Assertions.assertEquals(updatedDate, entity.getUpdatedDate());
//        Assertions.assertEquals(createdBy, entity.getCreatedBy());
//        Assertions.assertEquals(updatedBy, entity.getUpdatedBy());
//    }
//
//}