package com.siemens.digitalcockpit.domain.common;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(MockitoJUnitRunner.class)
class BaseModelTest {

    public BaseModel baseModel;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        baseModel = new BaseModel();
    }

    @Test
     void testNoArgConstructor() {
        BaseModel model = new BaseModel();
        assertEquals(null, model.getCreationDate());
        assertEquals(null, model.getUpdatedDate());
        assertEquals(null, model.getCreatedBy());
        assertEquals(null, model.getUpdatedBy());
    }

    @Test
     void testAllArgConstructor() {
        LocalDateTime creationDate = LocalDateTime.now();
        LocalDateTime updatedDate = LocalDateTime.now().plusDays(1);
        String createdBy = "John";
        String updatedBy = "Jane";

        BaseModel model = new BaseModel(creationDate, updatedDate, createdBy, updatedBy);
        assertEquals(creationDate, model.getCreationDate());
        assertEquals(updatedDate, model.getUpdatedDate());
        assertEquals(createdBy, model.getCreatedBy());
        assertEquals(updatedBy, model.getUpdatedBy());
    }

    @Test
     void testGetCreationDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModel.setCreationDate(expectedDateTime);
        LocalDateTime actualDateTime = baseModel.getCreationDate();
        assertEquals(expectedDateTime, actualDateTime);
    }

    @Test
     void testSetCreationDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModel.setCreationDate(expectedDateTime);
        assertEquals(expectedDateTime, baseModel.getCreationDate());
    }

    @Test
     void testGetUpdatedDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModel.setUpdatedDate(expectedDateTime);
        LocalDateTime actualDateTime = baseModel.getUpdatedDate();
        assertEquals(expectedDateTime, actualDateTime);
    }

    @Test
     void testSetUpdatedDate() {
        LocalDateTime expectedDateTime = LocalDateTime.now();
        baseModel.setUpdatedDate(expectedDateTime);
        assertEquals(expectedDateTime, baseModel.getUpdatedDate());
    }

    @Test
     void testGetCreatedBy() {
        String expectedCreatedBy = "John";
        baseModel.setCreatedBy(expectedCreatedBy);
        String actualCreatedBy = baseModel.getCreatedBy();
        assertEquals(expectedCreatedBy, actualCreatedBy);
    }

    @Test
     void testSetCreatedBy() {
        String expectedCreatedBy = "John";
        baseModel.setCreatedBy(expectedCreatedBy);
        assertEquals(expectedCreatedBy, baseModel.getCreatedBy());
    }

    @Test
     void testGetUpdatedBy() {
        String expectedUpdatedBy = "Jane";
        baseModel.setUpdatedBy(expectedUpdatedBy);
        String actualUpdatedBy = baseModel.getUpdatedBy();
        assertEquals(expectedUpdatedBy, actualUpdatedBy);
    }

    @Test
     void testSetUpdatedBy() {
        String expectedUpdatedBy = "Jane";
        baseModel.setUpdatedBy(expectedUpdatedBy);
        assertEquals(expectedUpdatedBy, baseModel.getUpdatedBy());
    }
}