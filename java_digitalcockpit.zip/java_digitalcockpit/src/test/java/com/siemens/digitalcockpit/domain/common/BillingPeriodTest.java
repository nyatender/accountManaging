package com.siemens.digitalcockpit.domain.common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class BillingPeriodTest {
    @Test
     void testMonthlyEnum() {
        BillingPeriod billingPeriod = BillingPeriod.MONTHLY;
        assertNotNull(billingPeriod);
        assertEquals("MONTHLY", billingPeriod.name());
        assertEquals(0, billingPeriod.ordinal());
    }

    @Test
     void testQuarterlyEnum() {
        BillingPeriod billingPeriod = BillingPeriod.QUARTERLY;
        assertNotNull(billingPeriod);
        assertEquals("QUARTERLY", billingPeriod.name());
        assertEquals(1, billingPeriod.ordinal());
    }

    @Test
     void testSemiAnnuallyEnum() {
        BillingPeriod billingPeriod = BillingPeriod.SEMIANNUALLY;
        assertNotNull(billingPeriod);
        assertEquals("SEMIANNUALLY", billingPeriod.name());
        assertEquals(2, billingPeriod.ordinal());
    }

    @Test
     void testAnnuallyEnum() {
        BillingPeriod billingPeriod = BillingPeriod.ANNUALLY;
        assertNotNull(billingPeriod);
        assertEquals("ANNUALLY", billingPeriod.name());
        assertEquals(3, billingPeriod.ordinal());
    }
}