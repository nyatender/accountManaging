package com.siemens.digitalcockpit.application.models;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

 class MetricDTOTest {
    @Test
     void testNoArgsConstructor() {
        MetricDTO metric = new MetricDTO();

        assertNull(metric.getId());
        assertNull(metric.getSelectedMetricId());
        assertNull(metric.getSelectedMetricName());
        assertNull(metric.getInsurancePremiumVariable());
        assertEquals(0L, metric.getAssetInstanceId());
    }

}