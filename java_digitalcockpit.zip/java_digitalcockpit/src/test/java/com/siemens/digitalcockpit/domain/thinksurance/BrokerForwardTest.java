package com.siemens.digitalcockpit.domain.thinksurance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BrokerForwardTest {
    private BrokerForward brokerForward;

    @BeforeEach
    void setUp() {
        brokerForward = new BrokerForward();
    }

    @Test
    void getUrl() {
        String expectedUrl = "https://example.com";
        brokerForward.setUrl(expectedUrl);
        String actualUrl = brokerForward.getUrl();
        assertEquals(expectedUrl, actualUrl);
    }

    @Test
    void setUrl() {
        String expectedUrl = "https://example.com";
        brokerForward.setUrl(expectedUrl);
        assertEquals(expectedUrl, brokerForward.getUrl());
    }
}