package com.siemens.digitalcockpit.application.models;


import com.siemens.digitalcockpit.application.usecases.queries.getcontractbyid.Currency;
import org.junit.jupiter.api.Test;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

import static org.junit.Assert.*;

 class BillingDTOTest {
    @Test
     void testNoArgsConstructor() {
        BillingDTO billingDTO = new BillingDTO();

        assertNull(billingDTO.getId());
        assertNull(billingDTO.getBillingPeriod());
        assertEquals(Currency.EUR.toString(), billingDTO.getCurrency());
        assertNull(billingDTO.getContributionBasis());
        assertNull(billingDTO.getDeductible());
        assertEquals(0, billingDTO.getContractId());
    }

    @Test
     void testAllArgsConstructor() {
        Long id = 1L;
        String billingPeriod = "Monthly";
        String currency = "USD";
        BigDecimal contributionBasis = new BigDecimal("100.00");
        BigDecimal deductible = new BigDecimal("10.00");
        long contractId = 2L;

        BillingDTO billingDTO = new BillingDTO(id, billingPeriod, currency, contributionBasis, deductible, contractId);

        assertEquals(id, billingDTO.getId());
        assertEquals(billingPeriod, billingDTO.getBillingPeriod());
        assertEquals(currency, billingDTO.getCurrency());
        assertEquals(contributionBasis, billingDTO.getContributionBasis());
        assertEquals(deductible, billingDTO.getDeductible());
        assertEquals(contractId, billingDTO.getContractId());
    }

    @Test
     void testGetterAndSetterId() {
        BillingDTO billingDTO = new BillingDTO();
        assertNull(billingDTO.getId());

        Long id = 1L;
        billingDTO.setId(id);
        assertEquals(id, billingDTO.getId());
    }

    @Test
     void testGetterAndSetterBillingPeriod() {
        BillingDTO billingDTO = new BillingDTO();
        assertNull(billingDTO.getBillingPeriod());

        String billingPeriod = "Monthly";
        billingDTO.setBillingPeriod(billingPeriod);
        assertEquals(billingPeriod, billingDTO.getBillingPeriod());
    }

    @Test
     void testGetterAndSetterCurrency() {
        BillingDTO billingDTO = new BillingDTO();
        assertEquals(Currency.EUR.toString(), billingDTO.getCurrency());

        String currency = "USD";
        billingDTO.setCurrency(currency);
        assertEquals(currency, billingDTO.getCurrency());
    }

    @Test
     void testGetterAndSetterContributionBasis() {
        BillingDTO billingDTO = new BillingDTO();
        assertNull(billingDTO.getContributionBasis());

        BigDecimal contributionBasis = new BigDecimal("100.00");
        billingDTO.setContributionBasis(contributionBasis);
        assertEquals(contributionBasis, billingDTO.getContributionBasis());
    }

    @Test
     void testGetterAndSetterDeductible() {
        BillingDTO billingDTO = new BillingDTO();
        assertNull(billingDTO.getDeductible());

        BigDecimal deductible = new BigDecimal("10.00");
        billingDTO.setDeductible(deductible);
        assertEquals(deductible, billingDTO.getDeductible());
    }

    @Test
     void testGetterAndSetterContractId() {
        BillingDTO billingDTO = new BillingDTO();
        assertEquals(0, billingDTO.getContractId());

        long contractId = 2L;
        billingDTO.setContractId(contractId);
        assertEquals(contractId, billingDTO.getContractId());
    }

    @Test
     void testValidationConstraints() throws NoSuchFieldException {
        BillingDTO billingDTO = new BillingDTO();

        assertNotNull(billingDTO.getClass().getDeclaredField("billingPeriod").getDeclaredAnnotation(NotNull.class));
        assertNotNull(billingDTO.getClass().getDeclaredField("currency").getDeclaredAnnotation(NotNull.class));
        assertNotNull(billingDTO.getClass().getDeclaredField("contributionBasis").getDeclaredAnnotation(NotNull.class));
        assertNotNull(billingDTO.getClass().getDeclaredField("deductible").getDeclaredAnnotation(NotNull.class));
        assertNull(billingDTO.getClass().getDeclaredField("contractId").getDeclaredAnnotation(NotNull.class));
    }
}