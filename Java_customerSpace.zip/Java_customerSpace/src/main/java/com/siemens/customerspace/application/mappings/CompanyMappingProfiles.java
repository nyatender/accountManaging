package com.siemens.customerspace.application.mappings;



import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.usecase.company.commands.updatecompany.UpdateCompanyCommand;
import com.siemens.customerspace.application.usecase.company.queries.getcompanies.CompanyResponseDTO;
import com.siemens.customerspace.domain.entities.Company;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

public class CompanyMappingProfiles {

    public CompletableFuture<CompanyResponseDTO> mapToCompanyDTO(Company company) throws CompanyNotFoundException {
        try {
            if (company == null) {
                return null;
            }
            CompanyResponseDTO companyResponseDTO = new CompanyResponseDTO();
            companyResponseDTO.setCompanyName(company.getCompanyName());
            companyResponseDTO.setGeneralEmailId(company.getGeneralEmailId());
            companyResponseDTO.setCountry(company.getCountry());
            companyResponseDTO.setTelephone(company.getTelephone());
            companyResponseDTO.setZipCode(company.getZipCode());
            companyResponseDTO.setAddress(company.getAddress());
            companyResponseDTO.setId(company.getId());
            companyResponseDTO.setUserCount(company.getUserCount());
            companyResponseDTO.setCreatedBy(company.getCreatedBy());
            companyResponseDTO.setCreationDate(company.getCreationDate());
            companyResponseDTO.setUpdatedBy(company.getUpdatedBy());
            companyResponseDTO.setUpdatedDate(company.getUpdatedDate());
            return CompletableFuture.completedFuture(companyResponseDTO);
        }
        catch (Exception e){
            throw new CompanyNotFoundException("Unable to map Company Entity to Company DTO");
        }
    }

        public CompletableFuture<Company> mapToCompany(UpdateCompanyCommand companyResponseDTO) throws CompanyNotFoundException {
        try {
            if (companyResponseDTO == null) {
                return null;
            }
            Company company = new Company();
            company.setId(companyResponseDTO.getId());
            company.setCompanyName(companyResponseDTO.getCompanyName());
            company.setAddress(companyResponseDTO.getAddress());
            company.setGeneralEmailId(companyResponseDTO.getGeneralEmailId());
            company.setTelephone(companyResponseDTO.getTelephone());
            company.setUpdatedBy(companyResponseDTO.getUpdatedBy());
            company.setCreatedBy(companyResponseDTO.getCreatedBy());
            company.setCreationDate(companyResponseDTO.getCreationDate());
            company.setUpdatedDate(LocalDateTime.now());
            company.setCountry(companyResponseDTO.getCountry());
            company.setZipCode(companyResponseDTO.getZipCode());
            company.setUpdatedDate(LocalDateTime.now());
            return CompletableFuture.completedFuture(company);
        }
        catch (Exception e){
            throw new CompanyNotFoundException("Unable to map Company DTO to Company Entity");
        }
    }
}
