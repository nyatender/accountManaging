package com.siemens.customerspace.application.usecase.companymapping.commands.updatemindsphereddxmapping;


import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

@Slf4j
public class UpdateMindSphereCompanyMappingCommandHandler {

    private ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository;

    @Autowired
    public UpdateMindSphereCompanyMappingCommandHandler(ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository){
        this.iCompanyConfigAsyncRepository = iCompanyConfigAsyncRepository;
    }

    @Transactional
    public CompletableFuture<MindSphereCompanyMapping> updateMindSphereDdxCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
        try {
            CompletableFuture<MindSphereCompanyMapping> mindSphereToken = this.iCompanyConfigAsyncRepository.updateMindSphereCompanyMapping(mindSphereCompanyMapping);
            log.info("MindSphere Token updated successfully");
            return mindSphereToken;
        } catch (CompanyNotFoundException e) {
            throw new CompanyNotFoundException(e.getMessage());
        }
    }
}
