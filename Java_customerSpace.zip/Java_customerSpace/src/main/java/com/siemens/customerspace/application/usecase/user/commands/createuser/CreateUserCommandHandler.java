package com.siemens.customerspace.application.usecase.user.commands.createuser;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.mappings.UserMappingProfiles;
import com.siemens.customerspace.application.usecase.user.queries.getusers.UserResponseDTO;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class CreateUserCommandHandler {

    private final IUserAsyncRepository iUserAsyncRepository;
    private final UserMappingProfiles userMappingProfiles;

    @Autowired
    public CreateUserCommandHandler(IUserAsyncRepository iUserAsyncRepository, UserMappingProfiles userMappingProfiles){
        this.iUserAsyncRepository = iUserAsyncRepository;
        this.userMappingProfiles = userMappingProfiles;
    }

    @Transactional
    public CompletableFuture<Long> createUser(CreateUserCommand request) throws UserNotFoundException, InterruptedException {
        try {
            User user = new User(
                    request.getName(), request.getEmailAddress(),
                    request.getPhoneNumber(), request.getCompanyId(),null
            );
            setBaseProperties(request, user);
            CompletableFuture<User> createdUser = this.iUserAsyncRepository.createUser(user);
            CompletableFuture<UserResponseDTO> createdUserResponseDTO = this.userMappingProfiles.mapToUserDTO(createdUser.get());
            log.info("User created successfully");
            return CompletableFuture.completedFuture(createdUserResponseDTO.get().getId());
        } catch (UserNotFoundException |  ExecutionException e) {
            log.error("Unable to create User");
            throw new UserNotFoundException(e.getMessage());
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }

    }

    private static void setBaseProperties(CreateUserCommand request, User user) {
        user.setCreatedBy(request.getCreatedBy());
        user.setUpdatedBy(request.getUpdatedBy());
        user.setCreationDate(LocalDateTime.now());
        user.setUpdatedDate(LocalDateTime.now());
    }
}
