package com.siemens.customerspace.infrastructure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "users",uniqueConstraints={@UniqueConstraint(columnNames={"id","email_address"})})
@NoArgsConstructor
@Getter
@Setter
public class UserEntity extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq_v1")
    @SequenceGenerator(name = "user_seq_v2", sequenceName = "user_seq_v2", allocationSize = 1)
    public Long id;

    @Column(name="name",length = 50)
    @NotEmpty
    private String name;

    @Column(name="email_address",length = 50)
    @NotEmpty
    private String emailAddress;

    @Column(name="phone_number",length = 50)
    @NotEmpty
    private String phoneNumber;


    @Column(name="company_id",length = 50)
    @NotNull
    private Long companyId;

    @Transient
    private String companyName;

    public String getCompanyName() {
        return companyName;
    }

}
