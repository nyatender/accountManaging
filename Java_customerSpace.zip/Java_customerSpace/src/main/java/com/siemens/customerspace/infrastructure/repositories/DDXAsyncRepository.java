package com.siemens.customerspace.infrastructure.repositories;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.customerspace.application.contracts.repositories.IDDXAsyncRepository;
import com.siemens.customerspace.application.exceptions.ClientException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.infrastructure.persistence.MindSphereDdxCompanyMappingContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class DDXAsyncRepository implements IDDXAsyncRepository {

    private @Value("${ddx.loginuri}") String ddxtokenuri;

    private @Value("${ddx.auth}") String auth;
    private @Value("${ddx.mindsphereloginuri}") String mindsphereloginuri;
    private @Value("${ddx.mindsphereauth}") String mindsphereAuth;

    private RestTemplate restTemplate= new RestTemplate();

    private final MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext;


    @Autowired
    public DDXAsyncRepository(MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext){
       this.mindSphereDdxCompanyMappingContext = mindSphereDdxCompanyMappingContext;
    }

    @Override
    public CompletableFuture<JsonNode> getDDXLoginToken(JsonNode mindSphereConfig) throws ClientException, InterruptedException, ExecutionException {
        try {
            JsonNode responseToken = this.handleGetEntityForDDX(ddxtokenuri,mindSphereConfig).get();
            return CompletableFuture.completedFuture(responseToken);
        } catch (ClientException e) {
            log.error(Constants.DDX_TOKEN_FAILED);
            throw new ClientException(ddxtokenuri,HttpStatus.NOT_FOUND.value(), e);
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException ex) {
            throw new InterruptedException(ex.getMessage());
        }
    }

    @Override
    public CompletableFuture<JsonNode> getMindSphereLoginToken() throws ConnectException, InterruptedException {
        try {
            Map<String ,String > valueMap = new HashMap<>();
            valueMap.put(Constants.GRANT_TYPE, Constants.GRANT_TYPE_CLIENT_CREDENTIALS);
            valueMap.put(Constants.APP_NAME, Constants.APP_NAME_VALUE);
            valueMap.put(Constants.APP_VERSION, Constants.APP_VERSION_VALUE);
            valueMap.put(Constants.HOST_TENANT, Constants.HOST_TENANT_VALUE);
            valueMap.put(Constants.USER_TENANT, Constants.HOST_TENANT_VALUE);
            JsonNode responseToken = this.handleMindsphereToken(valueMap, mindsphereloginuri, JsonNode.class).get();
            log.info("MindSphere Token retrieved successfully : "+responseToken);
            return CompletableFuture.completedFuture(responseToken);
        } catch (ExecutionException e ) {
            log.error(Constants.MINDSPHERE_TOKEN_FAILED);
            throw new ConnectException(Constants.MINDSPHERE_TOKEN_FAILED);
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }

    private CompletableFuture<JsonNode> handleGetEntityForDDX(String uri, JsonNode mindSphereConfig) throws ClientException, InterruptedException {
        JsonNode response = null;
        try {
            HttpHeaders headers = this.getDdxHeaders(mindSphereConfig).get();
            HttpEntity<String> httpEntity = new HttpEntity<>(headers);
            String fullUrl = null;
            response = getDDXToken(uri, httpEntity, fullUrl);
        } catch (ClientException | ExecutionException e) {
            throw new ClientException(uri,HttpStatus.NOT_FOUND.value(), e);
        } catch (InterruptedException exception){
            throw new InterruptedException(exception.getMessage());
        }
        return CompletableFuture.completedFuture(response);
    }

    private JsonNode getDDXToken(String uri, HttpEntity<String> httpEntity, String fullUrl) throws InterruptedException, ExecutionException {
        JsonNode response;
        try {
            fullUrl = this.buildURIForddx(uri).get();
            log.info(fullUrl);
            CompletableFuture<ResponseEntity<JsonNode>> responseEntity = CompletableFuture.completedFuture(this.restTemplate.exchange(fullUrl, HttpMethod.GET, httpEntity, JsonNode.class));
            response = responseEntity.get().getBody();
        } catch (RestClientResponseException ex) {
            log.error(Constants.MIND_SPHERE_SERVER_ERROR);
            throw new ClientException(fullUrl != null ? fullUrl : "", ex.getRawStatusCode(), ex);
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException exception) {
            throw new InterruptedException(exception.getMessage());
        }
        return response;
    }

    private  <R, T> CompletableFuture<T> handleMindsphereToken(R request, String uri, Class<T> responseType) throws ExecutionException, InterruptedException, ConnectException {
        T response = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            if (Constants.MINDSPEHERE_HEADER != null) {
                headers.add(Constants.MINDSPEHERE_HEADER, this.decryptPassword(mindsphereAuth).get());
            }
            HttpEntity<R> httpEntity = new HttpEntity<>(request, headers);
            String fullUrl = null;
            response = getMindSphereToken(uri, responseType, httpEntity, fullUrl);
        } catch (ExecutionException e) {
            log.error(e.getMessage());
            throw new ExecutionException(e);
        } catch (ConnectException e) {
            throw new ConnectException(e.getMessage());
        }
        return CompletableFuture.completedFuture(response);
    }

    private <R, T> T getMindSphereToken(String uri, Class<T> responseType, HttpEntity<R> httpEntity, String fullUrl) throws InterruptedException, ExecutionException, ConnectException {
        T response;
        try {
            fullUrl = this.buildURIForMindsphere(uri).get();
            log.info("Full uri : {},", fullUrl);
            CompletableFuture<ResponseEntity<T>> responseEntity = CompletableFuture.completedFuture(this.restTemplate.postForEntity(fullUrl, httpEntity, responseType));
            response = responseEntity.get().getBody();
        } catch (RestClientResponseException ex) {
            log.info("Rest Client exception in post");
            log.error("Exceptions while calling login url....{}", ex.toString());
            throw new ClientException(fullUrl, ex.getRawStatusCode(), ex);
        } catch (ResourceAccessException ex) {
            log.info("Rest Resource exception in post" + ex.toString().substring(0, 100));
            throw new ClientException(fullUrl, 404, ex);
        } catch (ExecutionException e) {
            log.error(e.getMessage());
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            log.error(e.getMessage());
            throw new InterruptedException(e.getMessage());
        } catch (ConnectException e) {
            throw new ConnectException(e.getMessage());
        }
        return response;
    }

    private CompletableFuture<HttpHeaders> getDdxHeaders(JsonNode mindSphereConfig) throws InterruptedException, ExecutionException {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(Constants.LOGIN_HEADER, this.decryptPassword(auth).get());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Constants.BEARER);
            stringBuilder.append(mindSphereConfig.get("access_token").textValue());
            headers.add(Constants.AUTH_HEADER, stringBuilder.toString());
            return CompletableFuture.completedFuture(headers);
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    private CompletableFuture<String> buildURIForMindsphere(String apiPath) throws ConnectException {
        try {
            StringBuilder builder = new StringBuilder();
            if (apiPath != null) {
                builder.append(apiPath);
            }
            return CompletableFuture.completedFuture(builder.toString());
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ConnectException(Constants.DDX_HEADER_ERROR);
        }
    }

    private CompletableFuture<String> buildURIForddx(String apiPath) {
        StringBuilder sb = new StringBuilder();
        if (apiPath != null) {
            sb.append(apiPath);
        }
        return CompletableFuture.completedFuture(sb.toString());
    }

    private CompletableFuture<String> decryptPassword(String value) {
        byte[] actualPassword = null;
        try {
            IvParameterSpec iv = new IvParameterSpec(Constants.INIT_VECTOR_KEY.getBytes(StandardCharsets.UTF_8));
            SecretKeySpec keySpec = new SecretKeySpec(Constants.KEY.getBytes(StandardCharsets.UTF_8), Constants.AES);
            Cipher cipher = Cipher.getInstance(Constants.ENCODING_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, iv);
            actualPassword = cipher.doFinal(Base64.decodeBase64(value));
        } catch (InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException |
                 BadPaddingException | NoSuchPaddingException | NoSuchAlgorithmException e) {
            log.error(e.toString());
        }
        return CompletableFuture.completedFuture(new String(actualPassword));
    }
}
