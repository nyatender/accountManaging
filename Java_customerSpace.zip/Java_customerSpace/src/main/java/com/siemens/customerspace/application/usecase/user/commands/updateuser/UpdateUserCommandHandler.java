package com.siemens.customerspace.application.usecase.user.commands.updateuser;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.mappings.UserMappingProfiles;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class UpdateUserCommandHandler {

    private final IUserAsyncRepository iUserAsyncRepository;
    private final UserMappingProfiles userMappingProfiles;
    @Autowired
    public UpdateUserCommandHandler(IUserAsyncRepository iUserAsyncRepository, UserMappingProfiles userMappingProfiles) {
        this.iUserAsyncRepository = iUserAsyncRepository;
        this.userMappingProfiles = userMappingProfiles;
    }
    @Transactional
    public CompletableFuture<User> updateUser(UpdateUserCommand request) throws Exception {

        try {
            CompletableFuture<Optional<User>> userById = this.iUserAsyncRepository.getUserById(request.getId());
            if (userById.get().isEmpty()) {
                throw new UserNotFoundException(Constants.USER_NOT_FOUND);
            }
            request.setCreationDate(userById.get().get().getCreationDate());
            CompletableFuture<User> user = this.userMappingProfiles.mapToUser(request) ;
            CompletableFuture<User> updatedUser = this.iUserAsyncRepository.updateUser(user.get());
            log.info("User details updated successfully");
            return CompletableFuture.completedFuture(updatedUser.get());
        } catch (UserNotFoundException | RuntimeException | ExecutionException e) {
            log.error(Constants.USER_UPDATE_FAILED);
            throw new UserNotFoundException(e.getMessage());
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }
}
