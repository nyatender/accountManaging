package com.siemens.customerspace.application.paging;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SortParamConverter implements ParamConverter<Sort> {

  public static final String REGEX_ASC_DESC_CHAR = "^[+-]";
  public static final String ASC_PREFIX = "-";

  @Override
  public Sort fromString(String s) {
    if (StringUtils.isBlank(s)) {
      return Sort.unsorted();
    }
    List<Order> orders =
            Stream.of(s.split(","))
                    .map(String::trim)
                    .map(this::convertToOrder)
                    .flatMap(Optional::stream)
                    .collect(Collectors.toList());
    return Sort.by(orders);
  }

  private Optional<Order> convertToOrder(String token) {
    if (StringUtils.isBlank(token)) {
      return Optional.empty();
    }
    Direction direction = token.startsWith(ASC_PREFIX) ? Direction.DESC : Direction.ASC;
    String property = token.replaceAll(REGEX_ASC_DESC_CHAR, "");
    return Optional.of(new Order(direction, property));
  }
}
