package com.siemens.customerspace.domain.common;

public class Constants {
    private Constants() {
    }

    public static final String INIT_VECTOR_KEY = "encryptionIntVec";
    public static final String ENCODING_ALGORITHM = "AES/CTR/NoPadding";
    public static final String KEY = "aesEncryptionKey";
    public static final String AES = "AES";
    public static final String LOGIN_HEADER = "X-IOT-IAM-AUTH-KEY";
    public static final String MINDSPEHERE_HEADER = "X-SPACE-AUTH-KEY";
    public static final String GRANT_TYPE = "grant_type";
    public static final String APP_NAME = "appName";
    public static final String APP_VERSION = "appVersion";
    public static final String HOST_TENANT = "hostTenant";
    public static final String USER_TENANT = "userTenant";

    public static final String GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials";
    public static final String APP_NAME_VALUE = "ddxplatformdevapiacc";
    public static final String APP_VERSION_VALUE = "v1.0.0";
    public static final String HOST_TENANT_VALUE = "ddx";
    public static final String USER_TENANT_VALUE = "ddx";

    public static final String AUTH_HEADER = "Authorization";
    public static final String BEARER = "Bearer ";

    public static final String BASIC = "Basic ";

    public static final String DDX_TOKEN_FAILED =  "Error while fetching DDX token.";

    public static final String MIND_SPHERE_SERVER_ERROR = "Error while fetching data from mindSphere";
    public static final String DDX_HEADER_ERROR = "Error in DDX header.";

    public static final String MINDSPHERE_TOKEN_FAILED =  "Error while fetching mindsphere token.";

    public static final String COMPANY_ALREADY_EXIST = "Company Already Exists";

    public static final String COMPANY_CREATED_SUCCESSFULLY ="Company created successfully";

    public static final String COMPANY_NOT_FOUND = "Unable to fetch company details.";

    public static final String COMPANY_WITH_ID_NOT_FOUND ="Company with Id : {0} does not exist";

    public static final String COMPANY_WITH_ID ="Company with Id {0} : {1}";

    public static final String COMPANY_BY_NAME_NOT_FOUND ="Unable to fetch Company with Name {0}";

    public static final String COMPANY_DELETED_SUCCESSFULLY = "Company with Id {0} is deleted successfully.";

    public static final String COMPANY_USER_MAPPING_ERROR = "Company cannot be deleted as user is associated with it, please delete the associated user first and then delete the company.";
    public static final String COMPANY_DELETE_FAILURE = "Company with ID {0} cannot be deleted";

    public static final String COMPANY_WITH_NAME_NOT_FOUND = "Company with Name {0} does not exist.";

    public static final String COMPANY_WITH_NAME = "Company with Name {0} : {1} ";

    public static final String CREATE_COMPANY_EXCEPTION="Unable to create company";

    public static final String COMPANY_UPDATE_FAILED ="Unable to update company details.";

    public static final String COMPANY_MAPPING_FAILED ="Unable to map company details.";

    public static final String USER_MAPPING_FAILED ="Unable to map user details.";

    public static final String USER_NOT_FOUND = "Unable to fetch user details.";

    public static final String USER_UPDATE_FAILED ="Unable to update user details.";

    public static final String USER_ALREADY_EXIST = "User Already Exists";
    public static final String USER_WITH_ID_NOT_FOUND ="User with Id : {0} not found.";

    public static final String USER_WITH_ID = "User details for Id {0} is : {1}";

    public static final String USER_WITH_NAME = "User details for name {0} is : {1}";

    public static final String USER_WITH_EMAIL ="User with Email Address {0} : {1}";

    public static final String USER_WITH_EMAIL_EXISTS = "User with Email Address {0} exists : {1}";

    public static final String USER_WITH_EMAIL_DOES_NOT_EXISTS = "User with Email Address {0} does not exists";

    public static final String USER_CREATED_SUCCESSFULLY = "User created successfully";

    public static final String USER_DELETE ="User with Id {0} is deleted successfully.";

    public static final String USER_DELETE_FAILURE = "User with ID {0} cannot be deleted";

    public static final String MINDSPHERE_COMPANY_MAPPING_EXCEPTION = "Unable to map mindSphereCompanyMappingEntity ";

}
