package com.siemens.customerspace.application.exceptions;


public class ClientException extends RuntimeException {
	private final int statusCode;
	private final String url;

	public int getStatusCode() {
		return statusCode;
	}

	public String getUrl() {
		return url;
	}

	public ClientException(String url, int statusCode, Throwable cause) {
		super(cause);
		this.statusCode = statusCode;
		this.url = url;
	}
}
