package com.siemens.customerspace.infrastructure.mapping;



import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.infrastructure.model.CompanyEntity;

import java.util.ArrayList;

public class CompanyMappingProfiles {
    private CompanyMappingProfiles() {
    }

    public static Company fromCompanyHibernate(CompanyEntity companyEntity) throws CompanyNotFoundException {

        try {
            if(companyEntity == null){
                throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
            }
            Company objCompany = new Company();
            objCompany.setId(companyEntity.getId());
            objCompany.setGeneralEmailId(companyEntity.getGeneralEmailId());
            objCompany.setCountry(companyEntity.getCountry());
            objCompany.setZipCode(companyEntity.getZipCode());
            objCompany.setTelephone(companyEntity.getTelephone());
            objCompany.setAddress(companyEntity.getAddress());
            objCompany.setCompanyName(companyEntity.getCompanyName());
            objCompany.setUpdatedDate(companyEntity.getUpdatedDate());
            objCompany.setUpdatedBy(companyEntity.getUpdatedBy());
            objCompany.setCreatedBy(companyEntity.getCreatedBy());
            objCompany.setCreationDate(companyEntity.getCreationDate());
            objCompany.setUserCount(companyEntity.getUserEntityList().size());
            return objCompany;
        } catch (CompanyNotFoundException ex){
            throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
        }
    }


    public static CompanyEntity toCompanyHibernate(Company company) throws CompanyNotFoundException {
        try {
            if(company == null){
                throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
            }
            CompanyEntity objCompanyEntity = new CompanyEntity();
            objCompanyEntity.setId(company.getId());
            objCompanyEntity.setCompanyName(company.getCompanyName());
            objCompanyEntity.setCountry(company.getCountry());
            objCompanyEntity.setTelephone(company.getTelephone());
            objCompanyEntity.setGeneralEmailId(company.getGeneralEmailId());
            objCompanyEntity.setAddress(company.getAddress());
            objCompanyEntity.setZipCode(company.getZipCode());
            objCompanyEntity.setUserEntityList(new ArrayList<>());
            objCompanyEntity.setCreationDate(company.getCreationDate());
            objCompanyEntity.setCreatedBy(company.getCreatedBy());
            objCompanyEntity.setUpdatedBy(company.getUpdatedBy());
            objCompanyEntity.setUpdatedDate(company.getUpdatedDate());
            return objCompanyEntity;
        } catch (CompanyNotFoundException ex){
            throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
        }
    }


    public static Company toCompany(CompanyEntity companyEntity) throws CompanyNotFoundException {
       try {
           if(companyEntity == null){
               throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
           }
           Company company = new Company();
           mapHibernateFieldsToCompany(companyEntity, company);
           return company;
       } catch (CompanyNotFoundException ex){
           throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
       }
    }

    public static void mapHibernateFieldsToCompany(CompanyEntity companyEntity, Company company) throws CompanyNotFoundException {

        try {
            if (companyEntity == null || company == null) {
                throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
            }
            company.setId(companyEntity.getId());
            company.setGeneralEmailId(companyEntity.getGeneralEmailId());
            company.setCountry(companyEntity.getCountry());
            company.setZipCode(companyEntity.getZipCode());
            company.setTelephone(companyEntity.getTelephone());
            company.setAddress(companyEntity.getAddress());
            company.setCompanyName(companyEntity.getCompanyName());
            company.setUpdatedDate(companyEntity.getUpdatedDate());
            company.setUpdatedBy(companyEntity.getUpdatedBy());
            company.setCreatedBy(companyEntity.getCreatedBy());
            company.setCreationDate(companyEntity.getCreationDate());
        } catch (CompanyNotFoundException ex) {
            throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
        }
    }
}
