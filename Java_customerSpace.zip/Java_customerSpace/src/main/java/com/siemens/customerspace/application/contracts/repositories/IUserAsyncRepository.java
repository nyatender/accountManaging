package com.siemens.customerspace.application.contracts.repositories;


import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public interface IUserAsyncRepository {

    CompletableFuture<Page<User>> getAllUsers(Pageable pageable, String filter) throws UserNotFoundException;
    CompletableFuture<User> createUser(User user) throws UserNotFoundException ;

    CompletableFuture<User> updateUser(User user) throws UserNotFoundException;

    CompletableFuture<Boolean> deleteUser(Long id) throws UserNotFoundException;

    CompletableFuture<Optional<User>> getUserById(Long id) throws UserNotFoundException;

    CompletableFuture<Page<User>> findByUserName(Pageable pageable,String companyName) throws UserNotFoundException;

    CompletableFuture<User> findByEmailAddress(String emailAddress) throws UserNotFoundException;
}
