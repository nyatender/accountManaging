package com.siemens.customerspace.application.usecase.company.queries.getcompanies;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.paging.PageRequestDTO;
import com.siemens.customerspace.application.paging.PageResponseDTO;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;

import javax.transaction.Transactional;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetCompanyQueryHandler {

    @Value("${ddx.loginuri}")
    private String uri;

    private final ICompanyAsyncRepository iCompanyAsyncRepository;

    @Autowired
    public GetCompanyQueryHandler(ICompanyAsyncRepository iCompanyAsyncRepository){
        this.iCompanyAsyncRepository = iCompanyAsyncRepository;
    }

    @Transactional
    public CompletableFuture<List<CompanyResponseDTO>> getCompanyIdAndName() throws CompanyNotFoundException, InterruptedException, ExecutionException {
        try {
            CompletableFuture<List<Company>> responseDTO = this.iCompanyAsyncRepository.getCompanyIdAndName();
            List<CompanyResponseDTO> mappedResponse =  new ModelMapper().map(responseDTO.get(),List.class);
            return CompletableFuture.completedFuture(mappedResponse);
        } catch (CompanyNotFoundException e) {
            log.info(Constants.COMPANY_NOT_FOUND + e.getMessage());
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        } catch (ExecutionException e ) {
            throw new ExecutionException(e);
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }

    @Transactional
    public CompletableFuture<PageResponseDTO<CompanyResponseDTO>> getCompanies(PageRequestDTO pageRequestDTO, String filter) throws CompanyNotFoundException, InterruptedException, ExecutionException {
        try {
            mapFilterOptions(pageRequestDTO, filter);
            CompletableFuture<Page<Company>> responseDTO = this.iCompanyAsyncRepository.getAllCompanies(pageRequestDTO.getPageable(),filter);
            Page<CompanyResponseDTO> mappedResponse =  new ModelMapper().map(responseDTO.get(),Page.class);
            PageResponseDTO<CompanyResponseDTO> mappedCompanyData = PageResponseDTO.of(mappedResponse);
            return CompletableFuture.completedFuture(mappedCompanyData);
        } catch (CompanyNotFoundException e) {
            log.info(Constants.COMPANY_NOT_FOUND + e.getMessage());
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        } catch (ExecutionException  e) {
            throw new ExecutionException(e);
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }

    private static void  mapFilterOptions(PageRequestDTO pageRequestDTO, String filter) {
        if(filter != null && !filter.isEmpty()) {
            String[] keyValuePairs = filter.split("&");

            for(String pair : keyValuePairs)
            {
                String[] entry = pair.split("=");
                if(entry[0].trim().equals("page")){
                    pageRequestDTO.setPage(Integer.valueOf(entry[1].trim()));
                }
                if(entry[0].trim().equals("size")){
                    pageRequestDTO.setPageSize(Integer.valueOf(entry[1].trim()));
                }
            }
        }
    }
}
