package com.siemens.customerspace.domain.entities;


import com.siemens.customerspace.domain.common.EntityBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Company extends EntityBase {

    private String companyName;

    private String generalEmailId;

    private String country;

    private String telephone;

    private String address;

    private String zipCode;

    private int userCount;

}
