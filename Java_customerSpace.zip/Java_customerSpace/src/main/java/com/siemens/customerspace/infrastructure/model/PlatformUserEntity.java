package com.siemens.customerspace.infrastructure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "platform_users",uniqueConstraints={@UniqueConstraint(columnNames={"id","email_address"})})
@NoArgsConstructor
@Getter
@Setter
public class PlatformUserEntity extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "platform_user_seq_v1")
    @SequenceGenerator(name = "platform_user_seq_v1", sequenceName = "platform_user_seq_v1", allocationSize = 1)
    private Long id;

    @Column(name="name",length = 50)
    @NotEmpty
    private String name;

    @Column(name="email_address",length = 50)
    @NotEmpty
    private String emailAddress;

    @Column(name="is_active",length = 10)
    private Boolean isActive;

}
