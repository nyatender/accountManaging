package com.siemens.customerspace.domain.entities;


import com.siemens.customerspace.domain.common.EntityBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class User extends EntityBase {

    private String name;

    private String emailAddress;

    private String phoneNumber;

    private Long companyId;

    private String companyName;

}
