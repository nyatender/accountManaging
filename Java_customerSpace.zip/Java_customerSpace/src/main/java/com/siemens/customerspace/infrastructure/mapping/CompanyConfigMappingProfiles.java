package com.siemens.customerspace.infrastructure.mapping;


import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import com.siemens.customerspace.infrastructure.model.MindSphereCompanyMappingEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CompanyConfigMappingProfiles {

    private CompanyConfigMappingProfiles() {
    }

    public static MindSphereCompanyMapping fromMindSphereCompanyConfigHibernate(MindSphereCompanyMappingEntity mindSphereCompanyMappingEntity) throws CompanyNotFoundException {
        try {
            if(mindSphereCompanyMappingEntity == null){
                throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
            }
            mindSphereCompanyMappingEntity.setId(mindSphereCompanyMappingEntity.getId());
            MindSphereCompanyMapping mindSphereCompanyMapping = new MindSphereCompanyMapping();
            mindSphereCompanyMapping.setId(mindSphereCompanyMappingEntity.getId());
            mindSphereCompanyMapping.setCompanyId(mindSphereCompanyMappingEntity.getCompanyId());
            mindSphereCompanyMapping.setMindSphereCompanyId(mindSphereCompanyMappingEntity.getMindSphereCompanyId());
            mindSphereCompanyMapping.setDdxToken(mindSphereCompanyMappingEntity.getDdxToken());
            mindSphereCompanyMapping.setBillingEmailId(mindSphereCompanyMappingEntity.getBillingEmailId());
            mindSphereCompanyMapping.setIncidentReportingEmailId(mindSphereCompanyMappingEntity.getIncidentReportingEmailId());
            mindSphereCompanyMapping.setUpdatedBy(mindSphereCompanyMappingEntity.getUpdatedBy());
            mindSphereCompanyMapping.setCreatedBy(mindSphereCompanyMappingEntity.getCreatedBy());
            mindSphereCompanyMapping.setCreationDate(mindSphereCompanyMappingEntity.getCreationDate());
            mindSphereCompanyMapping.setUpdatedDate(mindSphereCompanyMappingEntity.getUpdatedDate());
            return mindSphereCompanyMapping;
        } catch (CompanyNotFoundException e){
            log.error(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
            throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
        }
    }

    public static MindSphereCompanyMappingEntity toMindSphereCompanyConfigHibernate(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
        try {
            MindSphereCompanyMappingEntity mindSphereCompanyMappingEntity = new MindSphereCompanyMappingEntity();
            if(mindSphereCompanyMapping == null){
                throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
            }
            mindSphereCompanyMappingEntity.setId(mindSphereCompanyMapping.getId());
            mindSphereCompanyMappingEntity.setCompanyId(mindSphereCompanyMapping.getCompanyId());
            mindSphereCompanyMappingEntity.setMindSphereCompanyId(mindSphereCompanyMapping.getMindSphereCompanyId());
            mindSphereCompanyMappingEntity.setDdxToken(mindSphereCompanyMapping.getDdxToken());
            mindSphereCompanyMappingEntity.setBillingEmailId(mindSphereCompanyMapping.getBillingEmailId());
            mindSphereCompanyMappingEntity.setIncidentReportingEmailId(mindSphereCompanyMapping.getIncidentReportingEmailId());
            mindSphereCompanyMappingEntity.setUpdatedBy(mindSphereCompanyMapping.getUpdatedBy());
            mindSphereCompanyMappingEntity.setCreatedBy(mindSphereCompanyMapping.getCreatedBy());
            mindSphereCompanyMappingEntity.setCreationDate(mindSphereCompanyMapping.getCreationDate());
            mindSphereCompanyMappingEntity.setUpdatedDate(mindSphereCompanyMapping.getUpdatedDate());
            return mindSphereCompanyMappingEntity;
        } catch (CompanyNotFoundException e){
            log.error(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
            throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
        }
    }
}
