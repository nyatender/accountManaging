package com.siemens.customerspace.application.usecase.company.queries.getcompanybyname;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetCompanyByNameQueryHandler {

    private final ICompanyAsyncRepository iCompanyAsyncRepository;

    private static final Logger logger = LoggerFactory.getLogger(GetCompanyByNameQueryHandler.class);

    @Autowired
    public GetCompanyByNameQueryHandler(ICompanyAsyncRepository iCompanyAsyncRepository){
            this.iCompanyAsyncRepository = iCompanyAsyncRepository;
    }

    @Transactional
    public CompletableFuture<Optional<Company>> getCompanyByName(String companyName) throws CompanyNotFoundException {
        try {
            return this.iCompanyAsyncRepository.findByCompanyName(companyName);
        } catch (CompanyNotFoundException e) {
            logger.info(Constants.COMPANY_NOT_FOUND);
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }
    }
}
