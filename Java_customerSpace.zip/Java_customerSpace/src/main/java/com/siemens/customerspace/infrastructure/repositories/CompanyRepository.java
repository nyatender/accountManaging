package com.siemens.customerspace.infrastructure.repositories;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.infrastructure.mapping.CompanyMappingProfiles;
import com.siemens.customerspace.infrastructure.model.CompanyEntity;
import com.siemens.customerspace.infrastructure.persistence.CompanyContext;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
@Transactional
public class CompanyRepository implements ICompanyAsyncRepository {

    private final CompanyContext companyContext;

    ModelMapper modelMapper = new ModelMapper();

    @Autowired
    public CompanyRepository(CompanyContext companyContext) {
        this.companyContext = companyContext;

    }

    @Override
    public CompletableFuture<Page<Company>> getAllCompanies(Pageable pageable, String filter) throws CompanyNotFoundException
    {
        try {
            Page<CompanyEntity> companyHibernate = this.companyContext.findAll(pageable);
            if(companyHibernate == null){
                log.info(Constants.COMPANY_NOT_FOUND);
                throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
            }
            Page<Company> companies = modelMapper.map(companyHibernate, Page.class);
            return CompletableFuture.completedFuture(companies);
        }catch (CompanyNotFoundException e){
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<List<Company>> getCompanyIdAndName() throws CompanyNotFoundException
    {
        try {
            Object[] companyHibernate = this.companyContext.getCompanyIdAndName();
            if(companyHibernate == null){
                log.info(Constants.COMPANY_NOT_FOUND);
                throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
            }
            List<Company> companies = modelMapper.map(companyHibernate, List.class);
            return CompletableFuture.completedFuture(companies);
        }catch (CompanyNotFoundException e){
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<Company> getCompanyById(Long id) throws CompanyNotFoundException {
        try {
            Optional<CompanyEntity> companyHibernate = this.companyContext.findById(id);
            if (companyHibernate.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
            }
            return CompletableFuture.completedFuture(CompanyMappingProfiles.fromCompanyHibernate(companyHibernate.get()));
        } catch (CompanyNotFoundException ex) {
            log.error(Constants.COMPANY_NOT_FOUND);
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<Optional<Company>> findByCompanyName(String companyName) throws CompanyNotFoundException{
        try {
            Optional<CompanyEntity> companyHibernate = this.companyContext.findByCompanyName(companyName);
            if (companyHibernate.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_NAME_NOT_FOUND,companyName));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_NAME_NOT_FOUND,companyName));
            }
            return CompletableFuture.completedFuture(Optional.of(CompanyMappingProfiles.fromCompanyHibernate(companyHibernate.get())));
        } catch (CompanyNotFoundException ex) {
            log.error(Constants.COMPANY_NOT_FOUND);
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }
    }



    @Override
    public CompletableFuture<Company> createCompany(Company company) throws CompanyNotFoundException {


        CompanyEntity companyEntity = CompanyMappingProfiles.toCompanyHibernate(company);
        try {
            Optional<CompanyEntity> companyExists = this.companyContext.findByCompanyName(company.getCompanyName());
            if(!companyExists.isEmpty()) {
                throw new CompanyNotFoundException(Constants.COMPANY_ALREADY_EXIST);
            }
            CompanyEntity newCompany = this.companyContext.save(companyEntity);
            company = CompanyMappingProfiles.toCompany(newCompany);
            log.info(Constants.COMPANY_CREATED_SUCCESSFULLY);
        } catch (CompanyNotFoundException ex) {
            log.error(Constants.CREATE_COMPANY_EXCEPTION + ": "+ex.getMessage());
            throw new CompanyNotFoundException(Constants.CREATE_COMPANY_EXCEPTION + ": " + ex.getMessage());
        }
        return CompletableFuture.completedFuture(company);
    }

    @Override
    public CompletableFuture<Boolean> deleteCompany(Long id) throws CompanyNotFoundException {
        try {
            Optional<CompanyEntity> companyByID = this.companyContext.findById(id);
            if (companyByID.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
            }
            companyContext.deleteById(id);
            return CompletableFuture.completedFuture(true);
        } catch (CompanyNotFoundException e) {
            throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
        }
    }

    @Override
    public CompletableFuture<Company> updateCompany(Company company) throws CompanyNotFoundException {
        try {
            CompanyEntity companyEntity = CompanyMappingProfiles.toCompanyHibernate(company);
            Optional<CompanyEntity> companyById = companyContext.findById(company.getId());
            if (companyById.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,company.getId()));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,company.getId()));
            }
            CompanyEntity updateCompany = companyContext.save(companyEntity);
            log.info("Company details updated successfully");
            company = new ModelMapper().map(updateCompany, Company.class);
        } catch (CompanyNotFoundException e) {
            log.error(Constants.COMPANY_UPDATE_FAILED);
            throw new CompanyNotFoundException(Constants.COMPANY_UPDATE_FAILED);
        }
        return CompletableFuture.completedFuture(company);
    }
}
