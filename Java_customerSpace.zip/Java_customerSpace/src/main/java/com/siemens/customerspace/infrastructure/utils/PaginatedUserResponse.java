package com.siemens.customerspace.infrastructure.utils;


import com.siemens.customerspace.domain.entities.User;
import com.siemens.customerspace.infrastructure.model.UserEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


@Getter
@Setter
@NoArgsConstructor
public class PaginatedUserResponse {

    private  List<User> users;
    private  long totalElements;

    static ModelMapper modelMapper = new ModelMapper();

    public PaginatedUserResponse(List<User> pageUsers, long totalElements) {
        this.users = pageUsers;
        this.totalElements = totalElements;
    }

    public static PaginatedUserResponse getMappedUsersDataWithPagination(Page<Object[]> userHibernate) {
        List<UserEntity> listUserEntity = userHibernate.stream()
                .map(row -> {
                    UserEntity userEntity = (UserEntity) row[0];
                    String companyName = (String) row[1];
                    userEntity.setCompanyName(companyName);
                    return userEntity;
                })
                .collect(Collectors.toList());
        List<User> mappedUsers = listUserEntity.stream()
                .map(userEntity -> modelMapper.map(userEntity, User.class))
                .collect(Collectors.toList());

        int pageSize = userHibernate.getSize();
        int startItem = 0;
        List<User> pageUsers;

        if (listUserEntity.size() < startItem) {
            pageUsers = Collections.emptyList();
        } else {
            int toIndex = Math.min(startItem + pageSize, listUserEntity.size());
            pageUsers = mappedUsers.subList(startItem, toIndex);
        }

        long totalElements = userHibernate.getTotalElements();
        return new PaginatedUserResponse(pageUsers, totalElements);
    }
}
