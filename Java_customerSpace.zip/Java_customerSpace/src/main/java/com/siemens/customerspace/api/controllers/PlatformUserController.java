package com.siemens.customerspace.api.controllers;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.usecase.platformuser.queries.getplatformuserbyemailaddress.GetPlatformUserByEmailAddressQueryHandler;
import com.siemens.customerspace.domain.common.Constants;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLClientInfoException;
import java.text.MessageFormat;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@CircuitBreaker(name = "customer_space_service")
@RateLimiter(name = "basic")
@RequestMapping("api/v1")
public class PlatformUserController {

    private final GetPlatformUserByEmailAddressQueryHandler getPlatformUserByEmailAddressQueryHandler;

    @Autowired
    public PlatformUserController(GetPlatformUserByEmailAddressQueryHandler getPlatformUserByEmailAddressQueryHandler){
        this.getPlatformUserByEmailAddressQueryHandler = getPlatformUserByEmailAddressQueryHandler;
    }

    @GetMapping("/getPlatformUserByEmailAddress")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Boolean>> getPlatformUserByEmailAddress(@RequestHeader Map<String,String> headers) throws UserNotFoundException, InterruptedException, IOException {
        try {
            String uniqueName = getUniqueNameFromAccessToken(headers);
            Boolean emailAddressExists =this.getPlatformUserByEmailAddressQueryHandler.getUserByEmailAddress(uniqueName).get();
            log.info(MessageFormat.format(Constants.USER_WITH_EMAIL,uniqueName,emailAddressExists));
            return CompletableFuture.completedFuture(new ResponseEntity<>(emailAddressExists, HttpStatus.OK));
        } catch (UserNotFoundException | RuntimeException | ExecutionException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(ex.getMessage());
        } catch (JsonProcessingException e) {
            throw new IOException(e);
        } catch (InterruptedException exception){
            throw new InterruptedException(exception.getMessage());
        }
    }

    String getUniqueNameFromAccessToken(Map<String, String> headers) throws JsonProcessingException {
        String accessToken = getAccessToken(headers);
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String[] jwtToken = accessToken.split("\\.");
        String body = new String(decoder.decode(jwtToken[1]));
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(body);
        if (rootNode == null) {
            return null;
        }
        return rootNode.get("unique_name").textValue();
    }

    String getAccessToken(Map<String, String> headers) {
        String bearerToken = headers.get("authorization");
        return bearerToken.substring(7);
    }
}
