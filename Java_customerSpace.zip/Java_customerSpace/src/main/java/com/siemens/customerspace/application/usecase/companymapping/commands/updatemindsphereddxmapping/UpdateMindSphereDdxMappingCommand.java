package com.siemens.customerspace.application.usecase.companymapping.commands.updatemindsphereddxmapping;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateMindSphereDdxMappingCommand {

    private Long companyId;
    private Long mindSphereCompanyId;
    private String billingEmailId;
    private String incidentReportingEmailId;
    private String ddxToken;
}
