package com.siemens.customerspace.infrastructure.persistence;

import com.siemens.customerspace.infrastructure.model.CompanyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CompanyContext extends JpaRepository<CompanyEntity, Long> {

    public static final String FIND_COMPANY = "SELECT c.id,c.company_name FROM company c";

    public Optional<CompanyEntity> findByCompanyName(String companyName);

    @Query(value = FIND_COMPANY,nativeQuery = true)
    public Object[] getCompanyIdAndName();

}
