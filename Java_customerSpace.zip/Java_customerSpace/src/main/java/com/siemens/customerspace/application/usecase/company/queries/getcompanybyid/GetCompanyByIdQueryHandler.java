package com.siemens.customerspace.application.usecase.company.queries.getcompanybyid;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.mappings.MindSphereCompanyMappingProfile;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetCompanyByIdQueryHandler {

    private final ICompanyAsyncRepository iCompanyAsyncRepository;

    private final ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository;

    private static final Logger logger = LoggerFactory.getLogger(GetCompanyByIdQueryHandler.class);

    @Autowired
    public GetCompanyByIdQueryHandler(ICompanyAsyncRepository iCompanyAsyncRepository,ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository){
            this.iCompanyAsyncRepository = iCompanyAsyncRepository;
            this.iCompanyConfigAsyncRepository = iCompanyConfigAsyncRepository;
    }

    @Transactional
    public CompletableFuture<GetCompanyByIdQuery> getCompanyById(Long companyId) throws CompanyNotFoundException, InterruptedException {
        try {
            CompletableFuture<Company> companyById= this.iCompanyAsyncRepository.getCompanyById(companyId);
            CompletableFuture<MindSphereCompanyMapping> optionalCompletableFuture = this.iCompanyConfigAsyncRepository.getMindSphereCompanyByIdMapping(companyById.get().getId());
            return CompletableFuture.completedFuture(MindSphereCompanyMappingProfile.mapToMindSphereCompanyMappingDTO(companyById.get(),optionalCompletableFuture.get()).get());
        } catch (CompanyNotFoundException e) {
            logger.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,companyId));
            throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,companyId));
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }
}
