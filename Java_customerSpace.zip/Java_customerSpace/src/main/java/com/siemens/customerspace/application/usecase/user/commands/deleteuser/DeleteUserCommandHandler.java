package com.siemens.customerspace.application.usecase.user.commands.deleteuser;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class DeleteUserCommandHandler {
    private final IUserAsyncRepository iUserAsyncRepository;
    @Autowired
    public DeleteUserCommandHandler(IUserAsyncRepository iUserAsyncRepository) {
        this.iUserAsyncRepository = iUserAsyncRepository;
    }

    @Transactional
    public CompletableFuture<Boolean> deleteUser(DeleteUserCommand request) throws UserNotFoundException, InterruptedException, ExecutionException {
        try{
            CompletableFuture<Optional<User>> findUserByID = this.iUserAsyncRepository.getUserById(request.getId());
            if(findUserByID.get().isPresent()){
               return this.iUserAsyncRepository.deleteUser(request.getId());
            }
            else {
                throw new UserNotFoundException(MessageFormat.format("User with ID {0} does not exist",request.getId()));
            }
        } catch (UserNotFoundException e) {
            log.error("Unable to delete User details");
            throw new UserNotFoundException(MessageFormat.format("Unable to delete User details with Id {0}",request.getId()));
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

}
