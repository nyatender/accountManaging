package com.siemens.customerspace.application.usecase.companymapping.commands.createmindsphereddxmapping;


import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class CreateMindSphereCompanyMappingCommandHandler {

    private ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository;

    @Autowired
    public CreateMindSphereCompanyMappingCommandHandler(ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository){
        this.iCompanyConfigAsyncRepository = iCompanyConfigAsyncRepository;
    }

    @Transactional
    public CompletableFuture<MindSphereCompanyMapping> createMindSphereDdxCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws ConnectException, CompanyNotFoundException {
        try {
            CompletableFuture<MindSphereCompanyMapping> mindSphereToken = this.iCompanyConfigAsyncRepository.createMindSphereDDXCompanyMapping(mindSphereCompanyMapping);
            log.info("MindSphere Token saved successfully");
            return mindSphereToken;
        } catch (ConnectException e) {
            throw new ConnectException(e.getMessage());
        } catch (CompanyNotFoundException | UserNotFoundException e) {
            throw new CompanyNotFoundException(e.getMessage());
        }
    }
}

