package com.siemens.customerspace.application.usecase.companymapping.commands.createmindsphereddxmapping;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateMindSphereDdxMappingCommand {

    private Long companyId;

    private Long mindSphereCompanyId;

    private String billingEmailId;
    private String incidentReportingEmailId;
    private String ddxToken;
}
