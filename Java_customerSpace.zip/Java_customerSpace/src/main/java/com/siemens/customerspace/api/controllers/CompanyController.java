package com.siemens.customerspace.api.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.paging.PageRequestDTO;
import com.siemens.customerspace.application.paging.PageResponseDTO;
import com.siemens.customerspace.application.usecase.company.commands.createcompany.CreateCompanyCommand;
import com.siemens.customerspace.application.usecase.company.commands.createcompany.CreateCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.commands.deletecompany.DeleteCompanyCommand;
import com.siemens.customerspace.application.usecase.company.commands.deletecompany.DeleteCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.commands.updatecompany.UpdateCompanyCommand;
import com.siemens.customerspace.application.usecase.company.commands.updatecompany.UpdateCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanies.CompanyResponseDTO;
import com.siemens.customerspace.application.usecase.company.queries.getcompanies.GetCompanyQueryHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyid.GetCompanyByIdQuery;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyid.GetCompanyByIdQueryHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyname.GetCompanyByNameQuery;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyname.GetCompanyByNameQueryHandler;
import com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid.GetCompanyMappingByIdCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.commands.createmindsphereddxmapping.CreateMindSphereCompanyMappingCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.commands.updatemindsphereddxmapping.UpdateMindSphereCompanyMappingCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.queries.getaccesstoken.GetAccessTokenCommandHandler;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.sql.SQLClientInfoException;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("api/v1/company")
@CircuitBreaker(name = "customer_space_service")
@RateLimiter(name = "basic")
public class CompanyController {

    private final CreateCompanyCommandHandler createCompanyCommandHandler;

    private final DeleteCompanyCommandHandler deleteCompanyCommandHandler;
    private final UpdateCompanyCommandHandler updateCompanyCommandHandler;

    private final GetCompanyQueryHandler getCompanyQueryHandler;

    private final GetCompanyByIdQueryHandler getCompanyByIdQueryHandler;

    private final GetCompanyByNameQueryHandler getCompanyByNameQueryHandler;

    private final CreateMindSphereCompanyMappingCommandHandler createMindSphereCompanyMappingCommandHandler;

    private final UpdateMindSphereCompanyMappingCommandHandler updateMindSphereCompanyMappingCommandHandler;

    private final GetAccessTokenCommandHandler getAccessTokenCommandHandler;

    private final MindSphereCompanyMapping mindSphereCompanyMapping;

    private final GetCompanyMappingByIdCommandHandler getCompanyMappingByIdCommandHandler;

    private  CompletableFuture<Long> companyResponseDTO = new CompletableFuture<Long>();

    private Long companyId;

    @Autowired
    public CompanyController(CreateCompanyCommandHandler createCompanyCommandHandler,
                             DeleteCompanyCommandHandler deleteCompanyCommandHandler,
                             UpdateCompanyCommandHandler updateCompanyCommandHandler,
                             GetCompanyQueryHandler getCompanyQueryHandler,
                             GetCompanyByIdQueryHandler getCompanyByIdQueryHandler,
                             GetCompanyByNameQueryHandler getCompanyByNameQueryHandler,
                             CreateMindSphereCompanyMappingCommandHandler createMindSphereCompanyMappingCommandHandler,
                             GetAccessTokenCommandHandler getAccessTokenCommandHandler,
                             MindSphereCompanyMapping mindSphereCompanyMapping,
                             UpdateMindSphereCompanyMappingCommandHandler updateMindSphereCompanyMappingCommandHandler,
                             GetCompanyMappingByIdCommandHandler getCompanyMappingByIdCommandHandler){
        this.createCompanyCommandHandler = createCompanyCommandHandler;
        this.deleteCompanyCommandHandler = deleteCompanyCommandHandler;
        this.updateCompanyCommandHandler = updateCompanyCommandHandler;
        this.getCompanyQueryHandler = getCompanyQueryHandler;
        this.getCompanyByIdQueryHandler =  getCompanyByIdQueryHandler;
        this.getCompanyByNameQueryHandler = getCompanyByNameQueryHandler;
        this.createMindSphereCompanyMappingCommandHandler = createMindSphereCompanyMappingCommandHandler;
        this.getAccessTokenCommandHandler = getAccessTokenCommandHandler;
        this.mindSphereCompanyMapping = mindSphereCompanyMapping;
        this.updateMindSphereCompanyMappingCommandHandler =updateMindSphereCompanyMappingCommandHandler;
        this.getCompanyMappingByIdCommandHandler = getCompanyMappingByIdCommandHandler;
    }

    @PostMapping("/addCompany")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Long>> createCompany(
            @RequestBody CreateCompanyCommand companyRequestDTO,
            @RequestHeader Map<String,String> headers) throws Exception {
        try {
             String uniqueName = getUniqueNameFromAccessToken(headers);
             companyRequestDTO.setCreatedBy(uniqueName);
             companyRequestDTO.setUpdatedBy(uniqueName);
            CompletableFuture<Long> companyResponseDTO = this.createCompanyCommandHandler.createCompany(companyRequestDTO);
            companyId= companyResponseDTO.get();
            setMindSphereCompanyMappingConfig(uniqueName, companyResponseDTO,companyRequestDTO);
            CompletableFuture<MindSphereCompanyMapping> updatedMindSphereCompanyMapping = this.createMindSphereCompanyMappingCommandHandler.createMindSphereDdxCompanyMapping(mindSphereCompanyMapping);
            log.info(Constants.COMPANY_CREATED_SUCCESSFULLY);
            return companyResponseDTO.thenApplyAsync(ResponseEntity.ok()::body);
        } catch (CompanyNotFoundException ex){
            log.error(ex.getMessage());
            throw new CompanyNotFoundException(ex.getMessage());
        }
        catch (Exception e){
            log.error(e.getMessage());
            if(companyId != null) {
                DeleteCompanyCommand deleteCompanyCommand = new DeleteCompanyCommand();
                deleteCompanyCommand.setId(companyId);
                this.deleteCompanyCommandHandler.deleteCompany(deleteCompanyCommand);
            }
            throw new Exception(e.getMessage());
        }
    }

    @GetMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<PageResponseDTO<CompanyResponseDTO>>> getAllCompanies(
            @Valid PageRequestDTO pageRequestDTO, @RequestParam(required = false) String filter) throws CompanyNotFoundException, InterruptedException {

        CompletableFuture<PageResponseDTO<CompanyResponseDTO>> page;
        try {
                page = this.getCompanyQueryHandler.getCompanies(pageRequestDTO, filter);
            log.info("GetAll Companies : " + page.get().getItems());
            return CompletableFuture.completedFuture(new ResponseEntity<>(page.get(), HttpStatus.OK));
        } catch (CompanyNotFoundException | InterruptedException | ExecutionException e)
        {
            log.error(Constants.COMPANY_NOT_FOUND);
            throw new InterruptedException(Constants.COMPANY_NOT_FOUND);
        }
    }

    @GetMapping("/getCompanyIdAndName")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<List<CompanyResponseDTO>>> getCompanyIDAndName(
            @Valid PageRequestDTO pageRequestDTO, @RequestParam(required = false) String filter) throws CompanyNotFoundException, ExecutionException, InterruptedException {

        try {
            CompletableFuture<List<CompanyResponseDTO>> companyResponseDTO = this.getCompanyQueryHandler.getCompanyIdAndName();
            log.info("GetAll Companies Response {} ", companyResponseDTO);
            return CompletableFuture.completedFuture(new ResponseEntity<>(companyResponseDTO.get(), HttpStatus.OK));
        } catch (CompanyNotFoundException e)
        {
            log.error(Constants.COMPANY_NOT_FOUND);
            throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
        }catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(Constants.COMPANY_NOT_FOUND);
        }
    }

    @GetMapping("/{id}")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<GetCompanyByIdQuery>> getCompanyById(@Valid @PathVariable("id") Long id) throws CompanyNotFoundException, ExecutionException, InterruptedException {
        try {
             GetCompanyByIdQuery companyById =this.getCompanyByIdQueryHandler.getCompanyById(id).get();
             log.info(MessageFormat.format(Constants.COMPANY_WITH_ID ,id,companyById));
             return CompletableFuture.completedFuture(new ResponseEntity<>(companyById, HttpStatus.OK));
        } catch (CompanyNotFoundException ex) {
        log.error(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
        throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
        }

    }

    @GetMapping("/getByName")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Optional<GetCompanyByNameQuery>>> getCompanyByName(@Valid @RequestParam(required = false) String name) throws CompanyNotFoundException, ExecutionException, InterruptedException {
        try {
            Optional<GetCompanyByNameQuery> companyByName =new ModelMapper().map(this.getCompanyByNameQueryHandler.getCompanyByName(name).get(),Optional.class);
            log.info(MessageFormat.format(Constants.COMPANY_WITH_NAME ,name,companyByName));
            return CompletableFuture.completedFuture(new ResponseEntity<>(companyByName, HttpStatus.OK));
        } catch (CompanyNotFoundException ex) {
            log.error(MessageFormat.format(Constants.COMPANY_BY_NAME_NOT_FOUND,name));
            throw new CompanyNotFoundException(ex.getMessage());
        }
    }

    @DeleteMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Boolean>> deleteCompany(@Valid @RequestBody DeleteCompanyCommand companyID) throws CompanyNotFoundException, InterruptedException {
        try {
            CompletableFuture<Boolean> deleteCompany = this.deleteCompanyCommandHandler.deleteCompany(companyID);
            log.info(MessageFormat.format(Constants.COMPANY_DELETED_SUCCESSFULLY,companyID.getId()));
            return deleteCompany.thenApplyAsync(ResponseEntity.ok()::body);
        } catch (CompanyNotFoundException ex) {
            throw new CompanyNotFoundException(ex.getMessage());
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    @PutMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Company>> updateCompany(
            @Valid @RequestBody UpdateCompanyCommand companyRequestDTO,
            @RequestHeader Map<String,String> headers) throws Exception{
        try {
            String uniqueName = getUniqueNameFromAccessToken(headers);
            companyRequestDTO.setCreatedBy(uniqueName);
            companyRequestDTO.setUpdatedBy(uniqueName);
            CompletableFuture<Company> companyResponseDTO = this.updateCompanyCommandHandler.updateCompany(companyRequestDTO);
            CompletableFuture<MindSphereCompanyMapping> mindSphereMapping = this.getCompanyMappingByIdCommandHandler.getMindSphereMapping(companyResponseDTO.get().getId());
            MindSphereCompanyMapping toupdateMindSphereCompanyMapping = new MindSphereCompanyMapping();
            createMindSphereCompanyMappingDTO(companyRequestDTO, uniqueName, mindSphereMapping, toupdateMindSphereCompanyMapping);
            CompletableFuture<MindSphereCompanyMapping> updateMindSphereCompanyMapping = this.updateMindSphereCompanyMappingCommandHandler.updateMindSphereDdxCompanyMapping(toupdateMindSphereCompanyMapping);
            log.info("MindSphere Company mapping updated : "+ updateMindSphereCompanyMapping);
            log.info("Response {} ", companyResponseDTO);
            return CompletableFuture.completedFuture(new ResponseEntity<>(companyResponseDTO.get(), HttpStatus.OK));
        } catch (CompanyNotFoundException  ex) {
            log.error(Constants.COMPANY_UPDATE_FAILED + ex.getMessage());
            throw new CompanyNotFoundException(Constants.COMPANY_UPDATE_FAILED);
        } catch (Exception e){
            log.error(Constants.COMPANY_UPDATE_FAILED);
            throw new Exception(e.getMessage());
        }
    }

    private static void createMindSphereCompanyMappingDTO(UpdateCompanyCommand companyRequestDTO, String uniqueName, CompletableFuture<MindSphereCompanyMapping> mindSphereMapping, MindSphereCompanyMapping toupdateMindSphereCompanyMapping) throws Exception {
        try{
        validateToken(companyRequestDTO.getDdxToken());
        toupdateMindSphereCompanyMapping.setId(mindSphereMapping.get().getId());
        toupdateMindSphereCompanyMapping.setMindSphereCompanyId(mindSphereMapping.get().getMindSphereCompanyId());
        toupdateMindSphereCompanyMapping.setCompanyId(mindSphereMapping.get().getCompanyId());
        toupdateMindSphereCompanyMapping.setBillingEmailId(mindSphereMapping.get().getBillingEmailId());
        toupdateMindSphereCompanyMapping.setIncidentReportingEmailId(mindSphereMapping.get().getIncidentReportingEmailId());
        toupdateMindSphereCompanyMapping.setDdxToken(companyRequestDTO.getDdxToken());
        toupdateMindSphereCompanyMapping.setCreatedBy(mindSphereMapping.get().getCreatedBy());
        toupdateMindSphereCompanyMapping.setCreationDate(mindSphereMapping.get().getCreationDate());
        toupdateMindSphereCompanyMapping.setUpdatedDate(LocalDateTime.now());
        toupdateMindSphereCompanyMapping.setUpdatedBy(uniqueName);
        } catch (CompanyNotFoundException e){
            throw new CompanyNotFoundException(mindSphereMapping.get().getCompanyId().toString());
        }
    }

    String getUniqueNameFromAccessToken(Map<String, String> headers) throws Exception {
        String accessToken = getAccessToken(headers);
        JsonNode rootNode = validateToken(accessToken);
        if (rootNode == null) return null;
        return rootNode.get("unique_name").textValue();
    }

    private static JsonNode validateToken(String accessToken) throws Exception {
        try {
            Base64.Decoder decoder = Base64.getUrlDecoder();
            String[] jwtToken = accessToken.split("\\.");
            String body = new String(decoder.decode(jwtToken[1]));
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(body);
            if (rootNode == null) {
                return null;
            }
            return rootNode;
        } catch (Exception e){
            throw new Exception("Invalid Ddx token.");
        }
    }

    private String getAccessToken(Map<String,String> headers) {
        String bearerToken = headers.get("authorization");
        return bearerToken.substring(7);
    }

    Long getCompanyIdFromAccessToken(String ddxToken) throws Exception {

        JsonNode rootNode = validateToken(ddxToken);
        if (rootNode == null) return null;
        JsonNode company = rootNode.get("company");
        return company.get("companyId").asLong();
    }

    private void setMindSphereCompanyMappingConfig(String uniqueName, CompletableFuture<Long> companyResponseDTO,CreateCompanyCommand companyRequestDTO) throws Exception {
       try {
           mindSphereCompanyMapping.setCompanyId(companyResponseDTO.get());
           mindSphereCompanyMapping.setMindSphereCompanyId(getCompanyIdFromAccessToken(companyRequestDTO.getDdxToken()));
           mindSphereCompanyMapping.setCreatedBy(uniqueName);
           mindSphereCompanyMapping.setUpdatedBy(uniqueName);
           mindSphereCompanyMapping.setBillingEmailId(companyRequestDTO.getBillingEmailId());
           mindSphereCompanyMapping.setIncidentReportingEmailId(companyRequestDTO.getIncidentReportingEmailId());
           mindSphereCompanyMapping.setDdxToken(companyRequestDTO.getDdxToken());
           mindSphereCompanyMapping.setCreationDate(LocalDateTime.now());
           mindSphereCompanyMapping.setUpdatedDate(LocalDateTime.now());
       }catch (Exception e){
            throw new Exception("Invalid DDX token");
       }
    }
}
