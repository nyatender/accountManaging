package com.siemens.customerspace.application.usecase.company.queries.getcompanybyname;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class GetCompanyByNameQuery extends BaseModelDTO {

    private String companyName;
    private String companyEmailAddress;

    private String telephone;

    private String country;

    private String address;

    private String zipCode;

    private int userCount;

}
