package com.siemens.customerspace.infrastructure.repositories;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import com.siemens.customerspace.infrastructure.mapping.UserMappingProfiles;
import com.siemens.customerspace.infrastructure.model.UserEntity;
import com.siemens.customerspace.infrastructure.persistence.UserContext;
import com.siemens.customerspace.infrastructure.utils.PaginatedUserResponse;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
@Transactional
public class UserRepository implements IUserAsyncRepository {

    private final UserContext userContext;

    ModelMapper modelMapper = new ModelMapper();

    @Autowired
    public UserRepository(UserContext userContext) {
        this.userContext = userContext;

    }

    @Override
    public CompletableFuture<Page<User>> getAllUsers(Pageable pageable, String filter) throws UserNotFoundException
    {
        try {
            Page<Object[]> userHibernate = this.userContext.findAllUsersWithCompanyName(pageable);
            if(userHibernate == null){
                throw new UserNotFoundException(Constants.USER_NOT_FOUND);
            }
            PaginatedUserResponse pageUsers = PaginatedUserResponse.getMappedUsersDataWithPagination(userHibernate);
            log.info(MessageFormat.format("Get all users : {0} ",pageUsers));
            return CompletableFuture.completedFuture(new PageImpl<>(pageUsers.getUsers(), pageable, pageUsers.getTotalElements()));

        }catch (UserNotFoundException e){
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<Optional<User>> getUserById(Long id) throws UserNotFoundException {
        try {
            Optional<UserEntity> userHibernate = this.userContext.findById(id);
            if (userHibernate.isEmpty()) {
                log.info(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
                throw new UserNotFoundException(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
            }
            log.info(MessageFormat.format("User with ID {0} : {1} ",id, userHibernate));
            return CompletableFuture.completedFuture(Optional.of(UserMappingProfiles.fromUserHibernate(userHibernate.get())));
        } catch (UserNotFoundException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<Page<User>> findByUserName(Pageable pageable, String name) throws UserNotFoundException{
        try {
            Page<Object[]> userHibernate = userContext.findUserWithNameAndCompanyName(pageable,name);
            if(userHibernate == null){
                throw new UserNotFoundException(Constants.USER_NOT_FOUND);
            }
            PaginatedUserResponse pageUsers = PaginatedUserResponse.getMappedUsersDataWithPagination(userHibernate);
            log.info(MessageFormat.format("User with name {0} : {1} ",name, userHibernate));
            return CompletableFuture.completedFuture(new PageImpl<>(pageUsers.getUsers(), pageable, pageUsers.getTotalElements()));
        } catch (UserNotFoundException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        }
    }

    @Override
    public CompletableFuture<User> findByEmailAddress(String emailAddress) throws UserNotFoundException{
        try {
            Optional<UserEntity> userHibernate = this.userContext.findByEmailAddress(emailAddress);
            if (userHibernate.isEmpty()) {
                log.info(MessageFormat.format(Constants.USER_WITH_EMAIL_DOES_NOT_EXISTS,emailAddress));
                throw new UserNotFoundException(Constants.USER_NOT_FOUND);
            }
            log.info(MessageFormat.format(Constants.USER_WITH_EMAIL,emailAddress,userHibernate));
            return CompletableFuture.completedFuture(UserMappingProfiles.toUser(userHibernate.get()));
        } catch (Exception ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        }
    }


    @Override
    public CompletableFuture<User> createUser(User user) throws UserNotFoundException {

        UserEntity userEntity = UserMappingProfiles.toUserHibernate(user);
        try {
            Optional<UserEntity> userExists = this.userContext.findByEmailAddress(user.getEmailAddress());
            if(!userExists.isEmpty()) {
                throw new UserNotFoundException(Constants.USER_ALREADY_EXIST);
            }
            UserEntity newUser = this.userContext.save(userEntity);
            user = UserMappingProfiles.toUser(newUser);
            log.info(Constants.USER_CREATED_SUCCESSFULLY);
        } catch (Exception ex) {
            log.error(Constants.USER_ALREADY_EXIST);
            throw new UserNotFoundException(Constants.USER_ALREADY_EXIST);
        }
        return CompletableFuture.completedFuture(user);
    }

    @Override
    public CompletableFuture<Boolean> deleteUser(Long id) throws UserNotFoundException {
        try {
            Optional<UserEntity> userById = this.userContext.findById(id);
            if (userById.isEmpty()) {
                log.info(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
                throw new UserNotFoundException(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
            }
            userContext.deleteById(id);
            log.info(MessageFormat.format(Constants.USER_DELETE,id));
            return CompletableFuture.completedFuture(true);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
        }
    }

    @Override
    public CompletableFuture<User> updateUser(User user) throws UserNotFoundException {
        try {
            UserEntity userEntity = UserMappingProfiles.toUserHibernate(user);
            Optional<UserEntity> userById = userContext.findById(user.getId());
            if (userById.isEmpty()) {
                log.info(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,user.getId()));
                throw new UserNotFoundException(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,user.getId()));
            }
            UserEntity updateUser = userContext.save(userEntity);
            log.info(Constants.USER_CREATED_SUCCESSFULLY);
            user = new ModelMapper().map(updateUser, User.class);
        } catch (UserNotFoundException e) {
            log.error(Constants.USER_UPDATE_FAILED);
            throw new UserNotFoundException(Constants.USER_UPDATE_FAILED);
        }
        return CompletableFuture.completedFuture(user);
    }
}
