package com.siemens.customerspace.application.exceptions;

public class CompanyNotFoundException extends Exception {

    public CompanyNotFoundException(String message) {
        super(message);
    }
}
