package com.siemens.customerspace.infrastructure.repositories;


import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import com.siemens.customerspace.infrastructure.mapping.CompanyConfigMappingProfiles;
import com.siemens.customerspace.infrastructure.mapping.TokenMappingProfiles;
import com.siemens.customerspace.infrastructure.model.MindSphereCompanyMappingEntity;
import com.siemens.customerspace.infrastructure.persistence.MindSphereDdxCompanyMappingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.MessageFormat;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class CompanyConfigAsyncRepository implements ICompanyConfigAsyncRepository {

    MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext;

    @Autowired
    public CompanyConfigAsyncRepository(MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext) {
        this.mindSphereDdxCompanyMappingContext = mindSphereDdxCompanyMappingContext;

    }

    @Override
    public CompletableFuture<MindSphereCompanyMapping> createMindSphereDDXCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
        MindSphereCompanyMappingEntity savedMindSphereCompanyMapping = this.mindSphereDdxCompanyMappingContext.save(TokenMappingProfiles.toMindSphereCompanyMappingHibernate(mindSphereCompanyMapping));
        return CompletableFuture.completedFuture(TokenMappingProfiles.fromMindSphereCompanyMappingHibernate(savedMindSphereCompanyMapping));
    }

    @Override
    public CompletableFuture<MindSphereCompanyMapping> getMindSphereCompanyByIdMapping(Long companyId) throws CompanyNotFoundException {
        Optional<MindSphereCompanyMappingEntity> mindSphereCompanyMappingEntity = this.mindSphereDdxCompanyMappingContext.findByCompanyId(companyId);
        if(mindSphereCompanyMappingEntity.isPresent()) {
            return CompletableFuture.completedFuture(CompanyConfigMappingProfiles.fromMindSphereCompanyConfigHibernate(mindSphereCompanyMappingEntity.get()));
        }
        return CompletableFuture.completedFuture(new MindSphereCompanyMapping());
    }

    @Override
    public CompletableFuture<Boolean> deleteMindSphereCompanyMapping(Long id) throws CompanyNotFoundException {
        try {
            Optional<MindSphereCompanyMappingEntity> mindSphereCompanyMappingEntity = this.mindSphereDdxCompanyMappingContext.findByCompanyId(id);
            if (mindSphereCompanyMappingEntity.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
            }
            mindSphereDdxCompanyMappingContext.deleteById(mindSphereCompanyMappingEntity.get().getId());
            return CompletableFuture.completedFuture(true);
        } catch (CompanyNotFoundException e) {
            throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,id));
        }
    }

    @Override
    public CompletableFuture<MindSphereCompanyMapping> updateMindSphereCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
        try {
            MindSphereCompanyMappingEntity mindSphereCompanyMappingEntity = CompanyConfigMappingProfiles.toMindSphereCompanyConfigHibernate(mindSphereCompanyMapping);
            Optional<MindSphereCompanyMappingEntity> companyById = this.mindSphereDdxCompanyMappingContext.findById(mindSphereCompanyMapping.getId());
            if (companyById.isEmpty()) {
                log.info(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,mindSphereCompanyMapping.getId()));
                throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND,mindSphereCompanyMapping.getId()));
            }
            MindSphereCompanyMappingEntity updateMapping = this.mindSphereDdxCompanyMappingContext.save(mindSphereCompanyMappingEntity);
            log.info("Company details updated successfully");
           MindSphereCompanyMapping updatedMindSphereCompanyMapping = CompanyConfigMappingProfiles.fromMindSphereCompanyConfigHibernate(updateMapping);
            return CompletableFuture.completedFuture(updatedMindSphereCompanyMapping);
        } catch (CompanyNotFoundException e) {
            log.error(Constants.COMPANY_UPDATE_FAILED);
            throw new CompanyNotFoundException(Constants.COMPANY_UPDATE_FAILED);
        }

    }

}
