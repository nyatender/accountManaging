package com.siemens.customerspace.infrastructure.mapping;


import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import com.siemens.customerspace.infrastructure.model.MindSphereCompanyMappingEntity;

public class TokenMappingProfiles {

    private TokenMappingProfiles() {
    }

    public static MindSphereCompanyMappingEntity toMindSphereCompanyMappingHibernate(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
       try {
            if(mindSphereCompanyMapping == null){
                throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
            }
           MindSphereCompanyMappingEntity mindSphereCompanyMappingEntity = new MindSphereCompanyMappingEntity();
           mindSphereCompanyMappingEntity.setMindSphereCompanyId(mindSphereCompanyMapping.getMindSphereCompanyId());
           mindSphereCompanyMappingEntity.setCompanyId(mindSphereCompanyMapping.getCompanyId());
           mindSphereCompanyMappingEntity.setBillingEmailId(mindSphereCompanyMapping.getBillingEmailId());
           mindSphereCompanyMappingEntity.setIncidentReportingEmailId(mindSphereCompanyMapping.getIncidentReportingEmailId());
           mindSphereCompanyMappingEntity.setDdxToken(mindSphereCompanyMapping.getDdxToken());
           mindSphereCompanyMappingEntity.setCreatedBy(mindSphereCompanyMapping.getCreatedBy());
           mindSphereCompanyMappingEntity.setUpdatedBy(mindSphereCompanyMapping.getUpdatedBy());
           mindSphereCompanyMappingEntity.setCreationDate(mindSphereCompanyMapping.getCreationDate());
           mindSphereCompanyMappingEntity.setUpdatedDate(mindSphereCompanyMapping.getUpdatedDate());
           return mindSphereCompanyMappingEntity;
       } catch (CompanyNotFoundException ex){
           throw new CompanyNotFoundException(Constants.COMPANY_MAPPING_FAILED);
       }
    }

    public static MindSphereCompanyMapping fromMindSphereCompanyMappingHibernate(MindSphereCompanyMappingEntity mindSphereCompanyMappingEntity) throws CompanyNotFoundException {
        try{
            if(mindSphereCompanyMappingEntity == null){
                throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
            }
        MindSphereCompanyMapping mindSphereCompanyMapping = new MindSphereCompanyMapping();
        mindSphereCompanyMapping.setMindSphereCompanyId(mindSphereCompanyMappingEntity.getMindSphereCompanyId());
        mindSphereCompanyMapping.setCompanyId(mindSphereCompanyMappingEntity.getCompanyId());
        mindSphereCompanyMapping.setBillingEmailId(mindSphereCompanyMappingEntity.getBillingEmailId());
        mindSphereCompanyMapping.setIncidentReportingEmailId(mindSphereCompanyMappingEntity.getIncidentReportingEmailId());
        mindSphereCompanyMapping.setDdxToken(mindSphereCompanyMappingEntity.getDdxToken());
        mindSphereCompanyMapping.setCreatedBy(mindSphereCompanyMappingEntity.getCreatedBy());
        mindSphereCompanyMapping.setUpdatedBy(mindSphereCompanyMappingEntity.getUpdatedBy());
        mindSphereCompanyMapping.setCreationDate(mindSphereCompanyMappingEntity.getCreationDate());
        mindSphereCompanyMapping.setUpdatedDate(mindSphereCompanyMappingEntity.getUpdatedDate());
        return mindSphereCompanyMapping;
        }catch (CompanyNotFoundException e){
            throw new CompanyNotFoundException(Constants.MINDSPHERE_COMPANY_MAPPING_EXCEPTION);
        }

    }


}
