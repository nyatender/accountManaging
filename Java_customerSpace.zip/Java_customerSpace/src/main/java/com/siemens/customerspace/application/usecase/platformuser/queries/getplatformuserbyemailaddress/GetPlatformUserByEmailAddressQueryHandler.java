package com.siemens.customerspace.application.usecase.platformuser.queries.getplatformuserbyemailaddress;


import com.siemens.customerspace.application.contracts.repositories.IPlatformUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetPlatformUserByEmailAddressQueryHandler {

    private final IPlatformUserAsyncRepository iPlatformUserAsyncRepository;

    private static final Logger logger = LoggerFactory.getLogger(GetPlatformUserByEmailAddressQueryHandler.class);

    @Autowired
    public GetPlatformUserByEmailAddressQueryHandler(IPlatformUserAsyncRepository iPlatformUserAsyncRepository){
            this.iPlatformUserAsyncRepository = iPlatformUserAsyncRepository;
    }

    @Transactional
    public CompletableFuture<Boolean> getUserByEmailAddress(String emailAddress) throws UserNotFoundException, InterruptedException {
        try {
            return this.iPlatformUserAsyncRepository.findByEmailAddress(emailAddress);
        } catch (UserNotFoundException e) {
            logger.info(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }
}
