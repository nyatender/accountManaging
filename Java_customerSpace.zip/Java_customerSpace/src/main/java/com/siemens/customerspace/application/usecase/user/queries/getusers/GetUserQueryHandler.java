package com.siemens.customerspace.application.usecase.user.queries.getusers;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.paging.PageRequestDTO;
import com.siemens.customerspace.application.paging.PageResponseDTO;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import javax.transaction.Transactional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetUserQueryHandler {

    private final IUserAsyncRepository iUserAsyncRepository;

    @Autowired
    public GetUserQueryHandler(IUserAsyncRepository iUserAsyncRepository){
        this.iUserAsyncRepository = iUserAsyncRepository;
    }

    @Transactional
    public CompletableFuture<PageResponseDTO<UserResponseDTO>> getAllUsers(PageRequestDTO pageRequestDTO, String filter) throws UserNotFoundException, InterruptedException {
        try {
            mapFilterOptions(pageRequestDTO, filter);
            CompletableFuture<Page<User>> responseDTO = this.iUserAsyncRepository.getAllUsers(pageRequestDTO.getPageable(),filter);
            Page<UserResponseDTO> mappedResponse =  new ModelMapper().map(responseDTO.get(),Page.class);
            PageResponseDTO<UserResponseDTO> mappedUserData = PageResponseDTO.of(mappedResponse);
            return CompletableFuture.completedFuture(mappedUserData);
        } catch (UserNotFoundException e) {
            log.info(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        } catch (ExecutionException | InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    private static void mapFilterOptions(PageRequestDTO pageRequestDTO, String filter) {
        if(filter != null && !filter.isEmpty()) {
            String[] keyValuePairs = filter.split("&");

            for(String pair : keyValuePairs)
            {
                String[] entry = pair.split("=");
                if(entry[0].trim().equals("page")){
                    pageRequestDTO.setPage(Integer.valueOf(entry[1].trim()));
                }
                if(entry[0].trim().equals("size")){
                    pageRequestDTO.setPageSize(Integer.valueOf(entry[1].trim()));
                }
            }
        }
    }
}
