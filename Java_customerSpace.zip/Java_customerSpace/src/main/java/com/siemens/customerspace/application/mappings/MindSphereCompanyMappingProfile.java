package com.siemens.customerspace.application.mappings;



import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyid.GetCompanyByIdQuery;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;

import java.util.concurrent.CompletableFuture;

public class MindSphereCompanyMappingProfile {

    public static CompletableFuture<GetCompanyByIdQuery> mapToMindSphereCompanyMappingDTO(Company company, MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException {
        try {
            if (company == null) {
                return null;
            }
            GetCompanyByIdQuery companyResponseDTO = new GetCompanyByIdQuery();
            companyResponseDTO.setCompanyName(company.getCompanyName());
            companyResponseDTO.setGeneralEmailId(company.getGeneralEmailId());
            companyResponseDTO.setCountry(company.getCountry());
            companyResponseDTO.setTelephone(company.getTelephone());
            companyResponseDTO.setZipCode(company.getZipCode());
            companyResponseDTO.setAddress(company.getAddress());
            companyResponseDTO.setId(company.getId());
            companyResponseDTO.setBillingEmailId(mindSphereCompanyMapping.getBillingEmailId());
            companyResponseDTO.setIncidentReportingEmailId(mindSphereCompanyMapping.getIncidentReportingEmailId());
            companyResponseDTO.setDdxToken(mindSphereCompanyMapping.getDdxToken());
            companyResponseDTO.setCreatedBy(company.getCreatedBy());
            companyResponseDTO.setCreationDate(company.getCreationDate());
            companyResponseDTO.setUpdatedBy(company.getUpdatedBy());
            companyResponseDTO.setUpdatedDate(company.getUpdatedDate());
            companyResponseDTO.setUserCount(company.getUserCount());
            return CompletableFuture.completedFuture(companyResponseDTO);
        }
        catch (Exception e){
            throw new CompanyNotFoundException("Unable to map Company Entity to Company DTO");
        }
    }
}
