package com.siemens.customerspace.infrastructure.mapping;


import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import com.siemens.customerspace.infrastructure.model.UserEntity;

public class UserMappingProfiles {

    private UserMappingProfiles() {
    }

    public static User fromUserHibernate(UserEntity userEntity) throws UserNotFoundException {
        try {
            if (userEntity == null) {
                throw new UserNotFoundException("Error in user mapping");
            }
            User user = new User();
            user.setId(userEntity.getId());
            user.setName(userEntity.getName());
            user.setCompanyId(userEntity.getCompanyId());
            user.setCompanyName(userEntity.getCompanyName());
            user.setEmailAddress(userEntity.getEmailAddress());
            user.setPhoneNumber(userEntity.getPhoneNumber());
            user.setUpdatedDate(userEntity.getUpdatedDate());
            user.setUpdatedBy(userEntity.getUpdatedBy());
            user.setCreatedBy(userEntity.getCreatedBy());
            user.setCreationDate(userEntity.getCreationDate());
            return user;
        } catch (UserNotFoundException ex){
            throw new UserNotFoundException("Error in user mapping");
        }
    }

    public static UserEntity toUserHibernate(User user) throws UserNotFoundException {
        try {
            if (user == null) {
                throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
            }
            UserEntity userEntity = new UserEntity();

            userEntity.setId(user.getId());
            userEntity.setName(user.getName());
            userEntity.setCompanyId(user.getCompanyId());
            userEntity.setEmailAddress(user.getEmailAddress());
            userEntity.setPhoneNumber(user.getPhoneNumber());
            userEntity.setCreationDate(user.getCreationDate());
            userEntity.setCreatedBy(user.getCreatedBy());
            userEntity.setUpdatedBy(user.getUpdatedBy());
            userEntity.setUpdatedDate(user.getUpdatedDate());
            return userEntity;
        } catch (UserNotFoundException ex){
            throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
        }
    }

    public static User toUser(UserEntity userEntity) throws UserNotFoundException {

        try{
            if(userEntity == null){
                throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
            }
        User user = new User();
        mapHibernateFieldsToUser(userEntity, user);
        return user;
        } catch (UserNotFoundException e){
            throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
        }
    }

    public static void mapHibernateFieldsToUser(UserEntity userEntity, User user) throws UserNotFoundException {
        try {
            if (user == null || userEntity == null) {
                throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
            }
            user.setId(userEntity.getId());
            user.setName(userEntity.getName());
            user.setEmailAddress(userEntity.getEmailAddress());
            user.setCompanyId(userEntity.getCompanyId());
            user.setPhoneNumber(userEntity.getPhoneNumber());
            user.setUpdatedDate(userEntity.getUpdatedDate());
            user.setUpdatedBy(userEntity.getUpdatedBy());
            user.setCreatedBy(userEntity.getCreatedBy());
            user.setCreationDate(userEntity.getCreationDate());
        } catch (UserNotFoundException e){
            throw new UserNotFoundException(Constants.USER_MAPPING_FAILED);
        }
    }
}
