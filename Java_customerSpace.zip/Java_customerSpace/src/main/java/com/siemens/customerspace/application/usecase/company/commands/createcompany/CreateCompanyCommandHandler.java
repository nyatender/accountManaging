package com.siemens.customerspace.application.usecase.company.commands.createcompany;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.mappings.CompanyMappingProfiles;
import com.siemens.customerspace.application.usecase.company.queries.getcompanies.CompanyResponseDTO;
import com.siemens.customerspace.domain.entities.Company;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class CreateCompanyCommandHandler {

    private final ICompanyAsyncRepository iCompanyAsyncRepository;

    private final CompanyMappingProfiles companyMappingProfiles;


    @Autowired
    public  CreateCompanyCommandHandler(ICompanyAsyncRepository iCompanyAsyncRepository, CompanyMappingProfiles companyMappingProfiles){
        this.iCompanyAsyncRepository = iCompanyAsyncRepository;
        this.companyMappingProfiles = companyMappingProfiles;
    }

    @Transactional
    public CompletableFuture<Long> createCompany(CreateCompanyCommand request) throws CompanyNotFoundException, InterruptedException {
        try {
            Company company = new Company(
                    request.getCompanyName(), request.getGeneralEmailId(),
                    request.getCountry(), request.getTelephone(), request.getAddress(),
                     request.getZipCode(),0);
            setBaseProperties(request, company);
            CompletableFuture<Company> createdCompany = this.iCompanyAsyncRepository.createCompany(company);
            CompletableFuture<CompanyResponseDTO> createdCompanyResponseDTO = this.companyMappingProfiles.mapToCompanyDTO(createdCompany.get());
            log.info("Company created successfully");
            return CompletableFuture.completedFuture(createdCompanyResponseDTO.get().getId());
        } catch (CompanyNotFoundException | ExecutionException e) {
            log.error(e.getMessage());
            throw new CompanyNotFoundException(e.getMessage());
        }catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }

    }

    private static void setBaseProperties(CreateCompanyCommand request, Company company) {
        company.setCreatedBy(request.getCreatedBy());
        company.setUpdatedBy(request.getUpdatedBy());
        company.setCreationDate(LocalDateTime.now());
        company.setUpdatedDate(LocalDateTime.now());
    }
}
