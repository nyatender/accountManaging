package com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid;


import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

public class GetCompanyMappingByIdCommandHandler {
    private final ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository;

    @Autowired
    public GetCompanyMappingByIdCommandHandler(ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository){
        this.iCompanyConfigAsyncRepository = iCompanyConfigAsyncRepository;

    }
    @Transactional
    public CompletableFuture<MindSphereCompanyMapping> getMindSphereMapping(Long companyId) throws CompanyNotFoundException {
        try {
            return this.iCompanyConfigAsyncRepository.getMindSphereCompanyByIdMapping(companyId);
        } catch (CompanyNotFoundException e) {
            throw new CompanyNotFoundException(e.getMessage());
        }
    }

}
