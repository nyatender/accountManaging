package com.siemens.customerspace.application.contracts.repositories;

import com.fasterxml.jackson.databind.JsonNode;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public interface IDDXAsyncRepository {

    public CompletableFuture<JsonNode> getDDXLoginToken(JsonNode mindSphereConfig) throws ConnectException, InterruptedException, ExecutionException;

    public CompletableFuture<JsonNode> getMindSphereLoginToken() throws ConnectException, InterruptedException;


}
