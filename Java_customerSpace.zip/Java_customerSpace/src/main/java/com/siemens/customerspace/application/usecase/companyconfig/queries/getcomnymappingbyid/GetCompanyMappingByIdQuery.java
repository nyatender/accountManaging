package com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GetCompanyMappingByIdQuery {

    private String mindSphereToken;

    private String ddxToken;

    private Long mindSphereCompanyId;

    private Long companyId;

}
