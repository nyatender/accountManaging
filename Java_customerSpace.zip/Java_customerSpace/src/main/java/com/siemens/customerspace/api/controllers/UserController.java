package com.siemens.customerspace.api.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.paging.PageRequestDTO;
import com.siemens.customerspace.application.paging.PageResponseDTO;
import com.siemens.customerspace.application.usecase.user.commands.createuser.CreateUserCommand;
import com.siemens.customerspace.application.usecase.user.commands.createuser.CreateUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.commands.deleteuser.DeleteUserCommand;
import com.siemens.customerspace.application.usecase.user.commands.deleteuser.DeleteUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.commands.updateuser.UpdateUserCommand;
import com.siemens.customerspace.application.usecase.user.commands.updateuser.UpdateUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyemailaddress.GetUserByEmailAddressQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyid.GetUserByIdQuery;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyid.GetUserByIdQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyname.GetUserByNameQuery;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyname.GetUserByNameQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getusers.GetUserQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getusers.UserResponseDTO;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.sql.SQLClientInfoException;
import java.text.MessageFormat;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("api/v1/user")
@CircuitBreaker(name = "customer_space_service")
@RateLimiter(name = "basic")
public class UserController {

    private final CreateUserCommandHandler createUserCommandHandler;

    private final UpdateUserCommandHandler updateUserCommandHandler;

    private final DeleteUserCommandHandler deleteUserCommandHandler;

    private final GetUserByNameQueryHandler getUserByNameQueryHandler;

    private final GetUserQueryHandler getUserQueryHandler;

    private final GetUserByIdQueryHandler getUserByIdQueryHandler;

    private final GetUserByEmailAddressQueryHandler getUserByEmailAddressQueryHandler;

    @Autowired
    public UserController(CreateUserCommandHandler createUserCommandHandler,
                             UpdateUserCommandHandler updateUserCommandHandler,
                             DeleteUserCommandHandler deleteUserCommandHandler,
                             GetUserByNameQueryHandler getUserByNameQueryHandler,
                             GetUserQueryHandler getUserQueryHandler,
                             GetUserByIdQueryHandler getUserByIdQueryHandler,
                             GetUserByEmailAddressQueryHandler getUserByEmailAddressQueryHandler){

        this.createUserCommandHandler = createUserCommandHandler;
        this.updateUserCommandHandler = updateUserCommandHandler;
        this.deleteUserCommandHandler = deleteUserCommandHandler;
        this.getUserByNameQueryHandler = getUserByNameQueryHandler;
        this.getUserQueryHandler = getUserQueryHandler;
        this.getUserByIdQueryHandler = getUserByIdQueryHandler;
        this.getUserByEmailAddressQueryHandler = getUserByEmailAddressQueryHandler;
    }

    @PostMapping("/addUser")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Long>> createUser(
            @RequestBody CreateUserCommand userCommandDTO,
            @RequestHeader Map<String,String> headers) throws UserNotFoundException, InterruptedException {
        try {
            String uniqueName = getUniqueNameFromAccessToken(headers);
            userCommandDTO.setCreatedBy(uniqueName);
            userCommandDTO.setUpdatedBy(uniqueName);
            CompletableFuture<Long> userResponseDTO = this.createUserCommandHandler.createUser(userCommandDTO);
            return userResponseDTO.thenApplyAsync(ResponseEntity.ok()::body);
        } catch (TransactionSystemException | JsonProcessingException e){
            log.error(e.getCause().getCause().getMessage());
            throw new UserNotFoundException(e.getCause().getCause().getMessage());
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    @GetMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<PageResponseDTO<UserResponseDTO>>> getAllUsers(
            @Valid PageRequestDTO pageRequestDTO, @RequestParam(required = false) String filter) throws UserNotFoundException, InterruptedException {

        CompletableFuture<PageResponseDTO<UserResponseDTO>> page;
        try {
            page = this.getUserQueryHandler.getAllUsers(pageRequestDTO, filter);
            log.info("GetAll User Response " + page.get().getItems());
            return CompletableFuture.completedFuture(new ResponseEntity<>(page.get(), HttpStatus.OK));
        } catch (UserNotFoundException |  ExecutionException e)
        {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }

    @GetMapping("/{id}")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Optional<GetUserByIdQuery>>> getUserById(@Valid @PathVariable("id") Long id) throws UserNotFoundException, InterruptedException {
        try {
            Optional<GetUserByIdQuery> userById =new ModelMapper().map(this.getUserByIdQueryHandler.getUserById(id).get(),Optional.class);
            log.info(MessageFormat.format(Constants.USER_WITH_ID ,id,userById.get()));
            return CompletableFuture.completedFuture(new ResponseEntity<>(userById, HttpStatus.OK));
        } catch (UserNotFoundException | RuntimeException |  ExecutionException ex) {
            log.error(MessageFormat.format(Constants.USER_WITH_ID_NOT_FOUND,id));
            throw new UserNotFoundException(ex.getMessage());
        } catch (InterruptedException e){
            throw new InterruptedException(e.getMessage());
        }
    }

    @GetMapping("/getByName")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<PageResponseDTO<GetUserByNameQuery>>> getUserByName(
                                                 @Valid PageRequestDTO pageRequestDTO,
                                                 @Valid @RequestParam(required = false) String name,
                                                 @RequestParam(required = false) String filter) throws UserNotFoundException, InterruptedException {
        try {
            CompletableFuture<PageResponseDTO<GetUserByNameQuery>> page;
            page =this.getUserByNameQueryHandler.getUserByName(pageRequestDTO,name,filter);

            log.info(MessageFormat.format("Users with name {0} :" ,page.get().getItems()));
            return CompletableFuture.completedFuture(new ResponseEntity<>(page.get(), HttpStatus.OK));
        } catch (UserNotFoundException | RuntimeException |  ExecutionException ex) {
            log.error(MessageFormat.format(Constants.USER_WITH_NAME,name));
            throw new UserNotFoundException(ex.getMessage());
        } catch (InterruptedException e){
            throw new InterruptedException(e.getMessage());
        }
    }

    @GetMapping("/getByEmailAddress")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Boolean>> getUserByEmailAddress( @RequestHeader Map<String,String> headers) throws UserNotFoundException, InterruptedException {
        try {
            String uniqueName = getUniqueNameFromAccessToken(headers);
            User emailAddressExists =this.getUserByEmailAddressQueryHandler.getUserByEmailAddress(uniqueName).get();
            log.info(MessageFormat.format(Constants.USER_WITH_EMAIL_EXISTS,uniqueName,emailAddressExists));
            if(emailAddressExists == null) {
                return CompletableFuture.completedFuture(new ResponseEntity<>(false, HttpStatus.OK));
            }
            return CompletableFuture.completedFuture(new ResponseEntity<>(true, HttpStatus.OK));
        } catch (UserNotFoundException | RuntimeException |  ExecutionException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(ex.getMessage());
        } catch (InterruptedException | JsonProcessingException exception){
            throw new InterruptedException(exception.getMessage());
        }
    }

    @GetMapping("/searchByEmailAddress")
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Boolean>> searchUserByEmailAddress(String emailAddress) throws UserNotFoundException, InterruptedException {
        try {
            User emailAddressExists =this.getUserByEmailAddressQueryHandler.getUserByEmailAddress(emailAddress).get();
            log.info(MessageFormat.format(Constants.USER_WITH_EMAIL_EXISTS,emailAddress,emailAddressExists));
            if(emailAddressExists == null) {
                return CompletableFuture.completedFuture(new ResponseEntity<>(false, HttpStatus.OK));
            }
            return CompletableFuture.completedFuture(new ResponseEntity<>(true, HttpStatus.OK));
        } catch (UserNotFoundException | RuntimeException |  ExecutionException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(ex.getMessage());
        } catch (InterruptedException e){
            throw new InterruptedException(e.getMessage());
        }
    }

    @DeleteMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<Boolean>> deleteUser(@Valid @RequestBody DeleteUserCommand userID) throws UserNotFoundException, InterruptedException {
        try {
            CompletableFuture<Boolean> deleteUser = this.deleteUserCommandHandler.deleteUser(userID);
            log.info(MessageFormat.format(Constants.USER_DELETE,userID.getId()));
            return deleteUser.thenApplyAsync(ResponseEntity.ok()::body);
        } catch (UserNotFoundException ex) {
            throw new UserNotFoundException(MessageFormat.format(Constants.USER_DELETE_FAILURE,userID.getId()));
        } catch (InterruptedException | ExecutionException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    @PutMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<ResponseEntity<User>> updateUser(
            @Valid @RequestBody UpdateUserCommand userRequestDTO,
            @RequestHeader Map<String,String> headers) throws Exception{
        try {
            String uniqueName = getUniqueNameFromAccessToken(headers);
            userRequestDTO.setCreatedBy(uniqueName);
            userRequestDTO.setUpdatedBy(uniqueName);
            CompletableFuture<User> userResponseDTO = this.updateUserCommandHandler.updateUser(userRequestDTO);
            log.info("Response {} ", userResponseDTO);
            return CompletableFuture.completedFuture(new ResponseEntity<>(userResponseDTO.get(), HttpStatus.OK));
        } catch (UserNotFoundException | ExecutionException  ex) {
            log.error(Constants.USER_UPDATE_FAILED);
            throw new UserNotFoundException(Constants.USER_UPDATE_FAILED);
        } catch (InterruptedException e){
            throw new InterruptedException(e.getMessage());
        }
    }

    String getUniqueNameFromAccessToken(Map<String, String> headers) throws JsonProcessingException {
        String accessToken = getAccessToken(headers);
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String[] jwtToken = accessToken.split("\\.");
        String body = new String(decoder.decode(jwtToken[1]));
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(body);
        if (rootNode == null) {
            return null;
        }
        return rootNode.get("unique_name").textValue();
    }

    String getAccessToken(Map<String, String> headers) {
        String bearerToken = headers.get("authorization");
        return bearerToken.substring(7);
    }
}
