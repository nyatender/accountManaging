package com.siemens.customerspace.application.usecase.user.queries.getusers;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserResponseDTO extends BaseModelDTO {

    private String name;

    private String emailAddress;

    private String phoneNumber;

    private Long companyId;

    private String companyName;
}
