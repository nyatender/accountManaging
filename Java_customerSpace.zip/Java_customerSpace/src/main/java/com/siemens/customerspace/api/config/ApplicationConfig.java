package com.siemens.customerspace.api.config;


import com.siemens.customerspace.application.contracts.repositories.*;
import com.siemens.customerspace.application.mappings.CompanyMappingProfiles;
import com.siemens.customerspace.application.mappings.UserMappingProfiles;
import com.siemens.customerspace.application.usecase.company.commands.createcompany.CreateCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.commands.deletecompany.DeleteCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.commands.updatecompany.UpdateCompanyCommandHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanies.GetCompanyQueryHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyid.GetCompanyByIdQueryHandler;
import com.siemens.customerspace.application.usecase.company.queries.getcompanybyname.GetCompanyByNameQueryHandler;
import com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid.GetCompanyMappingByIdCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.commands.createmindsphereddxmapping.CreateMindSphereCompanyMappingCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.commands.updatemindsphereddxmapping.UpdateMindSphereCompanyMappingCommandHandler;
import com.siemens.customerspace.application.usecase.companymapping.queries.getaccesstoken.GetAccessTokenCommandHandler;
import com.siemens.customerspace.application.usecase.platformuser.queries.getplatformuserbyemailaddress.GetPlatformUserByEmailAddressQueryHandler;
import com.siemens.customerspace.application.usecase.user.commands.createuser.CreateUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.commands.deleteuser.DeleteUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.commands.updateuser.UpdateUserCommandHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyemailaddress.GetUserByEmailAddressQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyid.GetUserByIdQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyname.GetUserByNameQueryHandler;
import com.siemens.customerspace.application.usecase.user.queries.getusers.GetUserQueryHandler;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import com.siemens.customerspace.infrastructure.persistence.MindSphereDdxCompanyMappingContext;
import com.siemens.customerspace.infrastructure.repositories.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApplicationConfig {

    @Bean
    CreateCompanyCommandHandler standardTodosApi(ICompanyAsyncRepository repository, CreateMindSphereCompanyMappingCommandHandler createMindSphereCompanyMappingCommandHandler) {
        return new CreateCompanyCommandHandler(repository, new CompanyMappingProfiles());
    }

    @Bean
    GetCompanyQueryHandler standardTodosApi1(ICompanyAsyncRepository repository) {
        return new GetCompanyQueryHandler(repository);
    }

    @Bean
    GetCompanyByIdQueryHandler standardTodosApi2(ICompanyAsyncRepository repository, ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository) {
        return new GetCompanyByIdQueryHandler(repository,iCompanyConfigAsyncRepository);
    }

    @Bean
    DeleteCompanyCommandHandler standardTodosApi3(ICompanyAsyncRepository repository,
                                                  ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository) {
        return new DeleteCompanyCommandHandler(repository,iCompanyConfigAsyncRepository);
    }

    @Bean
    UpdateCompanyCommandHandler standardTodosApi4(ICompanyAsyncRepository repository) {
        return new UpdateCompanyCommandHandler(repository,new CompanyMappingProfiles());
    }

    @Bean
    GetCompanyByNameQueryHandler standardTodosApi5(ICompanyAsyncRepository repository){
        return new GetCompanyByNameQueryHandler(repository);
    }

    @Bean
    GetUserByIdQueryHandler standardTodosApi6(IUserAsyncRepository repository){
        return new GetUserByIdQueryHandler(repository);
    }

    @Bean
    GetUserQueryHandler standardTodosApi7(IUserAsyncRepository repository){
        return new GetUserQueryHandler(repository);
    }

    @Bean
    GetUserByNameQueryHandler standardTodosApi8(IUserAsyncRepository repository){
        return new GetUserByNameQueryHandler(repository);
    }

    @Bean
    CreateUserCommandHandler standardTodosApi9(IUserAsyncRepository repository){
        return new CreateUserCommandHandler(repository, new UserMappingProfiles());
    }

    @Bean
    UpdateUserCommandHandler standardTodosApi10(IUserAsyncRepository repository){
        return new UpdateUserCommandHandler(repository, new UserMappingProfiles());
    }

    @Bean
    DeleteUserCommandHandler standardTodosApi11(IUserAsyncRepository repository){
        return new DeleteUserCommandHandler(repository);
    }

    @Bean
    GetUserByEmailAddressQueryHandler standardTodosApi12(IUserAsyncRepository repository){
        return new GetUserByEmailAddressQueryHandler(repository);
    }

    @Bean
    GetPlatformUserByEmailAddressQueryHandler standardTodosApi13(IPlatformUserAsyncRepository repository){
        return new GetPlatformUserByEmailAddressQueryHandler(repository);
    }

    @Bean
    CreateMindSphereCompanyMappingCommandHandler standardTodosApi14(ICompanyConfigAsyncRepository repository){
        return new CreateMindSphereCompanyMappingCommandHandler(repository);
    }

    @Bean
    MindSphereCompanyMapping standardTodosApi15(IDDXAsyncRepository repository){
        return new MindSphereCompanyMapping();
    }

    @Bean
    GetAccessTokenCommandHandler standardTodosApi16(IDDXAsyncRepository repository){
        return new GetAccessTokenCommandHandler(repository);
    }

    @Bean
    GetCompanyMappingByIdCommandHandler standardTodosApi17(ICompanyConfigAsyncRepository repository) {
        return new GetCompanyMappingByIdCommandHandler(repository);
    }

    @Bean
    UpdateMindSphereCompanyMappingCommandHandler standardTodosApi18(ICompanyConfigAsyncRepository repository) {
        return new UpdateMindSphereCompanyMappingCommandHandler(repository);
    }

    @Bean
    IDDXAsyncRepository todosRepository3(MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext){
        return new DDXAsyncRepository(mindSphereDdxCompanyMappingContext);
    }

    @Bean
    ICompanyConfigAsyncRepository todosRepository4(MindSphereDdxCompanyMappingContext mindSphereDdxCompanyMappingContext){
        return new CompanyConfigAsyncRepository(mindSphereDdxCompanyMappingContext);
    }
}
