package com.siemens.customerspace.application.mappings;



import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.usecase.user.commands.updateuser.UpdateUserCommand;
import com.siemens.customerspace.application.usecase.user.queries.getusers.UserResponseDTO;
import com.siemens.customerspace.domain.entities.User;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

public class UserMappingProfiles {

    public CompletableFuture<UserResponseDTO> mapToUserDTO(User user) throws UserNotFoundException {
        try {
            if (user == null) {
                return null;
            }
            UserResponseDTO userResponseDTO = new UserResponseDTO();
            userResponseDTO.setId(user.getId());
            userResponseDTO.setName(user.getName());
            userResponseDTO.setEmailAddress(user.getEmailAddress());
            userResponseDTO.setPhoneNumber(user.getPhoneNumber());
            userResponseDTO.setCompanyId(user.getCompanyId());
            userResponseDTO.setCreatedBy(user.getCreatedBy());
            userResponseDTO.setCreationDate(user.getCreationDate());
            userResponseDTO.setUpdatedBy(user.getUpdatedBy());
            userResponseDTO.setUpdatedDate(user.getUpdatedDate());
            return CompletableFuture.completedFuture(userResponseDTO);
        }
        catch (Exception e){
            throw new UserNotFoundException("Unable to map User Entity to User DTO");
        }
    }

    public CompletableFuture<User> mapToUser(UpdateUserCommand userResponseDTO) throws UserNotFoundException {
        try {
            if (userResponseDTO == null) {
                return null;
            }
            User user = new User();
            user.setId(userResponseDTO.getId());
            user.setName(userResponseDTO.getName());
            user.setPhoneNumber(userResponseDTO.getPhoneNumber());
            user.setCompanyId(userResponseDTO.getCompanyId());
            user.setEmailAddress(userResponseDTO.getEmailAddress());
            user.setUpdatedBy(userResponseDTO.getUpdatedBy());
            user.setCreatedBy(userResponseDTO.getCreatedBy());
            user.setCreationDate(userResponseDTO.getCreationDate());
            user.setUpdatedDate(LocalDateTime.now());
            return CompletableFuture.completedFuture(user);
        }
        catch (Exception e){
            throw new UserNotFoundException("Unable to map User DTO to User Entity");
        }
    }
}
