package com.siemens.customerspace.application.contracts.repositories;


import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.entities.Company;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public interface ICompanyAsyncRepository {
    CompletableFuture<Page<Company>> getAllCompanies(Pageable pageable, String filter) throws CompanyNotFoundException;
    CompletableFuture<Company> createCompany(Company company) throws CompanyNotFoundException ;

    CompletableFuture<Company> updateCompany(Company company) throws CompanyNotFoundException;

    CompletableFuture<Boolean> deleteCompany(Long id) throws CompanyNotFoundException;

    CompletableFuture<Company> getCompanyById(Long id) throws CompanyNotFoundException;

    CompletableFuture<Optional<Company>> findByCompanyName(String companyName) throws CompanyNotFoundException;

    CompletableFuture<List<Company>> getCompanyIdAndName() throws CompanyNotFoundException;
}
