package com.siemens.customerspace.application.usecase.company.commands.deletecompany;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteCompanyCommand {
    private Long id;
}