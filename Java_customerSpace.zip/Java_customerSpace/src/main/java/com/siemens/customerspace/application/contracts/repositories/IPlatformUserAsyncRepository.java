package com.siemens.customerspace.application.contracts.repositories;



import com.siemens.customerspace.application.exceptions.UserNotFoundException;

import java.util.concurrent.CompletableFuture;

public interface IPlatformUserAsyncRepository {

    CompletableFuture<Boolean> findByEmailAddress(String emailAddress) throws UserNotFoundException,InterruptedException;
}
