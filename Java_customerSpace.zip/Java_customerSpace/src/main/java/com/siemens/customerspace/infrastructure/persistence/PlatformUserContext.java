package com.siemens.customerspace.infrastructure.persistence;


import com.siemens.customerspace.infrastructure.model.PlatformUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.concurrent.CompletableFuture;

public interface PlatformUserContext extends JpaRepository<PlatformUserEntity, Long> {

    public CompletableFuture<PlatformUserEntity> findByEmailAddress(String emailAddress);
}
