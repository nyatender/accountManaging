package com.siemens.customerspace.domain.entities;



import com.siemens.customerspace.domain.common.EntityBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MindSphereCompanyMapping extends EntityBase {

    private Long mindSphereCompanyId;
    private Long companyId;
    private String billingEmailId;
    private String incidentReportingEmailId;
    private String ddxToken;

}
