package com.siemens.customerspace.application.paging;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Builder
@AllArgsConstructor
@NoArgsConstructor

public class PageRequestDTO {

  private Integer defaultPageSize = 30;
  private Integer defaultPageNumber = 0;

  @Min(0)
  private Integer page;

  @Min(1)
  @Max(1000)
  private Integer pageSize;

  public Integer getPage() {
    return page;
  }

  public Integer getPageSize() {
    return pageSize;
  }

  public String getSort() {
    return sort;
  }

  public void setPage(Integer page) {
    this.page = page;
  }

  public void setPageSize(Integer pageSize) {
    this.pageSize = pageSize;
  }

  public void setSort(String sort) {
    this.sort = sort;
  }

  @Size(min = 1)
  private String sort;

  public Pageable getPageable() {
    Sort sortObject = new SortParamConverter().fromString(sort);
    return PageRequest.of(
        page == null ? defaultPageNumber : page,
        pageSize == null ? defaultPageSize : pageSize,
        sortObject);
  }
}
