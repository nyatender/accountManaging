package com.siemens.customerspace.application.contracts.repositories;



import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;

import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

public interface ICompanyConfigAsyncRepository {

    public CompletableFuture<MindSphereCompanyMapping> createMindSphereDDXCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws ConnectException, CompanyNotFoundException, UserNotFoundException;

    public CompletableFuture<MindSphereCompanyMapping> getMindSphereCompanyByIdMapping(Long companyId) throws CompanyNotFoundException;
    CompletableFuture<Boolean> deleteMindSphereCompanyMapping(Long id) throws CompanyNotFoundException;

    CompletableFuture<MindSphereCompanyMapping> updateMindSphereCompanyMapping(MindSphereCompanyMapping mindSphereCompanyMapping) throws CompanyNotFoundException;

}
