
package com.siemens.customerspace.application.usecase.user.queries.getuserbyemailaddress;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class GetUserByEmailAddressQuery extends BaseModelDTO {

    private String name;

    private String emailAddress;

    private String phoneNumber;

    private Long companyId;

}
