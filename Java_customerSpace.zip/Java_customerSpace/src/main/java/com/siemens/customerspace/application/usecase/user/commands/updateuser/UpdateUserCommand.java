package com.siemens.customerspace.application.usecase.user.commands.updateuser;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class UpdateUserCommand extends BaseModelDTO {

    private String name;

    private String emailAddress;

    private String phoneNumber;

    private Long companyId;
}
