package com.siemens.customerspace.infrastructure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name = "company",uniqueConstraints={@UniqueConstraint(columnNames={"company_name"})})
@NoArgsConstructor
@Getter
@Setter
public class CompanyEntity extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "company_seq_v2")
    @SequenceGenerator(name = "company_seq_v2", sequenceName = "company_seq_v2", allocationSize = 1)
    private Long id;

    @Column(name="company_name",length = 50)
    @NotEmpty
    private String companyName;

    @Column(name = "email_address",length = 50)
    @NotEmpty
    private String generalEmailId;

    @Column(name = "country",length = 50)
    @NotEmpty
    private String country;

    @Column(name = "telephone",length = 50)
    @NotEmpty
    private String telephone;


    @Column(name = "address")
    @NotEmpty
    @Size(max = 500, message = "Length cannot be greater than 500")
    private String address;

    @Column(name = "zip_code",length = 50)
    @NotEmpty
    private String zipCode;

    @OneToMany(
            targetEntity = UserEntity.class,
            fetch = FetchType.EAGER,
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    @JoinColumn(name ="company_id",referencedColumnName = "id",insertable = false,updatable = false)
    private List<UserEntity> userEntityList;
}
