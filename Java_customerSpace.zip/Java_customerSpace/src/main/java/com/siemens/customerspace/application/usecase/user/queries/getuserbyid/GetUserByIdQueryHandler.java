package com.siemens.customerspace.application.usecase.user.queries.getuserbyid;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class GetUserByIdQueryHandler {

    private final IUserAsyncRepository iUserAsyncRepository;

    private static final Logger logger = LoggerFactory.getLogger(GetUserByIdQueryHandler.class);

    @Autowired
    public GetUserByIdQueryHandler(IUserAsyncRepository iUserAsyncRepository){
            this.iUserAsyncRepository = iUserAsyncRepository;
    }

    @Transactional
    public CompletableFuture<Optional<User>> getUserById(Long userID) throws UserNotFoundException {
        try {

            return this.iUserAsyncRepository.getUserById(userID);
        } catch (UserNotFoundException e) {
            logger.info(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        }
    }
}
