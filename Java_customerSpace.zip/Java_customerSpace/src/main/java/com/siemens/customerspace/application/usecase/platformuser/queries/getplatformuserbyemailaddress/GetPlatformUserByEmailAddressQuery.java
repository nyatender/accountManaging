
package com.siemens.customerspace.application.usecase.platformuser.queries.getplatformuserbyemailaddress;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class GetPlatformUserByEmailAddressQuery extends BaseModelDTO {

    private String name;

    private String emailAddress;

    private Boolean isActive;

}
