package com.siemens.customerspace.infrastructure.repositories;


import com.siemens.customerspace.application.contracts.repositories.IPlatformUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.infrastructure.model.PlatformUserEntity;
import com.siemens.customerspace.infrastructure.persistence.PlatformUserContext;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
@Transactional
public class PlatformUserRepository implements IPlatformUserAsyncRepository {

    private final PlatformUserContext platformUserContext;

    ModelMapper modelMapper = new ModelMapper();

    @Autowired
    public PlatformUserRepository(PlatformUserContext platformUserContext) {
        this.platformUserContext = platformUserContext;

    }
    @Override
    public CompletableFuture<Boolean> findByEmailAddress(String emailAddress) throws UserNotFoundException, InterruptedException {
        try {
            CompletableFuture<PlatformUserEntity> userHibernate = this.platformUserContext.findByEmailAddress(emailAddress);
            if (userHibernate.get() == null) {
                log.info(MessageFormat.format(Constants.USER_WITH_EMAIL_DOES_NOT_EXISTS,emailAddress));
               return CompletableFuture.completedFuture(false);
            }
            return CompletableFuture.completedFuture(true);
        } catch (InterruptedException | ExecutionException ex) {
            log.error(Constants.USER_NOT_FOUND);
            throw new InterruptedException(Constants.USER_NOT_FOUND);
        }
    }
}
