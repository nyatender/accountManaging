package com.siemens.customerspace.application.usecase.user.commands.deleteuser;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteUserCommand {
    private Long id;
}