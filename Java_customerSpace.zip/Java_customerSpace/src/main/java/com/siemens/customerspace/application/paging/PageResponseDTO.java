package com.siemens.customerspace.application.paging;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.data.domain.Page;

import java.util.List;

@Value
@Builder
@AllArgsConstructor
public class PageResponseDTO<T> {
  List<T> items;
  int page;
  int pageSize;
  int totalPages;
  long totalElements;
  boolean hasNext;
  boolean hasPrevious;

  public static <R> PageResponseDTO<R> of(Page<R> page) {
    return PageResponseDTO.<R>builder()
        .items(page.getContent())
        .totalPages(page.getTotalPages())
        .totalElements(page.getTotalElements())
        .pageSize(page.getSize())
        .page(page.getNumber())
        .hasPrevious(!page.isFirst())
        .hasNext(!page.isLast())
        .build();
  }
}
