package com.siemens.customerspace.application.usecase.companymapping.queries.getaccesstoken;

import com.fasterxml.jackson.databind.JsonNode;

import com.siemens.customerspace.application.contracts.repositories.IDDXAsyncRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetAccessTokenCommandHandler {

    private IDDXAsyncRepository iddxAsyncRepository;

    @Autowired
    public GetAccessTokenCommandHandler(IDDXAsyncRepository iddxAsyncRepository){
        this.iddxAsyncRepository = iddxAsyncRepository;
    }

    @Transactional
    public CompletableFuture<JsonNode> getMindSphereToken() throws ConnectException, InterruptedException {
        try {
            return this.iddxAsyncRepository.getMindSphereLoginToken();
        } catch (ConnectException e) {
            throw new ConnectException(e.getMessage());
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    @Transactional
    public CompletableFuture<JsonNode> getDdxToken(JsonNode mindSphereConfig) throws ConnectException, InterruptedException {
        try {

            CompletableFuture<JsonNode> mindSphereToken = this.iddxAsyncRepository.getDDXLoginToken(mindSphereConfig);
            log.info("MindSphere Token saved successfully");

            return CompletableFuture.completedFuture(mindSphereToken.get());
        } catch (ConnectException | ExecutionException e){
            throw new ConnectException(e.getMessage());
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }
}
