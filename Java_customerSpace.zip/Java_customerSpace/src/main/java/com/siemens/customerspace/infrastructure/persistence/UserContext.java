package com.siemens.customerspace.infrastructure.persistence;


import com.siemens.customerspace.infrastructure.model.UserEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserContext extends JpaRepository<UserEntity, Long> {


    @Query("SELECT u, c.companyName FROM UserEntity u LEFT JOIN CompanyEntity c ON u.companyId = c.id")
    Page<Object[]> findAllUsersWithCompanyName(Pageable pageable);


    @Query("SELECT u, c.companyName FROM UserEntity u LEFT JOIN CompanyEntity c ON u.companyId = c.id WHERE u.name = :name")
    Page<Object[]> findUserWithNameAndCompanyName(Pageable pageable,String name);

    public Optional<UserEntity> findByEmailAddress(String emailAddress);
}
