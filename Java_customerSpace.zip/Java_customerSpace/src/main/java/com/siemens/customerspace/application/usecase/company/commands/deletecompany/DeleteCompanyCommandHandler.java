package com.siemens.customerspace.application.usecase.company.commands.deletecompany;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.contracts.repositories.ICompanyConfigAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;
import java.text.MessageFormat;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class DeleteCompanyCommandHandler {
    private final ICompanyAsyncRepository iCompanyAsyncRepository;

    private final ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository;
    @Autowired
    public DeleteCompanyCommandHandler(ICompanyAsyncRepository iCompanyAsyncRepository,
                                       ICompanyConfigAsyncRepository iCompanyConfigAsyncRepository) {
        this.iCompanyAsyncRepository = iCompanyAsyncRepository;
        this.iCompanyConfigAsyncRepository = iCompanyConfigAsyncRepository;
    }

    @Transactional
    public CompletableFuture<Boolean> deleteCompany(DeleteCompanyCommand request) throws CompanyNotFoundException, InterruptedException {
        try {
            CompletableFuture<Company> findCompanyByID = this.iCompanyAsyncRepository.getCompanyById(request.getId());
            if (findCompanyByID.get() != null ) {
                CompletableFuture<MindSphereCompanyMapping> mindSphereCompanyMapping = this.iCompanyConfigAsyncRepository.getMindSphereCompanyByIdMapping(findCompanyByID.get().getId());
                if (findCompanyByID.get().getUserCount() == 0 && mindSphereCompanyMapping.get().getId() != null) {
                  CompletableFuture<Boolean> isMindSphereMappingDeleted =  this.iCompanyConfigAsyncRepository.deleteMindSphereCompanyMapping(mindSphereCompanyMapping.get().getCompanyId());
                  log.info(MessageFormat.format("MindSphere Company mapping deleted :{0} ",isMindSphereMappingDeleted));
                    return this.iCompanyAsyncRepository.deleteCompany(request.getId());
                } else if (findCompanyByID.get().getUserCount() == 0 && mindSphereCompanyMapping.get().getId() == null) {
                    return this.iCompanyAsyncRepository.deleteCompany(request.getId());
                } else if (findCompanyByID.get().getUserCount() > 0) {
                    throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_USER_MAPPING_ERROR, request.getId()));
                } else {
                    throw new CompanyNotFoundException(MessageFormat.format(Constants.COMPANY_WITH_ID_NOT_FOUND, request.getId()));
                }
            }
        } catch (CompanyNotFoundException | ExecutionException e) {
            log.error(MessageFormat.format(Constants.COMPANY_DELETE_FAILURE, request.getId()));
            throw new CompanyNotFoundException(e.getMessage());
        } catch (InterruptedException ex) {
            throw new InterruptedException(ex.getMessage());
        }
        return null;
    }
}
