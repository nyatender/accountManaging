package com.siemens.customerspace.api.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid.GetCompanyMappingByIdCommandHandler;
import com.siemens.customerspace.application.usecase.companyconfig.queries.getcomnymappingbyid.GetCompanyMappingByIdQuery;
import com.siemens.customerspace.application.usecase.companymapping.queries.getaccesstoken.GetAccessTokenCommandHandler;
import com.siemens.customerspace.application.usecase.user.queries.getuserbyemailaddress.GetUserByEmailAddressQueryHandler;
import com.siemens.customerspace.domain.entities.MindSphereCompanyMapping;
import com.siemens.customerspace.domain.entities.User;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;
import java.sql.SQLClientInfoException;
import java.util.concurrent.CompletableFuture;


@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("api/v1/companyConfig")
@CircuitBreaker(name = "customer_space_service")
@RateLimiter(name = "basic")
public class CompanyConfigController {

    private final GetAccessTokenCommandHandler getAccessTokenCommandHandler;

    private final GetCompanyMappingByIdCommandHandler getCompanyMappingByIdCommandHandler;

    private final GetUserByEmailAddressQueryHandler getUserByEmailAddressQueryHandler;

    @Autowired
    public CompanyConfigController(GetAccessTokenCommandHandler getAccessTokenCommandHandler,
                                   GetUserByEmailAddressQueryHandler getUserByEmailAddressQueryHandler,
                                   GetCompanyMappingByIdCommandHandler getCompanyMappingByIdCommandHandler){
                this.getAccessTokenCommandHandler = getAccessTokenCommandHandler;
                this.getUserByEmailAddressQueryHandler = getUserByEmailAddressQueryHandler;
                this.getCompanyMappingByIdCommandHandler = getCompanyMappingByIdCommandHandler;
    }

    @GetMapping
    @Retryable(value = SQLClientInfoException.class, maxAttemptsExpression = "${retryConfig.retry.maxAttempts}", backoff = @Backoff(delayExpression = "${retryConfig.retry.maxAttempts}"))
    @Async
    public CompletableFuture<GetCompanyMappingByIdQuery> getAllCompanies(String emailAddress) throws Exception {
        try {
            GetCompanyMappingByIdQuery companyConfig = new GetCompanyMappingByIdQuery();
            CompletableFuture<JsonNode> mindSphereConfig = this.getAccessTokenCommandHandler.getMindSphereToken();
            CompletableFuture<User> user = this.getUserByEmailAddressQueryHandler.getUserByEmailAddress(emailAddress);
            CompletableFuture<MindSphereCompanyMapping> mindSphereCompanyMapping = this.getCompanyMappingByIdCommandHandler.getMindSphereMapping(user.get().getCompanyId());
            companyConfig.setMindSphereToken(mindSphereConfig.get().get("access_token").asText());
            companyConfig.setDdxToken(mindSphereCompanyMapping.get().getDdxToken());
            companyConfig.setCompanyId(mindSphereCompanyMapping.get().getCompanyId());
            companyConfig.setMindSphereCompanyId(mindSphereCompanyMapping.join().getMindSphereCompanyId());
            return CompletableFuture.completedFuture(companyConfig);
        } catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
}
