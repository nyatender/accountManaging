package com.siemens.customerspace.infrastructure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "mind_sphere_company_mapping",uniqueConstraints={@UniqueConstraint(columnNames={"id"})})
@NoArgsConstructor
@Getter
@Setter
public class MindSphereCompanyMappingEntity extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mind_sphere_company_mapping_seq_v1")
    @SequenceGenerator(name = "mind_sphere_company_mapping_seq_v1", sequenceName = "mind_sphere_company_mapping_seq_v1", allocationSize = 1)
    public Long id;

    @Column(name="company_id",length = 50)
    @NotNull
    private Long companyId;

    @Column(name="mind_sphere_company_id",length = 50)
    @NotNull
    private Long mindSphereCompanyId;

    @Column(name="billing_email_id",length = 50)
    @NotNull
    private String billingEmailId;

    @Column(name="incident_reporting_email_id",length = 50)
    @NotNull
    private String incidentReportingEmailId;

    @Column(name="ddx_token")
    @Size(max = 5000, message = "Length cannot be greater than 5000")
    private String ddxToken;

}
