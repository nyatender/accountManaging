package com.siemens.customerspace.infrastructure.persistence;


import com.siemens.customerspace.infrastructure.model.MindSphereCompanyMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MindSphereDdxCompanyMappingContext extends JpaRepository<MindSphereCompanyMappingEntity, Long> {

    public Optional<MindSphereCompanyMappingEntity> findByCompanyId(Long companyId);

}
