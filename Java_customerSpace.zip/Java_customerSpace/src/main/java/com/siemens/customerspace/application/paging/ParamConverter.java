package com.siemens.customerspace.application.paging;


public interface ParamConverter<T> {
  T fromString(String arg0);
}
