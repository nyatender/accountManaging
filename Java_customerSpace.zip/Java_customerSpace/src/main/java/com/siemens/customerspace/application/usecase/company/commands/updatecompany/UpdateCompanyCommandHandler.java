package com.siemens.customerspace.application.usecase.company.commands.updatecompany;


import com.siemens.customerspace.application.contracts.repositories.ICompanyAsyncRepository;
import com.siemens.customerspace.application.exceptions.CompanyNotFoundException;
import com.siemens.customerspace.application.mappings.CompanyMappingProfiles;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.Company;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class UpdateCompanyCommandHandler {

    private final ICompanyAsyncRepository iCompanyAsyncRepository;
    private final CompanyMappingProfiles companyMappingProfiles;
    @Autowired
    public UpdateCompanyCommandHandler(ICompanyAsyncRepository iCompanyAsyncRepository, CompanyMappingProfiles companyMappingProfiles) {
        this.iCompanyAsyncRepository = iCompanyAsyncRepository;
        this.companyMappingProfiles = companyMappingProfiles;
    }
    @Transactional
    public CompletableFuture<Company> updateCompany(UpdateCompanyCommand request) throws CompanyNotFoundException, InterruptedException {

        try {
            CompletableFuture<Company> companyById = this.iCompanyAsyncRepository.getCompanyById(request.getId());
            if (companyById.get() ==null) {
                throw new CompanyNotFoundException(Constants.COMPANY_NOT_FOUND);
            }
            request.setCreationDate(companyById.get().getCreationDate());
            CompletableFuture<Company> company = this.companyMappingProfiles.mapToCompany(request) ;
            CompletableFuture<Company> updatedCompany = this.iCompanyAsyncRepository.updateCompany(company.get());

            log.info("Company details updated successfully");
            return CompletableFuture.completedFuture(updatedCompany.get());
        } catch (CompanyNotFoundException | ExecutionException e) {
            log.error("Unable to update company details");
            throw new CompanyNotFoundException(e.getMessage());
        } catch (InterruptedException ex){
            throw new InterruptedException(ex.getMessage());
        }
    }
}
