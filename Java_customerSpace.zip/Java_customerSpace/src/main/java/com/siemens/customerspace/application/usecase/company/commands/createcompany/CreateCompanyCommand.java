package com.siemens.customerspace.application.usecase.company.commands.createcompany;


import com.siemens.customerspace.application.models.BaseModelDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CreateCompanyCommand extends BaseModelDTO {

    private String companyName;
    private String generalEmailId;

    private String telephone;

    private String country;

    private String address;

    private String zipCode;

    private String billingEmailId;
    private String incidentReportingEmailId;
    private String ddxToken;
}
