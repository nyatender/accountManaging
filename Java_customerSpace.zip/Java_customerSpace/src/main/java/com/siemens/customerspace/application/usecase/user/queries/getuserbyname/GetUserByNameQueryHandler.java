package com.siemens.customerspace.application.usecase.user.queries.getuserbyname;


import com.siemens.customerspace.application.contracts.repositories.IUserAsyncRepository;
import com.siemens.customerspace.application.exceptions.UserNotFoundException;
import com.siemens.customerspace.application.paging.PageRequestDTO;
import com.siemens.customerspace.application.paging.PageResponseDTO;
import com.siemens.customerspace.domain.common.Constants;
import com.siemens.customerspace.domain.entities.User;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Slf4j
public class GetUserByNameQueryHandler {

    private final IUserAsyncRepository iUserAsyncRepository;

    private static final Logger logger = LoggerFactory.getLogger(GetUserByNameQueryHandler.class);

    @Autowired
    public GetUserByNameQueryHandler(IUserAsyncRepository iUserAsyncRepository){
            this.iUserAsyncRepository = iUserAsyncRepository;
    }

    @Transactional
    public CompletableFuture<PageResponseDTO<GetUserByNameQuery>> getUserByName(PageRequestDTO pageRequestDTO, String name, String filter) throws UserNotFoundException, InterruptedException, ExecutionException {
        try {
            mapFilterOptions(pageRequestDTO, filter);
            CompletableFuture<Page<User>> responseDTO =  this.iUserAsyncRepository.findByUserName(pageRequestDTO.getPageable(),name);
            Page<GetUserByNameQuery> mappedResponse =  new ModelMapper().map(responseDTO.get(),Page.class);
            PageResponseDTO<GetUserByNameQuery> mappedUserData = PageResponseDTO.of(mappedResponse);
            return CompletableFuture.completedFuture(mappedUserData);
        } catch (UserNotFoundException e) {
            logger.info(Constants.USER_NOT_FOUND);
            throw new UserNotFoundException(Constants.USER_NOT_FOUND);
        } catch (ExecutionException e) {
            throw new ExecutionException(e);
        } catch (InterruptedException e) {
            throw new InterruptedException(e.getMessage());
        }
    }

    private static void mapFilterOptions(PageRequestDTO pageRequestDTO, String filter) {
        if(filter != null && !filter.isEmpty()) {
            String[] keyValuePairs = filter.split("&");

            for(String pair : keyValuePairs)
            {
                String[] entry = pair.split("=");
                if(entry[0].trim().equals("page")){
                    pageRequestDTO.setPage(Integer.valueOf(entry[1].trim()));
                }
                if(entry[0].trim().equals("size")){
                    pageRequestDTO.setPageSize(Integer.valueOf(entry[1].trim()));
                }
            }
        }
    }
}
