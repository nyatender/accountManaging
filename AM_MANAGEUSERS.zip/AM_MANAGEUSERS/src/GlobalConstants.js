export const NO_USERS_PRESENT_INFO = 'There are no users yet.';
export const NUMBER_OF_RECORDS_PER_PAGE = 20;
export const ACCESS_TO_FUNCTIONALITIES_HEADING = 'Access To Functionalities';
export const ONLINE_SHOP_DROPDOWN_LABEL = 'Online Shop';
export const SHOP_FILTER_SEARCH_PLACEHOLDER = 'Search Shop';
export const CONFIRMATION_DIALOG_HEADER_TEXT = 'Add User';
export const CONFIRMATION_DIALOG_SUBHEADER_TEXT = 'Please enter User email';
export const ERROR_DIALOG_HEADER_TEXT = 'Sorry';
export const ERROR_DIALOG_SUBHEADER_TEXT1 = 'A user with email';
export const ERROR_DIALOG_SUBHEADER_TEXT2 = 'already exists.';
export const EMAILID_VALIDATION_MESSAGE = 'Email is required';
export const EMAILID_FORMAT_ERROR_MESSAGE = 'Email is not valid';
export const EMAILID_SEARCH_PLACEHOLDER = 'Email Address';
export const PERSONAL_INFORMATION_TITLE_TEXT = 'Personal Information';
export const EMAIL_LABEL_TEXT = 'Email';
export const FIRSTNAME_VALIDATION_MESSAGE = 'First Name must not exceed 100 characters';
export const FIRSTNAME_REQUIRED_VALIDATION_MESSAGE = 'First Name is required';
export const LASTNAME_VALIDATION_MESSAGE = 'Last Name must not exceed 100 characters';
export const LASTNAME_REQUIRED_VALIDATION_MESSAGE = 'Last Name is required';
export const PHONE_NUMBER_VALIDATION_MESSAGE = 'Phone Number must contain only numbers';
export const JOB_TITLE_VALIDATION_MESSAGE = 'Job Title must not exceed 100 characters';
export const NUMBER_OF_ITEMS = 20;
export const AVAILABLE_ADDRESS_SEARCH_PLACEHOLDER = 'Search for address';
export const AVAILABLE_ADDRESS_VALIDATION_TEXT = 'Please select one of the addresses';
export const AVAILABLE_ADDRESS_TITLE_TEXT = 'Available Addresses';
export const DELETE_USER_CONFIRMATION_DIALOG_HEADER_TEXT = 'Delete user';
export const DELETE_USER_CONFIRMATION_DIALOG_SUBHEADER_TEXT = 'Are you sure that you want to delete the user';
export const DELETE_USER_SUCCESS_MSG_PART1 = 'User';
export const DELETE_USER_SUCCESS_MSG_PART2 = 'has been deleted.';
export const DELETE_USER_FAILURE_MSG = 'The user can’t be deleted. Please try again later.';
export const PAGE_TITLE_COMPANY_USERS = 'Company Users';
export const BUTTON_TEXT_ADD_NEW_USER = 'Add new User';
export const ACCESS_TO_FUNCTIONALITY_PLACEHOLDER = 'Select Role';
export const CREATE_USER_POP_UP_INFO_SUCCESS = 'User $firstName $lastName has been created';
export const CREATE_USER_POP_UP_INFO_FAILURE = 'The user can’t be created. Please try again later';
export const SAVE_USER_POP_UP_INFO_SUCCESS = 'User $firstName $lastName has been updated';
export const SAVE_USER_POP_UP_INFO_FAILURE = 'The user can’t be edited. Please try again later';
export const FILTERS_LABEL_TEXT = 'Filters';
export const SHOP_FILTER_LABEL_TEXT = 'Shop';
export const ROLE_FILTER_LABEL_TEXT = 'Role';
export const STATUS_FILTER_LABEL_TEXT = 'Status';
export const TOTAL_USERS_TEXT = 'Users';
export const CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT = 'Cancel';
export const CONFIRMATION_DIALOG_CHECK_EMAIL_BUTTON_TEXT = 'Check Email';
export const ERROR_DIALOG_OK_BUTTON_TEXT = 'Ok';
export const USER_PROFILE_PAGE_TITLE_ADD_USERS = 'Add User';
export const USER_PROFILE_PAGE_TITLE_USER = 'User';
export const USER_PROFILE_STATUS_LABEL_TEXT = 'Status';
export const USER_PROFILE_STATUS_ACTIVE_LABEL_TEXT = 'Active';
export const USER_PROFILE_STATUS_INACTIVE_LABEL_TEXT = 'Inactive';
export const FIRST_NAME_PLACEHOLDER_TEXT = 'First Name';
export const LAST_NAME_PLACEHOLDER_TEXT = 'Last Name';
export const PHONE_NUMBER_PLACEHOLDER_TEXT = 'Phone Number';
export const JOB_TITLE_PLACEHOLDER_TEXT = 'Job Title';
export const USER_PROFILE_CANCEL_BUTTON_TEXT = 'Cancel';
export const USER_PROFILE_ADD_USER_BUTTON_TEXT = 'Add User';
export const USER_PROFILE_SAVE_BUTTON_TEXT = 'Save';
export const DELETE_USER_CONFIRMATION_DIALOG_DELETE_BUTTON_TEXT = 'Delete';
export const DELETE_USER_CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT = 'Cancel';
export const USERLIST_SEARCH_PLACEHOLDER = 'Search by user name or email';
export const REVIEW_TOOLTIP_TEXT = 'Approve / Decline';
export const EDIT_TOOLTIP_TEXT = 'Edit';
export const DELETE_TOOLTIP_TEXT = 'Delete';
export const ERROR_CODE = {
  apiError: 'apiError',
  noContent: 'noContent',
};
export const ERROR_MESSAGE = {
  apiError: 'Sorry, unable to load the infomation. Please reload the page',
  noContent: 'No results',
};
export const LANGUAGE_PLACEHOLDER = 'Language';
export const CHANGE_PASSWORD_TEXT = 'Change password';
export const CHANGE_PASSWORD_BUTTON_TEXT = 'Change Password';
export const CHANGE_PASSWORD_SUBHEADING = 'Password must be between 8 and 16 characters long and contain three of the following 4 items: upper case letter, lower case letter, a symbol, a number.';
export const PASSWORD_PLACEHOLDER = {
  newPassword: 'New Password',
  confirmPassword: 'Confirm Password',
};
export const PASSWORD_VALIDATION_MESSAGE = {
  password: 'Password doesn’t fulfil the requirements',
  confirmPassword: 'Passwords do not match',
};

export const DEFAULT_SKIP_VALUE = 0;
export const PENDING_STATUS_CONFIRMATION_DIALOG = {
  headline: 'Already processed',
  subheadline: 'The user’s request is already processed. No more action required.',
};
export const MY_USER_PROFILE_PAGE_TITLE = 'My User Profile';
export const MY_USER_PROFILE_SAVE_BUTTON_TEXT = 'Save';
export const NEW_PASSWORD_REQUIRED_VALIDATION = 'Password is required';
export const CONFIRM_PASSWORD_REQUIRED_VALIDATION = 'Please confirm a new password';
export const CHANGE_PASSWORD_SUCCESS_NOTIFICATION_MESSAGE = 'The password is changed.';
export const CHANGE_PASSWORD_FAILURE_NOTIFICATION_MESSAGE = 'The password can’t be changed. Try again.';
export const UPDATE_MYUSERPROFILE_SUCCESS_NOTIFICATION_MESSAGE = 'Your profile has been updated.';
export const UPDATE_MYUSERPROFILE_FAILURE_NOTIFICATION_MESSAGE = 'Your profile can’t be updated. Please try again later';
export const REVIEW_BUTTON_TEXT = {
  approve: 'Approve',
  decline: 'Decline',
};
export const API_ERROR_NOTIFICATION_MESSAGES = {
  checkEmail: 'Sorry, Cannot validate the email at the moment. Please try again later',
  getRoles: 'Sorry, Currently not able to fetch the available roles. Please try again later',
  getLanguages: 'Sorry, Not able to fetch availables language options at the moment. Please try again later',
  getbyemail: 'Sorry, unable to load the infomation. Please reload the page',
  get: 'Sorry, unable to load the infomation. Please reload the page',
};
