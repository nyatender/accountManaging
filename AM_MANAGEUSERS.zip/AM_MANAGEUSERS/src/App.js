import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { ContextValue, GlobalContext } from './Context/GlobalContext.jsx';
import ErrorBoundary from './errorBoundary/ErrorBoundary.jsx';
import { routes } from './routes/routes.js';
import './styles.scss';

function App() {
  const globalContextValue = ContextValue();
  return (
    <ErrorBoundary>
      <div className="App">
        <GlobalContext.Provider value={globalContextValue}>
          <Router>
            <Switch>
              {
                                routes.map((route) => (
                                  <Route {...route} />
                                ))
                            }
            </Switch>
          </Router>
        </GlobalContext.Provider>
      </div>
    </ErrorBoundary>
  );
}

export default App;
