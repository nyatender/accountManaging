import UserList from '../Components/UserListComponent/UserList';
import UserProfile from '../Components/UserProfile/UserProfile';
import { paths } from './paths';

export const routes = [
  {
    key: 'UserList',
    path: paths.userListPage,
    component: UserList,
    exact: true,
    sensitive: true,
  }, {
    key: 'UserProfile',
    path: paths.userProfilePage,
    component: UserProfile,
    exact: true,
    sensitive: true,
  },
  {
    key: 'EditUserProfile',
    path: paths.editUserProfilePage,
    component: UserProfile,
    exact: true,
    sensitive: true,
  },
  {
    key: 'AddUser',
    path: paths.addUserPage,
    component: UserProfile,
    exact: true,
    sensitive: true,
  },
];
