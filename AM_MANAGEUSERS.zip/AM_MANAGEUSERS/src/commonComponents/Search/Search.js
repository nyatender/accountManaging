import React, { useState, useRef } from 'react';
import { SearchField } from '@wsa/echo-components/dist';
import _ from 'lodash';
import { DEBOUNCE_DELAY_FOR_SEARCH } from '../../Constants/ConfigurationConstants';

export default function Search({
  placeholder,
  defaultValue = '',
  className = '',
  onChange = (value) => { },
}) {
  const [searchInput, setSearchInput] = useState(defaultValue || '');
  const callCustomOnChangeFunction = (value) => {
    onChange(value);
  };
  const handleDebouncedChange = useRef(_.debounce(callCustomOnChangeFunction, DEBOUNCE_DELAY_FOR_SEARCH));
  const handleChange = (e) => {
    setSearchInput(e);
    handleDebouncedChange.current(e);
  };

  return (
    <SearchField
      placeholder={placeholder}
      value={searchInput}
      onChange={handleChange}
      className={className}
    />
  );
}
