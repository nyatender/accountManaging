import React, { useState, useRef, useEffect, useContext } from 'react'
import { InputField } from '@wsa/echo-components/dist'
import Validation from '../../Components/Validation';
import { GlobalContext } from '../../Context/GlobalContext';

export default function Password({ placeholder, validatePassword, errorMessage, id, setErrorMessage }) {
    const { passwordInput_value, confirmPasswordInput_value } = useContext(GlobalContext)
    const [password, setPassword] = useState('')
    const [, setPasswordInput] = passwordInput_value;
    const [, setConfirmPasswordInput] = confirmPasswordInput_value;
    const passwordRef = useRef(null);
    useEffect(() => {
        passwordRef.current.children[0].children[1].children[1].type = 'password'
    }, [])
    const handlerfunction = (e, id) => {
        if (e == "" & id == "passwordInput") {
            setErrorMessage('')
            setPasswordInput('')
        } else if (e == "" & id == "changePasswordInput") {
            setErrorMessage('')
            setConfirmPasswordInput('')
        }
        setPassword(e);
    }
    return (
        <div ref={passwordRef}>
            <InputField
                error={!!errorMessage}
                value={password}
                placeholder={placeholder}
                onChange={(e) => handlerfunction(e, id)}
                onBlur={validatePassword}
                id={id}
            />
            {!!errorMessage && <Validation message={errorMessage} />}
        </div>
    )
}
