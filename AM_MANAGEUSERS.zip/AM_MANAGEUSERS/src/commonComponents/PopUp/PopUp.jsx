import React from 'react'
import { Dialog, Typography, Button, Spacing, DialogFooter, Spinner } from '@wsa/echo-components';
import { ERROR_DIALOG_OK_BUTTON_TEXT, PENDING_STATUS_CONFIRMATION_DIALOG } from '../../GlobalConstants';

export default function PopUp({ isVisible, handleClose}) {
    return (
        <>
            <Dialog
                aria-label="Form Dialog"
                id="form-dialog"
                isVisible={isVisible}
                showCloseIcon={false}
                colSpanL={6}
            >
                <div style={{
                    display: 'flex',
                    flexDirection: "column",
                    alignItems: "center"
                }}>
                    <Typography
                        children={PENDING_STATUS_CONFIRMATION_DIALOG.headline}
                        variant="heading-s"
                    />
                    <Spacing mt={2} />
                    <Typography
                        children={PENDING_STATUS_CONFIRMATION_DIALOG.subheadline}
                        variant="body"
                    />
                    <Spacing mt={4} />
                </div>

                <div className="confirmationDialog-button-container">
                    <DialogFooter className='tw-flex tw-flex-wrap'>
                        <div className="tw-flex tw-flex-wrap">
                            <Button className="echo-button--small" variant="primary" onClick={handleClose}>
                                {ERROR_DIALOG_OK_BUTTON_TEXT}
                            </Button>
                        </div>
                    </DialogFooter>
                </div>
            </Dialog>
        </>
    )
}
