export const USER_LIST_TABLE_HEADERS = ['Name', 'Email', 'Role', 'Status'];
export const USER_LIST_TABLE_HEADER_TO_DATA_MAPPER = new Map([
  ['Name', 'name'],
  ['Email', 'email'],
  ['Role', 'role'],
  ['Status', 'status'],
]);
export const STATUS_TO_TEXT_MAPPER = new Map([
  [0, 'Inactive'],
  [1, 'Active'],
  [2, 'Pending'],
]);
export const PENDING_STATUS_VLAUE = 2;
