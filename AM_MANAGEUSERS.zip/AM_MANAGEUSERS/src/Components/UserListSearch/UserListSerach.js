import React, { useContext } from 'react';
import { Grid } from '@wsa/echo-components';
import { GlobalContext } from '../../Context/GlobalContext';
import Search from '../../commonComponents/Search/Search';
import { USERLIST_SEARCH_PLACEHOLDER } from '../../GlobalConstants';

export default function UserListSerach() {
  const { userListSearchText_value } = useContext(GlobalContext);
  const [, setUserListSearchText] = userListSearchText_value;

  const handleSearch = (searchTerm) => {
    setUserListSearchText(searchTerm);
  };

  return (
    <Grid>
      <Grid item colSpanS={10}>
        <Search
          placeholder={USERLIST_SEARCH_PLACEHOLDER}
          onChange={handleSearch}
          className="user-search"
        />
      </Grid>
    </Grid>
  );
}
