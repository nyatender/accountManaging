import React, { useState, useContext, useEffect } from 'react'
import { Dropdown, Grid } from '@wsa/echo-components/dist'
import { GlobalContext } from '../../Context/GlobalContext'
import { LANGUAGE_PLACEHOLDER } from '../../GlobalConstants'

export default function Language({ languages }) {
    const { languageSelected_value, firstClickFlag_value } = useContext(GlobalContext);
    const [languageSelected, setLanguageSelected] = languageSelected_value;
    const [optionSelected, setOptionSelected] = useState({ label: LANGUAGE_PLACEHOLDER, value: '' })
    const [firstClickFlag, setFirstClickFlag] = firstClickFlag_value

    let options = languages.map(item => {
        return { label: item.languageName, value: item.languageCode }
    })
    const handleDropdown = (e) => {
        if (languageSelected !== e && !firstClickFlag) {
            setFirstClickFlag(true)
        }
        setLanguageSelected(e);
        const option = options.filter(item => item.value === e)[0];
        setOptionSelected(option)
    }
    useEffect(() => {
        if (languageSelected && languageSelected !== '' && languages.length !== 0) {
            handleDropdown(languageSelected)
        }
    }, [languages, languageSelected])
    return (
        <Grid item colSpanS={12} colSpanL={6} colSpanM={12}>
            <div className='userProfile-language'>
                <Dropdown
                    placeholder={LANGUAGE_PLACEHOLDER}
                    options={options}
                    onChange={handleDropdown}
                    selectedItem={optionSelected}
                    id="myuserProfile-language"
                />
            </div>
        </Grid>
    )
}
