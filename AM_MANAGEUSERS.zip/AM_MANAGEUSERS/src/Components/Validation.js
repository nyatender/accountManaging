import React from 'react';
import { Typography } from '@wsa/echo-components';

function Validation({ message }) {
  return (
    <Typography children={message} component="h6" variant="caption" className="validation-error-color" />
  );
}

export default Validation;
