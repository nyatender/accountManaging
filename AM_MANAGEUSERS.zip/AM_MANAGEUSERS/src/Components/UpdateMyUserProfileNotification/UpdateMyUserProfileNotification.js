import React, { useContext } from 'react';
import { GlobalContext } from '../../Context/GlobalContext';
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { UPDATE_MYUSERPROFILE_SUCCESS_NOTIFICATION_MESSAGE, UPDATE_MYUSERPROFILE_FAILURE_NOTIFICATION_MESSAGE } from '../../GlobalConstants';

export default function UpdateMyUserProfileNotification() {
  const { showUpdateMyUserProfileMessage_value } = useContext(GlobalContext);
  const [showUpdateMyUserProfileMessage, setShowUpdateMyUserProfileMessage] = showUpdateMyUserProfileMessage_value;

  let message = '';
  if (showUpdateMyUserProfileMessage === 'success') {
    message = UPDATE_MYUSERPROFILE_SUCCESS_NOTIFICATION_MESSAGE;
  } else {
    message = UPDATE_MYUSERPROFILE_FAILURE_NOTIFICATION_MESSAGE;
  }

  const handleClose = () => {
    setShowUpdateMyUserProfileMessage('');
  };
  return (
    <NotificationMessage
      isVisible={!!showUpdateMyUserProfileMessage}
      handleClose={handleClose}
      message={message}
      severity={showUpdateMyUserProfileMessage}
    />
  );
}
