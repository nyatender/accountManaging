import React, { useContext } from 'react'
import { GlobalContext } from '../../Context/GlobalContext'
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { notificationDefaultValue } from '../../Constants/ConfigurationConstants';

export default function APIFailureNotification() {
    const { apiFailureNotification_value } = useContext(GlobalContext)
    const [apiFailureNotification, setApiFailureNotification] = apiFailureNotification_value;
    const { message, severity } = apiFailureNotification;
    const handleClose = () => {
        setApiFailureNotification(notificationDefaultValue());
    }
    return (
        <NotificationMessage
            isVisible={!!message}
            handleClose={handleClose}
            message={message}
            severity={severity} />
    )
}
