import React, { useContext, useRef } from 'react';
import {
  Grid, Panel, Typography, Button,
} from '@wsa/echo-components';
import UserListTable from '../UserListTable/UserListTable';
import Filters from '../Filters/Filters';
import UserListSearch from '../UserListSearch/UserListSerach';
import { GlobalContext } from '../../Context/GlobalContext';
import AddUserPopUp from '../AddUserPopUp/AddUserPopUp';
import DeleteUserPopUp from '../DeleteUserPopUp/DeleteUserPopup';
import CreateUserPopup from '../CreateUserPopUp/CreateUserPopup';
import { BUTTON_TEXT_ADD_NEW_USER, PAGE_TITLE_COMPANY_USERS } from '../../GlobalConstants';
import SaveUserPopUp from '../SaveUserPopUp/SaveUserPopUp';
import ApproveDeclineNotification from '../ApproveDeclineNotification/ApproveDeclineNotification';
import APIFailureNotification from '../APIFailureNotification/APIFailureNotification';

export default function UserList() {
  const refScrollTo = useRef();
  const {
    emailValidationPopUpIsVisible_value,
    firstName_value,
    lastName_value,
  } = useContext(GlobalContext);
  const [, setEmailValidationPopUpIsVisible] = emailValidationPopUpIsVisible_value;
  const [firstName] = firstName_value;
  const [lastName] = lastName_value;
  const handleAddUser = () => {
    setEmailValidationPopUpIsVisible(true);
  };
  const scrollToTop = () => {
    window.scrollTo(0, refScrollTo.current.offsetTop);
  };
  return (
    <div className="app-container">
      <Grid gridColsS={12} colSpanS={12} className="userlist-page-container">
        <Grid item colSpanL={12} colSpanM={12} colSpanXL={12} className="sections-user-list">
          <Panel className="header-panel">
            <Typography variant="heading-m">
              {PAGE_TITLE_COMPANY_USERS}
            </Typography>
          </Panel>
        </Grid>
        <div ref={refScrollTo} />
        <Grid item colSpanXL={12} colSpanL={12} id="userlistBody" className="sections-user-list userlist-body">
          <Grid colSpanL={12}>
            <Grid item colSpanL={8} colSpanS={6} className="user-search-grid">
              <UserListSearch />
            </Grid>
            <Grid item alignItems="end" colSpanL={4} colSpanS={6} className="user-search-grid">
              <Button id="add-user" className="add-user" onClick={handleAddUser}>
                {BUTTON_TEXT_ADD_NEW_USER}
              </Button>
            </Grid>
          </Grid>
          <Grid colSpanXL={12}>
            <Grid item colSpanXL={3}>
              <Filters />
            </Grid>
            <Grid item colSpanXL={9}>
              <UserListTable scrollToTop={scrollToTop} />
            </Grid>
          </Grid>
        </Grid>
        <AddUserPopUp />
        <CreateUserPopup firstName={firstName} lastName={lastName} />
        <DeleteUserPopUp />
        <SaveUserPopUp firstName={firstName} lastName={lastName} />
        <ApproveDeclineNotification />
        <APIFailureNotification />
      </Grid>
    </div>
  );
}
