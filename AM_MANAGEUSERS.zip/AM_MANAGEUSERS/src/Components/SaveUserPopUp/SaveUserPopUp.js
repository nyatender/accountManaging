import React, { useContext } from 'react';
import { GlobalContext } from '../../Context/GlobalContext';
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { SAVE_USER_POP_UP_INFO_FAILURE, SAVE_USER_POP_UP_INFO_SUCCESS } from '../../GlobalConstants';

export default function SaveUserPopUp({ firstName, lastName }) {
  const {
    showSaveUserPopUp_value,
    firstName_value,
    lastName_value,
  } = useContext(GlobalContext);
  const [showSaveUserPopUp, setShowSaveUserPopUp] = showSaveUserPopUp_value;
  const [, setfirstName] = firstName_value;
  const [, setlastName] = lastName_value;

  let info = '';
  if (showSaveUserPopUp === 'success') {
    info = SAVE_USER_POP_UP_INFO_SUCCESS.replace('$firstName', firstName).replace('$lastName', lastName);
  } else {
    info = SAVE_USER_POP_UP_INFO_FAILURE;
  }
  const resetUserProfile = () => {
    setfirstName('');
    setlastName('');
  };
  const handleClose = () => {
    setShowSaveUserPopUp('');
    if (showSaveUserPopUp === 'success') {
      resetUserProfile();
    }
  };
  return (
    <NotificationMessage
      isVisible={!!showSaveUserPopUp}
      handleClose={handleClose}
      message={info}
      severity={showSaveUserPopUp}
    />
  );
}
