import React, { useContext } from 'react';
import { GlobalContext } from '../../Context/GlobalContext';
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { CREATE_USER_POP_UP_INFO_FAILURE, CREATE_USER_POP_UP_INFO_SUCCESS } from '../../GlobalConstants';

export default function CreateUserPopup({ firstName, lastName }) {
  const {
    showCreateUserPopUp_value,
    firstName_value,
    lastName_value,
  } = useContext(GlobalContext);
  const [showCreateUserPopUp, setShowCreateUserPopUp] = showCreateUserPopUp_value;
  const [, setfirstName] = firstName_value;
  const [, setlastName] = lastName_value;

  let info = '';
  if (showCreateUserPopUp === 'success') {
    info = CREATE_USER_POP_UP_INFO_SUCCESS.replace('$firstName', firstName).replace('$lastName', lastName);
  } else {
    info = CREATE_USER_POP_UP_INFO_FAILURE;
  }
  const resetUserProfile = () => {
    setfirstName('');
    setlastName('');
  };
  const handleClose = () => {
    setShowCreateUserPopUp('');
    if (showCreateUserPopUp === 'success') {
      resetUserProfile();
    }
  };
  return (
    <NotificationMessage
      isVisible={!!showCreateUserPopUp}
      handleClose={handleClose}
      message={info}
      severity={showCreateUserPopUp}
    />
  );
}
