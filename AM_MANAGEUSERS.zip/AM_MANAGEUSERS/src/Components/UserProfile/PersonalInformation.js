import React, { useContext } from 'react';
import {
  Typography, Card, Spacing, InputField, Spinner,
} from '@wsa/echo-components';
import Validation from '../Validation';
import {
  PERSONAL_INFORMATION_TITLE_TEXT, FIRSTNAME_VALIDATION_MESSAGE,
  FIRSTNAME_REQUIRED_VALIDATION_MESSAGE, LASTNAME_VALIDATION_MESSAGE,
  LASTNAME_REQUIRED_VALIDATION_MESSAGE, PHONE_NUMBER_VALIDATION_MESSAGE,
  JOB_TITLE_VALIDATION_MESSAGE, EMAIL_LABEL_TEXT, FIRST_NAME_PLACEHOLDER_TEXT,
  LAST_NAME_PLACEHOLDER_TEXT, PHONE_NUMBER_PLACEHOLDER_TEXT,
  JOB_TITLE_PLACEHOLDER_TEXT,
  CHANGE_PASSWORD_TEXT,
} from '../../GlobalConstants';
import Language from '../LanguageInfo/Language';
import { GlobalContext } from '../../Context/GlobalContext';
import ChangePasswordPopUp from '../ChangePasswordPopUp/ChangePasswordPopUp';

function PersonalInformation({
  emailId, firstName, lastName,
  phoneNumber, jobTitle, handleFirstNameChange, handleLastNameChange,
  handlePhoneNoChange, handleJobTitleChange, firstNameError,
  phoneNoError, lastNameError, firstNamerequiredError, lastNamerequiredError,
  jobTitleError, checkFirstNameEmpty, checkLastNameEmpty, isEditMode,
  isPersonalInfoloaded, userProfileSelfMode, isMyUserProfilePersonalInfoloaded, languages,
}) {
  const { showChangePassword_value, isReviewMode_value } = useContext(GlobalContext);
  const [showChangePassword, setShowChangePassword] = showChangePassword_value;
  const [isReviewMode] = isReviewMode_value;
  const containerClassNames = userProfileSelfMode ? 'personal-info-card' : '';
  const renderInputField = (fieldName, value, label, handlerfunction, isDisabled, isRequired, isError, checkIsFieldEmpty) => (
    <InputField
      error={isError}
      value={value || ''}
      id={fieldName}
      label={label}
      onChange={handlerfunction}
      disabled={isDisabled}
      required={isRequired}
      onBlur={checkIsFieldEmpty}
    />
  );
  const handleClose = () => {
    setShowChangePassword(false);
  };
  const handleChangePassword = () => {
    setShowChangePassword(true);
  };
  const getSpinnerClassname = () => {
    if (isEditMode && isPersonalInfoloaded) {
      return '';
    } if (userProfileSelfMode && isMyUserProfilePersonalInfoloaded) {
      return 'myuserProfile-personalInfo-spinner';
    }
  };
  return (
    <Card className={containerClassNames}>
      <Typography children={PERSONAL_INFORMATION_TITLE_TEXT} variant="heading-s" />
      {

                    ((isEditMode || isReviewMode) && isPersonalInfoloaded) || (userProfileSelfMode && isMyUserProfilePersonalInfoloaded) ? <Spinner id={getSpinnerClassname()} size="medium" className="spinner-component" />
                      : (
                        <>
                          <Spacing mt={4} />
                          <Typography variant="body">{EMAIL_LABEL_TEXT}</Typography>
                          <Typography children={emailId} variant="body" />
                          <Spacing mt={4} />
                          <div className="personalInformation-flexGrid">
                            <div className="personalInformation-inputWidth">
                              {renderInputField('firstname', firstName, FIRST_NAME_PLACEHOLDER_TEXT, handleFirstNameChange, false, true, (!!(firstNameError || firstNamerequiredError)), checkFirstNameEmpty)}
                              {firstNameError && <Validation message={FIRSTNAME_VALIDATION_MESSAGE} />}
                              {firstNamerequiredError && <Validation message={FIRSTNAME_REQUIRED_VALIDATION_MESSAGE} />}
                            </div>

                            <div className="personalInformation-inputWidth">
                              {renderInputField('lastname', lastName, LAST_NAME_PLACEHOLDER_TEXT, handleLastNameChange, false, true, (!!(lastNameError || lastNamerequiredError)), checkLastNameEmpty)}
                              {lastNameError && <Validation message={LASTNAME_VALIDATION_MESSAGE} />}
                              {lastNamerequiredError && <Validation message={LASTNAME_REQUIRED_VALIDATION_MESSAGE} />}
                            </div>
                          </div>

                          {firstNameError || firstNamerequiredError || lastNameError || lastNamerequiredError ? <Spacing mt={2} /> : <Spacing mt={8} />}

                          <div className="personalInformation-flexGrid">
                            <div className="personalInformation-inputWidth">
                              {renderInputField('phoneNumber', phoneNumber, PHONE_NUMBER_PLACEHOLDER_TEXT, handlePhoneNoChange, false, false, (!!phoneNoError))}
                              {phoneNoError && <Validation message={PHONE_NUMBER_VALIDATION_MESSAGE} />}
                            </div>

                            <div className="personalInformation-inputWidth">
                              {renderInputField('jobtitle', jobTitle, JOB_TITLE_PLACEHOLDER_TEXT, handleJobTitleChange, false, false, (!!jobTitleError))}
                              {jobTitleError && <Validation message={JOB_TITLE_VALIDATION_MESSAGE} />}
                            </div>
                          </div>
                          {userProfileSelfMode && (
                            <>
                              <Spacing mt={8} />
                              <div className="personalInformation-inputWidth">
                                <Language languages={languages} />
                              </div>
                              <Spacing mt={8} />
                              <div className="personalInformation-flexGrid">
                                <div className="personalInformation-inputWidth">
                                  <Typography variant="body" children={CHANGE_PASSWORD_TEXT} className="change-password-text" onClick={handleChangePassword} />
                                </div>
                              </div>
                            </>
                          )}

                          {phoneNoError || jobTitleError ? <Spacing mt={0} /> : <Spacing mt={6} />}
                        </>
                      )
                }
      <ChangePasswordPopUp isVisible={showChangePassword} handleClose={handleClose} />
    </Card>
  );
}

export default PersonalInformation;
