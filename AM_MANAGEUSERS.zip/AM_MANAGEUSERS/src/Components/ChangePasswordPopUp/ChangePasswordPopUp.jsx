import React, { useContext, useState } from 'react'
import { Dialog, Typography, Button, Spacing, DialogFooter, Grid, Spinner } from '@wsa/echo-components';
import {
    CHANGE_PASSWORD_SUBHEADING, CHANGE_PASSWORD_TEXT, PASSWORD_PLACEHOLDER, PASSWORD_VALIDATION_MESSAGE,
    CHANGE_PASSWORD_BUTTON_TEXT, NEW_PASSWORD_REQUIRED_VALIDATION, CONFIRM_PASSWORD_REQUIRED_VALIDATION
} from '../../GlobalConstants';
import Password from '../../commonComponents/Password/Password';
import { GlobalContext } from '../../Context/GlobalContext';
import { passwordvalidation, scrollToTop } from '../../Utilities/CommonFuntions';
import { CHANGE_PASSWORD } from '../../Constants/URLConstants';

export default function ChangePasswordPopUp({ isVisible, handleClose }) {
    const { passwordInput_value, confirmPasswordInput_value,
        showChangePasswordMessage_value } = useContext(GlobalContext)
    const [passwordInput, setPasswordInput] = passwordInput_value;
    const [confirmPasswordInput, setConfirmPasswordInput] = confirmPasswordInput_value;
    const [passwordValidationError, setPasswordValidationError] = useState('');
    const [confirmPasswordValidationError, setConfirmPasswordValidationError] = useState('');
    const [loading, setLoading] = useState(false)
    const [, setShowChangePasswordMessage] = showChangePasswordMessage_value;

    const validatePassword = (e) => {
        //TODO : validation
        const isValid = passwordvalidation(e.target.value);
        if (isValid) {
            setPasswordValidationError('')
        }
        else {
            setPasswordValidationError(PASSWORD_VALIDATION_MESSAGE.password)
        }
        setPasswordInput(e.target.value);
    }
    const validateConfirmPassword = (e) => {
        setConfirmPasswordInput(e.target.value);
        if (passwordInput !== e.target.value) {
            setConfirmPasswordValidationError(PASSWORD_VALIDATION_MESSAGE.confirmPassword)
        }
        else {
            setConfirmPasswordValidationError('')
        }
    }
    const handleClosePopUp = () => {
        setPasswordInput('');
        setConfirmPasswordInput('');
        setPasswordValidationError('');
        setConfirmPasswordValidationError('');
        handleClose();
    }

    const handleChangePassword = () => {
        if (passwordInput == "") {
            setPasswordValidationError(NEW_PASSWORD_REQUIRED_VALIDATION)
        }
        if (confirmPasswordInput == "") {
            setConfirmPasswordValidationError(CONFIRM_PASSWORD_REQUIRED_VALIDATION)
        }
        if (passwordInput !== "" && confirmPasswordInput !== "" && passwordValidationError == "" && confirmPasswordValidationError == "") {
            if (passwordInput !== confirmPasswordInput) {
                setConfirmPasswordValidationError(PASSWORD_VALIDATION_MESSAGE.confirmPassword)
            } else {
                changePassword()
            }

        }
    }

    const changePassword = () => {
        setLoading(true);
        const _data = {
            "Password": passwordInput
        }
        fetch(CHANGE_PASSWORD, {
            method: "POST",
            body: JSON.stringify(_data),
            headers: { "Content-type": "application/json; charset=UTF-8" }
        })
            .then(response => {
                setLoading(false)
                if (response.status === 200) {
                    console.log('password changed successfully');
                    handleClosePopUp()
                    setShowChangePasswordMessage('success')
                }
                else {
                    setShowChangePasswordMessage('error')
                }
                scrollToTop()
                response.json()
            })
            .then(json => console.log(json))
            .catch(err => console.log(err));
    }

    return (
        <>
            <Dialog
                aria-label="Form Dialog"
                id="form-dialog"
                isVisible={isVisible}
                showCloseIcon={true}
                colSpanL={6}
                onClose={handleClosePopUp}
            >
                <div style={{
                    display: 'flex',
                    flexDirection: "column",
                    alignItems: "center"
                }}>
                    <Typography
                        children={CHANGE_PASSWORD_TEXT}
                        variant="heading-s"
                    />
                    <Spacing mt={2} />
                    <Typography
                        children={CHANGE_PASSWORD_SUBHEADING}
                        variant="body"
                    />
                    <Spacing mt={4} />
                </div>
                <Grid>
                    <Grid item colSpanS={6} colStartS={4}>
                        <Password
                            placeholder={PASSWORD_PLACEHOLDER.newPassword}
                            validatePassword={validatePassword}
                            errorMessage={passwordValidationError}
                            id={"passwordInput"}
                            setErrorMessage={setPasswordValidationError} />
                    </Grid>
                    <Spacing mt={4} />
                    <Grid item colSpanS={6} colStartS={4}>
                        <Password
                            placeholder={PASSWORD_PLACEHOLDER.confirmPassword}
                            validatePassword={validateConfirmPassword}
                            errorMessage={confirmPasswordValidationError}
                            id={"changePasswordInput"}
                            setErrorMessage={setConfirmPasswordValidationError} />
                    </Grid>
                </Grid>
                <div className="confirmationDialog-button-container">
                    <DialogFooter className='tw-flex tw-flex-wrap'>
                        <div className="tw-flex tw-flex-wrap">
                            <Button className="echo-button--small" variant="primary" onClick={handleChangePassword} disabled={loading}>
                                {CHANGE_PASSWORD_BUTTON_TEXT}{loading && <Spinner size="xsmall" className="change-password-button-spinner" />}
                            </Button>
                        </div>
                    </DialogFooter>
                </div>
            </Dialog>
        </>
    )
}
