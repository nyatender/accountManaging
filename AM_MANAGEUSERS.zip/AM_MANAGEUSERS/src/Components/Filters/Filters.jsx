import React from 'react'
import { Grid, Icon, Typography, Panel } from "@wsa/echo-components";
import ShopFilter from '../ShopFilter/ShopFilter';
import RoleFilter from '../RoleFilter/RoleFilter';
import STatusFilter from '../StatusFilter/STatusFilter';
import { FILTERS_LABEL_TEXT } from '../../GlobalConstants';

export default function Filters() {
    return (
        <Grid item colSpanS={12} className='filter-container'>
            <Grid item colSpanS={12} className='filter-header'>
                <Icon href="filter" size='large' title='Filter' />
                <Typography variant="heading-s" className='filter-label'>
                    {FILTERS_LABEL_TEXT}
                </Typography>
            </Grid>
            <Grid item colSpanS={12} className='filters-container'>
                <ShopFilter />
                <RoleFilter />
                <STatusFilter />
            </Grid>
        </Grid>
    )
}
