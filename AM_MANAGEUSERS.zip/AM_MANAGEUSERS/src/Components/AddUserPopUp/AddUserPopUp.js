import React, {
  useState, useContext,
} from 'react';
import { useHistory } from 'react-router-dom';
import ConfirmationDialog from './ConfirmationDialog';
import ErrorDialog from './ErrorDialog';
import { GlobalContext } from '../../Context/GlobalContext';
import {
  API_ERROR_NOTIFICATION_MESSAGES,
  CONFIRMATION_DIALOG_HEADER_TEXT, CONFIRMATION_DIALOG_SUBHEADER_TEXT,
  ERROR_DIALOG_HEADER_TEXT, ERROR_DIALOG_SUBHEADER_TEXT1, ERROR_DIALOG_SUBHEADER_TEXT2,
} from '../../GlobalConstants';
import { CHECK_EMAIL } from '../../Constants/URLConstants';
import { resetUserProfileData, CreateURLFromParams, fetchAPI } from '../../Utilities/CommonFuntions';
import { paths } from '../../routes/paths';

function CompanyUsers() {
  const history = useHistory();
  const {
    emailId_value,
    error_value,
    emailFormatError_value,
    emailValidationPopUpIsVisible_value,
    showCreateUserPopUp_value,
    firstName_value,
    lastName_value,
    showDeleteUserMessage_value,
    showSaveUserPopUp_value,
    approveDeclineNotification_value,
    apiFailureNotification_value,
  } = useContext(GlobalContext);

  const [emailId, setEmailId] = emailId_value;
  const [, sethasError] = error_value;
  const [emailFormatError, setEmailFormatError] = emailFormatError_value;
  const [open, setOpen] = useState(false);
  const [emailValidationPopUpIsVisible, setEmailValidationPopUpIsVisible] = emailValidationPopUpIsVisible_value;
  const [, setfirstName] = firstName_value;
  const [, setlastName] = lastName_value;
  const [, setShowCreateUserPopUp] = showCreateUserPopUp_value;
  const [, setShowDeleteUserMessage] = showDeleteUserMessage_value;
  const [, setShowSaveUserPopUp] = showSaveUserPopUp_value;
  const [, setApproveDeclineNotification] = approveDeclineNotification_value;
  const [, setApiFailureNotification] = apiFailureNotification_value;

  const [loading, setLoading] = useState(false);

  const handleChange = (value) => {
    sethasError(false);
    setEmailFormatError(false);
    setEmailId(value);
  };

  const handleClose = () => {
    sethasError(false);
    setEmailFormatError(false);
    setEmailId('');
    setEmailValidationPopUpIsVisible(false);
  };
  const handleclosePopup = () => {
    setOpen(false);
    setEmailId('');
  };
  const emailFormatValidation = (emailid) => {
    const regex = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (regex.test(emailid) === false) {
      return false;
    }
    return true;
  };
  const checkEmailFormat = () => {
    if (emailId !== '' && !emailFormatValidation(emailId)) {
      setEmailFormatError(true);
      return false;
    }
    return true;
  };
  const checkIfUserExists = async () => {
    setLoading(true);
    const paramsObject = {
      email: emailId,
    };
    const URL = CreateURLFromParams(CHECK_EMAIL, paramsObject);
    const paramsToFetchAPI = {
      url: URL,
      apiErrorMessage: API_ERROR_NOTIFICATION_MESSAGES.checkEmail,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    setLoading(false);
    setEmailValidationPopUpIsVisible(false);
    if (response.errorMessage) {
      setApiFailureNotification((apiFailureNotification) => (
        { ...apiFailureNotification, message: response.errorMessage }));
    } else {
      const { responseCode } = response;
      if (responseCode === '1001') {
        // open userprofile if user dosen't exists
        resetUserProfileData(
          setfirstName,
          setlastName,
          setShowCreateUserPopUp,
          setShowDeleteUserMessage,
          setShowSaveUserPopUp,
          setApproveDeclineNotification,
          setApiFailureNotification,
        );
        history.push(paths.addUserPage);
      } else if (responseCode === '1002' || responseCode === '1003') {
        // open user alreday exists error popup
        setOpen(true);
      }
    }
  };
  const validateEmail = () => {
    if (emailId === '') {
      sethasError(true);
    } else if (emailId !== '' && !emailFormatError) {
      checkIfUserExists();
    }
  };
  const handleKeyPress = (event) => {
    if (event.key === 'Enter' && checkEmailFormat()) {
      validateEmail();
    }
  };
  return (
    <div>
      <ConfirmationDialog
        isVisible={emailValidationPopUpIsVisible}
        handleClose={handleClose}
        headline={CONFIRMATION_DIALOG_HEADER_TEXT}
        subheadline={CONFIRMATION_DIALOG_SUBHEADER_TEXT}
        handleChange={handleChange}
        validateEmail={validateEmail}
        checkEmailFormat={checkEmailFormat}
        loading={loading}
        handleKeyPress={handleKeyPress}
      />
      <ErrorDialog
        isVisible={open}
        handleClose={handleclosePopup}
        headline={ERROR_DIALOG_HEADER_TEXT}
        subheadline={`${ERROR_DIALOG_SUBHEADER_TEXT1} ${emailId} ${ERROR_DIALOG_SUBHEADER_TEXT2}`}
      />
    </div>
  );
}

export default CompanyUsers;
