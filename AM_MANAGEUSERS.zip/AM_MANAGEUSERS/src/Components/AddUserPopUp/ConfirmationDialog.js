import React from 'react';
import {
  Dialog, Typography, Button, Spacing, DialogFooter, Spinner,
} from '@wsa/echo-components';
import Search from './Search';
import { CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT, CONFIRMATION_DIALOG_CHECK_EMAIL_BUTTON_TEXT } from '../../GlobalConstants';

function ConfirmatiomDialog({
  isVisible, handleClose, headline, subheadline, handleChange, validateEmail,
  checkEmailFormat, loading, handleKeyPress,
}) {
  return (
    <Dialog
      aria-label="Form Dialog"
      id="form-dialog"
      isVisible={isVisible}
      showCloseIcon={false}
      colSpanL={6}
    >
      <div style={{
				  display: 'flex',
				  flexDirection: 'column',
				  alignItems: 'center',
      }}
      >
        <Typography
          children={headline}
          variant="heading-s"
        />
        <Spacing mt={2} />
        <Typography
          children={subheadline}
          variant="body"
        />
        <Spacing mt={4} />
      </div>

      <div className="confirmationDialog-search-grid">
        <Search handleChange={handleChange} checkEmailFormat={checkEmailFormat} handleKeyPress={handleKeyPress} />
      </div>

      <div className="confirmationDialog-button-container">
        <DialogFooter className="tw-flex tw-flex-wrap">
          <div className="tw-flex tw-flex-wrap">
            <Button className="echo-button--small" variant="secondary" onClick={handleClose} disabled={loading}>
              {CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT}
            </Button>
            <Spacing mr={6} />
            <Button className="echo-button--small" variant="primary" onClick={validateEmail} disabled={loading}>
              {CONFIRMATION_DIALOG_CHECK_EMAIL_BUTTON_TEXT}
              {' '}
              {loading && <Spinner size="xsmall" className="confirmationDialog-checkEmail-button-spinner" />}
            </Button>
          </div>
        </DialogFooter>
      </div>
    </Dialog>
  );
}

export default ConfirmatiomDialog;
