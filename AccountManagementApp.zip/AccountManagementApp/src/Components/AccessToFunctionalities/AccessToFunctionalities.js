import React, { useState, useEffect, useContext } from 'react';
import {
  Card, Spacing, Dropdown, Typography, Spinner,
} from '@wsa/echo-components/dist';
import {
  ACCESS_TO_FUNCTIONALITIES_HEADING, ACCESS_TO_FUNCTIONALITY_PLACEHOLDER, 
  API_ERROR_NOTIFICATION_MESSAGES, ONLINE_SHOP_DROPDOWN_LABEL,
} from '../../GlobalConstants';
import { GlobalContext } from '../../Context/GlobalContext';
import { FETCH_ALL_ROLES } from '../../Constants/URLConstants';
import { ACCESS_TO_FUNCTIONALITIES_DEFAULT_VALUE } from '../../Constants/ConfigurationConstants';
import { fetchAPI } from '../../Utilities/CommonFuntions';

export default function AccessToFunctionalities({
  isRolesloaded, setIsRolesloaded, rolesRequiredError, setRolesRequiredError,
  myUserProfileRole, isMyUserProfileRolesloaded, setIsMyUserProfileRolesloaded,
}) {
  const {
    userRoleSelected_value,
    userRoleDataOnEdit_value,
    isEditMode_value,
    userProfileSelfMode_value,
    firstClickFlag_value,
    isReviewMode_value,
    roles_value,
    apiFailureNotification_value,
  } = useContext(GlobalContext);
  const [, setUserRoleSelected] = userRoleSelected_value;
  const [roles, setRoles] = roles_value;
  const [optionSelected, setOptionSelected] = useState(ACCESS_TO_FUNCTIONALITIES_DEFAULT_VALUE);
  const [userRoleDataOnEdit] = userRoleDataOnEdit_value;
  const [isEditMode] = isEditMode_value;
  const [userProfileSelfMode] = userProfileSelfMode_value;
  const [firstClickFlag, setFirstClickFlag] = firstClickFlag_value;
  const [isReviewMode] = isReviewMode_value;
  const [, setApiFailureNotification] = apiFailureNotification_value;

  const fetchAllRoles = async () => {
    const paramsToFetchAPI = {
      url: FETCH_ALL_ROLES,
      apiErrorMessage: API_ERROR_NOTIFICATION_MESSAGES.getRoles,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    if (response.errorMessage) {
      setApiFailureNotification((apiFailureNotification) => (
        { ...apiFailureNotification, message: response.errorMessage }));
      setIsRolesloaded(false);
    } else {
      setRoles(response.entity.items);
    }
  };

  useEffect(() => {
    fetchAllRoles();
  }, []);

  const options = roles.map((item) => ({ label: item.name, value: item.name }));
  const handleDropdown = (e) => {
    const selectedRole = roles.filter((role) => role.name === e);
    // To do : restrict  setting setFirstClickFlag on review mode
    if (!!selectedRole.length && userRoleDataOnEdit && !userRoleDataOnEdit.includes(selectedRole[0]?.id) && !firstClickFlag) {
      setFirstClickFlag(true);
    }
    if (!!selectedRole.length && !userRoleDataOnEdit && !firstClickFlag) {
      setFirstClickFlag(true);
    }

    setUserRoleSelected(selectedRole);
    const option = options.filter((item) => item.value === e)[0];
    setOptionSelected(option || ACCESS_TO_FUNCTIONALITIES_DEFAULT_VALUE);
    setRolesRequiredError(false);
  };

  useEffect(() => {
    /**
         * set the selected role to Default Placeholder when the role from edit user or user profile
         * API is not present in the list returned from GetRoles API
         */
    const selectedRoleFromAPI = isEditMode || isReviewMode ? userRoleDataOnEdit && userRoleDataOnEdit.filter((i) => roles.map((item) => item.id).includes(i)) : myUserProfileRole;

    const selectedRole = selectedRoleFromAPI?.length
      ? roles.filter((role) => role.id === selectedRoleFromAPI[0]) : [];
    handleDropdown(selectedRole[0]?.name);
    if (myUserProfileRole && myUserProfileRole.length !== 0 && roles.length !== 0) {
      setIsMyUserProfileRolesloaded(false);
    }
    if (userRoleDataOnEdit && userRoleDataOnEdit.length !== 0 && roles.length !== 0) {
      setIsRolesloaded(false);
    }
  }, [userRoleDataOnEdit, roles, myUserProfileRole]);

  return (
    <Card className={userProfileSelfMode ? '' : 'accesstofunctionalities-container'}>
      <Typography children={ACCESS_TO_FUNCTIONALITIES_HEADING} variant="heading-s" />
      <Spacing mt={4} />
      {((isEditMode || isReviewMode) && isRolesloaded) || (userProfileSelfMode && isMyUserProfileRolesloaded) ? <Spinner size="medium" className="spinner-component" /> : (
        <>
          <Typography children={ONLINE_SHOP_DROPDOWN_LABEL} variant="body" />
          <Spacing mt={1} />
          <Dropdown
            placeholder={ACCESS_TO_FUNCTIONALITY_PLACEHOLDER}
            options={options}
            onChange={handleDropdown}
            selectedItem={optionSelected}
            error={rolesRequiredError}
            disabled={!!userProfileSelfMode}
            id="accesstofunctionalities-dropdown"
          />
        </>
      )}
    </Card>
  );
}
