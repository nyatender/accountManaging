import React, { useContext, useEffect } from 'react';
import { SearchField } from '@wsa/echo-components';
import { GlobalContext } from '../../Context/GlobalContext';
import useDebounce from '../../Utilities/UseDebounce';
import { AVAILABLE_ADDRESS_SEARCH_PLACEHOLDER } from '../../GlobalConstants';

export default function AvailableAddressSearch({ setErrorMessage }) {
  const {
    availableAddressSearchText_value,
    skip_value,
    availableAddressOptions_value,
    totalItemsCount_value,
    isAddressChecked_value,
    searchTerm_value,
    selectedAddress_value,
  } = useContext(GlobalContext);

  const [, setAvailableAddressSearchText] = availableAddressSearchText_value;
  const [, setAvailableAddressOptions] = availableAddressOptions_value;
  const [, setIsAddressChecked] = isAddressChecked_value;
  const [, setSkip] = skip_value;
  const [, setTotalItemsCount] = totalItemsCount_value;
  const [searchTerm, setSearchTerm] = searchTerm_value;
  const [, setSelectedAddress] = selectedAddress_value;

  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const handleChange = (value) => {
    setSearchTerm(value);
    setSelectedAddress('');
    setSkip(0);
    setAvailableAddressOptions([]);
    setTotalItemsCount(0);
    setIsAddressChecked(false);
    setErrorMessage('');
    // to call again api after clearing serach text
    if (value == '') {
      setAvailableAddressSearchText(value);
    }
  };
  useEffect(
    () => {
      if (debouncedSearchTerm) {
        setAvailableAddressSearchText(debouncedSearchTerm);
      }
    },
    [debouncedSearchTerm], // Only call effect if debounced search term changes
  );
  return (
    <SearchField
      id="Addresssearch"
      placeholder={AVAILABLE_ADDRESS_SEARCH_PLACEHOLDER}
      value={searchTerm}
      onChange={handleChange}
    />
  );
}
