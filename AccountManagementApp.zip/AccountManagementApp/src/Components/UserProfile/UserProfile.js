import React, { useState, useContext, useEffect } from 'react';
import {
  Typography, Button, Grid, Card, Spacing, Switch, Spinner,
} from '@wsa/echo-components';
import { useHistory, useLocation } from 'react-router-dom';
import PersonalInformation from './PersonalInformation';
import { GlobalContext } from '../../Context/GlobalContext';
import AvailableAddress from './AvailableAddress';
import AccessToFunctionalities from '../AccessToFunctionalities/AccessToFunctionalities';
import {
  CREATE_USER, UPDATE_USERS, EDIT_USERS, FETCH_MY_USER_PROFILE_DATA, FETCH_ALL_LANGUAGES, UPDATE_MY_USER_PROFILE, APPROVE_USER_URL, DECLINE_USER_URL, FETCH_USERS,
} from '../../Constants/URLConstants';
import CreateUserPopup from '../CreateUserPopUp/CreateUserPopup';
import SaveUserPopUp from '../SaveUserPopUp/SaveUserPopUp';
import { paths } from '../../routes/paths';
import { scrollToTop, CreateURLFromParams, fetchAPI } from '../../Utilities/CommonFuntions';
import {
  USER_PROFILE_ADD_USER_BUTTON_TEXT, USER_PROFILE_CANCEL_BUTTON_TEXT, USER_PROFILE_PAGE_TITLE_ADD_USERS,
  USER_PROFILE_PAGE_TITLE_USER, USER_PROFILE_SAVE_BUTTON_TEXT, USER_PROFILE_STATUS_ACTIVE_LABEL_TEXT,
  USER_PROFILE_STATUS_INACTIVE_LABEL_TEXT, USER_PROFILE_STATUS_LABEL_TEXT,
  MY_USER_PROFILE_PAGE_TITLE, MY_USER_PROFILE_SAVE_BUTTON_TEXT, REVIEW_BUTTON_TEXT, DEFAULT_SKIP_VALUE, API_ERROR_NOTIFICATION_MESSAGES, ERROR_MESSAGE,
} from '../../GlobalConstants';
import ChangePasswordNotification from '../ChangePasswordNotification/ChangePasswordNotification';
import UpdateMyUserProfileNotification from '../UpdateMyUserProfileNotification/UpdateMyUserProfileNotification';
import {
  APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE, notificationDefaultValue, NOTIFICATION_SEVERITY, NUMBER_OF_RECORDS_PER_PAGE, USER_FLOW_CONTEXT,
} from '../../Constants/ConfigurationConstants';
import ApproveDeclineNotification from '../ApproveDeclineNotification/ApproveDeclineNotification';
import { PENDING_STATUS_VLAUE } from '../UserListTable/UserListTableConstants';
import APIFailureNotification from '../APIFailureNotification/APIFailureNotification';

function UserProfile() {
  const {
    emailId_value,
    isAddressChecked_value,
    searchTerm_value,
    availableAddressOptions_value,
    availableAddressSearchText_value,
    skip_value,
    totalItemsCount_value,
    selectedAddress_value,
    userRoleSelected_value,
    showCreateUserPopUp_value,
    firstName_value,
    lastName_value,
    isEditMode_value,
    userSelectedForEdit_value,
    userRoleDataOnEdit_value,
    userAddressDataOnEdit_value,
    showSaveUserPopUp_value,
    shopFilterOptionsSelected_value,
    roleFilterIdsSelected_value,
    statusFilterOptionsSelected_value,
    userListSearchText_value,
    userProfileSelfMode_value,
    languageSelected_value,
    showUpdateMyUserProfileMessage_value,
    isReviewMode_value,
    firstClickFlag_value,
    approveDeclineNotification_value,
    roles_value,
    apiFailureNotification_value,
    hasProfileLoadFailed_value,
  } = useContext(GlobalContext);

  const [emailId, setEmailId] = emailId_value;
  const [firstName, setfirstName] = firstName_value;
  const [lastName, setlastName] = lastName_value;
  const [phoneNumber, setphoneNumber] = useState('');
  const [jobTitle, setjobTitle] = useState('');
  const [statusActive, setStatusActive] = useState(true);
  const [firstNameError, setFirstNameError] = useState(false);
  const [lastNameError, setLastNameError] = useState(false);
  const [phoneNoError, setphoneNoError] = useState(false);
  const [jobTitleError, setjobTitleError] = useState(false);
  const [firstNamerequiredError, setfirstNamerequiredError] = useState(false);
  const [lastNamerequiredError, setlastNamerequiredError] = useState(false);
  const [isAddressChecked, setIsAddressChecked] = isAddressChecked_value;
  const [, setSearchTerm] = searchTerm_value;
  const [, setAvailableAddressOptions] = availableAddressOptions_value;
  const [, setAvailableAddressSearchText] = availableAddressSearchText_value;
  const [, setSkip] = skip_value;
  const [, setTotalItemsCount] = totalItemsCount_value;
  const [selectedAddress, setSelectedAddress] = selectedAddress_value;
  const [userRoleSelected, setUserRoleSelected] = userRoleSelected_value;
  const [, setShowCreateUserPopUp] = showCreateUserPopUp_value;
  const [loading, setLoading] = useState(false);
  const [userSelectedForEdit, setUserSelectedForEdit] = userSelectedForEdit_value;
  const [isEditMode, setIsEditMode] = isEditMode_value;
  const [, setUserRoleDataOnEdit] = userRoleDataOnEdit_value;
  const [, setUserAddressDataOnEdit] = userAddressDataOnEdit_value;
  const [, setShowSaveUserPopUp] = showSaveUserPopUp_value;
  const [, setShopFilterOptionsSelected] = shopFilterOptionsSelected_value;
  const [, setRoleFilterIdsSelected] = roleFilterIdsSelected_value;
  const [, setStatusFilterOptionsSelected] = statusFilterOptionsSelected_value;
  const [, setUserListSearchText] = userListSearchText_value;
  const [userProfileSelfMode, setUserProfileSelfMode] = userProfileSelfMode_value;
  const [isReviewMode, setIsReviewMode] = isReviewMode_value;
  const [approveDeclineNotification, setApproveDeclineNotification] = approveDeclineNotification_value;
  const [editUserData, setEditUserData] = useState({});
  const [isPersonalInfoloaded, setIsPersonalInfoloaded] = useState(false);
  const [isRolesloaded, setIsRolesloaded] = useState(false);
  const [addressRequiredError, setAddressRequiredError] = useState(false);
  const [rolesRequiredError, setRolesRequiredError] = useState(false);
  const [myUserProfileData, setMyUserProfileData] = useState({});
  const [myUserProfileRole, setMyUserProfileRole] = useState([]);
  const [languageSelected, setLanguageSelected] = languageSelected_value;
  const [isMyUserProfilePersonalInfoloaded, setIsMyUserProfileInfoloaded] = useState(false);
  const [isMyUserProfileRolesloaded, setIsMyUserProfileRolesloaded] = useState(false);
  const [languages, setLanguages] = useState([]);
  const [, setShowUpdateMyUserProfileMessage] = showUpdateMyUserProfileMessage_value;
  const [firstClickFlag, setFirstClickFlag] = firstClickFlag_value;
  const [isLoaded, setIsloaded] = useState(false);
  const [approveDeclineSpinner, setApproveDeclineSpinner] = useState({
    approve: false,
    decline: false,
  });
  const [roles, setRoles] = roles_value;
  const [shopxpRoles, setShopxpRoles] = useState([]);
  const [nonShopxpRoles, setNonShopxpRoles] = useState([]);
  const [, setApiFailureNotification] = apiFailureNotification_value;
  const [hasProfileLoadFailed, setHasProfileLoadFailed] = hasProfileLoadFailed_value;

  const isAddUserDisabled = !isAddressChecked || !userRoleSelected.length;
  const history = useHistory();

  /**
     * the below code resets the data on user Profile page on browser back button
     */
  const locationObj = useLocation();
  useEffect(() => () => {
    if (history.action === 'POP') {
      resetData();
    }
  }, [locationObj]);

  const getSubUserProfile = async () => {
    try {
      if (Object.keys(userSelectedForEdit).length !== 0) {
        setIsPersonalInfoloaded(true);
        setIsRolesloaded(true);
        const paramsObject = {
          email: userSelectedForEdit.id,
        };
        const URL = CreateURLFromParams(EDIT_USERS, paramsObject);
        const paramsToFetchAPI = {
          url: URL,
        };
        const response = await fetchAPI(paramsToFetchAPI);
        if (response.errorMessage) {
          resetData();
          setHasProfileLoadFailed(true);
          setIsPersonalInfoloaded(false);
          setIsRolesloaded(false);
        } else {
          const { entity } = response;
          setHasProfileLoadFailed(false);
          setEditUserData(entity);
          setUserData(entity);
        }
        // fetch(URL)
        //     .then(res => res.json())
        //     .then(res => {
        //         const { entity } = res;
        //         setEditUserData(entity)
        //         setUserData(entity)
        //     }).catch(error => {
        //         setIsPersonalInfoloaded(false)
        //         setIsRolesloaded(false)
        //     });
      }
    } catch (error) {
      setIsPersonalInfoloaded(false);
      setIsRolesloaded(false);
    }
  };

  useEffect(() => {
    getSubUserProfile();
  }, [isEditMode, isReviewMode]);

  const setMode = async (userDataFromEdit) => {
    const paramsObject = {
      skip: DEFAULT_SKIP_VALUE,
      take: NUMBER_OF_RECORDS_PER_PAGE,
      search: userDataFromEdit?.email,
    };
    const URL = CreateURLFromParams(FETCH_USERS, paramsObject);
    const responseObj = await fetch(URL);
    if (responseObj.status === 200) {
      const response = await responseObj.json();
      const { entity: { items, count } } = response;
      if (!items.length || items[0].status !== PENDING_STATUS_VLAUE) {
        setIsEditMode(true);
      } else {
        setIsReviewMode(true);
      }
    }
    setUserData(userDataFromEdit);
  };
  async function fetchAllProfileData() {
    await fetchLanguages();
    fetchMyUserProfileData();
  }
  const getEditUserOnPageRefresh = async (URL) => {
    const paramsToFetchAPI = {
      url: URL,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    if (response.errorMessage) {
      resetData();
      setHasProfileLoadFailed(true);
      setIsPersonalInfoloaded(false);
      setIsRolesloaded(false);
    } else {
      const { entity } = response;
      setHasProfileLoadFailed(false);
      setEditUserData(entity);
      entity?.email && setMode(entity);
    }
  };
  useEffect(() => {
    if (history.location.pathname === paths.userProfilePage) {
      setUserProfileSelfMode(true);
      setIsMyUserProfileInfoloaded(true);
      setIsMyUserProfileRolesloaded(true);
      fetchAllProfileData();
    } else {
      setUserProfileSelfMode(false);
      if (history.location.pathname.includes(paths.editUserPartialPath)) {
        const params = history.location.pathname.split('/');
        const email = params[params.length - 1];
        /**
                 * fetch the user
                 */
        if (Object.keys(userSelectedForEdit).length === 0) {
          setIsPersonalInfoloaded(true);
          setIsRolesloaded(true);
          const paramsObject = {
            email,
          };
          const URL = CreateURLFromParams(EDIT_USERS, paramsObject);
          // const URL = `${EDIT_USERS}/${userSelectedForEdit.email}`;
          getEditUserOnPageRefresh(URL);
          // fetch(URL)
          //     .then(res => res.json())
          //     .then(res => {
          //         const { entity } = res;
          //         setEditUserData(entity)
          //         entity?.email && setMode(entity)

          //     }).catch(error => {
          //         setIsPersonalInfoloaded(false)
          //         setIsRolesloaded(false)
          //     });
        }
      }
    }
  }, []);

  const fetchMyUserProfileData = async () => {
    const paramsToFetchAPI = {
      url: FETCH_MY_USER_PROFILE_DATA,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    if (response.errorMessage) {
      resetData();
      setHasProfileLoadFailed(true);
      setIsMyUserProfileInfoloaded(false);
      setIsMyUserProfileRolesloaded(false);
    } else {
      const { entity } = response;
      setHasProfileLoadFailed(false);
      setMyUserProfileData(entity);
      mapMyUserProfileData(entity);
    }
    // fetch(FETCH_MY_USER_PROFILE_DATA)
    //     .then(res => res.json())
    //     .then(res => {
    //         const { entity } = res;
    //         setMyUserProfileData(entity)
    //         mapMyUserProfileData(entity)
    //     }).catch(error => {
    //         setIsMyUserProfileInfoloaded(false)
    //         setIsMyUserProfileRolesloaded(false)
    //     });
  };

  const fetchLanguages = async () => {
    try {
      const paramsToFetchAPI = {
        url: FETCH_ALL_LANGUAGES,
        apiErrorMessage: API_ERROR_NOTIFICATION_MESSAGES.getLanguages,
      };
      const response = await fetchAPI(paramsToFetchAPI);
      if (response.errorMessage) {
        setApiFailureNotification((apiFailureNotification) => ({ ...apiFailureNotification, message: response.errorMessage }));
      } else {
        setLanguages(response.entity.items);
      }
      // const responseObj = await fetch(FETCH_ALL_LANGUAGES);
      // const response = await responseObj.json();
      // setLanguages(response.entity.items);
    } catch (error) {
      setIsMyUserProfileInfoloaded(false);
    }
  };
  const handleFirstNameChange = (value) => {
    if (!firstClickFlag) {
      setFirstClickFlag(true);
    }
    setfirstNamerequiredError(false);
    if (value == '') {
      setFirstNameError(false);
      setfirstName(value);
      return;
    }
    if (value.length >= 100) {
      setfirstName(value);
      setFirstNameError(true);
    } else if (value.length < 100) {
      setFirstNameError(false);
      setfirstName(value);
    }
  };
  const handleLastNameChange = (value) => {
    if (!firstClickFlag) {
      setFirstClickFlag(true);
    }
    setlastNamerequiredError(false);
    if (value == '') {
      setLastNameError(false);
      setlastName(value);
      return;
    }
    if (value.length >= 100) {
      setlastName(value);
      setLastNameError(true);
    } else if (value.length < 100) {
      setLastNameError(false);
      setlastName(value);
    }
  };
  const handlePhoneNoChange = (value) => {
    if (!firstClickFlag) {
      setFirstClickFlag(true);
    }
    const reg = /^\d+$/;
    if (value == '') {
      setphoneNoError(false);
      setphoneNumber(value);
      return;
    }
    if (reg.test(value)) {
      setphoneNoError(false);
      setphoneNumber(value);
    } else {
      setphoneNumber(value);
      setphoneNoError(true);
    }
  };
  const handleJobTitleChange = (value) => {
    if (!firstClickFlag) {
      setFirstClickFlag(true);
    }
    if (value == '') {
      setjobTitleError(false);
      setjobTitle(value);
      return;
    }
    if (value.length >= 100) {
      setjobTitle(value);
      setjobTitleError(true);
    } else if (value.length < 100) {
      setjobTitleError(false);
      setjobTitle(value);
    }
  };
  const resetData = (action) => {
    setUserRoleDataOnEdit([]);
    setUserAddressDataOnEdit('');
    setUserSelectedForEdit({});
    setEmailId('');
    setSearchTerm('');
    setAvailableAddressSearchText('');
    setAvailableAddressOptions([]);
    setSkip(0);
    setTotalItemsCount(0);
    setIsAddressChecked(false);
    setSelectedAddress('');
    setUserRoleSelected([]);
    setphoneNumber('');
    setjobTitle('');
    setIsEditMode(false);
    setShopFilterOptionsSelected([]);
    setRoleFilterIdsSelected([]);
    setStatusFilterOptionsSelected([]);
    setUserListSearchText('');
    setAddressRequiredError(false);
    setRolesRequiredError(false);
    setIsReviewMode(false);
    setFirstClickFlag(false);
    setApproveDeclineNotification(APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE);
    setRoles([]);
    setApiFailureNotification(notificationDefaultValue());
    if (action == 'onCancel') {
      setfirstName('');
      setlastName('');
    }
  };
  const handelCancel = () => {
    resetData('onCancel');
    history.push(paths.userListPage);
  };

  const handleSwitch = (newState) => {
    if (!firstClickFlag) {
      setFirstClickFlag(true);
    }
    setStatusActive(newState);
  };
  const validateProfileUpdate = ({ context, updator }) => {
    if (firstName == '') {
      setfirstNamerequiredError(true);
    }
    if (lastName == '') {
      setlastNamerequiredError(true);
    }
    if (userRoleSelected.length == 0) {
      !rolesRequiredError && setRolesRequiredError(true);
    }
    if (context === USER_FLOW_CONTEXT.adduser) {
      if (selectedAddress.length == 0) {
        !addressRequiredError && setAddressRequiredError(true);
      }
      if (firstName !== '' && lastName !== '' && Object.keys(selectedAddress).length > 0 && userRoleSelected.length > 0) {
        updator();
      }
    } else {
      if (!editUserData.company && selectedAddress.length == 0) {
        !addressRequiredError && setAddressRequiredError(true);
      }
      if (firstName !== '' && lastName !== '' && (Object.keys(selectedAddress).length > 0 || editUserData.company) && userRoleSelected.length > 0) {
        updator();
      }
    }
  };

  const handleAdd = () => {
    validateProfileUpdate({ context: USER_FLOW_CONTEXT.adduser, updator: createUser });
  };
  const handleSave = () => {
    validateProfileUpdate({ context: USER_FLOW_CONTEXT.edituser, updator: saveUserData });
  };
  const handleApprove = () => {
    validateProfileUpdate({ context: USER_FLOW_CONTEXT.approveuser, updator: approveUser });
  };
  const handleDecline = () => {
    validateProfileUpdate({ context: USER_FLOW_CONTEXT.declineuser, updator: declineUser });
  };

  const checkFirstNameEmpty = () => {
    if (firstName == '') {
      setfirstNamerequiredError(true);
    }
  };

  const checkLastNameEmpty = () => {
    if (lastName == '') {
      setlastNamerequiredError(true);
    }
  };

  const createUser = () => {
    setLoading(true);
    const scopes = userRoleSelected[0].groups[0].scopes.map((scope) => scope.alias);
    const _data = {
      Email: emailId,
      GivenName: firstName,
      SurName: lastName,
      Country: selectedAddress.shippingAddress.country,
      PhoneMobile: phoneNumber,
      Language: 'en',
      Active: statusActive,
      Company: selectedAddress.localCustomerNumber,
      Scopes: scopes,
      JobTitle: jobTitle,
      Roles: [
        userRoleSelected[0].id,
      ],
    };
    fetch(CREATE_USER, {
      method: 'POST',
      body: JSON.stringify(_data),
      headers: { 'Content-type': 'application/json; charset=UTF-8' },
    })
      .then((response) => {
        setLoading(false);
        if (response.status === 200) {
          resetData('onAddUser');
          history.push(paths.userListPage);
          setShowCreateUserPopUp('success');
        } else {
          setShowCreateUserPopUp('error');
        }
        scrollToTop();
        response.json();
      })
      .then((json) => console.log(json))
      .catch((err) => console.log(err));
  };

  const setUserData = (userData) => {
    setEmailId(userData.email);
    setfirstName(userData.givenName);
    setlastName(userData.surName);
    setphoneNumber(userData.phoneMobile);
    setjobTitle(userData.jobTitle);
    setStatusActive(userData.active);
    setIsPersonalInfoloaded(false);
    setUserRoleDataOnEdit(userData.roles);
    setUserAddressDataOnEdit(userData.company);
    if (userData.roles == null) {
      setIsRolesloaded(false);
    }
  };
  const declineUser = async () => {
    try {
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, decline: true }));
      const paramsObject = {
        id: userSelectedForEdit?.id ? userSelectedForEdit?.id : editUserData.id,
      };
      const URL = CreateURLFromParams(DECLINE_USER_URL, paramsObject);
      const response = await fetch(URL, {
        method: 'PUT',
        // body: JSON.stringify(_data),
        headers: { 'Content-type': 'application/json; charset=UTF-8' },
      });
      const json = await response.text();
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, decline: false }));
      const notification = { message: json };
      switch (response.status) {
        case 200:
          resetData('onDeclineUser');
          history.push(paths.userListPage);
          notification.severity = NOTIFICATION_SEVERITY.success;
          break;
        case 500:
          notification.severity = NOTIFICATION_SEVERITY.error;
          break;
        case 400:
          resetData('onDeclineUser');
          history.push(paths.userListPage);
          notification.severity = NOTIFICATION_SEVERITY.warning;
          break;
        default:
          break;
      }
      setApproveDeclineNotification(notification);
    } catch (error) {
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, decline: false }));
    }
  };

  const approveUser = async () => {
    try {
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, approve: true }));
      const roles = getRoles();
      const scopes = getScopes();
      const _data = {
        Email: emailId,
        GivenName: firstName,
        SurName: lastName,
        Country: selectedAddress ? selectedAddress.shippingAddress.country : editUserData.country,
        PhoneMobile: phoneNumber,
        Language: 'en',
        Active: statusActive,
        JobTitle: jobTitle,
        Company: selectedAddress ? selectedAddress.localCustomerNumber : editUserData.company,
        Scopes: scopes || [],
        Roles: roles || [],
      };
      const paramsObject = {
        id: userSelectedForEdit?.id ? userSelectedForEdit?.id : editUserData.id,
      };
      const URL = CreateURLFromParams(APPROVE_USER_URL, paramsObject);
      const response = await fetch(URL, {
        method: 'PUT',
        body: JSON.stringify(_data),
        headers: { 'Content-type': 'application/json; charset=UTF-8' },
      });
      const json = await response.text();
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, approve: false }));
      const notification = { message: json };
      switch (response.status) {
        case 200:
          resetData('onApproveUser');
          history.push(paths.userListPage);
          notification.severity = NOTIFICATION_SEVERITY.success;
          break;
        case 500:
          notification.severity = NOTIFICATION_SEVERITY.error;
          break;
        case 400:
          resetData('onApproveUser');
          history.push(paths.userListPage);
          notification.severity = NOTIFICATION_SEVERITY.warning;
          break;
        default:
          break;
      }
      setApproveDeclineNotification(notification);
    } catch (error) {
      console.log(error);
      setApproveDeclineSpinner((spinnerObj) => ({ ...spinnerObj, approve: false }));
    }
  };

  const getScopes = () => {
    let scopes = userRoleSelected[0]?.groups[0]?.scopes?.map((scope) => scope.alias);
    const ShopxpRoles = editUserData?.roles && editUserData.roles.filter((i) => roles.map((item) => item.id).includes(i));
    if (editUserData.scopes && ShopxpRoles && ShopxpRoles.length != 0) {
      const existingshopXpscopes = roles.filter((item) => item.id === ShopxpRoles[0])[0].groups[0].scopes.map((scope) => scope.alias);
      const filterscopes = editUserData.scopes.filter((item) => !existingshopXpscopes.includes(item));
      scopes = [...filterscopes, ...scopes];
      scopes = [...new Set(scopes)];
    } else if (editUserData.scopes) {
      scopes = [...editUserData.scopes, ...scopes];
      scopes = [...new Set(scopes)];
    }
    return scopes;
  };
  const getRoles = () => {
    let rolesArr = [userRoleSelected[0]?.id];
    const nonShopxpRoles = editUserData?.roles && editUserData.roles.filter((i) => !roles.map((item) => item.id).includes(i));
    const ShopxpRoles = editUserData?.roles && editUserData.roles.filter((i) => roles.map((item) => item.id).includes(i));
    setShopxpRoles(ShopxpRoles);
    setNonShopxpRoles(nonShopxpRoles);
    if (nonShopxpRoles && nonShopxpRoles.length != 0) {
      rolesArr = [...nonShopxpRoles, userRoleSelected[0]?.id];
      rolesArr = [...new Set(rolesArr)];
    }
    return rolesArr;
  };

  const saveUserData = () => {
    setLoading(true);
    const roles = getRoles();
    const scopes = getScopes();
    const _data = {
      Email: emailId,
      GivenName: firstName,
      SurName: lastName,
      Country: selectedAddress ? selectedAddress.shippingAddress.country : editUserData.country,
      PhoneMobile: phoneNumber,
      Language: 'en',
      Active: statusActive,
      JobTitle: jobTitle,
      Company: selectedAddress ? selectedAddress.localCustomerNumber : editUserData.company,
      Scopes: scopes || [],
      Roles: roles || [],
    };
    const paramsObject = {
      id: userSelectedForEdit?.id ? userSelectedForEdit?.id : editUserData.id,
    };
    const URL = CreateURLFromParams(UPDATE_USERS, paramsObject);
    // const URL = `${UPDATE_USERS}${userSelectedForEdit.id}`
    fetch(URL, {
      method: 'POST',
      body: JSON.stringify(_data),
      headers: { 'Content-type': 'application/json; charset=UTF-8' },
    })
      .then((response) => {
        setLoading(false);
        if (response.status === 200) {
          resetData('onSaveUser');
          history.push(paths.userListPage);
          setShowSaveUserPopUp('success');
        } else {
          setShowSaveUserPopUp('error');
        }
        scrollToTop();
        response.json();
      })
      .then((json) => console.log(json))
      .catch((err) => console.log(err));
  };
  const getPageTitle = () => {
    if (isEditMode || isReviewMode) {
      return `${USER_PROFILE_PAGE_TITLE_USER} ${emailId}`;
    } if (userProfileSelfMode) {
      return MY_USER_PROFILE_PAGE_TITLE;
    }
    return `${USER_PROFILE_PAGE_TITLE_ADD_USERS} ${emailId}`;
  };
  const handleUpdateUserProfile = () => {
    if (firstName == '') {
      setfirstNamerequiredError(true);
    }
    if (lastName == '') {
      setlastNamerequiredError(true);
    }
    if (firstName !== '' && lastName !== '') {
      updateMyUserProfileData();
    }
  };
  const updateMyUserProfileData = () => {
    setLoading(true);
    const _data = {
      Id: myUserProfileData.id,
      GivenName: firstName,
      SurName: lastName,
      PhoneMobile: phoneNumber,
      Language: languageSelected,
      JobTitle: jobTitle,
    };
    const paramsObject = {
      id: myUserProfileData.id,
    };
    const URL = CreateURLFromParams(UPDATE_MY_USER_PROFILE, paramsObject);
    fetch(URL, {
      method: 'POST',
      body: JSON.stringify(_data),
      headers: { 'Content-type': 'application/json; charset=UTF-8' },
    })
      .then((response) => {
        setLoading(false);
        if (response.status === 200) {
          setFirstClickFlag(false);
          setShowUpdateMyUserProfileMessage('success');
        } else {
          setShowUpdateMyUserProfileMessage('error');
        }
        scrollToTop();
        response.json();
      })
      .then((json) => console.log(json))
      .catch((err) => console.log(err));
  };

  const mapMyUserProfileData = (data) => {
    setEmailId(data.email);
    setfirstName(data.givenName);
    setlastName(data.surName);
    setphoneNumber(data.phoneMobile);
    setjobTitle(data.jobTitle);
    setLanguageSelected(data.language);
    setIsMyUserProfileInfoloaded(false);
    data.roles && setMyUserProfileRole(data.roles);
    if (data.roles == null) {
      setIsMyUserProfileRolesloaded(false);
    }
  };
  const renderReviewButtons = () => (
    <>
      <Button
        variant="primary"
        onClick={handleDecline}
        disabled={loading}
      >
        {REVIEW_BUTTON_TEXT.decline}
        {approveDeclineSpinner.decline && <Spinner size="xsmall" className="userProfile-AddUser-button-spinner" />}
      </Button>
      <Spacing mr={6} />
      <Button
        variant="primary"
        onClick={handleApprove}
        disabled={loading}
      >
        {REVIEW_BUTTON_TEXT.approve}
        {approveDeclineSpinner.approve && <Spinner size="xsmall" className="userProfile-AddUser-button-spinner" />}
      </Button>
    </>
  );
  return (
    <div className="app-container ">
      <Grid gridColsS={12} colSpanS={12} className="userProfile-body">
        <Grid colSpanS={12} item>
          <Card>
            <Typography style={userProfileSelfMode ? {} : { marginBottom: 'var(--echo-spacing-xxs)' }} variant="heading-m">
              {getPageTitle()}
            </Typography>
            {!userProfileSelfMode && !hasProfileLoadFailed
                            && (
                            <div className="userProfile-header-container">
                              <Typography variant="heading-s">
                                {USER_PROFILE_STATUS_LABEL_TEXT}
                              </Typography>
                              <Switch
                                labelChecked={USER_PROFILE_STATUS_ACTIVE_LABEL_TEXT}
                                labelUnchecked={USER_PROFILE_STATUS_INACTIVE_LABEL_TEXT}
                                checked={statusActive}
                                onChange={handleSwitch}
                              />
                            </div>
                            )}
          </Card>
        </Grid>
        {/* <Spacing mt={4} /> */}
        {!hasProfileLoadFailed ? (
          <>
            <Grid colSpanS={12} className="userProfile-grid-container" item>
              <Grid>

                <Grid colSpanS={6} item>
                  <PersonalInformation
                    emailId={emailId}
                    firstName={firstName}
                    lastName={lastName}
                    phoneNumber={phoneNumber}
                    jobTitle={jobTitle}
                    handleFirstNameChange={handleFirstNameChange}
                    handleJobTitleChange={handleJobTitleChange}
                    handleLastNameChange={handleLastNameChange}
                    handlePhoneNoChange={handlePhoneNoChange}
                    jobTitleError={jobTitleError}
                    firstNameError={firstNameError}
                    phoneNoError={phoneNoError}
                    lastNameError={lastNameError}
                    lastNamerequiredError={lastNamerequiredError}
                    firstNamerequiredError={firstNamerequiredError}
                    checkFirstNameEmpty={checkFirstNameEmpty}
                    checkLastNameEmpty={checkLastNameEmpty}
                    isPersonalInfoloaded={isPersonalInfoloaded}
                    isEditMode={isEditMode}
                    userProfileSelfMode={userProfileSelfMode}
                    languages={languages}
                    isMyUserProfilePersonalInfoloaded={isMyUserProfilePersonalInfoloaded}
                  />
                  <Spacing mt={6} />
                  <AccessToFunctionalities
                    setIsRolesloaded={setIsRolesloaded}
                    isRolesloaded={isRolesloaded}
                    rolesRequiredError={rolesRequiredError}
                    setRolesRequiredError={setRolesRequiredError}
                    myUserProfileRole={myUserProfileRole}
                    isMyUserProfileRolesloaded={isMyUserProfileRolesloaded}
                    setIsMyUserProfileRolesloaded={setIsMyUserProfileRolesloaded}
                  />
                </Grid>
                <Grid colSpanS={6} item>
                  <AvailableAddress addressRequiredError={addressRequiredError} setAddressRequiredError={setAddressRequiredError} />
                </Grid>
              </Grid>
            </Grid>
            <Spacing mt={4} />
            <Grid colSpanS={12} item>
              <div className="userProfile-button-container">
                {
                                !userProfileSelfMode
                                && (
                                <Button variant="secondary" onClick={handelCancel} disabled={loading}>
                                  {USER_PROFILE_CANCEL_BUTTON_TEXT}
                                </Button>
                                )
                            }
                <Spacing mr={6} />
                {
                                isReviewMode ? renderReviewButtons()
                                  : (
                                    <Button
                                      variant="primary"
                                      onClick={isEditMode ? handleSave : (userProfileSelfMode ? handleUpdateUserProfile : handleAdd)}
                                      disabled={loading || (isEditMode && !firstClickFlag) || (userProfileSelfMode && !firstClickFlag)}
                                    >
                                      {isEditMode ? USER_PROFILE_SAVE_BUTTON_TEXT : (userProfileSelfMode ? MY_USER_PROFILE_SAVE_BUTTON_TEXT : USER_PROFILE_ADD_USER_BUTTON_TEXT)}
                                      {' '}
                                      {loading && <Spinner size="xsmall" className="userProfile-AddUser-button-spinner" />}
                                    </Button>
                                  )
                            }
              </div>
            </Grid>
          </>
        ) : (
          <Grid colSpanS={12} item>
            <Card>
              <Typography variant="body" className="api-error-label">
                {ERROR_MESSAGE.apiError}
              </Typography>
            </Card>
          </Grid>
        )}
        <Spacing mb={4} />
      </Grid>
      <CreateUserPopup firstName={firstName} lastName={lastName} />
      <SaveUserPopUp firstName={firstName} lastName={lastName} />
      <ChangePasswordNotification />
      <UpdateMyUserProfileNotification />
      <ApproveDeclineNotification />
      <APIFailureNotification />
    </div>
  );
}

export default UserProfile;
