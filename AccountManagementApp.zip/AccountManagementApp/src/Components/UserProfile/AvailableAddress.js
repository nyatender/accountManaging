import React, { useContext, useEffect, useState } from 'react';
import {
  Typography, Card, Spacing, Grid, Radiobutton, Spinner,
} from '@wsa/echo-components';
import { GlobalContext } from '../../Context/GlobalContext';
import {
  NUMBER_OF_ITEMS, AVAILABLE_ADDRESS_TITLE_TEXT, AVAILABLE_ADDRESS_VALIDATION_TEXT, ERROR_MESSAGE,
} from '../../GlobalConstants';
import { concatShippingAddress, fetchAPI } from '../../Utilities/CommonFuntions';
import AvailableAddressSearch from './AvailableAddressSearch';
import { BASE_URL } from '../../Constants/URLConstants';

function AvailableAddress({ addressRequiredError, setAddressRequiredError }) {
  const {
    availableAddressOptions_value,
    selectedAddress_value,
    loading_value,
    availableAddressSearchText_value,
    skip_value,
    isAddressChecked_value,
    totalItemsCount_value,
    userAddressDataOnEdit_value,
    userProfileSelfMode_value,
    firstClickFlag_value,
  } = useContext(GlobalContext);

  const [availableAddressOptions, setAvailableAddressOptions] = availableAddressOptions_value;
  const [, setSelectedAddress] = selectedAddress_value;
  const [loading, setLoading] = loading_value;
  const [skip, setSkip] = skip_value;
  const [availableAddressSearchText] = availableAddressSearchText_value;
  const [, setIsAddressChecked] = isAddressChecked_value;
  const [totalItemsCount, setTotalItemsCount] = totalItemsCount_value;
  const [userAddressDataOnEdit] = userAddressDataOnEdit_value;
  const [errorMessage, setErrorMessage] = useState('');
  const [userProfileSelfMode, setUserProfileSelfMode] = userProfileSelfMode_value;
  const [firstClickFlag, setFirstClickFlag] = firstClickFlag_value;

  useEffect(() => {
    loadAddressList(skip);
  }, [availableAddressSearchText]);

  const handleRadioClick = (e) => {
    const { target: { id } } = e;
    setIsAddressChecked(true);
    setAddressRequiredError(false);
    const updatedAddressOptions = [...availableAddressOptions].map((item) => {
      if (item.id == id) {
        if (item.localCustomerNumber !== userAddressDataOnEdit && !firstClickFlag) {
          setFirstClickFlag(true);
        }
        setSelectedAddress(item);
        return { ...item, isChecked: true };
      }
      return { ...item, isChecked: false };
    });
    setAvailableAddressOptions(updatedAddressOptions);
  };
  const getAvailableAddresses = async (url, skip) => {
    setLoading(true);
    const paramsToFetchAPI = {
      url,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    setLoading(false);
    if (response.errorMessage) {
      setErrorMessage(response.errorMessage);
    } else {
      setErrorMessage('');
      const { entity } = response;
      const Items = entity.items;
      setTotalItemsCount(entity.count);
      if (Items.length == 1) {
        if (Items[0].localCustomerNumber != userAddressDataOnEdit && !firstClickFlag) {
          setFirstClickFlag(true);
        }
        setIsAddressChecked(true);
        setAddressRequiredError(false);
        setSelectedAddress(Items[0]);
      } else if (Items.length == 0) {
        setErrorMessage(ERROR_MESSAGE.noContent);
      }
      const addressItems = [...Items].map((item) => ({ ...item, isChecked: false }));
      if (skip == 0) {
        setAvailableAddressOptions(addressItems);
      } else {
        setAvailableAddressOptions([...availableAddressOptions, ...addressItems]);
      }
    }
  };

  const loadAddressList = (skip) => {
    if (totalItemsCount == 0 || skip < totalItemsCount) {
      // setLoading(true)
      let url = `${BASE_URL}/Common/GetMultipleShippingAddresses?skip=${skip}&take=${NUMBER_OF_ITEMS}`;
      if (availableAddressSearchText) {
        url = `${BASE_URL}/Common/GetMultipleShippingAddresses?skip=${skip}&take=${NUMBER_OF_ITEMS}&search=${availableAddressSearchText}`;
      }
      getAvailableAddresses(url, skip);
      // fetch(url).then(res => res.json()).then(res => {
      //     setLoading(false)
      //     const { entity } = res;
      //     let Items = entity.items;
      //     setTotalItemsCount(entity.count)
      //     if (Items.length == 1) {
      //         setIsAddressChecked(true)
      //         setSelectedAddress(Items[0]);
      //     }
      //     const addressItems = [...Items].map(item => {
      //         return { ...item, isChecked: false }
      //     })
      //     if (skip == 0) {
      //         setAvailableAddressOptions(addressItems);
      //     } else {
      //         setAvailableAddressOptions([...availableAddressOptions, ...addressItems]);
      //     }

      // }).catch(error => {
      //     setLoading(false)
      //     console.log("error", error)
      // });
    }
  };

  const infiniteScroll = (e) => {
    // End of the document reached?
    const bottom = e.target.scrollHeight - e.target.scrollTop;
    // console.log("scroll height", e.target.scrollHeight)
    // console.log("scrolltop", e.target.scrollTop)
    // console.log("offsetHeight", e.target.offsetHeight)

    // condition for not to call api if scroll top is 0 only call if it reached to bottom
    if (e.target.scrollTop != 0 && bottom === e.target.offsetHeight) {
      setSkip(skip + NUMBER_OF_ITEMS);
      loadAddressList(skip + NUMBER_OF_ITEMS);
    }
  };

  useEffect(() => {
    if (userAddressDataOnEdit != '') {
      const updatedAddressOptions = [...availableAddressOptions].map((item) => {
        if (item.localCustomerNumber == userAddressDataOnEdit) {
          setSelectedAddress(item);
          return { ...item, isChecked: true };
        }
        return { ...item, isChecked: false };
      });
      setAvailableAddressOptions(updatedAddressOptions);
    }
  }, [userAddressDataOnEdit, availableAddressOptions.length]);

  const getClassName = () => {
    if (addressRequiredError) {
      return 'availableaddress-validation-text-error';
    }
    return 'availableaddress-validation-text';
  };

  return (
    <div className="availableaddress-card-container">
      <Card className="availableaddress-card">
        <Typography
          children={AVAILABLE_ADDRESS_TITLE_TEXT}
          variant="heading-s"
          className="availableaddress-title-text"
        />
        {
                    !userProfileSelfMode && (
                    <>
                      <Spacing mt={4} />
                      <div className="availableaddress-Search-grid">
                        <AvailableAddressSearch setErrorMessage={setErrorMessage} />
                      </div>
                    </>
                    )
                }

        <Spacing mt={4} />
        {errorMessage ? (
          <Typography
            className="api-error-label"
            variant="body"
            children={errorMessage}
          />
        ) : (
          <>
            {!userProfileSelfMode && <Typography variant="body" className={getClassName()}>{AVAILABLE_ADDRESS_VALIDATION_TEXT}</Typography>}
            <Grid item colSpanXL={12} id="options-list">
              <div onScroll={infiniteScroll} className={userProfileSelfMode ? 'myUserProfile-available-address-options' : 'available-address-options-list'}>
                {
                                loading && availableAddressOptions.length == 0 && <Spinner id="availableaddress-spinner" size="medium" className="spinner-component" />
                            }
                {
                                availableAddressOptions && availableAddressOptions.map((item) => {
                                  const shippingAddress = concatShippingAddress(item.shippingAddress, ',');
                                  // shippingAddress=shippingAddress.replace(/\n/g, ' ');
                                  const labelVal = `${item.localCustomerNumber} - ${item.name} 
                                ${shippingAddress}`;
                                  return (
                                    <>
                                      {
                                                userProfileSelfMode ? (
                                                  <ul className="available-address-list">
                                                    <Typography variant="body" className="available-address-label">
                                                      {labelVal}
                                                    </Typography>
                                                  </ul>
                                                )
                                                  : (
                                                    <>
                                                      <Spacing mt={2} />
                                                      <Radiobutton
                                                        id={item.id}
                                                        label={labelVal}
                                                        name="radiobuttons"
                                                        value={item.name}
                                                        onClick={handleRadioClick}
                                                        className="available-address-radio"
                                                        checked={availableAddressOptions.length == 1 ? true : item.isChecked}
                                                      />
                                                    </>
                                                  )
}
                                    </>
                                  );
                                })
                            }
              </div>
              {
                            loading && availableAddressOptions.length !== 0 && <Spinner size="medium" />
                        }

            </Grid>
          </>
        )}
      </Card>
    </div>
  );
}

export default AvailableAddress;
