import React, { useContext, useRef, useEffect } from 'react';
import { SearchField } from '@wsa/echo-components';
import { GlobalContext } from '../../Context/GlobalContext';
import { EMAILID_VALIDATION_MESSAGE, EMAILID_FORMAT_ERROR_MESSAGE, EMAILID_SEARCH_PLACEHOLDER } from '../../GlobalConstants';
import Validation from '../Validation';

function Search({ handleChange, checkEmailFormat, handleKeyPress }) {
  const {
    emailId_value,
    error_value,
    emailFormatError_value,
  } = useContext(GlobalContext);
  const [emailId] = emailId_value;
  const [hasError] = error_value;
  const [emailFormatError] = emailFormatError_value;
  const searchInput = useRef();

  useEffect(() => {
    searchInput.current?.children[0].children[1].children[1].focus();
  });
  return (
    <>
      <div ref={searchInput}>
        <SearchField
          error={hasError || emailFormatError}
          id="emailIdSearch"
          placeholder={EMAILID_SEARCH_PLACEHOLDER}
          value={emailId}
          onChange={handleChange}
          onBlur={checkEmailFormat}
          onKeyPress={handleKeyPress}
        />
      </div>
      {hasError && <Validation message={EMAILID_VALIDATION_MESSAGE} />}
      {emailFormatError && <Validation message={EMAILID_FORMAT_ERROR_MESSAGE} />}
    </>
  );
}

export default Search;
