import React from 'react';
import {
  Dialog, Typography, Button, Spacing, DialogFooter,
} from '@wsa/echo-components';
import { ERROR_DIALOG_OK_BUTTON_TEXT } from '../../GlobalConstants';

function ErrorDialog({
  isVisible, handleClose, headline, subheadline,
}) {
  return (
    <Dialog
      aria-label="Form Dialog"
      id="form-dialog"
      isVisible={isVisible}
      showCloseIcon={false}
      colSpanL={6}
    >
      <div style={{
				  display: 'flex',
				  flexDirection: 'column',
				  alignItems: 'center',
      }}
      >
        <Typography
          children={headline}
          variant="heading-s"
        />
        <Spacing mt={4} />
        <Typography
          children={subheadline}
          variant="body"
        />
        <DialogFooter className="tw-flex tw-flex-wrap tw-justify-between">
          <Button className="echo-button--small" variant="primary" onClick={handleClose}>
            {ERROR_DIALOG_OK_BUTTON_TEXT}
          </Button>
        </DialogFooter>
      </div>
    </Dialog>
  );
}

export default ErrorDialog;
