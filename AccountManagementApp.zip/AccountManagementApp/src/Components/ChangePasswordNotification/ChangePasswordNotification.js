import React, { useContext } from 'react';
import { GlobalContext } from '../../Context/GlobalContext';
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { CHANGE_PASSWORD_SUCCESS_NOTIFICATION_MESSAGE, CHANGE_PASSWORD_FAILURE_NOTIFICATION_MESSAGE } from '../../GlobalConstants';

export default function ChangePasswordNotification() {
  const { showChangePasswordMessage_value } = useContext(GlobalContext);
  const [showChangePasswordMessage, setShowChangePasswordMessage] = showChangePasswordMessage_value;

  let message = '';
  if (showChangePasswordMessage === 'success') {
    message = CHANGE_PASSWORD_SUCCESS_NOTIFICATION_MESSAGE;
  } else {
    message = CHANGE_PASSWORD_FAILURE_NOTIFICATION_MESSAGE;
  }

  const handleClose = () => {
    setShowChangePasswordMessage('');
  };
  return (
    <NotificationMessage
      isVisible={!!showChangePasswordMessage}
      handleClose={handleClose}
      message={message}
      severity={showChangePasswordMessage}
    />
  );
}
