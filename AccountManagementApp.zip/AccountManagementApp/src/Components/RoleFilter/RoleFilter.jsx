import React, { useState, useEffect, useContext } from 'react';
import { Checkbox, Grid, Spinner, Typography } from '@wsa/echo-components/dist';
import { FETCH_ALL_ROLES } from '../../Constants/URLConstants';
import { GlobalContext } from '../../Context/GlobalContext';
import { fetchAPI, getSelectedOptions } from '../../Utilities/CommonFuntions';
import { ROLE_FILTER_LABEL_TEXT } from '../../GlobalConstants';

export default function RoleFilter() {
  // const [roles, setRoles] = useState([]);
  const { roleFilterIdsSelected_value, roles_value } = useContext(GlobalContext)
  const [roleFilterIdsSelected, setRoleFilterIdsSelected] = roleFilterIdsSelected_value;
  const [roles, setRoles] = roles_value;
  const [loading, setLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const getRoles = async () => {
    setLoading(true)
    const paramsToFetchAPI = {
      url: FETCH_ALL_ROLES,
    }
    const response = await fetchAPI(paramsToFetchAPI);
    setLoading(false)
    if (!!response.errorMessage) {
      setErrorMessage(response.errorMessage)
    }
    else {
      const updatedRoles = [...response.entity.items].map((item) => ({ ...item, isChecked: false }));
      setRoles(updatedRoles);
      setErrorMessage('')
    }
  }

  useEffect(() => {
    getRoles();
    // setLoading(true)
    // fetch(FETCH_ALL_ROLES).then((res) => res.json()).then((res) => {
    //   setLoading(false)
    //   const updatedRoles = [...res.entity.items].map((item) => ({ ...item, isChecked: false }));
    //   setRoles(updatedRoles);
    // });
  }, []);
  const handleCheckboxClick = (e) => {
    const { target: { id } } = e;
    const updatedRoleOptions = [...roles].map((item) => {
      if (item.id === id) {
        const optionsSelected = getSelectedOptions(item, roleFilterIdsSelected, 'id')
        setRoleFilterIdsSelected(optionsSelected);
        return { ...item, isChecked: !item.isChecked };
      }
      return item;
    });
    setRoles(updatedRoleOptions);
  };
  const handleCheckboxChange = (e) => {
    // console.log("change", e);
  };
  return (
    <Grid colSpanS={12} className="filters-container">
      <Grid item colSpanS={12}>
        <Typography variant="body">
          {ROLE_FILTER_LABEL_TEXT}
        </Typography>
      </Grid>
      <Grid item colSpanS={12} className="filter-options">
        {
          loading ? <Spinner size='medium' className='spinner-component' /> : !!errorMessage ? <Typography
            className="api-error-label"
            variant="body"
            children={`${errorMessage}`}
          /> :
            (
              roles.map((item) => (
                <Checkbox
                  label={(
                    <Typography
                      className="checkbox-label"
                      variant="body"
                      children={`${item.name}`}
                    />
                  )}
                  onClick={handleCheckboxClick}
                  onChange={handleCheckboxChange}
                  id={item.id}
                  value={item.id}
                  checked={item.isChecked}
                  key={item.id}
                  className="checkbox-filter"
                />
              ))
            )
        }
      </Grid>
    </Grid>
  );
}
