import React, { useContext, useState } from 'react';
import { GlobalContext } from '../../Context/GlobalContext';
import {
  DELETE_USER_CONFIRMATION_DIALOG_HEADER_TEXT, DELETE_USER_CONFIRMATION_DIALOG_SUBHEADER_TEXT,

  DELETE_USER_SUCCESS_MSG_PART1, DELETE_USER_SUCCESS_MSG_PART2, DELETE_USER_FAILURE_MSG,
} from '../../GlobalConstants';
import DeleteUserConfirmationDialog from './DeleteUserConfirmationDialog';
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { DELETE_USERS } from '../../Constants/URLConstants';
import { CreateURLFromParams, resetUserProfileData, scrollToTop } from '../../Utilities/CommonFuntions';

export default function DeleteUserPopUp() {
  const {
    showDeleteUserConfirmationPopup_value,
    showDeleteUserMessage_value,
    userSelectedForDeleteValue,
    showCreateUserPopUp_value,
    firstName_value,
    lastName_value,
    showSaveUserPopUp_value,
    approveDeclineNotification_value,
    apiFailureNotification_value,
  } = useContext(GlobalContext);
  const [showDeleteUserConfirmationPopup, setShowDeleteUserConfirmationPopup] = showDeleteUserConfirmationPopup_value;
  const [showDeleteUserMessage, setShowDeleteUserMessage] = showDeleteUserMessage_value;
  const [userSelectedForDelete, setUserSelectedForDelete] = userSelectedForDeleteValue;
  const [, setfirstName] = firstName_value;
  const [, setlastName] = lastName_value;
  const [, setShowCreateUserPopUp] = showCreateUserPopUp_value;
  const [, setShowSaveUserPopUp] = showSaveUserPopUp_value;
  const [, setApproveDeclineNotification] = approveDeclineNotification_value;
  const [loading, setLoading] = useState(false);
  const [, setApiFailureNotification] = apiFailureNotification_value;
  let message = '';
  if (showDeleteUserMessage === 'success') {
    message = `${DELETE_USER_SUCCESS_MSG_PART1} ${userSelectedForDelete.name} ${DELETE_USER_SUCCESS_MSG_PART2}`;
  } else {
    message = DELETE_USER_FAILURE_MSG;
  }

  const handleDeleteUser = () => {
    setLoading(true);
    const paramsObject = {
      id: userSelectedForDelete.id,
    };
    const url = CreateURLFromParams(DELETE_USERS, paramsObject);
    fetch(url)
      .then((response) => {
        try {
          setLoading(false);
          setShowDeleteUserConfirmationPopup(false);
          resetUserProfileData(
            setfirstName,
            setlastName,
            setShowCreateUserPopUp,
            setShowDeleteUserMessage,
            setShowSaveUserPopUp,
            setApproveDeclineNotification,
            setApiFailureNotification,
          );
          if (response.status === 200) {
            setShowDeleteUserMessage('success');
          } else {
            setShowDeleteUserMessage('error');
          }
          scrollToTop();
          response.json();
        } catch (error) {

        }
      })
      .catch((err) => { });
  };

  const handleCancel = () => {
    setShowDeleteUserConfirmationPopup(false);
  };
  const handleClose = () => {
    setShowDeleteUserMessage('');
    setUserSelectedForDelete({});
  };
  return (
    <>
      <DeleteUserConfirmationDialog
        isVisible={showDeleteUserConfirmationPopup}
        headline={DELETE_USER_CONFIRMATION_DIALOG_HEADER_TEXT}
        subheadline={`${DELETE_USER_CONFIRMATION_DIALOG_SUBHEADER_TEXT} ${userSelectedForDelete.name} ?`}
        handleDeleteUser={handleDeleteUser}
        handleCancel={handleCancel}
        loading={loading}
      />
      <NotificationMessage
        isVisible={!!showDeleteUserMessage}
        handleClose={handleClose}
        message={message}
        severity={showDeleteUserMessage}
      />
    </>
  );
}
