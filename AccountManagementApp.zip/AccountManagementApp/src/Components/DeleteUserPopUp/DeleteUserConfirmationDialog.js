import React from 'react';
import {
  Dialog, Typography, Button, Spacing, DialogFooter, Spinner,
} from '@wsa/echo-components';
import { DELETE_USER_CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT, DELETE_USER_CONFIRMATION_DIALOG_DELETE_BUTTON_TEXT } from '../../GlobalConstants';

function DeleteUserConfirmationDialog({
  isVisible, headline, subheadline, handleDeleteUser, handleCancel, loading,
}) {
  return (
    <Dialog
      aria-label="Form Dialog"
      id="form-dialog"
      isVisible={isVisible}
      showCloseIcon={false}
      colSpanL={6}
    >
      <div className="deleteUserConfirmationDialog-container">
        <Typography
          children={headline}
          variant="heading-s"
        />
        <Spacing mt={4} />
        <Typography
          children={subheadline}
          variant="body"
        />
        <DialogFooter className="tw-flex tw-flex-wrap tw-justify-between">
          <Button className="echo-button--small" variant="primary" onClick={handleDeleteUser} disabled={loading}>
            {DELETE_USER_CONFIRMATION_DIALOG_DELETE_BUTTON_TEXT}
            {' '}
            {loading && <Spinner size="xsmall" className="deleteUserConfirmationDialog-delete-button-spinner" />}
          </Button>
          <Spacing mr={6} />
          <Button className="echo-button--small" variant="secondary" onClick={handleCancel} disabled={loading}>
            {DELETE_USER_CONFIRMATION_DIALOG_CANCEL_BUTTON_TEXT}
          </Button>
        </DialogFooter>
      </div>
    </Dialog>
  );
}

export default DeleteUserConfirmationDialog;
