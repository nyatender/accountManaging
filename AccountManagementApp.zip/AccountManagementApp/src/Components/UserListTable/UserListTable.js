import React, { useContext, useEffect, useState } from 'react';
import {
  Typography, IconButton, Grid, Tooltip, Spinner,
} from '@wsa/echo-components';
import { useHistory } from 'react-router-dom';
import { GlobalContext } from '../../Context/GlobalContext';
import {
  PENDING_STATUS_VLAUE, STATUS_TO_TEXT_MAPPER, USER_LIST_TABLE_HEADERS
  , USER_LIST_TABLE_HEADER_TO_DATA_MAPPER,
} from './UserListTableConstants';
import {
  DEFAULT_SKIP_VALUE, DELETE_TOOLTIP_TEXT, EDIT_TOOLTIP_TEXT, NO_USERS_PRESENT_INFO
  , NUMBER_OF_RECORDS_PER_PAGE, REVIEW_TOOLTIP_TEXT, TOTAL_USERS_TEXT,
} from '../../GlobalConstants';
import Pagination from '../Pagination/Pagination';
import { FETCH_USERS } from '../../Constants/URLConstants';
import { CreateURLFromParams, fetchAPI, resetUserProfileData } from '../../Utilities/CommonFuntions';
import PendingConfirmationDialog from '../../commonComponents/PopUp/PopUp';
import { paths } from '../../routes/paths';

export default function UserListTable({ scrollToTop }) {
  const {
    userListSearchText_value,
    userList_value,
    totalElements_value,
    activePage_value,
    showDeleteUserConfirmationPopup_value,
    userSelectedForDeleteValue,
    showDeleteUserMessage_value,
    shopFilterOptionsSelected_value,
    roleFilterIdsSelected_value,
    statusFilterOptionsSelected_value,
    userSelectedForEdit_value,
    isEditMode_value,
    showCreateUserPopUp_value,
    firstName_value,
    lastName_value,
    showSaveUserPopUp_value,
    isReviewMode_value,
    approveDeclineNotification_value,
    roles_value,
    apiFailureNotification_value,
  } = useContext(GlobalContext);
  const [userList, setUserList] = userList_value;
  const [totalElements, setTotalElements] = totalElements_value;
  const [, setShowDeleteUserConfirmationPopup] = showDeleteUserConfirmationPopup_value;
  const [, setUserSelectedForDelete] = userSelectedForDeleteValue;
  const [showDeleteUserMessage, setShowDeleteUserMessage] = showDeleteUserMessage_value;
  const [userListSearchText] = userListSearchText_value;
  const [activePage] = activePage_value;
  const [shopFilterOptionsSelected] = shopFilterOptionsSelected_value;
  const [roleFilterIdsSelected] = roleFilterIdsSelected_value;
  const [statusFilterOptionsSelected] = statusFilterOptionsSelected_value;
  const [flag, setFlag] = useState(false);
  const [loading, setLoading] = useState(false);
  const [intialLoad, setIntialLoad] = useState(false);
  const [, setUserSelectedForEdit] = userSelectedForEdit_value;
  const [, setIsEditMode] = isEditMode_value;
  const [, setfirstName] = firstName_value;
  const [, setlastName] = lastName_value;
  const [, setShowCreateUserPopUp] = showCreateUserPopUp_value;
  const [, setShowSaveUserPopUp] = showSaveUserPopUp_value;
  const [, setIsReviewMode] = isReviewMode_value;
  const [, setApproveDeclineNotification] = approveDeclineNotification_value;
  const [roles] = roles_value;
  const [, setApiFailureNotification] = apiFailureNotification_value;

  const history = useHistory();
  const [errorMessage, setErrorMessage] = useState('');
  const [showPendingConfirmationDialog, setShowPendingConfirmationDialog] = useState(false);

  const fetchUsers = async () => {
    const paramsObject = {
      skip: (activePage - 1) * NUMBER_OF_RECORDS_PER_PAGE,
      take: NUMBER_OF_RECORDS_PER_PAGE,
      customerNumber: shopFilterOptionsSelected,
      roleId: roleFilterIdsSelected,
      status: statusFilterOptionsSelected,
      search: userListSearchText,
    };
    const URL = CreateURLFromParams(FETCH_USERS, paramsObject);
    setIntialLoad(true);
    setLoading(true);
    const paramsToFetchAPI = {
      url: URL,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    setLoading(false);
    if (response.errorMessage) {
      setErrorMessage(response.errorMessage);
    } else {
      const { entity: { items, count } } = response;
      setUserList(items);
      setTotalElements(count);
      setErrorMessage('');
    }
  };

  useEffect(() => {
    if (showDeleteUserMessage === 'success' || showDeleteUserMessage === 'error') {
      setFlag(true);
    }
    if (!(showDeleteUserMessage === '' && flag === true) && showDeleteUserMessage !== 'error') {
      fetchUsers();
    }
    showDeleteUserMessage !== 'success' && showDeleteUserMessage !== 'error' && flag && setFlag(false);
  }, [userListSearchText,
    activePage,
    shopFilterOptionsSelected,
    roleFilterIdsSelected,
    statusFilterOptionsSelected,
    showDeleteUserMessage]);

  const deleteUser = (selectedUser) => {
    setUserSelectedForDelete(selectedUser);
    setShowDeleteUserConfirmationPopup(true);
    setShowDeleteUserMessage('');
  };
  const openSubUserProfilePage = (selectedUser) => {
    setUserSelectedForEdit(selectedUser);
    resetUserProfileData(
      setfirstName,
      setlastName,
      setShowCreateUserPopUp,
      setShowDeleteUserMessage,
      setShowSaveUserPopUp,
      setApproveDeclineNotification,
      setApiFailureNotification,
    );
    history.push(`${paths.editUserPartialPath}/${selectedUser.id}`);
  };
  const editUser = (selectedUser) => {
    setIsEditMode(true);
    openSubUserProfilePage(selectedUser);
  };

  const handleClosePendingConfirmationPopUp = () => {
    setShowPendingConfirmationDialog(false);
    fetchUsers();
  };
  const reviewUser = async (selectedUser) => {
    const paramsObject = {
      skip: DEFAULT_SKIP_VALUE,
      take: NUMBER_OF_RECORDS_PER_PAGE,
      search: selectedUser.email,
    };
    const URL = CreateURLFromParams(FETCH_USERS, paramsObject);
    const paramsToFetchAPI = {
      url: URL,
    };
    const response = await fetchAPI(paramsToFetchAPI);
    if (!response.errorMessage) {
      const { entity: { items } } = response;
      if (!items.length || items[0].status !== PENDING_STATUS_VLAUE) {
        setShowPendingConfirmationDialog(true);
      } else {
        setIsReviewMode(true);
        openSubUserProfilePage(selectedUser);
      }
    }
  };
  return (
    <>
      <Grid item colSpanXL={12}>
        {
                    loading ? <Spinner size="medium" className="spinner-component" id="table-spinner" />
                      : errorMessage ? (
                        <Typography
                          className="api-error-label no-user-text"
                          variant="body"
                          children={`${errorMessage}`}
                        />
                      )
                        : (totalElements > 0 ? (
                          <>
                            <Grid item colSpanXL={12} className="total-users-label">
                              <Typography variant="body" children={totalElements ? `${totalElements} ${TOTAL_USERS_TEXT}` : ''} />
                            </Grid>
                            <table className="user-list-table">
                              <thead>
                                <tr>
                                  {USER_LIST_TABLE_HEADERS.map((header) => (
                                    <th key={header}>
                                      <Typography
                                        children={header}
                                        key={header}
                                        variant="heading-s"
                                      />
                                    </th>
                                  ))}
                                  <th />
                                  <th />
                                </tr>
                              </thead>
                              <tbody>
                                {userList.map((user) => (
                                  <tr key={user.id}>
                                    {USER_LIST_TABLE_HEADERS.map((header) => {
                                      let data = '';
                                      if (header === 'Status') {
                                        data = STATUS_TO_TEXT_MAPPER.get(user[USER_LIST_TABLE_HEADER_TO_DATA_MAPPER.get(header)]);
                                      } else if (header === 'Role') {
                                        const roleData = user?.role && user?.role.filter((role) => {
                                          const isShopXPRole = roles?.map((roleItem) => roleItem.id).includes(role.roleId);
                                          return isShopXPRole;
                                        });
                                        data = roleData?.length ? roleData[0]?.roleName : ' ';
                                      } else {
                                        data = user[USER_LIST_TABLE_HEADER_TO_DATA_MAPPER.get(header)];
                                      }
                                      return (
                                        <td key={header}>
                                          <Typography
                                            children={data}
                                            key={header}
                                            variant="body"
                                          />
                                        </td>
                                      );
                                    })}
                                    {user.status === 2
                                      ? (
                                        <>
                                          <td className="edit-user" />
                                          <td className="delete-user">
                                            <Tooltip className="tooltip-am tooltip-review" placement="bottom-start" text={REVIEW_TOOLTIP_TEXT}>
                                              <IconButton
                                                aria-label="Small"
                                                icon="review"
                                                size="medium"
                                                variant="secondary"
                                                className="icon-table"
                                                onClick={() => reviewUser(user)}
                                              />
                                            </Tooltip>

                                          </td>
                                          {' '}

                                        </>
                                      ) : (
                                        <>
                                          <td className="edit-user">
                                            <Tooltip className="tooltip-am" placement="bottom-start" text={EDIT_TOOLTIP_TEXT}>
                                              <IconButton
                                                aria-label="Small"
                                                icon="edit"
                                                size="medium"
                                                variant="secondary"
                                                className="icon-table"
                                                onClick={() => editUser(user)}
                                              />
                                            </Tooltip>
                                          </td>
                                          <td className="delete-user">
                                            <Tooltip className="tooltip-am" placement="bottom-start" text={DELETE_TOOLTIP_TEXT}>
                                              <IconButton
                                                aria-label="Small"
                                                icon="bin"
                                                size="medium"
                                                variant="secondary"
                                                className="icon-table"
                                                onClick={() => deleteUser(user)}
                                              />
                                            </Tooltip>
                                          </td>
                                        </>
                                      )}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                            <Grid item colSpanXL={12} className="pagination-container">
                              <Pagination scrollToTop={scrollToTop} />
                            </Grid>
                          </>
                        ) : intialLoad && <Typography children={NO_USERS_PRESENT_INFO} variant="body" className="no-user-text" />
                        )
                }
      </Grid>
      <PendingConfirmationDialog
        isVisible={showPendingConfirmationDialog}
        handleClose={handleClosePendingConfirmationPopUp}
      />
    </>
  );
}
