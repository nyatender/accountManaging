import React, { useContext, useEffect } from 'react';
import { IconButton, Button, Grid } from '@wsa/echo-components';
import { range } from 'lodash';
import { GlobalContext } from '../../Context/GlobalContext';
import { NUMBER_OF_RECORDS_PER_PAGE } from '../../GlobalConstants';

export default function Pagination({ scrollToTop }) {
  const { activePage_value, totalElements_value } = useContext(GlobalContext);
  const [activePage, setActivePage] = activePage_value;
  const [totalElements] = totalElements_value;
  const lastPage = Math.ceil(totalElements / NUMBER_OF_RECORDS_PER_PAGE);
  // useEffect(() => {
  //     setActivePage(1);
  // }, [totalElements])
  const handlepageClick = (e) => {
    setActivePage(parseInt(e.target.innerText));
    scrollToTop();
  };
  const getPageNumbers = () => {
    if (lastPage - activePage <= 4) {
      // show pages without elipses
      const firstPageToBeShown = lastPage - 4 > 0 ? lastPage - 4 : 1;
      return range(firstPageToBeShown, lastPage + 1).map((page) => (
        <Button
          variant="secondary"
          className="page-numbers"
          disabled={page === activePage}
          onClick={handlepageClick}
          key={page}
        >
          {page}
        </Button>
      ));
    }
    // show pages with elipses
    const lastPageShownBeforeElipses = Math.ceil(activePage / 3) * 3;
    const firstPageToBeShown = lastPageShownBeforeElipses - 2;

    return (
      <>
        {range(firstPageToBeShown, lastPageShownBeforeElipses + 1).map((page) => (
          <Button
            variant="secondary"
            className="page-numbers"
            disabled={page === activePage}
            onClick={handlepageClick}
            key={page}
          >
            {page}
          </Button>
        ))}
        <Button
          variant="secondary"
          className="page-numbers"
        >
          ...
        </Button>
        <Button
          variant="secondary"
          className="page-numbers"
          onClick={handlepageClick}
        >
          {lastPage}
        </Button>
      </>
    );
  };
  const handlePaginationMenuClick = (paginationAction) => {
    switch (paginationAction) {
      case 'first-page':
        setActivePage(1);
        break;
      case 'previous-page':
        setActivePage(activePage - 1);
        break;
      case 'next-page':
        setActivePage(activePage + 1);
        break;
      case 'last-page':
        setActivePage(lastPage);
        break;
      default:
        break;
    }
    scrollToTop();
  };
  return (
    <Grid item colSpanXL={6} className="pagination">

      <IconButton
        aria-label="Small"
        icon="firstPage"
        size="medium"
        variant="primary"
        className="first-page"
        onClick={() => { handlePaginationMenuClick('first-page'); }}
        disabled={activePage == 1}
      />
      <IconButton
        aria-label="Small"
        icon="chevronLeft"
        size="medium"
        variant="primary"
        className="previous-page"
        disabled={activePage == 1}
        onClick={() => { handlePaginationMenuClick('previous-page'); }}
      />
      {getPageNumbers()}
      <IconButton
        aria-label="Small"
        icon="chevronRight"
        size="medium"
        variant="primary"
        className="next-page"
        disabled={activePage == lastPage}
        onClick={() => { handlePaginationMenuClick('next-page'); }}
      />
      <IconButton
        aria-label="Small"
        icon="lastPage"
        size="medium"
        variant="primary"
        className="last-page"
        disabled={activePage == lastPage}
        onClick={() => { handlePaginationMenuClick('last-page'); }}
      />
    </Grid>

  );
}
