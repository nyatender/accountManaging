import React, { useState, useContext, useEffect } from 'react';
import {
    Checkbox, Grid, SearchField, Spinner, Typography,
} from '@wsa/echo-components/dist';
import { SHOP_LIST } from '../../Mockdata';
import { FETCH_ALL_SHOPS_URL } from '../../Constants/URLConstants';
import { GlobalContext } from '../../Context/GlobalContext';
import Search from '../../commonComponents/Search/Search';
import { fetchAPI, getSelectedOptions } from '../../Utilities/CommonFuntions';
import { ERROR_MESSAGE, SHOP_FILTER_LABEL_TEXT, SHOP_FILTER_SEARCH_PLACEHOLDER } from '../../GlobalConstants';

export default function ShopFilter() {
    const {
        shopFilterOptions_value,
        shopFilterSearchText_value,
        shopFilterOptionsSelected_value,
    } = useContext(GlobalContext);
    const [shopFilterOptions, setShopFilterOptions] = shopFilterOptions_value;
    const [shopFilterSearchText, setShopFilterSearchText] = shopFilterSearchText_value;
    const [shopFilterOptionsSelected, setShopFilterOptionsSelected] = shopFilterOptionsSelected_value;
    const [loading, setLoading] = useState(false);
    const [searchOptionsLength, setsearchOptionsLength] = useState(0)
    const [errorMessage, setErrorMessage] = useState('')

    const fetchShops = async () => {
        setLoading(true);
        const paramsToFetchAPI = {
            url: FETCH_ALL_SHOPS_URL,
        }
        const response = await fetchAPI(paramsToFetchAPI);
        setLoading(false)
        if (!!response.errorMessage) {
            setErrorMessage(response.errorMessage)
        }
        else {
            const shops = [...response.entity.items].map((shop) => ({ ...shop, isChecked: false, isDisplayed: true }));
            setShopFilterOptions(shops);
            setsearchOptionsLength(shops.filter(option => option.isDisplayed).length);
            setErrorMessage('');
        }
    }

    useEffect(() => {
        fetchShops();
        // setLoading(true)
        // fetch(FETCH_ALL_SHOPS_URL).then((res) => res.json()).then((res) => {
        //     setLoading(false)
        //     const shops = [...res.entity.items].map((shop) => ({ ...shop, isChecked: false, isDisplayed: true }));
        //     setShopFilterOptions(shops);
        // });
    }, []);
    useEffect(() => {
        const filterOptions = shopFilterOptions.map((option) => {
            option.isDisplayed = true;
            if (option.localCustomerNumber.toLowerCase().indexOf(shopFilterSearchText) < 0
                && option.name.toLowerCase().indexOf(shopFilterSearchText) < 0) {
                option.isDisplayed = false;
            }
            return option;
        });
        const searchResultOptionsLength = filterOptions.filter(option => option.isDisplayed).length;
        // setShopFilterOptions((filterOptions) => filterOptions.map((option) => {
        //     option.isDisplayed = true;
        //     if (option.localCustomerNumber.toLowerCase().indexOf(shopFilterSearchText) < 0
        //         && option.name.toLowerCase().indexOf(shopFilterSearchText) < 0) {
        //         option.isDisplayed = false;
        //     }
        //     return option;
        // }));
        setShopFilterOptions(filterOptions);
        setsearchOptionsLength(searchResultOptionsLength);
    }, [shopFilterSearchText]);

    const handleCheckboxClick = (e) => {
        const { target: { id } } = e;
        const updatedShopOptions = [...shopFilterOptions].map((shop) => {
            if (shop.id === id) {
                const optionsSelected = getSelectedOptions(shop, shopFilterOptionsSelected, 'localCustomerNumber')
                setShopFilterOptionsSelected(optionsSelected);
                return { ...shop, isChecked: !shop.isChecked };
            }
            return shop;
        });
        setShopFilterOptions(updatedShopOptions);
    };

    const handleCheckboxChange = (e) => {
        // console.log("change", e);
    };

    const handleSearchInputChange = (searchTerm) => {
        setShopFilterSearchText(searchTerm.toLowerCase());
    };

    return (
        <Grid colSpanS={12} className="shop-filter-container">
            <Grid item colSpanS={12}>
                <Typography variant="body">
                    {SHOP_FILTER_LABEL_TEXT}
                </Typography>
            </Grid>
            <Grid item colSpanS={12}>
                <Search placeholder={SHOP_FILTER_SEARCH_PLACEHOLDER} className="shop-filter-search" onChange={handleSearchInputChange} />
            </Grid>
            <Grid item colSpanS={12} className="shop-filter-options ">
                {loading ? <Spinner size="medium" className='spinner-component' /> :
                    !!errorMessage ? <Typography
                        className="api-error-label"
                        variant="body"
                        children={`${errorMessage}`}
                    /> :
                        (!!searchOptionsLength ?
                            (
                                shopFilterOptions.map((shop) => (
                                    shop.isDisplayed ? (
                                        <Checkbox
                                            label={<Typography className="checkbox-label" variant="body" key={shop.id} children={`${shop.localCustomerNumber}-${shop.name}`} />}
                                            onClick={handleCheckboxClick}
                                            onChange={handleCheckboxChange}
                                            id={shop.id}
                                            value={shop.id}
                                            checked={shop.isChecked}
                                            key={shop.id}
                                            className="checkbox-filter"
                                        />
                                    ) : ''
                                ))
                            ) : <Typography
                                className="no-result-label"
                                variant="body"
                                children={`${ERROR_MESSAGE.noContent}`}
                            />)
                }
            </Grid>
        </Grid>
    );
}
