import React, { useState, useContext } from 'react';
import { Checkbox, Grid, Typography } from '@wsa/echo-components/dist';
import { STATUS_LIST } from '../../Mockdata';
import { GlobalContext } from '../../Context/GlobalContext';
import { STATUS_TO_TEXT_MAPPER } from '../UserListTable/UserListTableConstants';
import { getSelectedOptions } from '../../Utilities/CommonFuntions';
import { STATUS_FILTER_LABEL_TEXT } from '../../GlobalConstants';

export default function STatusFilter() {
  const [statusItems, setStatusItems] = useState(STATUS_LIST.map((statusObj) => ({ ...statusObj, isChecked: false })));
  const { statusFilterOptionsSelected_value } = useContext(GlobalContext);
  const [statusFilterOptionsSelected, setStatusFilterOptionsSelected] = statusFilterOptionsSelected_value;

  const handleCheckboxClick = (e) => {
    const { target: { id } } = e;
    const updatedStatusOptions = [...statusItems].map((item) => {
      if (item.id === id) {
        const optionsSelected = getSelectedOptions(item, statusFilterOptionsSelected, 'id')
        setStatusFilterOptionsSelected(optionsSelected);
        return { ...item, isChecked: !item.isChecked };
      }
      return item;
    });
    setStatusItems(updatedStatusOptions);
  };
  const handleCheckboxChange = (e) => {
    // console.log("change", e);
  };

  return (
    <Grid colSpanS={12} className="filters-container">
      <Grid item colSpanS={12}>
        <Typography variant="body">
          {STATUS_FILTER_LABEL_TEXT}
        </Typography>
      </Grid>
      <Grid item colSpanS={12} className="filter-options">
        {statusItems.map((item) => (
          <Checkbox
            label={(
              <Typography
                className="checkbox-label"
                variant="body"
                children={`${item.status}`}
              />
            )}
            onClick={handleCheckboxClick}
            onChange={handleCheckboxChange}
            id={item.id}
            value={item.status}
            checked={item.isChecked}
            key={item.status}
            className="checkbox-filter"
          />
        ))}
      </Grid>
    </Grid>
  );
}
