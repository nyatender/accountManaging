import React, { useContext } from 'react'
import { GlobalContext } from '../../Context/GlobalContext'
import NotificationMessage from '../../commonComponents/Notification/NotificationMessage';
import { APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE } from '../../Constants/ConfigurationConstants';

export default function ApproveDeclineNotification() {
    const { approveDeclineNotification_value } = useContext(GlobalContext)
    const [approveDeclineNotification, setApproveDeclineNotification] = approveDeclineNotification_value;
    const { message, severity } = approveDeclineNotification;
    const handleClose = () => {
        setApproveDeclineNotification(APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE);
    }
    return (
        <NotificationMessage
            isVisible={!!message}
            handleClose={handleClose}
            message={message}
            severity={severity} />
    )
}
