import React from 'react';
import ReactDom from 'react-dom';
import authentication from 'react-azure-b2c';
import App from './App';

require('@wsa/echo-components/dist/widex.js');

// authentication.initialize({
//     // optional, will default to this
//     instance: 'https://login.microsoftonline.com/tfp/',
//     // your B2C tenant
//     tenant: 'stgb2cwdxaad.onmicrosoft.com',
//     // the policy to use to sign in, can also be a sign up or sign in policy
//     signInPolicy: 'B2C_1_fitxp_signin',
//     // the the B2C application you want to authenticate with (that's just a random GUID - get yours from the portal)
//     clientId: '8d374c6b-cb83-4382-912a-592e934b4393',
//     // where MSAL will store state - localStorage or sessionStorage
//     cacheLocation: 'sessionStorage',
//     // the scopes you want included in the access token
//     scopes: [
//         'https://stgb2cwdxaad.onmicrosoft.com/api-mgt/fitxp.api.demoaccess',
//         'https://stgb2cwdxaad.onmicrosoft.com/api-mgt/identity.authuser.read'
//     ],
//     // optional, the redirect URI - if not specified MSAL will pick up the location from window.href
//     //redirectUri: 'https://localhost:3000'
// });

// authentication.run(() => {
//     const token = authentication.getAccessToken();
//     ReactDOM.render( < App /> , document.getElementById('root'));

//     serviceWorker.register();
// });

ReactDom.render(
  <App />,
  document.getElementById('root'),
);
