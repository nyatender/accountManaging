import _, { countBy } from 'lodash';
import { APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE, notificationDefaultValue } from '../Constants/ConfigurationConstants';
import { GlobalContext } from '../Context/GlobalContext';
import { ERROR_CODE, ERROR_MESSAGE } from '../GlobalConstants';

export const concatShippingAddress = (obj, separator) => Object.values(obj).filter((val) => val).join(separator);

export const getSelectedOptions = (item, filterOptionsSelected, propertyToCompare) => {
  if (item.isChecked) {
    return filterOptionsSelected.filter((value) => value !== item[propertyToCompare]);
  }
  return [...filterOptionsSelected, item[propertyToCompare]];
};

export const CreateURLFromParams = (url, paramsObject) => {
  const params = _.pickBy(paramsObject, (value, key) => (_.isUndefined(value.length) ? value !== '' : value.length));
  const paramsString = decodeURIComponent(new URLSearchParams(params).toString());
  return paramsString === '' ? url : `${url}?${paramsString}`;
};

export const resetUserProfileData = (setfirstName, setlastName, setShowCreateUserPopUp, setShowDeleteUserMessage, setShowSaveUserPopUp, setApproveDeclineNotification, setApiFailureNotification) => {
  setfirstName('');
  setlastName('');
  setShowCreateUserPopUp('');
  setShowDeleteUserMessage('');
  setShowSaveUserPopUp('');
  setApproveDeclineNotification(APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE);
  setApiFailureNotification(notificationDefaultValue());
};

export const scrollToTop = () => {
  window.scrollTo(0, 0);
};

export const fetchAPI = async ({ url, apiErrorMessage }) => {
  try {
    const promise = await fetch(url);
    const { status } = promise;
    if (status === 200) {
      const response = promise.json();
      return response;
    }
    if (status === 204) {
      return { errorCode: ERROR_CODE.noContent, errorMessage: ERROR_MESSAGE.noContent };
    }
    if (status !== 200) {
      return {
        errorCode: ERROR_CODE.apiError,
        errorMessage: apiErrorMessage || ERROR_MESSAGE.apiError,
      };
    }
    if (status === 401 || status === 403) {
      // TODO
    }
  } catch (error) {
    console.log(error);
    // TODO
  }
};

export const passwordvalidation = (str) => {
  // NOTE: each index of the below array denote the lowercase countBy,uppercase countz,numeric count and symbol count respectively
  const arr = [0, 0, 0, 0];
  for (let i = 0; i < str.length; i++) {
    if (str[i] >= 'A' && str[i] <= 'Z') arr[0]++;
    else if (str[i] >= 'a' && str[i] <= 'z') arr[1]++;
    else if (str[i] >= '0' && str[i] <= '9') arr[2]++;
    else arr[3]++;
  }
  const res = arr.filter((item) => item > 0);
  const valid = res.length >= 3 && str.length >= 8 && str.length <= 16;
  return valid;
};
