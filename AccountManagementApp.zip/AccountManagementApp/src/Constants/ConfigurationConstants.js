import { ACCESS_TO_FUNCTIONALITY_PLACEHOLDER } from '../GlobalConstants';

export const DEBOUNCE_DELAY_FOR_SEARCH = '500';
export const NUMBER_OF_RECORDS_PER_PAGE = 20;
export const FALLBACK_UI_MESSAGE = 'Something went wrong, please refresh the page';
export const ACCESS_TO_FUNCTIONALITIES_DEFAULT_VALUE = { label: ACCESS_TO_FUNCTIONALITY_PLACEHOLDER, value: '' };
export const NOTIFICATION_SEVERITY = {
  success: 'success',
  error: 'error',
  warning: 'warning',
  info: 'info',
};
export const APPROVE_DECLINE_NOTIFICATION_DEFAULT_VALUE = {
  severity: NOTIFICATION_SEVERITY.success,
  message: '',
};
export const USER_FLOW_CONTEXT = {
  adduser: 'adduser',
  edituser: 'edituser',
  approveuser: 'approveuser',
  declineuser: 'declineuser',
};
export const notificationDefaultValue = (severity = NOTIFICATION_SEVERITY.error) => ({
  severity,
  message: '',
});
