export const paths = {
  userListPage: '/manageusers',
  userProfilePage: '/profile',
  editUserProfilePage: '/manageusers/edit/:id',
  addUserPage: '/manageusers/add',
  editUserPartialPath: '/manageusers/edit',
};
