export const SHOP_LIST = [
  '11253 - Shop A',
  '11242 - Shop B',
  '11254 - Shop C',
  '11273 - Shop E',
  '11258 - Shop A',
  '11263 - Shop D',
  '11253 - Shop X',
  '11253 - Shop F',
  '11253 - Shop Y',
  '11253 - Shop Z',
  '11253 - Shop W',
  '11253 - Shop Q',
  '11253 - Shop R',
  '11253 - Shop S',
  '11253 - Shop T',
  '11253 - Shop U',
  '11253 - Shop V',
  '11253 - Shop O',
  '11253 - Shop P',
];

export const ROLE_LIST = [
  'Admin',
  'Local',
  'Global',
];

export const STATUS_LIST = [
  { status: 'Pending', id: '2' },
  { status: 'Active', id: '1' },
  { status: 'Inactive', id: '0' },
];

export const LANGUAGE_LIST = [
  'English', 'French', 'German',
];
