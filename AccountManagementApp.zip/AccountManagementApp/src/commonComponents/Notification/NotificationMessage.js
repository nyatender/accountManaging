import React from 'react';
import { Notification } from '@wsa/echo-components';
import './Notification.css';

export default function NotificationMessage({
  isVisible, handleClose, message, severity,
}) {
  return (
    <div className="Notification">
      <Notification
        message={message}
        onClose={handleClose}
        open={isVisible}
        severity={severity}
        title={severity ? severity.charAt(0).toUpperCase() + severity.slice(1)
          : ''}
      />
    </div>
  );
}
