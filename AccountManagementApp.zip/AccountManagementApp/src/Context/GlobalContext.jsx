import React, { useState } from 'react';
import { DEFAULT_STATE } from './DefaultContext';
const {
    userListSearchTextDefault,
    userListDefault,
    totalElementsDefault,
    activePageDefault,
    emailValidationPopUpIsVisibleDefault,
    userRoleSelectedDefault,
    emailIdDefault,
    hasErrorDefault,
    emailFormatErrorDefault,
    availableAddressOptionsDefault,
    selectedAddressDefault,
    loadingDefault,
    availableAddressSearchTextDefault,
    skipDefauilt,
    isAddressCheckedDefault,
    totalItemsCountDefault,
    searchTermDefault,
    showDeleteUserConfirmationPopupDefault,
    shopFilterOptionsDefault,
    shopFilterSearchTextDefault,
    showCreateUserPopUpDefault,
    showDeleteUserMessageDefault,
    userSelectedForDeleteDefault,
    firstNameDefault,
    lastNameDefault,
    shopFilterOptionsSelectedDefault,
    roleFilterIdsSelectedDefault,
    statusFilterOptionsSelectedDefault,
    userSelectedForEditDefault,
    isEditModeDefault,
    userRoleDataOnEditDefault,
    userAddressDataOnEditDefault,
    showSaveUserPopUpDefault,
    userProfileSelfModeDefault,
    languageSelectedDefault,
    showChangePasswordDefault,
    passwordInputDefault,
    confirmPasswordInputDefault,
    showChangePasswordMessageDefault,
    showUpdateMyUserProfileMessageDefault,
    isReviewModeDefault,
    firstClickFlagDefault,
    approveDeclineNotificationDefault,
    rolesDefault,
    notificationDefault,
    hasProfileLoadFailedDefault
} = DEFAULT_STATE;
export const ContextValue = () => {
    const [name, setname] = useState(DEFAULT_STATE.name);
    const [userListSearchText, setUserListSearchText] = useState(userListSearchTextDefault);
    const [userList, setUserList] = useState(userListDefault);
    const [totalElements, setTotalElements] = useState(totalElementsDefault);
    const [activePage, setActivePage] = useState(activePageDefault)
    const [emailValidationPopUpIsVisible, setEmailValidationPopUpIsVisible] = useState(emailValidationPopUpIsVisibleDefault)
    const [userRoleSelected, setUserRoleSelected] = useState(userRoleSelectedDefault);
    const [emailId, setEmailId] = useState(emailIdDefault);
    const [hasError, sethasError] = useState(hasErrorDefault);
    const [emailFormatError, setEmailFormatError] = useState(emailFormatErrorDefault);
    const [availableAddressOptions, setAvailableAddressOptions] = useState(availableAddressOptionsDefault);
    const [selectedAddress, setSelectedAddress] = useState(selectedAddressDefault)
    const [loading, setLoading] = useState(loadingDefault)
    const [availableAddressSearchText, setAvailableAddressSearchText] = useState(availableAddressSearchTextDefault)
    const [skip, setSkip] = useState(skipDefauilt)
    const [isAddressChecked, setIsAddressChecked] = useState(isAddressCheckedDefault)
    const [totalItemsCount, setTotalItemsCount] = useState(totalItemsCountDefault)
    const [searchTerm, setSearchTerm] = useState(searchTermDefault)
    const [showDeleteUserConfirmationPopup, setShowDeleteUserConfirmationPopup] = useState(showDeleteUserConfirmationPopupDefault)
    const [shopFilterOptions, setShopFilterOptions] = useState(shopFilterOptionsDefault);
    const [shopFilterSearchText, setShopFilterSearchText] = useState(shopFilterSearchTextDefault);
    const [showCreateUserPopUp, setShowCreateUserPopUp] = useState(showCreateUserPopUpDefault);
    const [showDeleteUserMessage, setShowDeleteUserMessage] = useState(showDeleteUserMessageDefault)
    const [userSelectedForDelete, setUserSelectedForDelete] = useState(userSelectedForDeleteDefault)
    const [firstName, setfirstName] = useState(firstNameDefault);
    const [lastName, setlastName] = useState(lastNameDefault);
    const [shopFilterOptionsSelected, setShopFilterOptionsSelected] = useState(shopFilterOptionsSelectedDefault);
    const [roleFilterIdsSelected, setRoleFilterIdsSelected] = useState(roleFilterIdsSelectedDefault);
    const [statusFilterOptionsSelected, setStatusFilterOptionsSelected] = useState(statusFilterOptionsSelectedDefault);
    const [userSelectedForEdit, setUserSelectedForEdit] = useState(userSelectedForEditDefault);
    const [isEditMode, setIsEditMode] = useState(isEditModeDefault);
    const [userRoleDataOnEdit, setUserRoleDataOnEdit] = useState(userRoleDataOnEditDefault);
    const [userAddressDataOnEdit, setUserAddressDataOnEdit] = useState(userAddressDataOnEditDefault);
    const [showSaveUserPopUp, setShowSaveUserPopUp] = useState(showSaveUserPopUpDefault)
    const [userProfileSelfMode, setUserProfileSelfMode] = useState(userProfileSelfModeDefault)
    const [languageSelected, setLanguageSelected] = useState(languageSelectedDefault)
    const [showChangePassword, setShowChangePassword] = useState(showChangePasswordDefault)
    const [passwordInput, setPasswordInput] = useState(passwordInputDefault)
    const [confirmPasswordInput, setConfirmPasswordInput] = useState(confirmPasswordInputDefault)
    const [showChangePasswordMessage, setShowChangePasswordMessage] = useState(showChangePasswordMessageDefault)
    const [showUpdateMyUserProfileMessage, setShowUpdateMyUserProfileMessage] = useState(showUpdateMyUserProfileMessageDefault)
    const [isReviewMode, setIsReviewMode] = useState(isReviewModeDefault)
    const [firstClickFlag, setFirstClickFlag] = useState(firstClickFlagDefault)
    const [approveDeclineNotification, setApproveDeclineNotification] = useState(approveDeclineNotificationDefault)
    const [roles, setRoles] = useState(rolesDefault)
    const [apiFailureNotification, setApiFailureNotification] = useState(notificationDefault)
    const [hasProfileLoadFailed, setHasProfileLoadFailed] = useState(hasProfileLoadFailedDefault)

    const value = {
        username: [name, setname],
        userListSearchText_value: [userListSearchText, setUserListSearchText],
        userList_value: [userList, setUserList],
        totalElements_value: [totalElements, setTotalElements],
        activePage_value: [activePage, setActivePage],
        emailValidationPopUpIsVisible_value: [emailValidationPopUpIsVisible, setEmailValidationPopUpIsVisible],
        emailId_value: [emailId, setEmailId],
        error_value: [hasError, sethasError],
        userRoleSelected_value: [userRoleSelected, setUserRoleSelected],
        emailFormatError_value: [emailFormatError, setEmailFormatError],
        availableAddressOptions_value: [availableAddressOptions, setAvailableAddressOptions],
        selectedAddress_value: [selectedAddress, setSelectedAddress],
        loading_value: [loading, setLoading],
        availableAddressSearchText_value: [availableAddressSearchText, setAvailableAddressSearchText],
        skip_value: [skip, setSkip],
        isAddressChecked_value: [isAddressChecked, setIsAddressChecked],
        totalItemsCount_value: [totalItemsCount, setTotalItemsCount],
        searchTerm_value: [searchTerm, setSearchTerm],
        showDeleteUserConfirmationPopup_value: [showDeleteUserConfirmationPopup, setShowDeleteUserConfirmationPopup],
        shopFilterOptions_value: [shopFilterOptions, setShopFilterOptions],
        shopFilterSearchText_value: [shopFilterSearchText, setShopFilterSearchText],
        showCreateUserPopUp_value: [showCreateUserPopUp, setShowCreateUserPopUp],
        showDeleteUserMessage_value: [showDeleteUserMessage, setShowDeleteUserMessage],
        userSelectedForDeleteValue: [userSelectedForDelete, setUserSelectedForDelete],
        firstName_value: [firstName, setfirstName],
        lastName_value: [lastName, setlastName],
        shopFilterOptionsSelected_value: [shopFilterOptionsSelected, setShopFilterOptionsSelected],
        roleFilterIdsSelected_value: [roleFilterIdsSelected, setRoleFilterIdsSelected],
        statusFilterOptionsSelected_value: [statusFilterOptionsSelected, setStatusFilterOptionsSelected],
        userSelectedForEdit_value: [userSelectedForEdit, setUserSelectedForEdit],
        isEditMode_value: [isEditMode, setIsEditMode],
        userRoleDataOnEdit_value: [userRoleDataOnEdit, setUserRoleDataOnEdit],
        userAddressDataOnEdit_value: [userAddressDataOnEdit, setUserAddressDataOnEdit],
        showSaveUserPopUp_value: [showSaveUserPopUp, setShowSaveUserPopUp],
        userProfileSelfMode_value: [userProfileSelfMode, setUserProfileSelfMode],
        languageSelected_value: [languageSelected, setLanguageSelected],
        showChangePassword_value: [showChangePassword, setShowChangePassword],
        passwordInput_value: [passwordInput, setPasswordInput],
        confirmPasswordInput_value: [confirmPasswordInput, setConfirmPasswordInput],
        showChangePasswordMessage_value: [showChangePasswordMessage, setShowChangePasswordMessage],
        showUpdateMyUserProfileMessage_value: [showUpdateMyUserProfileMessage, setShowUpdateMyUserProfileMessage],
        isReviewMode_value: [isReviewMode, setIsReviewMode],
        firstClickFlag_value: [firstClickFlag, setFirstClickFlag],
        approveDeclineNotification_value: [approveDeclineNotification, setApproveDeclineNotification],
        roles_value: [roles, setRoles],
        apiFailureNotification_value: [apiFailureNotification, setApiFailureNotification],
        hasProfileLoadFailed_value: [hasProfileLoadFailed, setHasProfileLoadFailed],
    };
    return value;
};

export const GlobalContext = React.createContext({});
