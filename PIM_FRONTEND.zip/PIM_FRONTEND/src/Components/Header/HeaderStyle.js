import { makeStyles } from "@material-ui/styles";
import MenuItem from "@material-ui/core/MenuItem";
import { withStyles } from "@material-ui/core/styles";

const drawerWidth = 240;

export const StyledMenuItem = withStyles((theme) => ({
  root: {
    "&:focus": {
      backgroundColor: theme.palette.primary.main,
      "& .MuiListItemIcon-root, & .MuiListItemText-primary": {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);

export const headerStyles = makeStyles((theme) => ({
  toolbarMargin: {},
  tabContainer: {},
  menuicon: {
    width: "30%",
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  logo: {
    width: "10%",
    cursor: "pointer",
  },
  tabs: {
    width: "100%",
  },
  paper: {
    width: 150
  },
  tab: {
    textTransform: "none",
    padding: "0",
  },
  select: {
    padding: "0",
    marginLeft: "15px",
    marginRight: "15px",
    icon: "BusinessIcon",
    color: "White",
  },
  item: {
    color: "Black",
  },
  margin: {
    color: "white",
    marginRight: "30px",
    padding: "auto",
  },
  icon: {
    width: "30px",
  },
  button: {
    background: "transparent",
    padding: "10px",
    marginRight: "30px",
    fontSize: "16px",
    textTransform: "none",
    color: "White",
  },
  heading: {
    fontWeight: "Bold",
    fontSize: "40px",
    lineHeight: "55px",
    color: "#FFFFFF",
    characterSpacing: "0",
    lineSpacing: "0px",
    opacity: "1",
    textAlign: "left",
  },
  privateLabel: {
    textAlign: "left",
    fontSize: "14px",
    lineHeight: "19px",
    letterSpacing: "0px",
    color: "#FF901E",
    textTransform: "uppercase",
    opacity: "1",
  },
  listItem: {
    padding: 0,
    backgroundColor: '#FAFAFA',
    margin: 10,
    borderRadius: 8,
    maxWidth: 365
  },
  listItemTextPrimary: {
    color: '#4D4F5C',
    fontSize: 14
  },
  listItemTextSecondary: {
    color: '#7000FF',
    fontSize: 14
  },
  notifications: {
    maxHeight: '60%',
    maxWidth: '25%'
  },
  notificationTitle: {
    color: '#4D4F5C',
    fontSize: 20
  },
  headerLeftDrawerOpen: {
    marginLeft: 270
  },
  headerLeftDrawerClose: {
    marginLeft: 80
  },
  headerRightDrawerOpen: {
    marginLeft: 450
  },
  headerRightDrawerClose: {
    display: "flex",
    justifyContent: "flex-end"
  },
  laguageMenu: {
    flexGrow: 3,
    justifyContent: "flex-start"
  },
  // selected: {
  //   color: "#7000FF"
  // }
  selected: {
  },
  rootMenuItem: {
    "&$selected": {
      color: "#7000FF",
      background: "#FFFFFF"
      },
    color:'#7A7D8E'
  }
}));

export const toolBarStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  label1: {
    fontWeight: "Regular",
    textAlign: "left",
    fontSize: "16px",
    lineHeight: "27px",
    letterSpacing: "0px",
    opacity: "1",
    textTransform: "none",
    minWidth: "50px",
  },
  label2: {
    fontWeight: "Regular",
    textAlign: "left",
    fontSize: " 16px",
    lineHeight: "27px",
    letterSpacing: "0px",
    opacity: "1",
    textTransform: "none",
    minWidth: "50px",
  },
  indicator: {
    fontWeight: "Regular",
    fontSize: "20px",
    lineHeight: "27px",
    textColor: "#000000",
    lineSpacing: "0px",
    textTransform: "none",
  },
}));
