import React, { useState, useContext } from "react";
import Button from "@material-ui/core/Button";
import { ReactComponent as Brand } from "./../../Asset/brand.svg";
import { ReactComponent as BlueDropdown } from "./../../Asset/blue-dropdown-arrow.svg";
import { headerStyles } from "./HeaderStyle";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import GlobalState from "../../Context/GlobalState";
import { Grid } from "@material-ui/core";
import { StyledMenu } from "../../Utilities/CommonStyle";
import Alert from "@material-ui/lab/Alert";
import { dialogMessage } from "../../Utilities/Constants";

const BrandDropDownInHeader = () => {
  const classes = headerStyles();
  const iconHeight = 22;
  const [anchorElForBrand, setAnchorElForBrand] = useState(null);

  const {
    value1,
    value2,
    value3,
    value5,
    value7,
    value12,
    value29,
    value31,
    value35,
    value36,
    value37,
    value60,
    value77,
    value87,
    value137,
    value140,
    value148,
    value221,
  } = useContext(GlobalState);

  const [, setBrandKey] = value1;
  const [, setPage] = value2;
  const [, setProperties] = value3;
  const [selectedBrandNameInHeader, setSelectedBrandNameInHeader] = value5;
  const [, setShowCategoryProductTable] = value7;
  const [, setCheckedKeyDelete] = value12;
  const [, setFilterBrandCheck] = value29;
  const [, setFilterBrandValue] = value31;
  const [, setSelectedStaticListItemIndex] = value35;
  const [, setCategoryChipData] = value36;
  const [selectedChannelIDForHeader] = value37;
  const [, setShowAllProductTable] = value60;
  const [, setPageNum] = value77;
  const [, setSelectedListItemIndex] = value87;
  const [selectedBrandIdInHeader, setSelectedBrandIdInHeader] = value137;
  const [isMediaTab] = value140;
  const [associatedChannels] = value148;
  const [, setIsProductCheckedInTable] = value221;

  const handleBrandSelect = (key, brandName) => {
    handleBrandDropDownClose()
    setSelectedBrandIdInHeader(key);
    setIsProductCheckedInTable(false);
    setSelectedBrandNameInHeader(brandName);
    setBrandKey(key);
    key === "" ? setShowAllProductTable(true) : setShowAllProductTable(false);

    if (!isMediaTab) {
      setPage(false);
      setProperties(false);
      setShowCategoryProductTable(false);
      setCheckedKeyDelete([]);
      setSelectedStaticListItemIndex();
      setSelectedListItemIndex();
      setCategoryChipData([]);
      setFilterBrandCheck([]);
      setFilterBrandValue([]);
      setPageNum(1);
    }
  };

  const handleBrandDropDownClick = (event) => {
    setAnchorElForBrand(event.currentTarget);
  };

  const handleBrandDropDownClose = () => {
    setAnchorElForBrand(null);
  };

  const getBrandListOfParticularType = (typeOfBrand, brandDetails) => {
    return brandDetails?.filter(
      (brandValue) => brandValue.brandType === typeOfBrand
    );
  };

  const renderBrandAndPL = () => {
    const selectedChannelDetails = associatedChannels
      .map((channel) => channel.channel)
      .filter((channel) => channel.channelId === selectedChannelIDForHeader);

    const brandDetails = selectedChannelDetails[0].supportedBrands;

    const brandList = getBrandListOfParticularType("BRAND", brandDetails);

    const globalPrivateLabelList = getBrandListOfParticularType(
      "GLOBAL_PRIVATE_LABEL",
      brandDetails
    );

    const localPrivateLabelList = getBrandListOfParticularType(
      "LOCAL_PRIVATE_LABEL",
      brandDetails
    );


    //for first time load of this page when selected brand is null, setting All Brands as default selected
    if (
      !selectedBrandIdInHeader ||
      brandDetails?.filter((val) => val.brandId === selectedBrandIdInHeader)
        ?.length === 0
    ) {
      setSelectedBrandIdInHeader("GUID-ABC");
      setSelectedBrandNameInHeader("All Brands");
    }

    return renderBrandAndPLGrid(
      brandList,
      globalPrivateLabelList,
      localPrivateLabelList
    );
  };

  const renderBrandAndPLGrid = (
    brandList,
    globalPrivateLabelList,
    localPrivateLabelList
  ) => {
    return (
      <Grid container style={{ display: "flex" }} style={{ width: "50em" }}>
        {renderBrandAndPLGridItem(brandList, "Brands", true)}
        {renderBrandAndPLGridItem(
          globalPrivateLabelList,
          "Global Private labels",
          false
        )}
        {renderBrandAndPLGridItem(
          localPrivateLabelList,
          "Local Private lables",
          false
        )}
      </Grid>
    );
  };

  const renderAllBrandsMenu = (isBrandList) => {
    return (
      isBrandList && (
        <MenuItem
          key={"GUID-ABC"}
          value={"GUID-ABC"}
          onClick={() => handleBrandSelect("", "All Brands")}
          selected={selectedBrandIdInHeader === "GUID-ABC"}
          classes={{ selected: classes.selected, root: classes.rootMenuItem }}
        >
          {"All Brands"}
        </MenuItem>
      )
    );
  };

  const renderList = (listOfBrand) => listOfBrand?.length > 0 ? renderListOfBrandAndPLMenuItem(listOfBrand) : renderNoBrandAlert()

  const renderListOfBrandAndPLMenuItem = (listOfBrand) => {
    return listOfBrand
      ?.sort((a, b) => a.name[0]?.text?.localeCompare(b.name[0].text))
      ?.map((option) => (
        <MenuItem
          key={option.brandId}
          value={option.brandId}
          onClick={() => handleBrandSelect(option.brandId, option.name[0].text)}
          classes={{ selected: classes.selected, root: classes.rootMenuItem }}
          selected={selectedBrandIdInHeader === option.brandId}
         
        >
          {option.name[0].text}
        </MenuItem>
      ));
  };

  const renderBrandAndPLGridItem = (listOfBrand, columnTitle, isBrandList) => {
    return (
      <Grid item xs={4} style={{padding:"2px"}}>
        <FormHelperText style={{ padding: "1em", textTransform: "uppercase" }}>
          {columnTitle}
        </FormHelperText>
        {renderAllBrandsMenu(isBrandList)}
        {renderList(listOfBrand)}
      </Grid>
    );
  };

  const renderNoBrandAlert = () => {
    return (
      <Alert severity="info" style={{padding:'0px'}}>
      {dialogMessage.NO_DATA_FOUND_MSG}
    </Alert>
    );
  };

  const renderListOfBrandAndPL = () =>
    associatedChannels.length === 0 || !selectedChannelIDForHeader
      ? renderNoBrandAlert()
      : renderBrandAndPL();

  return (
    <>
      <Button
        className={classes.button}
        startIcon={<Brand className={classes.icon} height={iconHeight} />}
        size="large"
        style={{ color: "#7000FF" }}
        endIcon={<BlueDropdown />}
        onClick={(event) => handleBrandDropDownClick(event)}
      >
        {selectedBrandNameInHeader}
      </Button>

      <StyledMenu
        tabIndex={0}
        anchorEl={anchorElForBrand}
        keepMounted
        open={Boolean(anchorElForBrand)}
        onClose={handleBrandDropDownClose}
        arrow
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
      >
        {renderListOfBrandAndPL()}
      </StyledMenu>
    </>
  );
};

export default BrandDropDownInHeader;
