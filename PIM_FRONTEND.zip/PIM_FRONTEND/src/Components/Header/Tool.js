import React, { useContext } from "react";
import PropTypes from "prop-types";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import { Link } from "react-router-dom";
import { toolBarStyles } from "./HeaderStyle";
import GlobalState from "./../../Context/GlobalState";
import userPermission from '../../Utilities/userPermissionHook'

export function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}>
      {value === index && (
        <Box p={3} style={{ paddingLeft: 0 , paddingTop: 0 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

export function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function Tool() {
  const classes = toolBarStyles();
  const {
    value27,
    value29,
    value30,
    value31,
    value32,
    value33,
    value34,
    value36,
    value37,
    value45,
    value46,
    value47,
    value48,
    value49,
    value52,
    value53,
    value51,
    value50,
    value54,
    value69,
    value101,
    value103,
    value104,
    value106,
    value115,
    value140,
    value159,
    value163,
    value181,
    value183,
    value184,
    value185,
    value186,
    value187,
    value188,
    value189
  } = useContext(GlobalState);
  const [, setOpenAddProductPopup] = value27;
  const [, setFilterBrandCheck] = value29;
  const [, setFilterCategoryCheck] = value30;
  const [, setFilterBrandValue] = value31;
  const [, setFilterCategoryValue] = value32;
  const [, setTailoringGroupValue] = value33;
  const [, setSelectedListItemIndex] = value34;
  const [, setCategoryChipData] = value36;
  const [selectedChannelIDForHeader] = value37;
  const [, setChannelGeneralData] = value45;
  const [, setProductsChipAttributes] = value46;
  const [, setCategoryChipAttributes] = value47;
  const [, setChannelChipData] = value48;
  const [, setChannelName] = value49;
  const [, setChannelActive] = value52;
  const [, setChannelIsGlobal] = value53;
  const [, setLanguageListForChannel] = value51;
  const [, setBrandListForChannel] = value50;
  const [, setRootCategoryForChannel] = value54;
  const [, setPublishDateForProduct] = value69;
  const [, setIsTailoringGroupSelected] = value101;
  const [, setConfigurableSupportedItem] = value103;
  const [, setDefaultChildProduct] = value104;
  const [, setSelectedSupportedItems] = value106;
  const [, setSelectedBundleProducts] = value115;
  const [, setIsMediaTab] = value140;
  const [, setOpenAddSimpleProductPopup] = value159;
  const [, setSelectedTreeNodeIndex] = value163;
  const [, setAttributeListForFilterInCreateProduct] = value181;
  const [, setTailoredFilterAttributeValue] = value183;
  const [, setAdditionalFilterList] = value184;
  const [, setNumberOfFilterAvailable] = value185;
  const [, setSelectedAttributeDetailsOfFirstFilter] = value186;
  const [, setSelectedAttributeDetailsOfSecondFilter] = value187;
  const [, setSelectedAttributeIdOfFirstFilter] = value188;
  const [, setSelectedAttributeIdOfSecondFilter] = value189;


  const [role] = userPermission()

  const handleChange = (event, newValue) => {
    setOpenAddProductPopup(false);
    setSelectedTreeNodeIndex();
    setValue(newValue);
    setFilterBrandCheck([]);
    setFilterCategoryCheck([]);
    setFilterCategoryValue([]);
    setFilterBrandValue([]);
    setTailoringGroupValue("");
    setSelectedListItemIndex();
    setCategoryChipData([]);
    setChannelName("");
    setChannelActive(false);
    setChannelIsGlobal(false);
    setLanguageListForChannel([]);
    setBrandListForChannel([]);
    setChannelGeneralData([]);
    setProductsChipAttributes([]);
    setCategoryChipAttributes([]);
    setChannelChipData([]);
    setRootCategoryForChannel("");
    setPublishDateForProduct("");
    setIsTailoringGroupSelected(false);
    setDefaultChildProduct(0);
    setSelectedSupportedItems([]);
    setConfigurableSupportedItem([]);
    setIsMediaTab(false);
    setSelectedBundleProducts([]);
    setOpenAddSimpleProductPopup(false);
    setAttributeListForFilterInCreateProduct([]);
    setTailoredFilterAttributeValue([]);
    setAdditionalFilterList([]);
    setNumberOfFilterAvailable(0);
    setSelectedAttributeDetailsOfFirstFilter([]);
    setSelectedAttributeDetailsOfSecondFilter([]);
    setSelectedAttributeIdOfFirstFilter("");
    setSelectedAttributeIdOfSecondFilter("");
  };

  const [value, setValue] = React.useState(1);

  React.useEffect(() => {
    let path = window.location.pathname;
    if (path === "/") {
      setValue(1);
    } else {
      const parsedValue = Number(localStorage.getItem("value") || 1);
      setValue(parsedValue);
    }
  }, [selectedChannelIDForHeader]);

  React.useEffect(() => {
    localStorage.setItem("value", value);
  }, [value]);

  return (
    <div className={classes.root}>
      <AppBar position="static" color="default">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          className={classes.indicator}
          aria-label="simple tabs example"
        >
          <Tab
            label="Dashboard"
            className={classes.label2}
            style={{
              color: value === 0 ? "black" : "#7A7D8E",
            }}
            {...a11yProps(0)}
            component={Link}
            to="/dashboard"
          />
          <Tab
            label="Products"
            {...a11yProps(1)}
            component={Link}
            to="/products"
            className={classes.label1}
            style={{
              color: value === 1 ? "black" : "#7A7D8E",
            }}
          />
          {/* hiding Release & Publish tab for now */}
          {/* <Tab
            label="Release & Publish"
            {...a11yProps(3)}
            component={Link}
            to="/release"
            className={classes.label1}
            style={{
              color: value === 3 ? "black" : "#7A7D8E",
            }}
          /> */}
          <Tab
            label="Settings"
            {...a11yProps(5)}
            component={Link}
            to="/settings"
            className={classes.label1}
            style={{
              color: value === 2 ? "black" : "#7A7D8E",
            }}
          />
          <Tab
            label="Help"
            {...a11yProps(4)}
            component={Link}
            to="/help"
            className={classes.label1}
            style={{
              color: value === 3 ? "black" : "#7A7D8E",
            }}
          />
          {["systemadmin", "globaluser"].includes(role?.toLowerCase()) &&
            <Tab
              label="User Management"
              {...a11yProps(2)}
              component={Link}
              to="/user"
              className={classes.label1}
              style={{
                color: value === 4 ? "black" : "#7A7D8E",
              }}
            />
          }
        </Tabs>
      </AppBar>
    </div>
  );
}