import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import BrandDropDownInHeader from "../BrandDropDownInHeader";
import { ThemeProvider } from "@material-ui/core/styles";
import theme from "../../../Components/Theme";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";

describe("snapshot test for BrandDropDownInHeader", () => {
  it("matches  snap shot of BrandDropDownInHeader", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ThemeProvider theme={theme}>
        <BrandDropDownInHeader />
        </ThemeProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });
});
