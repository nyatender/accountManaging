import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import { client } from "../../../Components/App";
import { ThemeProvider } from "@material-ui/core/styles";
import theme from "../../../Components/Theme";
import ReusableHeader  from '../ReusableHeader'
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";

describe("snapshot test for reusable header" , () => {
    it("matches  snap shot of reusable header", () => {
        const subject = mount(
            <GlobalContextProvider>
                <ApolloProvider client={client}>

                <ThemeProvider theme={theme}>
                    <ReusableHeader />
                </ThemeProvider>
                </ApolloProvider>

                </GlobalContextProvider>
            
                
        );
        expect(EnzymeToJson(subject)).toMatchSnapshot();
    });
});