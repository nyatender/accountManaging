import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import Tool from "../Tool";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";
import { BrowserRouter } from "react-router-dom";

describe("snapshot test for Tool", () => {
  it("matches  snap shot of Tool", () => {
    const subject = mount(
      <GlobalContextProvider>
        <BrowserRouter>
          <Tool />
        </BrowserRouter>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });
});
