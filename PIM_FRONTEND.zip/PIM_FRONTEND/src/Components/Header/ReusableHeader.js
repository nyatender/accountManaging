import React, { useState, useContext, useEffect } from "react";
import { AppBar, Typography, Divider, List, ListItem, ListItemText, Badge, IconButton } from "@material-ui/core";
import Toolbar from "@material-ui/core/Toolbar";
import clsx from 'clsx'
import Tabs from "@material-ui/core/Tabs";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import Button from "@material-ui/core/Button";
import Cookies from 'js-cookie'
import { ReactComponent as Language } from "./../../Asset/language.svg";
import { ReactComponent as Sales } from "./../../Asset/channel.svg";
import { ReactComponent as Notification } from "./../../Asset/notification.svg";
import { ReactComponent as UserIcon } from "./../../Asset/usericon.svg";
import { ReactComponent as BlueDropdown } from "./../../Asset/blue-dropdown-arrow.svg";
import { headerStyles, StyledMenuItem } from "./HeaderStyle";
import {StyledMenu} from '../../Utilities/CommonStyle'
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import GlobalState from "../../Context/GlobalState";
import authentication from 'react-azure-b2c'
import { ReactAzureAdB2CInitialization,menuProps } from '../../Utilities/Constants'
import { Capitalize } from '../../Utilities/CommonFunctions';
import AlertBox from '../UI/AlertBox'
import { ReactComponent as ValueMissing } from '../../Asset/valuemissing.svg'
import ClearIcon from '@material-ui/icons/Clear';
import SideNavigationBar from '../../Components/SideNavigationBar/SideNavigationBar'
import BrandDropDownInHeader from "./BrandDropDownInHeader";

const ReusableHeader = () => {
  const classes = headerStyles();
  const [value, setValue] = useState(0);
  const [anchorEl, setAnchorEl] = useState(null)

  const iconHeight = 22

  const {
    value3,
    value7,
    value12,
    value17,
    value29,
    value31,
    value37,
    value56,
    value58,
    value60,
    value77,
    value87,
    value108,
    value109,
    value124,
    value139,
    value140,
    value146,
    value147,
    value148,
    value155,
    value190,
    value217,
    value101,
    value34,
    value214,
    value221
  } = useContext(GlobalState);

  const [, setProperties] = value3;
  const [, setShowCategoryProductTable] = value7;
  const [, setCheckedKeyDelete] = value12;
  const [, setClearSelectedRows] = value17;
  const [, setFilterBrandCheck] = value29;
  const [, setFilterBrandValue] = value31;
  const [selectedChannelIDForHeader, setSelectedChannelIDForHeader] = value37;
  const [globalChannelID, setGlobalChannelId] = value56;
  const [selectedLanguageInHeader, setSelectedLanguageInHeader] = value58;
  const [, setShowAllProductTable] = value60;
  const [, setPageNum] = value77;
  const [, setSelectedListItemIndex] = value87;
  const [, setResetAllProductsTable] = value108;
  const [, setResetCategoryTree] = value109;
  const [, setResetPublishingDate] = value124;
  const [, setShowMediaLoader] = value139;
  const [isMediaTab] = value140;
  const [firstName] = value146
  const [lastName] = value147
  const [associatedChannels] = value148
  const [userRole, setUserRole] = value155
  const [notifications, setNotifications] = value190
  const [open] = value217
  const [, setIsTailoringGroupSelected] = value101
  const [, setAttributeGroupSelectedListItemIndex] = value34
  const [, setSelectedNavigationModule] = value214
  const [, setIsProductCheckedInTable] = value221

  useEffect(() => {
    const role = associatedChannels?.filter(({ channel }) => channel.channelId === selectedChannelIDForHeader)[0]?.role
    setUserRole(role)
  }, [selectedChannelIDForHeader])

  const handleChannelChange = (event) => {
    setSelectedNavigationModule('allProducts')
    setIsTailoringGroupSelected(false);
    setAttributeGroupSelectedListItemIndex();
    setSelectedChannelIDForHeader(event.target.value);
    setProperties(false);
    setCheckedKeyDelete([]);
    setResetCategoryTree(true);
    setShowAllProductTable(true);
    setShowCategoryProductTable(false);
    setSelectedListItemIndex();
    setPageNum(1);
    setClearSelectedRows(true);
    setResetAllProductsTable(true);
    setResetPublishingDate(true);
    setFilterBrandCheck([]);
    setFilterBrandValue([]);
    setSelectedLanguageInHeader("");
    setIsProductCheckedInTable(false);
    if (isMediaTab) {
      setShowMediaLoader(true);
      setTimeout(() => {
        setShowMediaLoader(false);
      }, 2000);
    }
  };

  const handleLanguageSelect = (key) => {
    setSelectedLanguageInHeader(key);
    setResetCategoryTree(true);
    setPageNum(1);
    setIsProductCheckedInTable(false);
  };

  function fetchAllChannels() {
    if (associatedChannels?.length === 0) {
      return <MenuItem>No Channel Available</MenuItem>;
    }

    const goodChannels = associatedChannels.map(channel => channel.channel)
      .filter((channel) => channel && channel.name && channel.channelId)
      .sort((a, b) => a.name[0].text.localeCompare(b.name[0].text));

    const globalChannelData = goodChannels.filter(
      (item) => item.isGlobal === true
    );

    setGlobalChannelId(globalChannelData[0]?.channelId);

    //for first time load of this page when selected channel is null
    if (!selectedChannelIDForHeader) {
      //if there is no global channel , then setting up first channel from the list as pre selected one
      setSelectedChannelIDForHeader(
        globalChannelData?.length === 0
          ? goodChannels[0].channelId
          : globalChannelData[0]?.channelId
      );
    }

    return goodChannels.map((option) => (
      <MenuItem key={option.channelId} value={option.channelId} classes={{ selected: classes.selected, root: classes.rootMenuItem }}>
        {option.name[0].text}
      </MenuItem>
    ));
  }

  function fetchAllLanguage() {
    if (associatedChannels?.length === 0) {
      return <MenuItem>No data</MenuItem>;
    }

    if (selectedChannelIDForHeader) {
      const selectedChannelDetails = associatedChannels.map(channel => channel.channel)
        .filter(channel => channel.channelId === selectedChannelIDForHeader)

      const languageOptions = selectedChannelDetails[0].supportedLanguages;
      //for first time load of this page when selected language is null, setting selectedLanguageInHeader as default selected
      if (!selectedLanguageInHeader) {
        setSelectedLanguageInHeader(
          selectedChannelDetails[0].defaultLanguageCode ||
          selectedChannelDetails[0].supportedLanguages[0].languageCode
        );
      }

      return languageOptions
        .sort((a, b) => a.description.localeCompare(b.description))
        .map((option) => (
          <MenuItem
            key={option.languageCode}
            value={option.languageCode}
            classes={{ selected: classes.selected, root: classes.rootMenuItem }}
            onClick={() => handleLanguageSelect(option.languageCode)}
          >
            {option.description}
          </MenuItem>
        ));
    }

    return (
      <MenuItem key={"no-language"} value={"no-language"}>
        {"No Languages"}
      </MenuItem>
    );
  }

  const handleClick = (event) => {
    setValue(event.currentTarget);
  };

  const handleClose = (event) => {
    setValue(0);
  };

  const openMenu = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const closeMenu = () => {
    setAnchorEl(false)
  }

  authentication.initialize(ReactAzureAdB2CInitialization)

  const handleLogout = () => {
    setAnchorEl(false)
    Cookies.remove('token')
    authentication.signOut()
  }

  const channelList = fetchAllChannels();

  const deleteNotification = (notificationId) => {
    const notificationsCopy = [...notifications]
    setNotifications(notificationsCopy.filter(notification => notification.notificationId !== notificationId))
  }

  return (
    <>
      <AppBar style={{ position: "fixed", backgroundColor: "white",justifyContent: "flex-end",display: 'flex', flexDirection: 'row'}} variant={'outlined'} >
        <Toolbar style={{ width: '100%' }}>
          <div className={classes.tabs}>
            <Tabs className={classes.tabContainer}>
              <Button
                //className={classes.button}
                className={clsx({
                  [classes.button]: true,
                  [classes.headerLeftDrawerOpen]: open,
                  [classes.headerLeftDrawerClose]: !open
                })}
                startIcon={<Sales className={classes.icon} height={iconHeight} />}
                size="large"
              >
                <Select
                  value={selectedChannelIDForHeader || globalChannelID}
                  //displayEmpty={true}
                  id="grouped-select"
                  disableUnderline
                  style={{ color: "#7000FF" }}
                  IconComponent={BlueDropdown}
                  onChange={handleChannelChange}
                  MenuProps={menuProps}
                >
                  {channelList}
                </Select>
              </Button>

              <BrandDropDownInHeader/>
              

              <Button
                className={`${classes.button} ${classes.laguageMenu}`}
                startIcon={<Language className={classes.icon} height={iconHeight} />}
                size="large"
              >
                <Select
                  value={selectedLanguageInHeader}
                  id="grouped-select"
                  disableUnderline
                  style={{ color: "#7000FF", width: "10em" }}
                  IconComponent={BlueDropdown}
                  MenuProps={menuProps}
                >
                  {fetchAllLanguage()}
                </Select>
              </Button>


              <IconButton
                aria-label="notification"
                className={classes.headerRightDrawerClose}
                // className={clsx({
                //   [classes.margin]: true,
                //   [classes.headerRightDrawerOpen]: open,
                //   [classes.headerRightDrawerClose]: !open
                // })}
                size="medium"
                onClick={handleClick}
                value={value}
              >
                <Badge color="error" anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }} variant="dot" overlap={'circle'} invisible={!notifications || notifications.length === 0}>
                  <Notification fontSize="inherit" className={classes.icon} height={iconHeight} />
                </Badge>
              </IconButton>
              <StyledMenu
                id="customized-menu"
                anchorEl={value}
                keepMounted
                open={Boolean(value)}
                onClose={handleClose}
                classes={{ paper: classes.notifications }}
                style={{ left: -60 }}
              >
                <List disablePadding>
                  {(notifications && notifications.length > 0) ?
                    <>
                      <ListItem style={{ padding: '10px 20px' }}>
                        <ListItemText secondary={'Notifications'} classes={{ secondary: classes.notificationTitle }} />
                      </ListItem>
                      <Divider />
                    </> :
                    <ListItem style={{ padding: '10px 0px' }}>
                      <AlertBox
                        message="No Notifications"
                        severity="info"
                      />
                    </ListItem>
                  }
                  {notifications.map((notification, index) => (
                    <>
                      <ListItem className={classes.listItem}>
                        <ValueMissing height='25px' />
                        <ListItemText
                          primary={notification.message}
                          secondary={`Product SKU - ${notification.sku}`}
                          classes={{ primary: classes.listItemTextPrimary, secondary: classes.listItemTextSecondary }}
                        />
                        <IconButton onClick={() => deleteNotification(notification.notificationId)}><ClearIcon fontSize={'small'} /></IconButton>
                      </ListItem>
                    </>
                  ))}
                </List>
              </StyledMenu>

              <Button
                className={classes.button}
                startIcon={<UserIcon src="/broken-image.jpg" height={30} />}
                endIcon={<ArrowDropDownIcon style={{ color: 'blue' }} />}
                size="large"
                onClick={openMenu}
              >
                <Typography>
                  <div style={{ color: '#7000FF' }}>{Capitalize(firstName)} {Capitalize(lastName)}</div>
                  <div style={{ fontSize: 'small', color: '#7000FF' }}>{userRole?.name}</div>
                </Typography>
              </Button>
              <StyledMenu
                id="customized-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={closeMenu}
                classes={{ paper: classes.paper }}
              >
                <StyledMenuItem onClick={handleLogout}>
                  <ListItemText primary="Logout" />
                </StyledMenuItem>
              </StyledMenu>
            </Tabs>
          </div>
        </Toolbar>
      </AppBar>
      <SideNavigationBar />
      <div className={classes.toolbarMargin} />
    </>
  );
}

export default ReusableHeader;
