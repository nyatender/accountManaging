import React from "react";
import Alert from "@material-ui/lab/Alert";

const Help = () => {
  return (
    <>
      <Alert severity="info" style={{ fontWeight: "bold" }}>
        If you need help with PROCAT or experiencing any technical issues,
        please write to{" "}
        <a href="mailto:support.procat@wsa.com" target="_top">
          support.procat@wsa.com
        </a>
      </Alert>
    </>
  );
};

export default Help;
