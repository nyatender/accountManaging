import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import { client } from "../App";
import Help from './Help'

describe("Help snapshot test " , () => {
    it("matches ItemAttributes snap shot", () => {
        const subject = mount(
            <ApolloProvider client ={client}>
                <Help />
            </ApolloProvider>
        );
        expect(EnzymeToJson(subject)).toMatchSnapshot();
    });
});