import React from "react";
import memoize from "memoize-one";
import Item from "./../../Asset/single-item.svg";
import NoPic from "./../../Asset/Image-indicator.svg";
import UnfoldMoreIcon from "@material-ui/icons/UnfoldMore";
import Product from "./../../Asset/products.svg";
import Bundle from "./../../Asset/bundle.svg";
import DeletePopup from "./DeletePopup";
import DeleteSinglePopup from "./DeleteSingleProductPopup";
import TableMenu from "./TableMenu";
import Tooltip from "@material-ui/core/Tooltip";
import {
  convertUTCToLocal,
  productStatus,
} from "../../Utilities/CommonFunctions";
import ProductPublishStatus from "./PublishAndAvailableFeatureInTable";

export const sortIcon = <UnfoldMoreIcon />;
export const selectProps = {
  indeterminate: (isIndeterminate) => isIndeterminate,
  color: "primary",
};

export const contextActions = memoize((showMove) => (
  <>
    <DeletePopup />
    <TableMenu showMove={showMove} />
  </>
));
export function Title() {
  return (
    <>
      <h3
        style={{
          textAlign: "left",
          fontSize: "18px",
          lineHeight: "52px",
          fontWeight: "Regular",
          letterSpacing: "0px",
          color: "#7A7D8E",
          textTransform: "uppercase",
          opacity: "1",
          width: "40%",
          display: "inline-block",
          marginBottom: "2em",
        }}
      >
        All Products
      </h3>
    </>
  );
}

export const columnName = (name) => (
  <h4
    style={{
      textAlign: "left",
      fontSize: "15px",
      lineHeight: "20px",
      letterSpacing: "0px",
      color: "#BFBFBF",
      textTransform: "uppercase",
      opacity: "1",
    }}
  >
    {name}
  </h4>
);

export const getProductType = (row) => {
  if (row.productType === "PRODUCT_VARIANT") {
    return (
      <Tooltip title="Product Variant" placement="top">
        <img
          style={{ background: "transparent", opacity: "1" }}
          height="20px"
          width="30px"
          alt={row.sku}
          src={Item}
        />
      </Tooltip>
    );
  } else if (row.productType === "PRODUCT") {
    return (
      <Tooltip title="Product" placement="top">
        <img
          style={{ background: "transparent", opacity: "1" }}
          height="23px"
          width="35px"
          alt={row.sku}
          src={Product}
        />
      </Tooltip>
    );
  } else if (row.productType === "BUNDLE") {
    return (
      <Tooltip title="Bundle" placement="top">
        <img
          style={{ background: "transparent", opacity: "1" }}
          height="23px"
          width="35px"
          alt={row.sku}
          src={Bundle}
        />
      </Tooltip>
    );
  }
};

export const getProductStatus = (releaseDate, phaseOutDate) => {
  const status = productStatus(
    convertUTCToLocal(releaseDate),
    convertUTCToLocal(phaseOutDate)
  );
  if (["released", "nearingPhasedOut"].includes(status)) return "Released";
  else if (["phasedOut"].includes(status)) return "Phased out";
  else return "Created";
};

export const getProductName = (data) => {
  return data.productName ? (
    <Tooltip title={data.productName[0]?.text} placement="top">
      <div
        data-tag="allowRowEvents"
        style={{ zIndex: 0 }}
        onClick={(e) => e.persist()}
      >
        {data.productName[0]?.text}
      </div>
    </Tooltip>
  ) : (
    <div> ---- </div>
  );
};

export const columns = memoize(() => [
  {
    name: columnName("image"),
    grow: 0,
    selector: "posterUrl",
    cell: (row) => (
      <div style={{ paddingTop: "10px", paddingBottom: "10px" }}>
        <img
          style={{
            background: "transparent",
            opacity: "1",
            padding: "5px",
            border: "1px solid #EBE9E7",
          }}
          height="44px"
          width="40px"
          alt="no pic"
          src={NoPic}
        />
      </div>
    ),
  },

  {
    name: columnName("type"),
    selector: "type",
    style: {
      letterSpacing: "0px",
      opacity: "1",
      color: "#BFBFBF",
      font: "normal normal normal 16px/52px Noto Sans",
    },
    cell: (row) => (
      <div
        style={{ paddingTop: "10px", paddingBottom: "10px" }}
        id={row.productType}
      >
        {getProductType(row)}
      </div>
    ),
  },
  {
    name: columnName("SKU"),
    selector: "sku",
    style: {
      letterSpacing: "0px",
      color: "#7000FF",
      opacity: "1",
      fontSize: "14px",
      lineHeight: "52px",
      cursor: "pointer"
    },
    sortable: true,
    grow: 2,
  },
  {
    name: columnName("name"),
    //selector: "productName",
    style: {
      letterSpacing: "0px",
      color: "#7000FF",
      opacity: "1",
      fontSize: "14px",
      lineHeight: "20px",
      cursor: "pointer"
    },
    sortable: true,
    grow: 2,
    cell: (row) => (
      <div
        data-tag="allowRowEvents"
        style={{
          overflow: "hidden",
          display: "-webkit-box",
          WebkitBoxOrient: "vertical",
          WebkitLineClamp: 2,
        }}
      >
        {getProductName(row)}
      </div>
    ),
  },
  {
    name: columnName("status"),
    style: {
      letterSpacing: "0px",
      color: "#7000FF",
      opacity: "1",
      fontSize: "14px",
      lineHeight: "20px",
    },
    sortable: true,
    grow: 2,
    cell: (row) => (
      <div
        data-tag="allowRowEvents"
        style={{
          overflow: "hidden",
          display: "-webkit-box",
          WebkitBoxOrient: "vertical",
          WebkitLineClamp: 2,
        }}
      >
        {getProductStatus(row.publishedDate, row.phaseOutDate)}
      </div>
    ),
  },
  {
    name: columnName("action"),
    cell: (row) => (
      <div style={{ display: "flex" }}>
        <ProductPublishStatus row={row} />
        <DeleteSinglePopup row={row} />
      </div>
    ),
    button: true,
  },
]);
