import React, { useContext } from "react";
import IconButton from "@material-ui/core/IconButton";
import MenuItem from "@material-ui/core/MenuItem";
import { StyledMenu } from "../../Utilities/CommonStyle";
import { ReactComponent as More } from "./../../Asset/more.svg";
import { tableMenuStyles } from "./CategoryStyles";
import GlobalState from "../../Context/GlobalState";
import MovePopup from "./ProductMoveAndAssociate/MovePopup";
import AssociatePopup from "./ProductMoveAndAssociate/AssociatePopup";
import RelatePopup from "./ProductRelations/RelatePopup";
import AssociateCustomerGroupPopup from "./ProductMoveAndAssociate/AssociateCustomerGroupsPopup";
import { Paper } from "@material-ui/core";
import PublishProductFeature from "../Tailoring/ProductPublish/PublishProductFeature";

export default function TableMenu({ showMove }) {
  const classes = tableMenuStyles();

  const [anchorEl, setAnchorEl] = React.useState(null);
  const {
    value14,
    value15,
    value16,
    value18,
    value37,
    value56,
    value80,
    value131,
    value179,
  } = useContext(GlobalState);
  const [, setOpenMovePopup] = value14;
  const [, setOpenAssociatePopup] = value15;
  const [selectedRows] = value16;
  const [, setCheckBoxForCard] = value18;
  const [selectedChannelIDForHeader] = value37;
  const [globalChannelID] = value56;
  const [, setOpenAddRelationPopup] = value80;
  const [, setOpenAssociateCustomerGroupsPopup] = value131;
  const [, setIsPublishDialogOpen] = value179;

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleMovePopup = () => {
    setOpenMovePopup(true);
    selectedRows.map((item) => {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
      return null;
    });
    setAnchorEl(null);
  };
  const handleAssociatePopup = () => {
    setOpenAssociatePopup(true);
    selectedRows.map((item) => {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
      return null;
    });
    setAnchorEl(null);
  };

  const handleRelationPopup = () => {
    setOpenAddRelationPopup(true);
    selectedRows.map((item) => {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
      return null;
    });
    setAnchorEl(null);
  };

  const handleCustomerGroupPopup = () => {
    setOpenAssociateCustomerGroupsPopup(true);
    selectedRows.map((item) => {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
      return null;
    });
    setAnchorEl(null);
  };

  const handlePublishProductPopup = () => {
    setIsPublishDialogOpen(true);
    setAnchorEl(null);
  };

  return (
    <>
      <div>
        <IconButton
          variant="contained"
          color="primary"
          size="small"
          onClick={handleClick}
        >
          <More width="28px" />
        </IconButton>
        <StyledMenu
          id="simple-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
          arrow
        >
          {showMove === true ? (
            <MenuItem onClick={handleMovePopup} className={classes.title}>
              Move To
            </MenuItem>
          ) : null}
          <MenuItem onClick={handleRelationPopup} className={classes.title}>
            Relate Products
          </MenuItem>
          <MenuItem onClick={handleAssociatePopup} className={classes.title}>
            Associate to Categories
          </MenuItem>
          {selectedChannelIDForHeader !== globalChannelID && (
            <MenuItem
              onClick={handleCustomerGroupPopup}
              className={classes.title}
            >
              Associate to customer groups
            </MenuItem>
          )}
          {selectedChannelIDForHeader === globalChannelID && (
            <MenuItem
              onClick={handlePublishProductPopup}
              className={classes.title}
            >
              Publish Product
            </MenuItem>
          )}
        </StyledMenu>
      </div>
      <Paper>
        <MovePopup />
        <AssociatePopup />
        <RelatePopup />
        <AssociateCustomerGroupPopup />
        <PublishProductFeature isTailoringPage={false} />
      </Paper>
    </>
  );
}
