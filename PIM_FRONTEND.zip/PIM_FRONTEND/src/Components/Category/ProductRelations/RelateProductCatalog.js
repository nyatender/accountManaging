import React, { useState, useContext } from "react";
import IconButton from "@material-ui/core/IconButton";
import { relateProductCatalogStyle } from "./ProductRelationStyles";
import {
  Divider,
  FormLabel,
  Grid,
  Tooltip,
} from "@material-ui/core";
import CategoryTreeView from "./ProductTreeView";
import ProductView from "./ProductListView";
import { ReactComponent as Back } from "../../../Asset/back-icon.svg";
import { Link } from "react-router-dom";
import { GET_PRODUCTS_BY_CATEGORY } from "../../Query";
import { useQuery } from "@apollo/react-hooks";
import GlobalState from "../../../Context/GlobalState";
import { SearchBoxStyle } from "./../CategoryStyles";
import Search from "./../../UI/Search";
import RelateProductCategoryTreeSearch from "./RelateProductCategoryTreeSearch"

function RelateProductCatalog() {
  const classesSearchBox = SearchBoxStyle();
  const { value80, value88, value89, value90, value58 } = useContext(GlobalState);
  const classes = relateProductCatalogStyle();
  const [showProducts, setShowProducts] = useState(false);
  const [relateCategoryTreeData, setRelateCategoryTreeData] = useState([]);
  const [clickedCategoryID, setClickedCategoryID] = useState(
    "7b4c6ffc-ff2b-11ea-a693-0242ac110002"
  );
  const [categoryName, setCategoryName] = useState("");
  const [searchVariable, setSearchVariable] = useState("");
  const [searchResult, setSearchResult] = useState([]);

  const [openAddRelationPopup] = value80;
  const [selectedCategoryList, setSelectedCategoryList] = value88;
  const [, setCheckedCategoryList] = value89;
  const [checkedCategory, setCheckedCategory] = value90;
  const [selectedLanguageInHeader] = value58;

  const handleListDisplay = (val, categoryID) => {
    setShowProducts(val);
    setClickedCategoryID(categoryID);
    if (selectedCategoryList.includes(categoryID)) {
      setCheckedCategory(true);
    } else {
      setCheckedCategory(false);
    }
  };

  const { loading, error, data } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: {
      categoryId: clickedCategoryID,
      channelFilter: {
        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        languageCode: selectedLanguageInHeader,
      },
      skip: clickedCategoryID === "" || !openAddRelationPopup || !showProducts,
    },
  });
  const handleClearSearch = () => {
    setSearchVariable("");
    setSelectedCategoryList([]);
    setCheckedCategoryList([]);
  };
  const handleSearchBoxChange = (event) => {
    setSearchVariable(event.target.value);
    const results = relateCategoryTreeData.filter(
      (category) =>
        category.state !== "DELETED" &&
        category.name !== null &&
        category.isActive === true &&
        category.name[0]?.text !== null &&
        category?.name[0]?.text
          .toLowerCase()
          .includes(event.target.value.toLowerCase())
    );
    setSearchResult(results);
  };

  const renderCategoryData = () =>
  searchVariable.trim() !== "" ? (
    <RelateProductCategoryTreeSearch 
    searchResultData={searchResult}
    setClickedCategoryID={setClickedCategoryID}
    setShowProducts={setShowProducts}
    setCategoryName={setCategoryName} 
    setSearchVariable={setSearchVariable}
    
    />
  ) : (
    <CategoryTreeView
    setClickedCategoryID={setClickedCategoryID}
    setShowProducts={setShowProducts}
    setCategoryName={setCategoryName}
    setCategoryTreeData={setRelateCategoryTreeData}
  />
  );

  return (
    <Grid container justify="center" direction="column">
      <Grid item xs={12} className={classesSearchBox.searchGrid}>
        <div>
          <Search
            className={classesSearchBox.searchBox}
            searchTerm={searchVariable}
            handleSearch={handleSearchBoxChange}
            handleClearSearch={handleClearSearch}
            disabled={showProducts}
            width={"100%"}
          />
        </div>
      </Grid>
      <Divider orientation="horizontal" />
      <Grid item xs={12} className={classes.flexColScroll}>
        {showProducts === true ? (
          <div>
            <Tooltip title="Back to Category tree">
              <IconButton
                component={Link}
                to="/products"
                onClick={() => {
                  handleListDisplay(false, clickedCategoryID);
                }}
              >
                <Back width="18px" />
              </IconButton>
            </Tooltip>
            <FormLabel style={{ fontSize: "16px", fontWeight: "bold" }}>
              {categoryName}
            </FormLabel>
          </div>
        ) : (
          <div></div>
        )}

        {showProducts === false ? renderCategoryData() : (
          <ProductView
            loading={loading}
            error={error}
            data={data}
            selectAll={checkedCategory}
          />
        )}
      </Grid>
    </Grid>
  );
}

export default RelateProductCatalog;
