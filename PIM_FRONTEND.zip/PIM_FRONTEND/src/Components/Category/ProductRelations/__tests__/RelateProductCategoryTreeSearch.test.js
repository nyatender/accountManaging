import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import RelateProductCategoryTreeSearch from "../RelateProductCategoryTreeSearch";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"
import { act } from "react-dom/test-utils";
import {
  Checkbox,
  ListItemText,
  ListItem
} from "@material-ui/core";
const props = {
  searchResultData: [
    {
      channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
      extendedTailoringAttributes: [],
      id: "ad6b1db4-c11e-4a80-9a0d-b6742b9941cd",
      isActive: true,
      name: [
        {text: "A_Root__Category", __typename: "TextTranslationOutput"}
      ],
      parentCategoryId: null,
      state: "UPDATED",
      supportedAttributes: [],
      tailoringAttributes: [],
      totalSupportedAttributes: [],
      updatedAt: "2021-08-25T04:33:32.1314002Z",
      __typename: "CategorySchema"
    },
    {
      channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
      extendedTailoringAttributes: null,
      id: "6eddeeeb-7a7e-4d4f-965c-5a2625adb0c0",
      isActive: true,
      name: [{text: "A_Root_Category_101", __typename: "TextTranslationOutput"}],
      parentCategoryId: null,
      state: "UPDATED",
      supportedAttributes: [],
      tailoringAttributes: [],
      totalSupportedAttributes: [],
      updatedAt: "2021-08-20T07:39:22.117449Z"
    }
  ],
  setClickedCategoryID: jest.fn(),
  setShowProducts:jest.fn(),
  setCategoryName:jest.fn(),
  setSearchVariable:jest.fn()
}
describe("RelateProductCategoryTreeSearch Component ", () => {
  it("matches RelateProductCategoryTreeSearch snap shot", () => {
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <RelateProductCategoryTreeSearch />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  describe("Unit tests - RelateProductCategoryTreeSearch", ()=>{
    let wrapper;
    beforeEach(()=> {
      act(()=>{
        wrapper = mount(
          <GlobalContextProvider>
          <ApolloProvider client={client}>
            <RelateProductCategoryTreeSearch {...props} />
          </ApolloProvider>
          </GlobalContextProvider>
        );
      })
    })

    it("should render category lists without crashing", ()=>{
      expect(wrapper.find(ListItem).length).toBeGreaterThan(0);
    })
  
    it("should category checkboxes work properly", ()=>{
      let checkbox = wrapper.find(Checkbox).first();
      act(()=>{
        checkbox.props().onChange({target:{checked:true}})
      })
      wrapper.update();
      expect(wrapper.find(Checkbox).first().props().checked).toBeTruthy();
      
      act(()=>{
        wrapper.find(Checkbox).first().props().onChange({target:{checked:false}})
      })
      wrapper.update();
      expect(wrapper.find(Checkbox).first().props().checked).not.toBeTruthy();
    })
  
    it("ListItemText component should be clickable", ()=>{
      let listItemText = wrapper.find(ListItemText).first();
      act(()=>{
        listItemText.props().onClick()
      })
      wrapper.update();
      expect(props.setCategoryName).toHaveBeenCalled();
    })
  })
});
