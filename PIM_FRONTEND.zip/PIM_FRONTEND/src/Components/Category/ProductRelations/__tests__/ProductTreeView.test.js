import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import ProductTreeView from "../ProductTreeView";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import { MockedProvider, wait } from "@apollo/react-testing";
import { context, response } from "../__mocks__/ProductTreeView_mocks";
import Spinner from "../../../UI/Spinner";
import { act } from "react-dom/test-utils";

const props = {
  setCategoryName: jest.fn(),
  setCategoryTreeData: jest.fn(),
  setClickedCategoryID: jest.fn(),
  setShowProducts: jest.fn()
}
describe("ProductTreeView Component ", () => {
  it("matches ProductTreeView snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <ProductTreeView />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

  it("Should render Spinner while loading categories", ()=>{
    let wrapper;
    act(()=>{
        wrapper = mount(<GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
              <ProductTreeView {...props} />
          </MockedProvider>
        </GlobalContextProvider>);
    })
    expect(wrapper.find(Spinner).exists()).toBeTruthy();
  })

  it("Should render AlertBox with error message when loading fails", async ()=>{
    let wrapper;
    act(()=>{
        wrapper = mount(<GlobalContextProvider mockData={context}>
          <MockedProvider mocks={[]} addTypename={false}>
              <ProductTreeView {...props} />
          </MockedProvider>
        </GlobalContextProvider>);
    })
    await act(()=> wait(500));
    expect(wrapper.text()).toBe("Error occurred while loading category tree");
  })
});
