import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import ProductListView from "../ProductListView";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import Spinner from "../../../UI/Spinner";
import AlertBox from "../../../UI/AlertBox";
import ListItem from "@material-ui/core/ListItem";
import Checkbox from "@material-ui/core/Checkbox";
import { act } from "react-dom/test-utils";

const mockProps = {
  data: {
    product: {
      getProductsByCategory: [
        {
          categoryId: "ad6b1db4-c11e-4a80-9a0d-b6742b9941cd",
          channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
          createdAt: "2021-07-15T10:40:54.078619",
          isAvailable: false,
          isPublished: false,
          parentProductId: null,
          phaseOutDate: null,
          productId: "ef53fe37-1ae6-46fe-9415-2367f9067c67",
          productName: [
            {
              languageCode: "en_GB",
              text: "Testprodyc346",
              __typename: "TextTranslationOutput",
            },
          ],
          productSource: "PIM",
          productType: "PRODUCT_VARIANT",
          publishedDate: "2021-07-16T10:50:00",
          ranking: 2,
          sku: "Testprodyc346",
          state: "UPDATED",
          __typename: "ProductSchema",
        },
        {
          categoryId: "ad6b1db4-c11e-4a80-9a0d-b6742b9941cd",
          channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
          createdAt: "2021-07-29T17:54:02.07883",
          isAvailable: false,
          isPublished: false,
          parentProductId: null,
          phaseOutDate: null,
          productId: "f98abf89-39e6-46e9-b6e8-dbe22cf3a0e4",
          productName: [
            {
              languageCode: "en_GB",
              text: "Default",
              __typename: "TextTranslationOutput",
            },
          ],
          productSource: "PIM",
          productType: "PRODUCT",
          publishedDate: "0001-01-01T00:00:00",
          ranking: 1,
          sku: "Config-Default",
          state: "UPDATED",
          __typename: "ProductSchema",
        },
      ],
      __typename: "ProductQuery",
    },
  },
  error: undefined,
  loading: false,
  selectAll: false,
};

describe("ProductListView Component ", () => {
  it("matches ProductListView snap shot", () => {
    const props = {
      data: [],
    };
    const wrapper = mount(
      <GlobalContextProvider>
        <ApolloProvider client={client}>
          <ProductListView props={props} />
        </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it("should render spinner while loading product list", () => {
    const props = {
      loading: true,
    };
    const wrapper = mount(
      <GlobalContextProvider>
        <ApolloProvider client={client}>
          <ProductListView {...props} />
        </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(wrapper.find(Spinner).text()).toBe("Loading Product List...");
  });

  it("should render Alert error message when loading product list failed", () => {
    const props = {
      error: new Error("Error occured"),
    };
    const wrapper = mount(
      <GlobalContextProvider>
        <ApolloProvider client={client}>
          <ProductListView {...props} />
        </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(wrapper.find(AlertBox).text()).toBe(
      "Error occurred while loading products!!"
    );
  });

  it("should render list of product categories without crashing", () => {
    let props = { ...mockProps, selectAll: true };
    const wrapper = mount(
      <GlobalContextProvider>
        <ApolloProvider client={client}>
          <ProductListView {...props} />
        </ApolloProvider>
      </GlobalContextProvider>
    );
    let listItem = wrapper.find(ListItem).first();
    expect(listItem.exists()).toBeTruthy();
  });

  it("should checkbox component work properly", async () => {
    let props = { ...mockProps, selectAll: false };
    let wrapper;

    await act(async () => {
      wrapper = mount(
        <GlobalContextProvider>
          <ApolloProvider client={client}>
            <ProductListView {...props} />
          </ApolloProvider>
        </GlobalContextProvider>
      );
    });
    act(() => {
      wrapper
        .find(Checkbox)
        .first()
        .props()
        .onChange({ target: { checked: false } });
    });
    wrapper.update();
    expect(wrapper.find(Checkbox).first().props().checked).not.toBeTruthy();

    let checkbox = wrapper.find(Checkbox).first();

    act(() => {
      checkbox.props().onChange({ target: { checked: true } });
    });
    wrapper.update();
    expect(wrapper.find(Checkbox).first().props().checked).toBeTruthy();
  });
});
