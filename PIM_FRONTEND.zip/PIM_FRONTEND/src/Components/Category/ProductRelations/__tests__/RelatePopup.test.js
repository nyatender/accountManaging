import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import RelatePopup from "../RelatePopup";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"

describe("RelatePopup Component ", () => {
  it("matches RelatePopup snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <RelatePopup />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
