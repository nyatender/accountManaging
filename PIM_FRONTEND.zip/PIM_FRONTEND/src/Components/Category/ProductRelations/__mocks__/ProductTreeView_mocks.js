import { GET_CATEGORY_TREE } from "../../../Query";

module.exports = {
    context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
    },
    response: [
        {
            request: {
                query: GET_CATEGORY_TREE,
                variables: {
                    channelFilter: {channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21", languageCode: "en_GB"},
                    includeCategoryDetails: true
                }
            },
            result: JSON.parse(`{
                "data": {
                    "category": {
                        "getCategoryTreeByRootCategoryId": [
                            {
                                "id": "6eddeeeb-7a7e-4d4f-965c-5a2625adb0c0",
                                "isActive": true,
                                "parentCategoryId": null,
                                "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                                "name": [
                                  {
                                    "text": "A_Root_Category_101",
                                    "__typename": "TextTranslationOutput"
                                  }
                                ],
                                "supportedAttributes": [],
                                "totalSupportedAttributes": [
                                  {
                                    "attributeId": "5b3f3cf6-81ff-47c5-952f-200d85e09e47",
                                    "name": [
                                      {
                                        "text": "FamilyId",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "3029cf13-64e0-4adb-851c-f01f3ae6e66a",
                                    "name": [
                                      {
                                        "text": "Plm Id",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "6a3ce0b2-828c-4c4e-9f9c-207d9909d7bf",
                                    "name": [
                                      {
                                        "text": "testcategoryAttr",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "d56a42fe-aff0-48f6-84de-828d260f8a5c",
                                    "name": [
                                      {
                                        "text": "proCat Multiselect",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "e84f6a5d-26fd-4c7e-aa7d-a8ed074e4df0",
                                    "name": [
                                      {
                                        "text": "CatDesc",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "c3d7df4d-6dc8-4b41-b22a-04fc3e183b37",
                                    "name": [
                                      {
                                        "text": "TextFieldDemo",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "adb2ed1a-63dd-4a08-8431-a38d5711c7c8",
                                    "name": [
                                      {
                                        "text": "checkingAttr",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "name": [
                                      {
                                        "text": "1mandatory attribute text",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "723f53bc-81f4-4343-b475-a7d2ed5f8d00",
                                    "name": [
                                      {
                                        "text": "Category Type",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  }
                                ],
                                "extendedTailoringAttributes": null,
                                "tailoringAttributes": [
                                  {
                                    "attributeId": "e84f6a5d-26fd-4c7e-aa7d-a8ed074e4df0",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_AREA",
                                    "pricevalue": 0,
                                    "textBoxData": [],
                                    "__typename": "TailoringAttributeOutputType"
                                  },
                                  {
                                    "attributeId": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_FIELD",
                                    "pricevalue": 0,
                                    "textBoxData": [
                                      {
                                        "languageCode": "de_DE",
                                        "text": "Testing-Text-10",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "TailoringAttributeOutputType"
                                  }
                                ],
                                "state": "UPDATED",
                                "updatedAt": "2021-08-20T07:39:22.117449Z",
                                "__typename": "CategorySchema"
                              },
                              {
                                "id": "ad6b1db4-c11e-4a80-9a0d-b6742b9941cd",
                                "isActive": true,
                                "parentCategoryId": null,
                                "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                                "name": [
                                  {
                                    "text": "A_Root__Category",
                                    "__typename": "TextTranslationOutput"
                                  }
                                ],
                                "supportedAttributes": [
                                  {
                                    "id": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "__typename": "SupportedAttributeOutputType"
                                  }
                                ],
                                "totalSupportedAttributes": [
                                  {
                                    "attributeId": "5b3f3cf6-81ff-47c5-952f-200d85e09e47",
                                    "name": [
                                      {
                                        "text": "FamilyId",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "3029cf13-64e0-4adb-851c-f01f3ae6e66a",
                                    "name": [
                                      {
                                        "text": "Plm Id",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "6a3ce0b2-828c-4c4e-9f9c-207d9909d7bf",
                                    "name": [
                                      {
                                        "text": "testcategoryAttr",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "d56a42fe-aff0-48f6-84de-828d260f8a5c",
                                    "name": [
                                      {
                                        "text": "proCat Multiselect",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "e84f6a5d-26fd-4c7e-aa7d-a8ed074e4df0",
                                    "name": [
                                      {
                                        "text": "CatDesc",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "c3d7df4d-6dc8-4b41-b22a-04fc3e183b37",
                                    "name": [
                                      {
                                        "text": "TextFieldDemo",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "adb2ed1a-63dd-4a08-8431-a38d5711c7c8",
                                    "name": [
                                      {
                                        "text": "checkingAttr",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "name": [
                                      {
                                        "text": "1mandatory attribute text",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  },
                                  {
                                    "attributeId": "723f53bc-81f4-4343-b475-a7d2ed5f8d00",
                                    "name": [
                                      {
                                        "text": "Category Type",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "AttributeOutputType"
                                  }
                                ],
                                "extendedTailoringAttributes": [
                                  {
                                    "attributeId": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_FIELD",
                                    "pricevalue": 0,
                                    "textBoxData": [
                                      {
                                        "languageCode": "en_GB",
                                        "text": "Test",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "ExtendedTailoringAttributeOutputType"
                                  }
                                ],
                                "tailoringAttributes": [
                                  {
                                    "attributeId": "183de429-bd8d-431d-ab34-632fc06d4022",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_FIELD",
                                    "pricevalue": 0,
                                    "textBoxData": [
                                      {
                                        "languageCode": "en_GB",
                                        "text": "Test",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "TailoringAttributeOutputType"
                                  },
                                  {
                                    "attributeId": "ef70c34e-ff74-4dfe-adc8-31ef10d1848f",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_FIELD",
                                    "pricevalue": 0,
                                    "textBoxData": [
                                      {
                                        "languageCode": "en_GB",
                                        "text": "category",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "TailoringAttributeOutputType"
                                  },
                                  {
                                    "attributeId": "3029cf13-64e0-4adb-851c-f01f3ae6e66a",
                                    "dropdownvalue": null,
                                    "checkBoxListvalue": null,
                                    "dateTimevalue": "0001-01-01T00:00:00",
                                    "imageURL": null,
                                    "inputControl": "TEXT_FIELD",
                                    "pricevalue": 0,
                                    "textBoxData": [
                                      {
                                        "languageCode": "en_GB",
                                        "text": "PLM",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "__typename": "TailoringAttributeOutputType"
                                  }
                                ],
                                "state": "UPDATED",
                                "updatedAt": "2021-08-25T04:33:32.1314002Z",
                                "__typename": "CategorySchema"
                              }
                        ],
                        "__typename": "CategoryQuery"
                    }
                }
            }`)
        }
    ]
}