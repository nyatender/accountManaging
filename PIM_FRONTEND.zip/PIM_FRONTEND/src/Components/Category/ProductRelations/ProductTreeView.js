import React, { useContext, useEffect } from "react";
import Tree, { TreeNode } from "rc-tree";
import "rc-tree/assets/index.css";
import "./relationTreeStyle.css";
import { treeViewStyles } from "../CategoryStyles";
import { ReactComponent as Folder } from "../../../Asset/category.svg";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";
import GlobalState from "../../../Context/GlobalState";
import { useQuery } from "@apollo/react-hooks";
import { GET_CATEGORY_TREE } from "../../Query";
import Spinner from "../../UI/Spinner";
import { Tooltip } from "@material-ui/core";
import { switcherIcon } from "../../../Utilities/CommonFunctions";
import AlertBox from "../../UI/AlertBox";

export default function TreeView(props) {
  const classes = treeViewStyles();

  const { value37, value88, value89, value90, value58, value109 } =
    useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [selectedCategoryList, setSelectedCategoryList] = value88;
  const [checkedCategoryList, setCheckedCategoryList] = value89;
  const [, setCheckedCategory] = value90;
  const [selectedLanguageInHeader] = value58;
  const [resetCategoryTree, setResetCategoryTree] = value109;

  const includeCategoryDetails = true;

  const { loading, error, data, refetch } = useQuery(GET_CATEGORY_TREE, {
    variables: {
      includeCategoryDetails,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
  });

  useEffect(() => {
    if (
      selectedChannelIDForHeader !== null &&
      selectedChannelIDForHeader !== undefined &&
      includeCategoryDetails !== null &&
      resetCategoryTree !== false &&
      selectedLanguageInHeader !== null &&
      selectedLanguageInHeader !== undefined
    ) {
      refetch();
    }
  }, [
    selectedCategoryList,
    selectedChannelIDForHeader,
    checkedCategoryList,
    selectedLanguageInHeader,
  ]);

  const onSelect = async (info, obj) => {
    props.setCategoryName(
      obj.selectedNodes[0]?.title.props.children.props.children
    );
    props.setClickedCategoryID(obj.node.value.id);
    props.setShowProducts(true);
    if (selectedCategoryList.includes(obj.node.key)) {
      setCheckedCategory(true);
    } else {
      setCheckedCategory(false);
    }
  };

  const onCheck = (checkedKeys, info) => {
    console.log(checkedKeys);
    console.log(info);
    setCheckedCategoryList(checkedKeys);
    if (info.checkedNodes !== null) {
      info.checkedNodes.map((valueOutside) => {
        setSelectedCategoryList(checkedKeys);
        if ("children" in valueOutside) {
          valueOutside.children.map((inside) => {
            setSelectedCategoryList((prevArray) => [...prevArray, inside.key]);
          });
        }
      });
    }
    if (info.checked === false && info.checkedNodes.length <= 0) {
      setSelectedCategoryList([]);
    }
  };

  const treeLoopThree = (dataTree, id) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === id) {
          return (
            <TreeNode
              title={
                <Tooltip title="View Product">
                  <span className={classes.title}>{i.text}</span>
                </Tooltip>
              }
              key={item.id}
              value={item}
              style={{ paddingBottom: "10px" }}
              icon={<SubCategory className={classes.subCatgeoryStyle} />}
            >
              {treeLoopTwo(dataTree, item.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  const treeLoopTwo = (dataTree, id) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId !== null && item.parentCategoryId === id) {
          return (
            <TreeNode
              title={
                <Tooltip title="View Product">
                  <span className={classes.title}>{i.text}</span>
                </Tooltip>
              }
              key={item.id}
              value={item}
              style={{ paddingBottom: "10px" }}
              icon={<SubCategory className={classes.subCatgeoryStyle} />}
            >
              {treeLoopThree(dataTree, item.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  const treeLoopOne = (dataTree) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === null) {
          return (
            <TreeNode
              title={
                <Tooltip title="View Product">
                  <span className={classes.title2}>{i.text}</span>
                </Tooltip>
              }
              key={item.id}
              value={item}
              style={{ paddingBottom: "10px", paddingTop: "5px" }}
              icon={<Folder className={classes.folderStyle} />}
            >
              {treeLoopTwo(dataTree, item.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  function createTreeStructure() {
    if (loading) {
      setResetCategoryTree(false);
      return "loading";
    }
    if (error) {
      setResetCategoryTree(false);
      return "error";
    }
    if (data.category.getCategoryTreeByRootCategoryId !== null) {
      setResetCategoryTree(false);
      props.setCategoryTreeData(
        data?.category?.getCategoryTreeByRootCategoryId
      );
      const dataTree = Object.values(
        data.category.getCategoryTreeByRootCategoryId
      );
      const treeDataValue = dataTree
        .filter(
          (value) =>
            value.isActive === true &&
            value.state !== "DELETED" &&
            value.name !== null &&
            value.name[0]?.text !== null
        )
        .reverse()
        .sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text));
      if (
        (treeDataValue?.length === 1 &&
          treeDataValue[0].parentCategoryId !== null) ||
        treeDataValue?.length === 0
      )
        return null;
      else return treeLoopOne(treeDataValue);
    }
  }
  const treeData = createTreeStructure();

  const renderCategoryTreeDataState = () =>
    treeData === "loading" ? (
      <Spinner message="Loading Category Tree..." topHeight="10px" />
    ) : (
      renderErrorState()
    );

  const renderErrorState = () =>
    treeData === "error" ? (
      <AlertBox
        message="Error occurred while loading category tree"
        severity="error"
      />
    ) : (
      renderAlertOrCategoryTreeData()
    );
  const renderAlertOrCategoryTreeData = () =>
    data?.category?.getCategoryTreeByRootCategoryId?.length === 0 ||
    data?.category?.getCategoryTreeByRootCategoryId === null ||
    treeData === null ? (
      <AlertBox message="No Categories Found!" severity="info" />
    ) : (
      renderCategoryTreeData()
    );

  const renderCategoryTreeData = () => {
    return (
      <Tree
        onSelect={onSelect}
        checkable
        virtual
        checkedKeys={checkedCategoryList}
        onCheck={onCheck}
        checkStrictly={false}
        showLine={false}
        style={{ height: "240px", paddingBottom: "50px" }}
        switcherIcon={(obj) => switcherIcon(obj, data, classes)}
      >
        {createTreeStructure()}
      </Tree>
    );
  };

  return <div style={{ height: "240px" }}>{renderCategoryTreeDataState()}</div>;
}
