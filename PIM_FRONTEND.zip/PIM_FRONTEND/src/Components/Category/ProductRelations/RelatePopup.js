import React, { useContext, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import TextField from "@material-ui/core/TextField";
import {
  StyledCardContent,
} from "../../../Utilities/CommonStyle";
import {relatePopupStyle} from "./ProductRelationStyles";
import GlobalState from "../../../Context/GlobalState";
import RelateProductCatalog from "./RelateProductCatalog";
import CardComponent from "../../UI/CardForSelectedRows";
import {
  CREATE_PRODUCT_RELATIONSHIP,
  GET_ALL_PRODUCT_RELATIONSHIP_TYPES,
} from "../../Query";
import { useQuery, useMutation } from "@apollo/react-hooks";
import Card from "@material-ui/core/Card";
import { Grid } from "@material-ui/core";
import Checkbox from "@material-ui/core/Checkbox";
import MenuItem from "@material-ui/core/MenuItem";
import { dialogMessage } from "../../../Utilities/Constants";

export default function RelatePopup() {
  const classes = relatePopupStyle();
  const {
    value80,
    value16,
    value17,
    value18,
    value19,
    value37,
    value74,
    value86,
    value88,
    value89,
    value81,
    value90,
    value146,
    value147
  } = useContext(GlobalState);
  const [selectedRows] = value16;
  const [, setClearSelectedRows] = value17;
  const [openAddRelationPopup, setOpenAddRelationPopup] = value80;
  const [, setTreeRadioForCopy] = value19;
  const [checkBoxValueForCard, setCheckBoxForCard] = value18;
  const [selectedChannelIDForHeader] = value37;
  const [, setSnackbarData] = value74;
  const [relation, setRelation] = useState("");
  const [, setShowOverlay] = value81;
  const [selectedProductsList, setSelectedProductsList] = value86;
  const [selectedCategoryList, setSelectedCategoryList] = value88;
  const [, setCheckedCategotysList] = value89;
  const [, setCheckedCategory] = value90;
  const [firstName] = value146;
  const [lastName] = value147;
  const [showError, setShowError] = useState(false);

  const {
    loading: relationsLoading,
    error: relationsError,
    data: relationsData,
  } = useQuery(GET_ALL_PRODUCT_RELATIONSHIP_TYPES, {
    skip: !openAddRelationPopup,
  });

  const isButtonDisabled = !selectedProductsList.length && !selectedCategoryList.length

  const fetchListOfRelations = () => {
    if (relationsLoading) {
      return <MenuItem>Loading...</MenuItem>;
    }
    if (relationsError) {
      return <MenuItem>Error...</MenuItem>;
    }

    if (relationsData?.relationshipInfo?.getMasterRelationshipInfo === null) {
      return <MenuItem disabled>No Relations available</MenuItem>;
    }

    if (relationsData?.relationshipInfo?.getMasterRelationshipInfo !== null) {
      return relationsData?.relationshipInfo?.getMasterRelationshipInfo.map(
        (relations) => (
          <MenuItem
            key={relations.relationShipId}
            name={relations.name}
            value={relations.relationShipId}
          >
            {relations.name}
          </MenuItem>
        )
      );
    }
  };

  const [createProductRelations] = useMutation(CREATE_PRODUCT_RELATIONSHIP, {
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occurred !!",
        severity: "error",
      });
    },
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Product Relation added succesfully",
        severity: "success",
      });
    },
  });

  const handleSelect = (event) => {
    setRelation(event.target.value);
    setShowError(false);
  };

  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;
    if (isChecked === true) {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
      setSelectedCategoryList((prevArray) => [...prevArray, item.productId]);
    }
    if (checkBoxValueForCard.includes(item) && isChecked === false) {
      setCheckBoxForCard(checkBoxValueForCard.filter((x) => x !== item));
      setSelectedCategoryList(checkBoxValueForCard.filter((x) => x !== item));
    }
  };

  //Save
  const handleCreateProductRelation = (showHide) => {
    if (relation === "") {
      setShowError(true);
    } else {
      setShowOverlay(true);
      let uniqueArray = [...new Set(selectedCategoryList)];
      let productsList = [];
      checkBoxValueForCard.map((item) => {
        productsList.push(item.productId);
      });
      createProductRelations({
        variables: {
          ProductIds: productsList,
          RelatedProductIds: selectedProductsList,
          RelatedCategoryIds: uniqueArray,
          RelationshipId: relation,
          ChannelId: selectedChannelIDForHeader,
          CreatedBy: `${firstName} ${lastName}`,
        },
      });
      if (showHide) {
        handleClose();
      }
    }
    return null;
  };

  const handleClose = () => {
    setClearSelectedRows(true);
    setOpenAddRelationPopup(false);
    setTreeRadioForCopy("");
    setCheckBoxForCard([]);
    setCheckedCategory(false);
    setSelectedCategoryList([]);
    setCheckedCategotysList([]);
    setRelation("");
    setSelectedProductsList([]);
  };

  return (
    <Dialog
      open={openAddRelationPopup}
      onClose={handleClose}
      fullWidth={true}
      maxWidth="md"
      disableBackdropClick={true}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle>Relate products to</DialogTitle>
      <DialogContent>
        <TextField
          id="select-relationship"
          select
          label="Choose Relationship*"
          value={relation}
          onChange={handleSelect}
          error={showError}
          helperText={
            showError && "Please select Product relations before Save"
          }
          className={classes.textFieldStyle}
        >
          {fetchListOfRelations()}
        </TextField>
        <Grid container spacing={3}>
          <Grid item xs={6}>
            <DialogContentText>{dialogMessage.POPUP_MSG}</DialogContentText>
            <div className={classes.productDivStyle}>
              {selectedRows.map((item, index) => (
                <>
                  <Card>
                    <StyledCardContent key={item.productId}>
                      <Grid container spacing={3}>
                        <Grid item xs={1}>
                          <Checkbox
                            key={item.productId}
                            value={item}
                            onChange={(event) => handleCheck(event, item)}
                            size="small"
                            color="primary"
                            checked={checkBoxValueForCard.includes(item)}
                          />
                        </Grid>
                        <CardComponent
                          title={item.sku}
                          item={item}
                          productType={item.productType}
                          productName={
                            item.productName !== null
                              ? item.productName[0].text
                              : ""
                          }
                        />
                      </Grid>
                    </StyledCardContent>
                  </Card>
                  <br />
                </>
              ))}
            </div>
          </Grid>
          <Grid item xs={6}>
            <DialogContentText>Related Products</DialogContentText>
            <div>
              <RelateProductCatalog />
            </div>
          </Grid>
        </Grid>
        <DialogContentText>
          <i>
            <h5>
              Select the type of relation and products that you want to relate
            </h5>
          </i>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          size="large"
          onClick={handleClose}
          color="primary"
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          size="large"
          disabled={isButtonDisabled}
          onClick={() => handleCreateProductRelation(false)}
          color="primary"
        >
          Save
        </Button>
        <Button
          size="large"
          variant="contained"
          disabled={isButtonDisabled}
          onClick={() => handleCreateProductRelation(true)}
          color="primary"
        >
          Save and Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
