import { makeStyles } from "@material-ui/styles";

export const relateProductCatalogStyle = makeStyles(() => ({
  search: {
    border: "1px outset grey",
    borderRadius: "8px",
    display: "flex",
    width: "300px",
    height: "35px",
  },
  divider: {
    height: "45px",
    margin: "4px",
  },
  flexColScroll: {
    flexGrow: "1",
    height: "42vh",
    overflowY: "auto",
    border: "1px solid #EBE9E7",
    padding: "12px",
    width: "100%",
  },
  flexSection: {
    flexGrow: "1",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
  },
  iconButton: {},
  divButton: {
    borderLeft: "none",
    borderRight: "1px outset transparent",
    borderRadius: "8px",
    backgroundColor: "#7000FF",
    left: "500px",
    width: "50px",
    height: "35px",
  },
  divSearch: {
    paddingRight: "100px",
  },
  iconSearch: {
    width: "25px",
    height: "10px",
  },
  searchGrid: {
    //  border: "1px solid #EBE9E7",
    // paddingTop: "10px",
    paddingBottom: "10px",
    paddingLeft: "45px",
  },
}));

export const relatePopupStyle = makeStyles(() => ({
  productDivStyle: {
    height: "49vh",
    overflowY: "auto",
    border: "1px solid #EBE9E7",
    padding: "12px",
    width: "100%",
  },
  textFieldStyle: {
    marginBottom: "16px",
    width: "50%"
  }
}));

export const searchListStyles = makeStyles((theme) => ({
  listItemTextStyle: {
    color: "#7000FF",
    fontSize: "16px",
    letterSpacing: "0px"
  },

  listItemIconStyle: {
    width: "25px",
    minWidth: "0px"
  }

}))
