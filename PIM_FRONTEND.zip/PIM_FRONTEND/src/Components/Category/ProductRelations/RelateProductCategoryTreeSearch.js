import React, { useContext } from "react";
import { searchListStyles } from "./ProductRelationStyles";
import GlobalState from "../../../Context/GlobalState";
import AlertBox from "../../UI/AlertBox";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";
import {
  Checkbox,
  ListItemText,
  ListItem,
  List,
  ListItemIcon,
} from "@material-ui/core";

function CategorySearch({
  searchResultData,
  setClickedCategoryID,
  setShowProducts,
  setCategoryName,
  setSearchVariable,
}) {
  const classes = searchListStyles();
  const { value88, value89, value90 } = useContext(GlobalState);
  const [selectedCategoryList, setSelectedCategoryList] = value88;
  const [checkedCategoryList, setCheckedCategoryList] = value89;
  const [, setCheckedCategory] = value90;

  const handleCategoryCheck = (event, categoryId) => {
    var isChecked = event.target.checked;

    if (isChecked === true) {
      setSelectedCategoryList((prevArray) => [...prevArray, categoryId]);
      setCheckedCategoryList((prevArray) => [...prevArray, categoryId]);
    }
    if (selectedCategoryList.includes(categoryId) && isChecked === false) {
      setSelectedCategoryList(
        selectedCategoryList.filter((x) => x !== categoryId)
      );
      setCheckedCategoryList(
        checkedCategoryList.filter((x) => x !== categoryId)
      );
    }
  };

  const handleCategoryClick = (category, categoryName) => {
    setCategoryName(categoryName);
    setClickedCategoryID(category?.id);
    setShowProducts(true);
    if (selectedCategoryList.includes(category?.id)) {
      setCheckedCategory(true);
    } else {
      setCheckedCategory(false);
    }
    setSearchVariable("");
  };

  return (
    <div style={{ height: "240px" }}>
      {searchResultData?.length > 0 ? (
        <List component="list" aria-label="search result">
          {searchResultData
            ?.sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text))
            ?.map((category, index) => (
              <ListItem button key={index} style={{ padding: "5px" }}>
                <Checkbox
                  edge="start"
                  color="primary"
                  value={category.id}
                  onChange={(event) => handleCategoryCheck(event, category?.id)}
                  tabIndex={-1}
                  disableRipple
                  checked={selectedCategoryList.includes(category?.id)}
                />
                <ListItemIcon className={classes.listItemIconStyle}>
                  <SubCategory width={"18px"} height={"14px"} />
                </ListItemIcon>
                <ListItemText
                  disableTypography
                  className={classes.listItemTextStyle}
                  onClick={() =>
                    handleCategoryClick(category, category?.name[0]?.text)
                  }
                >
                  {category.name[0].text}
                </ListItemText>
              </ListItem>
            ))}
        </List>
      ) : (
        <AlertBox message={"No data found"} severity="info" />
      )}
    </div>
  );
}

export default CategorySearch;
