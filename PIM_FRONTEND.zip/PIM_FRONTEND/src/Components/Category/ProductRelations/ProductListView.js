import React, { useState, useContext, useEffect } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import GlobalState from "../../../Context/GlobalState";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";
import Tooltip from "@material-ui/core/Tooltip"
import {getProductNameAndSKU} from "../../../Utilities/CommonFunctions"
import {ellipsisTextStyle} from "../../../Utilities/CommonStyle"
export default function ProductListView(props) {
  const { value86 } = useContext(GlobalState);
  const [checkBoxValue, setCheckBoxValue] = useState([]);
  const [, setSelectedProductsList] = value86;
  const classes = ellipsisTextStyle();

  useEffect(() => {
    let allProductIds = [];
    if (props.selectAll) {
      props.data?.product.getProductsByCategory.forEach((element) => {
        allProductIds.push(element.productId);
      });
      let uniqueProductIds = [...new Set(allProductIds)];
      setCheckBoxValue(uniqueProductIds);
    }
  }, [props.data?.product.getProductsByCategory, props.selectAll]);

  if (props.loading) {
    return <Spinner message="Loading Product List..." topHeight="0px" />;
  }

  if (props.error) {
    return (
      <AlertBox
        message="Error occurred while loading products!!"
        severity="info"
      />
    );
  }

  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;
    if (isChecked === true) {
      setCheckBoxValue((prevArray) => [...prevArray, item]);
      setSelectedProductsList((prevArray) => [...prevArray, item]);
    }
    if (checkBoxValue.includes(item) && isChecked === false) {
      setCheckBoxValue(checkBoxValue.filter((x) => x !== item));
      setSelectedProductsList(checkBoxValue.filter((x) => x !== item));
    }
  };

  return (
    <div style={{height:"190px"}}>
      {props.data?.product.getProductsByCategory?.length > 0 ? (
        props.data?.product.getProductsByCategory.map((productData, index) => (
          <ListItem key={productData.productId} role={undefined} dense button>
            <ListItemIcon>
              <Checkbox
                edge="start"
                color="primary"
                value={productData.productId}
                onChange={(event) => handleCheck(event, productData.productId)}
                tabIndex={-1}
                disableRipple
                checked={checkBoxValue.includes(productData.productId)}
              />
            </ListItemIcon>
            <Tooltip title={getProductNameAndSKU(productData)} placement="top-start">
            <ListItemText
              id={productData.productId}
              primary={getProductNameAndSKU(productData)}
              className={classes.textStyle}
            />
            </Tooltip>
          </ListItem>
        ))
      ) : (
        <AlertBox message="No products under this category" severity="info" />
      )}
    </div>
  );
}
