import React, { useState, useContext, useEffect } from "react";
import BrandProductDataTable from "./BrandProductDataTable";
import AllProductsDataTable from "./AllProductsDataTable";
import GlobalState from "../../Context/GlobalState";
import { useQuery } from "@apollo/react-hooks";
import {
  GET_PRODUCTS_BY_BRAND,
  GET_ALL_PRODUCTS,
  GET_ALL_ATTRIBUTES,
  GET_PRODUCTS_BY_CATEGORY
} from "../Query";
import Spinner from "../UI/Spinner";
import { SEARCH_CONTEXT } from "./../../Utilities/Constants";
import Search from "./../Search/search";
import Card from "@material-ui/core/Card";
import { productTableStyles } from "./CategoryStyles";
import {productSearchStyle} from "./../../Utilities/CommonStyle";

function FilterTable() {
  const {
    value1,
    value6,
    value7,
    value17,
    value21,
    value29,
    value30,
    value31,
    value37,
    value58,
    value60,
    value76,
    value77,
    value108,
    value218,
    value221,
  } = useContext(GlobalState);
  const classes = productTableStyles();
  const [categoryId] = value6;
  const [show] = value7;
  const [brandKey] = value1;
  const [, setClearSelectedRows] = value17;
  const [, setAttributeValue] = value21;
  const [filterBrandCheck, setFilterBrandCheck] = value29;
  const [filterCategoryCheck] = value30;
  const brand = brandKey;
  const [filterBrandValue, setFilterBrandValue] = value31;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [showAllProductTable] = value60;
  const [rowsPerPage, setRowsPerPage] = value76;
  const [resetAllProductsTable, setResetAllProductsTable] = value108;
  const [isNoData, setIsNoData] = useState(false);
  const [pageNum, setPageNum] = value77;
  const [productSearchTerm] = value218;
  const [isProductCheckedInTable] = value221;
  const { loading, error, data, refetch: refetchGetProductsByBrand } = useQuery(GET_PRODUCTS_BY_BRAND, {
    variables: {
      brandId: brand,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      paginationFilter: {
        pageNumber: pageNum,
        pageSize: rowsPerPage,
        sortBy: "CreatedAt",
        sortDirection: "DESCENDING",
      },
      searchFilter: productSearchTerm[SEARCH_CONTEXT.allProducts],
      skip: showAllProductTable || brand === "",
    },
  });

  const {
    refetch: refetchGetProductsBYCategory,
  } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: { categoryId, channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader }, searchFilter: productSearchTerm[SEARCH_CONTEXT.allProducts], },
    skip: !show || categoryId === "",
  });

  const {
    loading: allProductsLoading,
    error: allProductsError,
    data: allProductsData,
    refetch,
  } = useQuery(GET_ALL_PRODUCTS, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      paginationFilter: {
        pageNumber: pageNum,
        pageSize: rowsPerPage,
        sortBy: "CreatedAt",
        sortDirection: "DESCENDING",
      },
      searchFilter: productSearchTerm[SEARCH_CONTEXT.allProducts],
    },
    skip: selectedLanguageInHeader === "",
  });

  useEffect(() => {
    console.log("Check 1" + filterBrandCheck);
    console.log("Check 2" + filterCategoryCheck);
    if (
      selectedChannelIDForHeader !== null &&
      selectedChannelIDForHeader !== undefined &&
      selectedLanguageInHeader !== null &&
      selectedLanguageInHeader !== undefined &&
      resetAllProductsTable !== false
    ) {
      refetch();
      if (!(!show || categoryId === "")) {
        refetchGetProductsBYCategory();
      }
      refetchGetProductsByBrand();
    }
  }, [filterCategoryCheck, selectedChannelIDForHeader, resetAllProductsTable, productSearchTerm]);

  const { data: attributeData } = useQuery(GET_ALL_ATTRIBUTES, {
    variables: {
      filter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
    skip: !selectedLanguageInHeader
  });

  const getAllAttributes = () => {
    if (attributeData)
      setAttributeValue(attributeData?.attributes?.getAllAttributes);
    return null;
  };

  const handleNoDataCheck = (listOfProduct) => {
    return (
      listOfProduct !== null &&
      listOfProduct?.products !== undefined &&
      listOfProduct?.products.length !== 0
    );
  };

  const handleBrandTable = () => {
    if (loading) {
      setIsNoData(false);
      return <Spinner message="Loading products..." />;
    }

    if (error) {
      setIsNoData(false);
      return <div>Error...</div>;
    }

    if (data !== undefined && handleNoDataCheck(data?.product?.searchProductsByBrand)) {
      if (filterBrandCheck == 0) {
        setIsNoData(false);
        return data?.product?.searchProductsByBrand?.products
          ?.filter((value) => value.state !== "DELETED")
          ?.sort((a, b) => a.ranking - b.ranking);
      } else {
        if (JSON.stringify(filterBrandValue) === "[]") setIsNoData(true);
        else {
          setIsNoData(false);
          return filterBrandValue.sort((a, b) => a.ranking - b.ranking);
        }
      }
    } else {
      setIsNoData(true);
      return <div>No data</div>;
    }
  };

  const handleAllProductsTable = () => {
    if (allProductsLoading) {
      setIsNoData(false);
      setResetAllProductsTable(false);
      return <Spinner message="Loading products..." />;
    }

    if (allProductsError) {
      setIsNoData(false);
      setResetAllProductsTable(false);
      return <div>Error...</div>;
    }

    if (
      allProductsData !== undefined &&
      handleNoDataCheck(allProductsData?.product?.searchProducts)
    ) {
      setResetAllProductsTable(false);
      if (filterBrandCheck == 0) {
        setIsNoData(false);
        return allProductsData?.product?.searchProducts?.products
          ?.filter((value) => value.state !== "DELETED")
          ?.sort((a, b) => a.ranking - b.ranking);
      } else {
        if (JSON.stringify(filterBrandValue) === "[]") setIsNoData(true);
        else {
          setIsNoData(false);
          return filterBrandValue.sort((a, b) => a.ranking - b.ranking);
        }
      }
    } else {
      setIsNoData(true);
      setResetAllProductsTable(false);
      return <div>No data</div>;
    }
  };

  const handlePageChange = (page, totalRows) => {
    setPageNum(page);
    setFilterBrandCheck([]);
    setFilterBrandValue([]);
  };
  const handlePerRowsChange = (newPerPage, page) => {
    setRowsPerPage(newPerPage);
    setClearSelectedRows(true);
  };

  const renderProductTable = () =>
    show !== true && showAllProductTable !== true
      ? renderBrandProductDataTable()
      : renderAllProductDataTable();

  const renderBrandProductDataTable = () => (
    <BrandProductDataTable
      tableData={handleBrandTable}
      isNoData={isNoData}
      handlePageChange={handlePageChange}
      handlePerRowsChange={handlePerRowsChange}
      dataPerPage={rowsPerPage}
      pageNum={pageNum}
      isError={error}
      paginationInfoData={data?.product?.searchProductsByBrand?.pagination}
    />
  );

  const renderAllProductDataTable = () => (
    <AllProductsDataTable
      tableData={handleAllProductsTable}
      handlePerRowsChange={handlePerRowsChange}
      dataPerPage={rowsPerPage}
      handlePageChange={handlePageChange}
      pageNum={pageNum}
      isNoData={isNoData}
      isError={allProductsError}
      paginationInfoData={allProductsData?.product?.searchProducts?.pagination}
    />
  );

  return (
    <>
      <div className={classes.tableDivStyle}>
        <Card className={classes.tableData}>
          <Search searchContainerStyle={productSearchStyle()} shouldTogglePosition={isProductCheckedInTable} searchContext={SEARCH_CONTEXT.allProducts}/>
          <div>
            {renderProductTable()}
          </div>
        </Card>
      </div>

      {getAllAttributes()}
    </>
  );
}

export default FilterTable;
