import React, { useContext, useEffect } from "react";
import DataTable from "react-data-table-component";
import {
  sortIcon,
  columns,
  selectProps,
  contextActions,
} from "./TableConstants";
import GlobalState from "../../Context/GlobalState";
import Checkbox from "@material-ui/core/Checkbox";
import Spinner from "../UI/Spinner";
import AlertBox from "../UI/AlertBox";
import { dialogMessage } from "../../Utilities/Constants";
import Alert from "@material-ui/lab/Alert";
import { productTableStyles } from "./CategoryStyles";
import { dataTableContextActionsThemeUpdator } from "./../../Utilities/CommonFunctions";

export default function AllProductsDataTable({
  tableData,
  handlePerRowsChange,
  dataPerPage,
  handlePageChange,
  isNoData,
  isError,
  paginationInfoData,
}) {
  const classes = productTableStyles();
  const {
    value17,
    value16,
    value24,
    value66,
    value69,
    value70,
    value77,
    value134,
    value136,
    value214,
    value221,
  } = useContext(GlobalState);
  const [, setSelectedRows] = value16;
  const [clearSelected, setClearSelectedRows] = value17;
  const [, setRowDetails] = value24;
  const [, setSkuValue] = value66;
  const [, setPublishDateForProduct] = value69;
  const [, setProductDetail] = value70;
  const [pageNum] = value77;
  const [, setIsPublishProduct] = value134;
  const [, setIsProductAvailable] = value136;
  const [, setSelectedNavigationModule] = value214;
  const [, setIsProductCheckedInTable] = value221;

  setClearSelectedRows(false);
  useEffect(() => {
    return () => {
      setIsProductCheckedInTable(false);
    };
  }, []);

  const handleChange = (state) => {
    setSelectedRows(state.selectedRows);
    setIsProductCheckedInTable(!!state.selectedRows.length);
  };

  const handleRowClicked = (row) => {
    setSelectedNavigationModule("productTailoring");
    setRowDetails(row);
    setSkuValue(row.sku);
    if (row.publishedDate !== "0001-01-01T00:00:00") {
      setPublishDateForProduct(row.publishedDate.split(".")[0]);
    }
    setProductDetail(row);
    setIsPublishProduct(row.isPublished);
    setIsProductAvailable(row.isAvailable);
  };

  const renderNoDataComponent = () =>
    isNoData ? (
      <Alert severity="info" className={classes.tableNotification}>
        {" "}
        {dialogMessage.NO_DATA_AVAILABLE_MSG}
      </Alert>
    ):(
      renderLoaderOrError()
    );
  const renderLoaderOrError = () =>
    isError ? (
      <AlertBox
        severity="error"
        message="Error occurred while loading all products"
      />
    ) : (
      <Spinner message="Loading products..." topHeight="0px" />
    );

  return (
    <DataTable
      data={tableData()}
      columns={columns()}
      sortIcon={sortIcon}
      defaultSortField="name"
      sortFunction
      contextActions={contextActions(false)}
      selectableRows
      selectableRowsComponentProps={selectProps}
      onSelectedRowsChange={handleChange}
      selectableRowsComponent={Checkbox}
      onRowClicked={handleRowClicked}
      clearSelectedRows={clearSelected}
      pagination
      paginationServer
      paginationDefaultPage={pageNum}
      paginationTotalRows={
        +paginationInfoData?.productCount
      }
      paginationPerPage={dataPerPage}
      paginationRowsPerPageOptions={[5, 10, 15, 20, 25, 30, 50, 100]}
      onChangeRowsPerPage={handlePerRowsChange}
      onChangePage={handlePageChange}
      noDataComponent={renderNoDataComponent()}
      theme={dataTableContextActionsThemeUpdator()}
    />
  );
}
