import { makeStyles } from "@material-ui/styles";

export const productTableStyles = makeStyles(() => ({
  tableDivStyle: {
    flexGrow: 1,
    overflow: "auto",
    minHeight: "100%",
    height: "88vh",
  },
  headerStyle: {
    textAlign: "left",
    fontSize: "18px",
    lineHeight: "52px",
    fontWeight: "Regular",
    letterSpacing: "0px",
    color: "#7A7D8E",
    textTransform: "uppercase",
    opacity: "1",
    width: "40%",
    display: "inline-block",
  },
  tableData: {
    position: "relative",
    minHeight: "100%",
    "& .rdt_Table": {
      marginTop: "3.5em",
    }
  },
  tableNotification: {
    minWidth: "100%",
  }
}));

export const popUpStyle = makeStyles(() => ({
  text: {
    textAlign: "justify",
    lineHeight: "38px",
    letterSpacing: "0px",
    opacity: "1",
    fontWeight: "600",
    fontSize: "13px"
  },
  title: {
    textAlign: "left",
    fontSize: "28px",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  deleteImage: {
    width: "80px",
  },
  multiDeleteImage: {
    width: "80px",
  },
  dialogAction: {
    justifyContent: "center",
  },
  deleteButton: {
    paddingTop: "5px",
  },
}));

export const filterTableStyles = makeStyles(() => ({
  buttonStyle: {
    borderRadius: "8px",
    background: "#7000FF",
    color: "white",
    textTransform: "none",
    width: "130px",
    fontSize: "18px",
    height: "35px",
    "&:hover": {
      background: "#7000FF",
      color: "#FFFFFF !important",
    },
  },
  spanStyle: {
    paddingLeft: "90px",
    paddingBottom: "0px",
  },
  formControlStyle: {
    paddingLeft: "5px",
    color: "#7A7D8E",
    lineHeight: "27px",
    fontSize: "20px",
    letterSpacing: "0px",
  },
}));

export const categoriesStyles = makeStyles((theme) => ({
  paper: {
    padding: "10px",
    height: "90vh",
    position: "relative",
    paddingTop: "50px",
    borderBottom: "none",
  },
  "@global": {
    "html, body, #root": {
      height: "100%",
    },
  },
  container: {
    overflowY: "scroll",
    maxHeight: "100%",
  },
  divider: {},
  table: {
    paddingTop: "120px",
  },
}));

export const searchStyles = makeStyles((theme) => ({
  root: {
    height: 230,
    paddingTop: "30px",
    paddingBottom: "30px",
  },
  container: {
    display: "flex",
    paddingTop: "80px",
    width: "500px",
    paddingBottom: "30px",
  },
  paper: {},
  input: {
    marginLeft: "10px",
    flex: 1,
  },
  iconButton: {
    padding: 10,
  },
  divider: {
    height: 28,
    margin: 4,
  },
  mySvgStyle: {
    background: "#7000FF",
  },
  list: {
    marginTop: "20px",
    marginBottom: "20px",
  },
  search: {
    border: "1px outset black",
    borderRadius: "8px",
    display: "flex",
    width: "330px",
  },
  text: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    "&:hover": {
      color: "#7000FF",
    },
    textNumber: {
      textAlign: "left",
      fontSize: "12px",
      lineHeight: "52px",
      letterSpacing: "0px",
      color: "#BFBFBF",
      opacity: "1",
      paddingRight: "100px",
    },
  },
}));

export const categoryStyles = makeStyles((theme) => ({
  root: {
    height: 180,
  },
  treeView: {
    paddingLeft: "10px",
    flexGrow: "1",
    overflow: "auto",
    minHeight: "100%",
    height: "340px",
  },
  container: {
    display: "flex",
    width: "700px",
  },
  label1: {
    textAlign: "left",
    fontSize: "15px",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#BFBFBF",
    textTransform: "uppercase",
    opacity: "1",
    paddingTop: "5px",
    paddingLeft: "10px",
  },
  label2: {
    paddingLeft: "75px",
    textAlign: "left",
    fontSize: "16px",
    lineHeight: "52px",
    letterSpacing: "0px",
    color: "#BFBFBF",
    opacity: "1",
  },
}));

export const treeDiv = {
  letterSpacing: "0px",
  color: "#BFBFBF",
  opacity: "1",
  paddingLeft: "12px",
};

export const tableMenuStyles = makeStyles((theme) => ({
  title: {
    textAlign: "left",
    fontSize: "20px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    "&:hover": {
      color: "#7000FF",
    },
  },
}));

export const treeViewStyles = makeStyles((theme) => ({
  title: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7000FF",
    opacity: "1",
    paddingLeft: "10px",
  },
  title2: {
    textAlign: "left",
    fontSize: "17px",
    letterSpacing: "0px",
    color: "#7000FF",
    opacity: "1",
    paddingLeft: "6px",
  },
  icon1: {
    width: "16px",
    height: "16px",
  },
  icon2: {
    width: "16px",
    height: "16px",
  },
  subCatgeoryStyle: {
    width: "18px",
    height: "14px",
  },
  folderStyle: {
    width: "20px",
    height: "15px",
  },
}));

export const SearchBoxStyle = makeStyles((theme) => ({
  searchBox: {
    width: "100%"
  },
  container: {
    paddingTop: "20px",
    paddingBottom: "20px",
  },
  searchGrid: {
    border: "1px solid #EBE9E7",
    padding: "1em",
  },
  searchStatus: {
    color: "rgb(112, 117, 122)",
    display: "block",
    fontSize: "14px",
    lineHeight: " 43px",
  },
  buttonSearch: {
    padding: "3px",
  },
  toggledSearch: {
    right: "7em",
  }
}));