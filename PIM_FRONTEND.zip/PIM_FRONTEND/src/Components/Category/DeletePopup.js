import React, { useContext, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import IconButton from "@material-ui/core/IconButton";
import { ReactComponent as Delete } from "./../../Asset/multidelete.svg";
import { ReactComponent as DeleteImage } from "./../../Asset/deletePopup.svg";
import { popUpStyle } from "./CategoryStyles";
import { useMutation } from "@apollo/react-hooks";
import {
  DELETE_PRODUCT,
  GET_ALL_PRODUCTS,
  GET_PRODUCTS_BY_BRAND,
} from "../Query";
import GlobalState from "../../Context/GlobalState";
import Alert from "@material-ui/lab/Alert";
import { Tooltip, Typography } from "@material-ui/core";

export default function DeletePopup() {
  const classes = popUpStyle();
  const [open, setOpen] = React.useState(false);
  const [errorHandler, setErrorHandler] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const {
    value1,
    value16,
    value17,
    value37,
    value58,
    value60,
    value74,
    value76,
    value77,
    value81,
    value108,
    value146,
    value147
  } = useContext(GlobalState);
  const [brand] = value1;
  const [selectedRows] = value16;
  const [, setResetAllProductsTable] = value108;
  const [, setClearSelectedRows] = value17;
  const [selectedLanguageInHeader] = value58;
  const [showAllProductTable] = value60;
  const [pageNum] = value77;
  const [, setShowOverlay] = value81;
  const [selectedChannelIDForHeader] = value37;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setSnackbarData] = value74;
  const [rowsPerPage] = value76;

  const [deleteMultiProduct] = useMutation(DELETE_PRODUCT, 
  {
    refetchQueries: 
    [
      {
        query: GET_PRODUCTS_BY_BRAND,
        variables: {
          brandId: brand,
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          paginationFilter: {
            pageNumber: pageNum,
            pageSize: rowsPerPage,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          },
        },
      },
      {
        query: GET_ALL_PRODUCTS,
        variables: {
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          paginationFilter: {
            pageNumber: pageNum,
            pageSize: rowsPerPage,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          },
        },
      },
    ],
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Product(s) Deleted succesfully",
        severity: "success",
      }); 
    },
  });

  const handleMultiProductDeleteIconClick = () => { setOpen(true); };

  const handleCloseMultiDeletePopup = () => {
    setOpen(false);
    setErrorMessage("");
    setClearSelectedRows(true);
    setErrorHandler(false);
  };

  const handleMultiProductDelete = async () => {
    var rowsToDelete = [];

    for (var index = 0; index < selectedRows?.length; index++) {
      const rowsSelected = {
        productId: selectedRows[index].productId,
        channelId: selectedRows[index].channelId,
        updatedBy: `${firstName} ${lastName}`,
      };

      rowsToDelete.push(rowsSelected);
    }

    try {
      setShowOverlay(true);
      setOpen(false);
      setClearSelectedRows(true);
      await deleteMultiProduct({
        variables: {
          products: rowsToDelete,
        },
      });
      if (showAllProductTable) setResetAllProductsTable(true);
    } catch (e) {
      setShowOverlay(false);
      console.log(e);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result?.errors[0]?.message);
    }
  };

  return (
    <div>
      <Tooltip title="Delete Product(s)">
      <IconButton color="primary" onClick={handleMultiProductDeleteIconClick} size="small">
        <Delete width={"25px"} />
      </IconButton>
      </Tooltip>
      <Dialog
        open={open}
        onClose={handleCloseMultiDeletePopup}
        maxWidth="xs"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle>Confirmation</DialogTitle>
        <DialogContent>
          <DeleteImage className={classes.deleteImage} />

          <DialogContentText
            id="alert-dialog-description"
          >
            <Typography>
              Do you really want to delete the selected products?
            </Typography>
          </DialogContentText>
          {errorHandler && (
            <DialogContentText>
              <Alert
                severity="error"
                style={{ paddingLeft: "10px", fontSize: "16px" }}
              >
                Error Occured while deleting Product(s) : {errorMessage}
              </Alert>
            </DialogContentText>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleCloseMultiDeletePopup}
            variant="outlined"
            size="medium"
            color="primary"
          >
            Cancel
          </Button>
          <Button
            onClick={handleMultiProductDelete}
            size="medium"
            variant="contained"
            color="primary"
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
