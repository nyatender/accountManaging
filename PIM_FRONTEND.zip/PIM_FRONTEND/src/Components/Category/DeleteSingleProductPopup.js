import React, { useContext, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import IconButton from "@material-ui/core/IconButton";
import { ReactComponent as Delete } from "./../../Asset/delete.svg";
import { ReactComponent as DisabledDelete } from './../../Asset/disabled_delete.svg'
import { ReactComponent as DeletePopup } from "./../../Asset/deletePopup.svg";
import { useMutation } from "@apollo/react-hooks";
import {
  DELETE_PRODUCT,
  GET_PRODUCTS_BY_BRAND,
  GET_ALL_PRODUCTS,
} from "../Query";
import GlobalState from "../../Context/GlobalState";
import Alert from "@material-ui/lab/Alert";
import Typography from "@material-ui/core/Typography";
import { Tooltip } from "@material-ui/core";

export default function DeleteSingleProductPopup({ row }) {
  const [open, setOpen] = useState(false);
  const [errorHandler, setErrorHandler] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const {
    value1,
    value17,
    value37,
    value58,
    value60,
    value74,
    value76,
    value77,
    value81,
    value108,
    value146,
    value147
  } = useContext(GlobalState);
  const [brand] = value1;
  const [, setClearSelectedRows] = value17;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [showAllProductTable] = value60;
  const [, setSnackbarData] = value74;
  const [rowsPerPage] = value76;
  const [pageNum] = value77;
  const [, setShowOverlay] = value81;
  const [, setResetAllProductsTable] = value108;
  const [firstName] = value146;
  const [lastName] = value147;

  const [deleteProduct] = useMutation(DELETE_PRODUCT, {
    refetchQueries: [
      {
        query: GET_ALL_PRODUCTS,
        variables: {
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          paginationFilter: {
            pageNumber: pageNum,
            pageSize: rowsPerPage,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          },
        },
      },
      {
        query: GET_PRODUCTS_BY_BRAND,
        variables: {
          brandId: brand,
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          paginationFilter: {
            pageNumber: pageNum,
            pageSize: rowsPerPage,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          },
        },
      },
    ],
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Product Deleted succesfully",
        severity: "success",
      });
    },
  });

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setClearSelectedRows(true);
    setErrorHandler(false);
    setErrorMessage("");
  };

  const handleProductDelete = async () => {
    try {
      setShowOverlay(true);
      await deleteProduct({
        variables: {
          products: [
            {
              productId: row.productId,
              channelId: row.channelId,
              updatedBy: `${firstName} ${lastName}`,
            },
          ],
        },
      });
      setOpen(false);
      setClearSelectedRows(true);
      if (showAllProductTable) setResetAllProductsTable(true);
    } catch (e) {
      setShowOverlay(false);
      console.log(e);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result?.errors[0]?.message);
    }
  };

  return (
    <div>
      {row?.productSource === "INFOR" ? 
        <Tooltip title="Cannot delete Infor product" placement="top" disableFocusListener disableTouchListener>
        <IconButton size="small" disableRipple style={{cursor: 'default', backgroundColor: 'transparent'}}>
          <DisabledDelete width={'25px'} />
        </IconButton>
      </Tooltip>
      : 
      <Tooltip title="Delete Product" placement="top">
        <IconButton color="primary" onClick={handleClickOpen} size="small">
          <Delete width={"25px"} />
        </IconButton>
      </Tooltip>
      }
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="xs"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle>Confirmation</DialogTitle>
        <DialogContent>
          <div style={{ paddingLeft: 120 }}><DeletePopup height='40px' /></div>

          <DialogContentText id="alert-dialog-description">
            <Typography>
              Do you really want to delete the selected product?
            </Typography>
          </DialogContentText>
          {errorHandler && (
            <DialogContentText>
              <Alert
                severity="error"
                style={{ paddingLeft: "10px", fontSize: "14px" }}
              >
                Error Occured while deleting a Product : {errorMessage}
              </Alert>
            </DialogContentText>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleClose}
            variant="outlined"
            size="medium"
            color="primary"
          >
            Cancel
          </Button>
          <Button
            onClick={handleProductDelete}
            size="medium"
            variant="contained"
            color="primary"
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
