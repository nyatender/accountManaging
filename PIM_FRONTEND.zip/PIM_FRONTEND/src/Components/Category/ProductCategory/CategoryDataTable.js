import React, { useContext, useEffect } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "react-data-table-component";
import {
  sortIcon,
  selectProps,
  columns,
} from "../TableConstants";
import { GET_PRODUCTS_BY_CATEGORY } from "../../Query";
import GlobalState from "../../../Context/GlobalState";
import { useQuery } from "@apollo/react-hooks";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";
import { dialogMessage } from "../../../Utilities/Constants";
import Alert from "@material-ui/lab/Alert";

export default function CategoryDataTable({ searchTermContext }) {
  const {
    value10,
    value16,
    value17,
    value24,
    value37,
    value66,
    value69,
    value70,
    value134,
    value136,
    value214,
    value58,
    value151,
    value153,
    value218,
    value222,
  } = useContext(GlobalState);
  const [, setSelectedRows] = value16;
  const [clearSelected, setClearSelectedRows] = value17;
  const [categoryId] = value10;
  const [, setRowDetails] = value24;
  const [selectedChannelIDForHeader] = value37;
  const [, setSkuValue] = value66;
  const [, setPublishDateForProduct] = value69;
  const [, setProductDetail] = value70;
  const [, setIsPublishProduct] = value134;
  const [, setIsProductAvailable] = value136;
  const [, setSelectedNavigationModule] = value214;
  const [selectedLanguageInHeader] = value58;
  const [, setInvokedFromProductCategory] = value151;
  const [, setInvokedFromUncategorisedProductsList] = value153;
  const [productSearchTerm] = value218;
  const [resetCategoryProductsTable, setResetCategoryProductsTable] = value222;
  setClearSelectedRows(false);

  useEffect(() => {
    if (productSearchTerm[searchTermContext] !== "" && resetCategoryProductsTable)
      refetch();
  }, [productSearchTerm]);

  const { loading, error, data, refetch } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: {
      categoryId,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      searchFilter: productSearchTerm[searchTermContext],
    },
  });

  const handleChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const handleRowClicked = (row) => {
    setSelectedNavigationModule("productTailoring");
    setRowDetails(row);
    setSkuValue(row.sku);
    if (row.publishedDate !== "0001-01-01T00:00:00") {
      setPublishDateForProduct(row.publishedDate.split(".")[0]);
    }
    setProductDetail(row);
    setIsPublishProduct(row.isPublished);
    setIsProductAvailable(row.isAvailable);

    if (categoryId === null)
      setInvokedFromUncategorisedProductsList(true);
    else
      setInvokedFromProductCategory(true);
  };

  if (loading) {
    setResetCategoryProductsTable(false);
    return <Spinner message="Loading products..." />;
  }

  if (error) {
    return (
      <AlertBox
        message="Error occurred while loading products"
        severity="error"
      />
    );
  }

  const renderProductsData = () => {
    if (data && data?.product?.getProductsByCategory !== null) return renderData(data);
     else return renderAlert();
  };

  const renderData = (categoryData) => {
    return [...new Set(Object.values(categoryData?.product?.getProductsByCategory))]
      .filter((value) => value.state !== "DELETED")
      .sort((a, b) => a.ranking - b.ranking);
  }

  const renderAlert = () => {
    return (
      <Alert severity="info" style={{ width: "100%" }}>{dialogMessage.NO_DATA_AVAILABLE_MSG}</Alert>
    );
  }

  return (
    <div>
      <DataTable
        style={{ paddingTop: 80 }}
        columns={columns()}
        data={renderProductsData()}
        selectableRows
        sortIcon={sortIcon}
        paginationPerPage={25}
        paginationRowsPerPageOptions={[5, 10, 15, 20, 25, 30, 50, 100]}
        highlightOnHover
        defaultSortField="name"
        sortFunction
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        onSelectedRowsChange={handleChange}
        clearSelectedRows={clearSelected}
        onRowClicked={handleRowClicked}
        noHeader
        pagination
        noDataComponent={
          <Alert severity="info" style={{ width: "100%" }}>
            {dialogMessage.NO_DATA_AVAILABLE_MSG}
          </Alert>
        }
      />
    </div>
  );
}