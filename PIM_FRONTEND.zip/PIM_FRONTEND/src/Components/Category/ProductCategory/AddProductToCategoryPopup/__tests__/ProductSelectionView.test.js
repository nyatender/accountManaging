import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import Search from "../../../../UI/Search";
import Spinner from "../../../../UI/Spinner";
import AlertBox from "../../../../UI/AlertBox";
import { ApolloProvider } from "react-apollo";
import { client } from "../../../../App";
import { Checkbox, ListItem } from "@material-ui/core";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import ProductSelectionView from "../ProductSelectionView";
import {act} from "react-dom/test-utils";
import {context, response} from "../__mocks__/ProductSelectionView_mocks";
import { MockedProvider, wait } from "@apollo/react-testing";
import Pagination from "@material-ui/lab/Pagination";

let wrapper;
beforeEach(() => {
    wrapper = mount(
        <GlobalContextProvider>
            <ApolloProvider client={client}>
                <ProductSelectionView/>
            </ApolloProvider>
        </GlobalContextProvider>);
  });

describe("ProductSelectionView snapshot test", () => {
    it("ProductSelectionView should match its snapshot", () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
});

describe("ProductSelectionView functional tests", ()=>
{
    it("should check search works properly",()=>{
        act(()=>{
          wrapper.find(Search).props().handleSearch({ target: { value: 'Test'} }) 
        })
        wrapper.update();
        expect(wrapper.find(Search).props().searchTerm).toEqual('Test');
    });

    it("should check clear search works properly",()=>{
        act(()=>{
          wrapper.find(Search).props().handleClearSearch() 
        })
        wrapper.update();
        expect(wrapper.find(Search).props().searchTerm).toEqual('');
    });

    it("should render list of product categories without crashing",async() => {
        let container = GetContainer(response);
        await act(() => wait(500));
        container.update()
        let listItem = container.find(ListItem);

        expect(listItem.exists()).toBeTruthy();
        expect(listItem.length).toBeGreaterThan(0);
    });

    it("should render AlertBox with error message when loading fails",async() => {
        let container = GetContainer([]);
        await act(() => wait(500));
        container.update()
        let alertBox = container.find(AlertBox).first();

        expect(alertBox.exists()).toBeTruthy();
        expect(alertBox.prop("message")).toEqual("Error occurred while loading products");
    });

    it("Should render Spinner while loading products",async() => {
        let container = GetContainer(response);

        expect(container.find(Spinner).exists()).toBeTruthy();
        expect(container.find(Spinner).prop("message")).toEqual("Loading products...");
    });

    it("should render pagination information properly", async() => {
        let container = GetContainer(response);
        await act(() => wait(500));
        container.update();

        expect(container.find(Pagination).props().count).toEqual(869);
    });
    
    it("should check checkbox Functionality works properly", async() => {
        let container;
        let props = {
            selectedProducts: [],
            setSelectedProducts: jest.fn()
        }
        act(()=>{
            container = mount(
                <GlobalContextProvider mockData={context}>
                    <MockedProvider  mocks={response} addTypename={false}>
                        <ProductSelectionView {...props}/>
                    </MockedProvider>
                </GlobalContextProvider>);
        });
        await act(() => wait(500));
        container.update();

        expect(container.find(Checkbox).first().props().checked).toBeFalsy();
        act(()=>{
            container.find(Checkbox).first().props().onChange({target:{ checked:true}});
        });
        container.update();
        expect(props.setSelectedProducts).toHaveBeenCalled();
    });
});

const GetContainer = (mockResponse) => {
    let container;
    let props = {
        selectedProducts: [],
        setSelectedProducts: jest.fn()
    };
    act(() => {
        container = mount(
            <GlobalContextProvider mockData={context}>
                <MockedProvider mocks={mockResponse} addTypename={false}>
                    <ProductSelectionView {...props} />
                </MockedProvider>
            </GlobalContextProvider>);
    });
    return container;
}
