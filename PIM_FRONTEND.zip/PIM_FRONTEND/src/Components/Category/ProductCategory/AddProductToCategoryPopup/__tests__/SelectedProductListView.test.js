import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import { ApolloProvider } from "react-apollo";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import SelectedProductListView from "../SelectedProductListView";
import IconButton from "@material-ui/core/IconButton";
import {act} from "react-dom/test-utils";
import { DragDropContext } from "react-beautiful-dnd";

let wrapper;
let props = {
    selectedProducts: [
        {
            "sku": "ASB-SKU",
            "productName": [
              {
                "text": "TestPIM885",
                "languageCode": "en_GB",
                "__typename": "TextTranslationOutput"
              }
            ],
            "productId": "d93dcd27-5e6e-41c8-a9a6-ba9c67e1f750",
            "productSource": "PIM",
            "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            "categoryId": null,
            "productType": "PRODUCT_VARIANT",
            "ranking": 0,
            "isPublished": true,
            "publishedDate": "2021-09-15T05:28:00",
            "parentProductId": null,
            "phaseOutDate": "2021-12-31T05:24:00",
            "createdAt": "2021-09-15T04:40:56.693896",
            "isAvailable": true,
            "__typename": "ProductSchema"
          },
          {
            "sku": "ASB-Product",
            "productName": [
              {
                "text": "Test product-Global",
                "languageCode": "en_GB",
                "__typename": "TextTranslationOutput"
              }
            ],
            "productId": "59866ca3-3645-4894-b450-5c97f057f81b",
            "productSource": "PIM",
            "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            "categoryId": null,
            "productType": "PRODUCT_VARIANT",
            "ranking": 0,
            "isPublished": false,
            "publishedDate": "2021-09-15T10:55:00",
            "parentProductId": null,
            "phaseOutDate": "2022-01-31T06:39:00",
            "createdAt": "2021-09-15T05:40:19.53487",
            "isAvailable": true,
            "__typename": "ProductSchema"
          }
    ],
    updateSelectedProducts: jest.fn()
};

beforeEach(() => {
    wrapper = mount(
        <GlobalContextProvider>
            <ApolloProvider client={client}>
                <SelectedProductListView {...props}/>
            </ApolloProvider>
        </GlobalContextProvider>);
});

describe("SelectedProductListView snapshot test", () => {
    it("SelectedProductListView should match its snapshot", () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
});

describe("SelectedProductListView functional tests", ()=>
{
    it("Should update the product list on click of remove icon", () => {
        act(() => {
            wrapper.find(IconButton).first().props().onClick();
        });
        wrapper.update();
    
        expect(props.updateSelectedProducts).toHaveBeenCalled();
    });

    it("Should reorder the product list on drag end of an element", () => {
        let dragResultObject = {
            source: {
                index: 1,
                droppableId: "droppable"
            },
            destination: {
                droppableId: "droppable",
                index: 0
            },
        };
        act(() => {
            wrapper.find(DragDropContext).last().props().onDragEnd(dragResultObject);
        });
        wrapper.update();
    
        expect(props.updateSelectedProducts).toHaveBeenCalled();
    });
});