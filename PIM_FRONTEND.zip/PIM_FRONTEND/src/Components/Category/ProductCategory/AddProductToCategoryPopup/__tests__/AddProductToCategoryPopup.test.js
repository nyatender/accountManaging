import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import { ApolloProvider } from "react-apollo";
import { client } from "../../../../App";
import AddProductToCategoryPopup from "../AddProductToCategoryPopup";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import { Dialog, DialogTitle , DialogContentText , Button} from "@material-ui/core";
import {act} from "react-dom/test-utils";
import { wait } from '@apollo/react-testing';

let wrapper;
const context = {
    openAddProductToCategoryPopup: true
  }
  
beforeEach(() => {
    wrapper = mount(
        <GlobalContextProvider mockData={context}>
            <ApolloProvider client={client}>
                <AddProductToCategoryPopup/>
            </ApolloProvider>
        </GlobalContextProvider>);
  });

 describe("AddProductToCategoryPopup snapshot test ", () => 
 {
    it("AddProductToCategoryPopup should match its snapshot", () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
    it("AddProductToCategoryPopup should display dialog title", () => {
        expect(wrapper.find(DialogTitle).text()).toBe("Add product to category");
    });
    it("AddProductToCategoryPopup should display dialogcontent Text", () => {
        expect(wrapper.find(DialogContentText).first().text()).toBe("Product Catalog");
        expect(wrapper.find(DialogContentText).at(1).text()).toBe("You are going to add");
    });
    it("AddProductToCategoryPopup should render cancel and Done buttons", () => {
        expect(wrapper.find(Button).first().text()).toBe("Cancel");
        expect(wrapper.find(Button).last().text()).toBe("Done");
    });
});


describe("AddProductToCategoryPopup functional tests", ()=>
{
    it("AddProductToCategoryPopup should call function on click of cancel button", async()=>
    {
        act(() => wrapper.find(Button).first().props().onClick())
        await act(()=> wait(500));
        wrapper.update();

        expect(wrapper.find(Dialog).props().open).toEqual(false);
    });

    it("AddProductToCategoryPopup should call function on click of Done button", async()=>
    {
        act(() => wrapper.find(Button).last().props().onClick())
        await act(()=> wait(500));
        wrapper.update();

        expect(wrapper.find(Dialog).props().open).toEqual(false);
    });
})