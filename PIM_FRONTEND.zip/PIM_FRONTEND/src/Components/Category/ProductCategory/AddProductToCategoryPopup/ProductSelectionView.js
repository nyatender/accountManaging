import React, { useState, useEffect, useContext } from "react";
import { useQuery } from "@apollo/react-hooks";
import GlobalState from "../../../../Context/GlobalState";
import Pagination from "@material-ui/lab/Pagination";
import 
{
  Grid,
  ListItemText,
  ListItem,
  ListItemIcon,
  Checkbox,
  Box,
  Tooltip
} from "@material-ui/core";
import { GET_ALL_PRODUCTS } from "../../../Query";
import { productSelectionViewStyle } from "./AddProductToCategoryPopupStyles";
import Spinner from "../../../UI/Spinner";
import AlertBox from "../../../UI/AlertBox";
import Search from "../../../UI/Search";
import Item from "../../../../Asset/single-item.svg";
import Product from "../../../../Asset/products.svg";
import Bundle from "../../../../Asset/bundle.svg";
import {getProductNameAndSKU} from "../../../../Utilities/CommonFunctions"

export default function ProductSelectionView(
{
    selectedProducts,
    setSelectedProducts,
}) 
{
    const styleClasses = productSelectionViewStyle();
    const { value37, value58} = useContext(GlobalState);
    const [pageNum, setPageNum] = useState(1);
    const [selectedChannelIDForHeader] = value37;
    const [selectedLanguageInHeader] = value58;
    const [allProductsList, setAllProductsList] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [searchResult, setSearchResults] = useState([]);

    const {
        loading: productLoading,
        error: productError,
        data: productData,
      } = useQuery(GET_ALL_PRODUCTS, {
        variables: {
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          paginationFilter: {
            pageNumber: pageNum,
            pageSize: 25,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          }
        },
    });
    
    useEffect(() => {
        handleProductList();
      }, [productData]);  

    const handleProductList = () => 
    {
        if (productLoading) {
          return  <Spinner message="Loading Products.." topHeight="0px" />
        }
        if (productError) {
          return <div>Error ...</div>;
        }
        if (productData) {
          let apiData = productData?.product?.searchProducts?.products;
    
          setAllProductsList(apiData);
        }
    };

    const handleCheckboxChange = (event, item) => {
      var isChecked = event.target.checked;
        if(isChecked === true)
          setSelectedProducts((prevArray) => [...prevArray, item]);
        else
          setSelectedProducts(
            selectedProducts.filter((x) => x !== item)
          );
    };
    
    const handlePageChange = (e, page) => {
        setPageNum(page);
    };

    const handleSearchBoxChange = (event) => {
        setSearchTerm(event.target.value);
        const results = allProductsList.filter(
          (product) =>
          product.productName[0]?.text.toLowerCase().includes(event.target.value.toLowerCase())
        );
        setSearchResults(results);
    };

    const handleClearSearch = () => {
        setSearchTerm("");
        setSearchResults([]);
    };

    const getProductTypeImage = (type) => 
    {
      if (type === "PRODUCT_VARIANT") 
        return Item;
      else if (type === "PRODUCT")
        return Product;
      else if (type === "BUNDLE") 
        return Bundle;
    };

    const tableData = !!searchTerm ? 
                        searchResult : 
                        allProductsList;

    return(
            <Grid container>
                <Search
                    className={styleClasses.searchGrid}
                    searchTerm={searchTerm}
                    handleSearch={handleSearchBoxChange}
                    handleClearSearch={handleClearSearch}/>
                <Box className={styleClasses.searchDividerBox} />
                <div className={styleClasses.listView}>
                    {productLoading ? (
                        <Spinner message="Loading products..." topHeight="0px"/>
                        ) : null}
                    {productError ? (
                        <AlertBox
                            message="Error occurred while loading products"
                            severity="error"
                        />
                        ) : null}
                    {!productLoading &&
                        !productError &&
                        tableData?.length === 0 ? (
                        <AlertBox message="No Products Found" severity="info" />
                        ) : null}
                    {!productLoading &&
                        !productError &&
                        tableData?.map((item, index) => (
                        <ListItem
                        key={item.productId}
                        role={undefined}
                        dense
                        button
                        >
                        <ListItemIcon>
                            <Checkbox
                              edge="start"
                              key={item.productId}
                              value={item}
                              onChange={(event) => handleCheckboxChange(event, item)}
                              tabIndex={-1}
                              disableRipple
                              color="primary"
                              checked={selectedProducts.some( (attr) => attr.productId === item.productId )}/>
                            <img
                              alt="type"
                              height="19px"
                              width="30px"
                              style={{marginTop: "12px",}}
                              src={getProductTypeImage(item.productType) }/>
                        </ListItemIcon>
                        <Tooltip title={getProductNameAndSKU(item)} placement='top-start'>
                        <ListItemText
                            id={item.productId}
                            primary=
                            {
                              getProductNameAndSKU(item)
                            }
                            disableTypography/>
                        </Tooltip>
                        </ListItem>
                    ))}
                </div>
                <Box className={styleClasses.paginationDividerBox} />
                <div className={styleClasses.pagination}>
                {tableData?.length === 0 ? 
                    null :  (<Pagination
                        count={ productData?.product?.searchProducts?.pagination?.pageCount }
                        color="primary"
                        size="small"
                        onChange={handlePageChange}/>) 
                }
                </div>
            </Grid>
    );
}