import React from "react";
import { Grid, Tooltip } from "@material-ui/core";
import { selectedProductListStyle } from "./AddProductToCategoryPopupStyles";
import IconButton from "@material-ui/core/IconButton";
import CancelIcon from "@material-ui/icons/Cancel";
import Typography from "@material-ui/core/Typography";
import Card from "@material-ui/core/Card";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import Item from "../../../../Asset/single-item.svg";
import Product from "../../../../Asset/products.svg";
import Bundle from "../../../../Asset/bundle.svg";

export default function SelectedProductListView({
  selectedProducts,
  updateSelectedProducts,
}) {
  const styleClasses = selectedProductListStyle();

  const handleRemoveItem = (event, item) => {
    updateSelectedProducts(
      selectedProducts.filter((x) => x.productId !== item.productId)
    );
  };

  const reorderList = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);

    return result;
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    if (result.destination.index === result.source.index) return;

    const items = reorderList(
      selectedProducts,
      result.source.index,
      result.destination.index
    );
    
    updateSelectedProducts(items);
  };

  const getProductTypeImage = (type) => 
  {
    if (type === "PRODUCT_VARIANT") 
      return Item;
    else if (type === "PRODUCT")
      return Product;
    else if (type === "BUNDLE") 
      return Bundle;
  };

  return (
    <Grid container className={styleClasses.flexSection} direction="column">
      <Grid item xs={12}>
        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable droppableId="droppable">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef}>
                {selectedProducts.map((product, index) => (
                  <Draggable
                    key={product.productId}
                    draggableId={product.productId}
                    index={index}
                  >
                    {(providedDraggable) => (
                      <div
                        ref={providedDraggable.innerRef}
                        {...providedDraggable.draggableProps}
                        {...providedDraggable.dragHandleProps}
                      >
                        <Card className={styleClasses.card}>
                          <img
                            alt="type"
                            height="19px"
                            width="30px"
                            src={getProductTypeImage(product.productType) }
                          />
                          <Tooltip
                            title={product.productName[0].text}
                            placement="top-start"
                          >
                            <Typography
                              className={styleClasses.typographyStyle}
                            >
                              {product.productName[0].text}({product.sku})
                            </Typography>
                          </Tooltip>
                          <Tooltip title="Remove from the list" placement="top">
                            <IconButton
                              onClick={(event) =>
                                handleRemoveItem(event, product)
                              }
                            >
                              <CancelIcon color="error" />
                            </IconButton>
                          </Tooltip>
                        </Card>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </Grid>
    </Grid>
  );
}
