import React, { useState, useContext } from "react";
import GlobalState from "../../../../Context/GlobalState";
import 
{
  Grid,
  Dialog,
  DialogTitle,
  DialogActions,
  Button,
  DialogContentText,
} from "@material-ui/core";
import { addProductToCategoryPopupStyle } from "./AddProductToCategoryPopupStyles";
import SelectedProductListView from "./SelectedProductListView";
import ProductSelectionView from "./ProductSelectionView";
import 
{
  GET_PRODUCTS_BY_CATEGORY,
  COPY_PRODUCT_WITHIN_CATEGORY,
} from "../../../Query";
import { useMutation } from "@apollo/react-hooks";

export default function AddProductToCategoryPopup()
{
    const styleClasses = addProductToCategoryPopupStyle();
    const { value10,value37, value58,  value74, value81, value146, value147,value216 } = useContext(GlobalState);
    const [categoryId] = value10;
    const [openAddProductToCategoryPopup, setOpenAddProductToCategoryPopup] = value216;
    const [, setShowOverlay] = value81;
    const [selectedChannelIDForHeader] = value37;
    const [, setSnackbarData] = value74;
    const [selectedLanguageInHeader] = value58;
    const [firstName] = value146;
    const [lastName] = value147;

    const [selectedProducts, setSelectedProducts] = useState([]);

    const destinationCategoryId = categoryId;

    const [associateProductToCategory] = useMutation(COPY_PRODUCT_WITHIN_CATEGORY, {
        refetchQueries: [
          {
            query: GET_PRODUCTS_BY_CATEGORY,
            variables: {
              categoryId: destinationCategoryId,
              channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
              searchFilter: ""
            }
          },
        ],
        awaitRefetchQueries: true,
        onCompleted: () => {
          setShowOverlay(false);
          setSnackbarData({
            show: true,
            message: "Product Associated succesfully To a Category",
            severity: "success",
          });
        },
        onError: () => {
          setShowOverlay(false);
          setSnackbarData({
            show: true,
            message: "Error occured while associating a product to a category",
            severity: "error",
          });
        },
      });



    const updateProductsAssociatedToCategory = (selectedProductIds) => {
        setShowOverlay(true);

        let productIdList = [];
        selectedProductIds?.map((item) => 
        {
          var obj= {productId: item};
          productIdList.push(obj);
            return null;
        });

        associateProductToCategory({
            variables: {
              product: productIdList,
              category: [
                {
                  id: destinationCategoryId,
                },
              ],
              user: `${firstName} ${lastName}`,
              channel: selectedChannelIDForHeader, 
            },
          });  
    };

    const handleClose = () => {
        setOpenAddProductToCategoryPopup(false);
        setSelectedProducts([]);
    };

    const handleDone = () => {
        setOpenAddProductToCategoryPopup(false);
        const selectedProductIds = selectedProducts.map((product) => product.productId);
        if(!!selectedProductIds.length)
            updateProductsAssociatedToCategory(selectedProductIds);
        handleClose();
    };

    const updateSelectedProducts = (data) => {
        setSelectedProducts(data);
    };

    return (
        <div>
            <Dialog
                open={openAddProductToCategoryPopup}
                fullWidth={true}
                maxWidth="md"
                disableBackdropClick
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">

                <DialogTitle className={styleClasses.dialogTitle} disableTypography>
                    Add product to category
                </DialogTitle>

                <Grid container spacing={0}>
                    <Grid item xs={6}>
                        <DialogContentText className={styleClasses.contentText1}>Product Catalog</DialogContentText>
                        <div className={styleClasses.productSelectionContainer}>
                            <ProductSelectionView
                                selectedProducts = {selectedProducts}
                                setSelectedProducts= {setSelectedProducts}
                            />
                        </div>
                    </Grid>
                    <Grid item xs={6}>
                        <DialogContentText className={styleClasses.contentText2}>You are going to add</DialogContentText>
                            <div className={styleClasses.selectedProductListContainer}>
                                <SelectedProductListView
                                    selectedProducts={selectedProducts}
                                    updateSelectedProducts={updateSelectedProducts} />
                            </div>
                    </Grid>
                </Grid>

                <DialogActions className={styleClasses.doneButton}>
                    <Button
                        variant="outlined"
                        size="large"
                        color="primary"
                        onClick={handleClose}>
                        Cancel
                        </Button>
                    <Button
                        variant="contained"
                        size="large"
                        color="primary"
                        onClick={handleDone}>
                        Done
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}