import 
{ GET_ALL_PRODUCTS } from "../../../../Query"

module.exports = 
{
    context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
    },
    response: [
        {
            request: {
                query: GET_ALL_PRODUCTS,
                variables: {
                    channelFilter: {channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21", languageCode: "en_GB"},
                    paginationFilter: {
                        pageNumber: 1,
                        pageSize: 25,
                        sortBy: "CreatedAt",
                        sortDirection: "DESCENDING"
                    }
                }
            },
            result: JSON.parse(`{
                "data": {
                    "product": {
                        "searchProducts": {
                            "pagination": {
                                "pageCount": 869,
                                "productCount": 21725,
                                "__typename": "PaginationSchema"
                            },
                            "products": [
                                {
                                    "sku": "ASB-SKU",
                                    "productName": [
                                      {
                                        "text": "TestPIM885",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "productId": "d93dcd27-5e6e-41c8-a9a6-ba9c67e1f750",
                                    "productSource": "PIM",
                                    "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                                    "categoryId": null,
                                    "productType": "PRODUCT_VARIANT",
                                    "ranking": 0,
                                    "isPublished": true,
                                    "publishedDate": "2021-09-15T05:28:00",
                                    "parentProductId": null,
                                    "phaseOutDate": "2021-12-31T05:24:00",
                                    "createdAt": "2021-09-15T04:40:56.693896",
                                    "isAvailable": true,
                                    "__typename": "ProductSchema"
                                  },
                                  {
                                    "sku": "ASB-Product",
                                    "productName": [
                                      {
                                        "text": "Test product-Global",
                                        "languageCode": "en_GB",
                                        "__typename": "TextTranslationOutput"
                                      }
                                    ],
                                    "productId": "59866ca3-3645-4894-b450-5c97f057f81b",
                                    "productSource": "PIM",
                                    "channelId": "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                                    "categoryId": null,
                                    "productType": "PRODUCT_VARIANT",
                                    "ranking": 0,
                                    "isPublished": false,
                                    "publishedDate": "2021-09-15T10:55:00",
                                    "parentProductId": null,
                                    "phaseOutDate": "2022-01-31T06:39:00",
                                    "createdAt": "2021-09-15T05:40:19.53487",
                                    "isAvailable": true,
                                    "__typename": "ProductSchema"
                                  }
                            ],
                            "__typename": "SearchProductOutputType"
                        },
                        "__typename": "ProductQuery"
                    }
                }
            }`)
        },
    ]
}