import { makeStyles } from "@material-ui/styles";

export const addProductToCategoryPopupStyle = makeStyles((theme) => ({
  dialogTitle: {
    textAlign: "left",
    fontSize: "22px",
    paddingLeft: "30px",
    paddingBottom: "20",
    paddingTop: "30px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
    display: "inline-flex",
  },
  dialogContentDisplay: {
    display: "inline-flex",
  },
  contentText1: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "30px",
  },
  contentText2: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "10px",
  },
  productSelectionContainer: {
    marginLeft: "30px",
    marginRight: "10px",
    height: "25em",
    border: "1px solid #EBE9E7",
    overflow: "auto"
  },
  selectedProductListContainer: {
    marginRight: "30px",
    marginLeft: "10px",
    height: "25em",
    border: "1px solid #EBE9E7",
  },
  doneButton: {
    padding: "30px",
  },
}));

export const productSelectionViewStyle = makeStyles((theme) => ({
  searchGrid: {
    marginTop: "20px",
    marginBottom: "5px",
    marginLeft: "30px",
    marginRight: "30px",
    width: "86%",
  },
  searchDividerBox: {
    height: "1px",
    backgroundColor: "#EBE9E7",
    marginTop: "20px",
    marginBottom: "0px",
    width: "100%"
  },
  listView: {
    padding: "0px",
    paddingTop: "10px",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 200,
    },
    "@media (min-height: 901px)": {
      maxHeight: 400,
    },
  },
  pagination: {
    display: "flex",
    justifyContent: "center",
    marginLeft: "80px",
  },
  paginationDividerBox: {
    height: "1px",
    backgroundColor: "#EBE9E7",
    marginTop: "0px",
    marginBottom: "10px",
    width: "100%"
  },
}));

export const selectedProductListStyle = makeStyles((theme) => ({
  flexSection: {
    padding: "0px",
    width: "100%",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 360,
    },
    "@media (min-height: 901px)": {
      maxHeight: 400,
    },
  },
  typographyStyle: {
    fontSize: "16px",
    color: "#7A7D8E",
    paddingTop: "10px",
    paddingLeft: "10px",
    paddingBottom: "10px",
    whiteSpace: "nowrap !important",
    overflow: "hidden !important",
    textOverflow: "ellipsis",
    display: "inline-block",
    width: "360px",
  },
  card: {
    padding: "10px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    height: "50px",
    backgroundColor: "#EBE9E7",
    margin: "10px",
  },
}));