import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import { ApolloProvider } from "react-apollo";
import { client } from "../../../../App";
import UncategorisedProductsList from "../UncategorisedProductsList";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";

describe("UncategorisedProductsList snapshot test", () => {
    it("UncategorisedProductsList should match its snapshot", () => {
     const wrapper = mount(
        <GlobalContextProvider>
            <ApolloProvider client={client}>
                <UncategorisedProductsList props={""}/>
            </ApolloProvider>
        </GlobalContextProvider>);
     expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
});