import React, { useContext } from "react";
import { UncategorisedProductsListStyles } from "./UncategorisedProductsListStyles";
import BreadCrumb from "../../../UI/BreadCrumb";
import GlobalState from "../../../../Context/GlobalState";
import CategoryDataTable from "../CategoryDataTable";
import Search from "../../../Search/search";
import { SEARCH_CONTEXT } from "./../../../../Utilities/Constants";
import {productSearchStyle} from "./../../../../Utilities/CommonStyle";

export default function UncategorisedProductsList() {
    const styleClasses = UncategorisedProductsListStyles();

    const { value2, value3, value123, value152 } = useContext(GlobalState);
    const [, setIsProductCategoryTree] = value2;
    const [, setIsCreateCategory] = value3;
    const [, setShowLoader] = value123;
    const [, setShowUncategorisedProducts] = value152;

    const handleBreadCrumbClick = () => {
      setShowLoader(true);
      setTimeout(() => {
        setShowLoader(false);
      }, 300);
      setIsProductCategoryTree(true);
      setShowUncategorisedProducts(false);
      setIsCreateCategory(false);
    };
    
    return (
    <>
      <BreadCrumb
        breadCrumbLink={"Product Category"}
        breadCrumbTitle={"Uncategorised products"}
        style={styleClasses.breadCrumbStyle}
        handleClick={handleBreadCrumbClick}/>
      <div style={{position: "relative", marginBottom: "20px"}}>
        <Search searchContainerStyle={productSearchStyle()} searchContext={SEARCH_CONTEXT.uncategorisedProductCategories}/>
      </div>
      <CategoryDataTable searchTermContext={SEARCH_CONTEXT.uncategorisedProductCategories}/>
    </>
    );
}