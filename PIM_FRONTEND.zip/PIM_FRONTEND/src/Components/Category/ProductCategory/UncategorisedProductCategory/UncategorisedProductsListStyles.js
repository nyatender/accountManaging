import { makeStyles } from "@material-ui/styles";

export const UncategorisedProductsListStyles = makeStyles((theme) => ({
    breadCrumbStyle: {
        paddingLeft:"10px",
        fontSize:"14px",
        marginTop:"5px"
    },
}));