import React, { useContext } from "react";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";
import { listStyles } from "./ProductCategoryStyles";
import GlobalState from "../../../Context/GlobalState";
import userPermission from "../../../Utilities/userPermissionHook";
import {
  getHasDeletePermission,
  handleCategoryAttributeInEdit,
} from "../../../Utilities/CommonFunctions";
import AlertBox from "../../UI/AlertBox";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";

function CategorySearch({ searchResultData }) {
  const classes = listStyles();
  const {
    value2,
    value3,
    value4,
    value8,
    value9,
    value10,
    value11,
    value12,
    value36,
    value39,
    value38,
    value40,
    value41,
    value123,
    value145,
    value211,
    value152,
  } = useContext(GlobalState);
  const [, setIsProductCategoryTree] = value2;
  const [, setIsCreateCategory] = value3;
  const [, setText] = value4;
  const [, setIsEditCategory] = value8;
  const [, setCheckBoxValue] = value9;
  const [, setCategoryIdForEdit] = value10;
  const [, setParentCategoryId] = value11;
  const [checkedCategoryIdForDelete, setCheckedCategoryIdForDelete] = value12;
  const [, setCategoryChipData] = value36;
  const [, setShowAddSubCategory] = value39;
  const [, setCategoryEditChipData] = value38;
  const [, setShowAttributes] = value40;
  const [, setEditAttributeListData] = value41;
  const [, setShowLoader] = value123;
  const [listOfCategoryFromAPI] = value145;
  const [, setSelectedCategoryTailoringAttributes] = value211;
  const [, setShowUncategorisedProducts] = value152;

  const [role, , , , delePermission] = userPermission("category");

  const hasDeletePermission = getHasDeletePermission(role, delePermission);

  const handleCategoryClick = (category, categoryText) => {
    setShowLoader(true);
    setIsProductCategoryTree(false);
    setShowUncategorisedProducts(false);
    setTimeout(() => {
      setShowLoader(false);
    }, 2000);
    setCategoryIdForEdit(category.id);
    setIsCreateCategory(true);
    setText(categoryText);
    setIsEditCategory(true);
    category.isActive === false
      ? setCheckBoxValue(false)
      : setCheckBoxValue(true);
    setParentCategoryId(category.parentCategoryId);
    setCategoryChipData([]);
    setShowAddSubCategory(false);
    setShowAttributes(false);
    handleCategoryAttributeInEdit(
      category.id,
      listOfCategoryFromAPI,
      setEditAttributeListData,
      setCategoryEditChipData,
      setSelectedCategoryTailoringAttributes
    );
  };

  const handleCategoryCheck = (event, categoryId) => {
    var isChecked = event.target.checked;

    if (isChecked === true) {
      setCheckedCategoryIdForDelete((prevArray) => [...prevArray, categoryId]);
    }
    if (
      checkedCategoryIdForDelete.includes(categoryId) &&
      isChecked === false
    ) {
      setCheckedCategoryIdForDelete(
        checkedCategoryIdForDelete.filter((x) => x !== categoryId)
      );
    }
  };

  return (
    <>
      {searchResultData?.length > 0 ? (
        <List component="list" aria-label="search result" dense={true}>
          {searchResultData
            ?.sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text))
            ?.map((category, index) => (
              <ListItem button key={index} className={classes.listItemStyle}>
                {hasDeletePermission && (
                  <Checkbox
                    edge="start"
                    color="primary"
                    value={category.id}
                    onChange={(event) =>
                      handleCategoryCheck(event, category?.id)
                    }
                    tabIndex={-1}
                    disableRipple
                    checked={checkedCategoryIdForDelete.includes(category?.id)}
                  />
                )}
                <ListItemIcon className={classes.listIconStyle}>
                  <SubCategory width={"18px"} height={"14px"} />
                </ListItemIcon>
                <ListItemText
                  disableTypography
                  className={classes.listTextStyle}
                  primary={`${category.name[0].text}`}
                  onClick={() =>
                    handleCategoryClick(category, category?.name[0]?.text)
                  }
                ></ListItemText>
              </ListItem>
            ))}
        </List>
      ) : (
        <AlertBox message={"No data found"} severity="info" />
      )}
    </>
  );
}

export default CategorySearch;
