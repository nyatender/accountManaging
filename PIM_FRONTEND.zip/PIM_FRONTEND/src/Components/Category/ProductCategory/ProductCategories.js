import React, { useState, useContext } from "react";
import { productCategories } from "./ProductCategoryStyles";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import { ReactComponent as Plus } from "../../../Asset/plus.svg";
import GlobalState from "../../../Context/GlobalState";
import CategoryTree from "../ProductCategory/CategoryTree";
import CategoryDeletePopup from "./CategoryDeletePopup";
import Tooltip from "@material-ui/core/Tooltip";
import userPermission from "../../../Utilities/userPermissionHook";
import { getIsNotALocalAdminUser } from "../../../Utilities/CommonFunctions";
import Search from "../../UI/Search";
import CategorySearch from "./CategorySearch";

export default function ProductCategories() {
  const classes = productCategories();
  const {
    value2,
    value3,
    value4,
    value8,
    value36,
    value39,
    value145,
    value155,
    value152,
    value10,
  } = useContext(GlobalState);
  const [, setIsProductCategoryTree] = value2;
  const [, setIsCreateCategory] = value3;
  const [, setIsEditCategory] = value8;
  const [, setText] = value4;
  const [, setCategoryChipData] = value36;
  const [, setShowAddSubCategory] = value39;
  const [listOfCategoryFromAPI] = value145;
  const [userRole] = value155;
  const [, setShowUncategorisedProducts] = value152;
  const [, setCategoryId] = value10;

  const [searchTerm, setSearchTerm] = useState("");
  const [searchResult, setSearchResult] = useState([]);

  const handleSearchBoxChange = (event) => {
    setSearchTerm(event.target.value);
    const results = listOfCategoryFromAPI.filter(
      (category) =>
        category.state !== "DELETED" &&
        category.name !== null &&
        category.name[0]?.text !== null &&
        category?.name[0]?.text
          .toLowerCase()
          .includes(event.target.value.toLowerCase())
    );
    setSearchResult(results);
  };

  const handleClearSearch = () => {
    setSearchTerm("");
  };

  const [, createPermission, , , delePermission] = userPermission("category");

  const isNotALocalAdminUser = getIsNotALocalAdminUser(userRole);

  const handleCreateNewCategory = () => {
    setIsCreateCategory(true);
    setText("");
    setIsEditCategory(false);
    setCategoryChipData([]);
    setIsProductCategoryTree(false);
    setShowAddSubCategory(false);
    setShowUncategorisedProducts(false);
  };

  const renderCategoryData = () =>
    searchTerm.trim() !== "" ? (
      <CategorySearch searchResultData={searchResult} />
    ) : (
      <CategoryTree />
  );

  const handleUncategorisedProducts = () =>
  {
    setIsProductCategoryTree(false);
    setShowUncategorisedProducts(true);
    setIsCreateCategory(false);
    setIsEditCategory(false);
    setCategoryId(null);
  }

  return (
    <Grid container className={classes.root}>
      <Grid className={classes.actionItemsContainer} container item xs={12}>
        <Grid className='create-new' item style={{ paddingTop: "7px" }}>
          {isNotALocalAdminUser && createPermission && (
            <Tooltip title="Create New Root Category">
              <Button
                variant="contained"
                color="primary"
                size="medium"
                startIcon={<Plus />}
                onClick={handleCreateNewCategory}
              >
                Create New
              </Button>
            </Tooltip>
          )}
        </Grid>
        <Grid className='search-box' container>
          <Search
            className={classes.searchBox}
            width={"22vw"}
            searchTerm={searchTerm}
            handleSearch={handleSearchBoxChange}
            handleClearSearch={handleClearSearch}
          />
        </Grid>
        <Grid className='delete-icon' container style={{ paddingTop: "7px" }}>
          {isNotALocalAdminUser && delePermission && <CategoryDeletePopup setSearchTerm={setSearchTerm} />}
        </Grid>
      </Grid>
      <Grid item xs={12}>
       <Button
        className={classes.underlinedButton}
        color="primary"
        onClick={handleUncategorisedProducts}>
          View uncategorised products
        </Button>
      </Grid>
      <Grid item xs={12} className={classes.body}>
        {renderCategoryData()}
      </Grid>
    </Grid>
  );
}
