import React, { useContext, useState, useEffect } from "react";
import { addSubCategoryStyle, categoryHeaderStyle } from "./ProductCategoryStyles";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import { ReactComponent as Delete } from "../../../Asset/delete.svg";
import { ReactComponent as Save } from "../../../Asset/save.svg";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import GlobalState from "../../../Context/GlobalState";
import { useMutation } from "@apollo/react-hooks";
import { CREATE_CATEGORY } from "../../Query";
import RegexTextField from "../../UI/RegexTextField";
import { HandleEmptyTextField } from "./Properties";
import AddAttributeForCategory from "./AddAttributeForCategory";
import Tooltip from "@material-ui/core/Tooltip";
import BreadCrumb from "../../UI/BreadCrumb";
import Grid from "@material-ui/core/Grid";

export default function AddSubCategory() {
  const classes = addSubCategoryStyle();
  const headerClasses = categoryHeaderStyle();
  const {
    value2,
    value3,
    value4,
    value10,
    value28,
    value36,
    value37,
    value39,
    value58,
    value74,
    value81,
    value109,
    value146,
    value147
  } = useContext(GlobalState);
  const [addText, setAddText] = useState("");
  const [addChecked, setAddChecked] = useState(false);
  const [addHidden, setAddHidden] = useState(false);

  const [, setIsProductCategoryTree] = value2;
  const [, setIsCreateCategory] = value3;
  const [categoryName] = value4;
  const [categoryIdForEdit] = value10;
  const [, setTextFieldValidate] = value28;
  const [categoryAttributeChipData, setCategoryChipData] = value36;
  const [selectedChannelIDForHeader] = value37;
  const [, setShowAddSubCategory] = value39;
  const [selectedLanguageInHeader] = value58;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetCategoryTree] = value109;
  const [firstName] = value146;
  const [lastName] = value147;

  const onlyAlphanumericRegex = /[^a-z0-9-_' ]/gi;

  const [addNewSubTree] = useMutation(CREATE_CATEGORY, {
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while Creating a Category!",
        severity: "error",
      });
    },
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Category created succesfully",
        severity: "success",
      });
    },
  });

  useEffect(() => {
    handleAddHidden();
  }, [addChecked, addHidden]);

  const handleShowOrHideCategory = (event) => {
    setAddChecked((previousState) => !previousState);
  };

  const handleAddHidden = () => {
    addChecked === true ? setAddHidden(true) : setAddHidden(false);
  };

  const handleSave = async () => {
    if (addText === "") {
      setTextFieldValidate(true);
    } else {
      setShowOverlay(true);
      var supportedAttributeList = [];
      if (JSON.stringify(categoryAttributeChipData) !== "[]") {
        categoryAttributeChipData.map((attribute) => {
          const attributeValue = {
            id: attribute.key,
          };
          supportedAttributeList.push(attributeValue);
        });
      }
      if (JSON.stringify(categoryAttributeChipData) === "[]") {
        supportedAttributeList = null;
      }
      await addNewSubTree({
        variables: {
          category: [
            {
              parentCategoryId: categoryIdForEdit,
              name: [
                {
                  languageCode: selectedLanguageInHeader,
                  text: addText,
                },
              ],
              ranking: 1,
              isActive: addHidden,
              supportedAttributes: supportedAttributeList,
            },
          ],
          user: `${firstName} ${lastName}`,
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
        },
      });
      setResetCategoryTree(true);
      setAddText("");
      setShowAddSubCategory(false);
      setIsProductCategoryTree(true);
      setAddChecked(false);
      setCategoryChipData([]);
    }
  };

  const handleBreadCrumbClick = () => {
    setIsCreateCategory(true);
    setIsProductCategoryTree(false);
  };

  return (
    <>
      <div className={classes.root}>
        <BreadCrumb
          breadCrumbLink={categoryName}
          breadCrumbTitle={"Add Sub Category"}
          style={headerClasses.breadCrumbStyle}
          handleClick={handleBreadCrumbClick}
        />
        <Grid container>
          <Grid item xs={4} className={headerClasses.createEditTitleStyle}>
            <Typography
              component="h1"
              variant="h4"
              className={classes.typography}
            >
              Add Sub Category
            </Typography>
          </Grid>
          <Grid item xs={8} className={headerClasses.buttonHeaderStyle}>
            <IconButton
              classes={{ label: classes.iconButton1 }}
              onClick={handleSave}
            >
              <Save />
            </IconButton>
            <IconButton
              classes={{ label: classes.iconButton2 }}
              disabled={addText === ""}
              onClick={() => setAddText("")}
            >
              <Delete />
            </IconButton>
          </Grid>
        </Grid>
        <div className={classes.body}>
          <RegexTextField
            regex={onlyAlphanumericRegex}
            value={addText}
            label="Title *"
            onChange={(event) => {
              setAddText(event.target.value);
            }}
            style={{ width: "70%" }}
          />
        </div>
        <Tooltip title={addChecked ? "Hide Category" : "Show Category"}>
          <FormControlLabel
            control={
              <Checkbox
                checked={addChecked}
                onChange={handleShowOrHideCategory}
                name="checkedB"
                color="primary"
              />
            }
            label="Show"
            className={classes.body}
          />
        </Tooltip>
      </div>
      <AddAttributeForCategory />
      <HandleEmptyTextField />
    </>
  );
}
