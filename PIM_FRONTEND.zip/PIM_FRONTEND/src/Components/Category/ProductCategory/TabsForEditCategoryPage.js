import React, { useContext, useState, useEffect } from "react";
import { editCategoryStyle } from "./ProductCategoryStyles";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import GlobalState from "../../../Context/GlobalState";
import Divider from "@material-ui/core/Divider";
import RegexTextField from "../../UI/RegexTextField";
import { HandleEmptyTextField } from "./Properties";
import EditAttributeForCategory from "./EditAttributeForCategory";
import Tooltip from "@material-ui/core/Tooltip";
import { TabPanel } from "./../../Header/Tool";
import Tabs from "@material-ui/core/Tabs";
import { tabsGenerator } from "./../../../Utilities/CommonFunctions";
import { tabsGeneratorStyle } from "./../../Tailoring/TailoringStyles";
import { PRODUCT_CATEGORY_TABS, SEARCH_CONTEXT } from "./../../../Utilities/Constants";
import CategoryAtrributeTailoring from "./CategoryAttributeTailoring";
import CategoryDataTable from "./CategoryDataTable";
import { ReactComponent as Add } from "../../../Asset/pluse-purple.svg";
import ProductMultiDeletePopup from "../DeletePopup";
import ProductTableMenu from "../TableMenu";
import AddProductToCategoryPopup from "./AddProductToCategoryPopup/AddProductToCategoryPopup";
import Search from "../../Search/search";
import {productSearchStyle} from "./../../../Utilities/CommonStyle";

export default function TabsForEditCategoryPage({ editHidden, setEditHidden }) {
  const classes = editCategoryStyle();
  const tabClasses = tabsGeneratorStyle();
  const {
    value4,
    value9,
    value16,
    value37,
    value56,
    value216,
  } = useContext(GlobalState);

  const [editText, setEditText] = value4;
  const [editChecked, setEditChecked] = value9;
  const [checkedRowsInTable] = value16;
  const [selectedChannelIDForHeader] = value37;
  const [globalChannelID] = value56;
  const [, setOpenAddProductToCategoryPopup] = value216;
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const onlyAlphanumericRegex = /[^a-z0-9-_' ]/gi;

  useEffect(() => {
    handleEditHidden();
  }, [editChecked, editHidden]);
  
  const handleEditChange = async (event) => {
    await setEditChecked((previousState) => !previousState);
  };

  const handleEditHidden = () => {
    editChecked === true ? setEditHidden(true) : setEditHidden(false);
  };

  const handleShowAddProductPopup = () => {
    setOpenAddProductToCategoryPopup(true)
  }

  const renderButtonsOnTableCheck = () => {
    return (
      checkedRowsInTable?.length > 0 && (
        <div style={{ marginTop: "7px", display: "flex" }}>
          <ProductTableMenu showMove={true} />
          <ProductMultiDeletePopup />
        </div>
      )
    );
  };

  const renderProductTableButton = () => {
    return (
      <Grid
        container
        item
        style={{
          display: "flex",
          flexGrow: 8,
          justifyContent: "flex-end",
          flexBasis: '80%',
          paddingRight: '24px'
        }}
      >
        <Tooltip title="Add Product(s)">
          <IconButton onClick={handleShowAddProductPopup}>
            <Add width="20px" />
          </IconButton>
        </Tooltip>
        {renderButtonsOnTableCheck()}
      </Grid>
    );
  };

  return (
    <div>
      <div style={{ display: "flex" }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="static tabs"
          indicatorColor="primary"
          textColor="primary" >
          {tabsGenerator(PRODUCT_CATEGORY_TABS, tabClasses.tabText)}
        </Tabs>
        {value === 0 && renderProductTableButton()}
      </div>
      <Divider />
      <TabPanel value={value} index={0}>
        <div style={{ position: "relative", marginTop: "0px", paddingBottom: 15 }}>
          <Search searchContainerStyle={productSearchStyle()} searchContext={SEARCH_CONTEXT.categoryProductSearch} />
        </div>
        <CategoryDataTable searchTermContext={SEARCH_CONTEXT.categoryProductSearch} />
      </TabPanel>
      <TabPanel value={value} index={1} className={""}>
        <div className={classes.body}>
          <RegexTextField
            regex={onlyAlphanumericRegex}
            value={editText}
            label="Title *"
            onChange={(event) => {
              setEditText(event.target.value);
            }}
            style={{ width: "70%" }} />
        </div>
        <Tooltip title={editChecked ? "Hide Category" : "Show Category"}>
          <FormControlLabel
            control={
              <Checkbox
                checked={editChecked}
                onChange={handleEditChange}
                name="checkedB"
                color="primary" />
            }
            label="Show"
            className={classes.body} />
        </Tooltip>

        {globalChannelID === selectedChannelIDForHeader && (
          <EditAttributeForCategory />
        )}
        <HandleEmptyTextField />
      </TabPanel>
      <TabPanel value={value} index={2} className={""}>
        <CategoryAtrributeTailoring />
      </TabPanel>
      <AddProductToCategoryPopup />
    </div>
  );
}