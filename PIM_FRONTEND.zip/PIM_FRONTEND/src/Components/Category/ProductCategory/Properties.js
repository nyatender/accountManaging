import React, { useContext, useState, useEffect } from "react";
import { propertiesStyle, textFieldAlertStyle, categoryHeaderStyle } from "./ProductCategoryStyles";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import { ReactComponent as Delete } from "../../../Asset/delete.svg";
import { ReactComponent as Save } from "../../../Asset/save.svg";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import GlobalState from "../../../Context/GlobalState";
import { useMutation } from "@apollo/react-hooks";
import { CREATE_CATEGORY } from "../../Query";
import RegexTextField from "../../UI/RegexTextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Button from "@material-ui/core/Button";
import Alert from "@material-ui/lab/Alert";
import FormLabel from "@material-ui/core/FormLabel";
import AddAttributeForCategory from "./AddAttributeForCategory";
import Tooltip from "@material-ui/core/Tooltip";
import BreadCrumb from "../../UI/BreadCrumb";
import Grid from "@material-ui/core/Grid";

export function HandleEmptyTextField() {
  const { value28 } = useContext(GlobalState);
  const classes = textFieldAlertStyle();
  const [textFieldValidate, setTextFieldValidate] = value28;

  const handleClose = () => {
    setTextFieldValidate(false);
  };

  return (
    <Dialog
      open={textFieldValidate}
      onClose={handleClose}
      maxWidth="xs"
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle className={classes.title} disableTypography>
        Alert{" "}
      </DialogTitle>
      <DialogContent>
        <DialogContentText
          id="alert-dialog-description"
          className={classes.errorPopupTitle}
        >
          <Alert severity="error" className={classes.errorAlertText}>
            <FormLabel style={{ fontSize: "17px" }}>
              <strong>Category Title </strong> Field cannot be Empty, please
              enter the Title!
            </FormLabel>
          </Alert>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={classes.dialogAction}>
        <Button variant="contained" color="primary" onClick={handleClose}>
          OK
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default function Properties() {
  const classes = propertiesStyle();
  const headerClasses = categoryHeaderStyle();
  const {
    value2,
    value4,
    value3,
    value28,
    value36,
    value37,
    value58,
    value74,
    value81,
    value109,
    value146,
    value147,
    value123,
  } = useContext(GlobalState);
  const [, setIsProductCategoryTree] = value2;
  const [text, setText] = value4;
  const [checked, setChecked] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [, setIsCreateCategory] = value3;
  const [, setTextFieldValidate] = value28;
  const [categoryAttributeChipData, setCategoryChipData] = value36;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetCategoryTree] = value109;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setShowLoader] = value123;

  const [rootTree] = useMutation(CREATE_CATEGORY, {
    onCompleted: () => {
      setResetCategoryTree(true);
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Category created succesfully",
        severity: "success",
      });
    },
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while Creating a Category!",
        severity: "error",
      });
    },
  });
  const onlyAlphanumericRegex = /[^a-z0-9-_' ]/gi;

  useEffect(() => {
    console.log(checked + "inside effect");
    handleHidden();
    console.log(hidden + ": hidden");
  }, [checked, hidden]);

  const handleChange = (event) => {
    setChecked((previousState) => !previousState);
    console.log(checked);
  };

  const handleHidden = () => {
    checked === true ? setHidden(true) : setHidden(false);
  };

  const handleSave = async () => {
    if (text === "") {
      setTextFieldValidate(true);
    } else {
      setShowOverlay(true);
      var supportedAttributeList = [];
      if (JSON.stringify(categoryAttributeChipData) !== "[]") {
        categoryAttributeChipData.map((attribute) => {
          const attributeValue = {
            id: attribute.key,
          };
          supportedAttributeList.push(attributeValue);
        });
      }
      if (JSON.stringify(categoryAttributeChipData) === "[]") {
        supportedAttributeList = null;
      }
      await rootTree({
        variables: {
          category: [
            {
              parentCategoryId: null,
              name: [{ languageCode: selectedLanguageInHeader, text: text }],
              isActive: hidden,
              supportedAttributes: supportedAttributeList,
            },
          ],
          user: `${firstName} ${lastName}`,
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
        },
      });
      handleBreadCrumbClick()
    }
  };

  const handleBreadCrumbClick = () => 
  {
    setShowLoader(true);
    setTimeout(() => {
      setShowLoader(false);
    }, 300);
    setIsProductCategoryTree(true);
    setIsCreateCategory(false);
    setText("");
    setCategoryChipData([]);
  };

  return (
    <div className={classes.root}>
      <BreadCrumb
        breadCrumbLink={"Product Category"}
        breadCrumbTitle={"Add Root Category"}
        style={headerClasses.breadCrumbStyle}
        handleClick={handleBreadCrumbClick}/>
      <Grid container>
        <Grid item xs={4} className={headerClasses.createEditTitleStyle}>
          <Typography
            component="h1"
            variant="h4"
            className={classes.typography}>
            Add Root Category
          </Typography>
        </Grid>
        <Grid item xs={8} className={headerClasses.buttonHeaderStyle}>
          <Tooltip title="Save Root Category">
            <IconButton
              classes={{ label: classes.iconButton1 }}
              onClick={handleSave}>
              <Save />
            </IconButton>
          </Tooltip>
          <IconButton
            classes={{ label: classes.iconButton2 }}
            disabled={text === ""}
            onClick={() => setText("")} >
            <Delete />
          </IconButton>
        </Grid>
      </Grid>
      <div className={classes.body}>
        <RegexTextField
          regex={onlyAlphanumericRegex}
          value={text}
          label="Title *"
          onChange={(event) => {
            setText(event.target.value);
          }}
          style={{ width: "70%" }} />
      </div>
      <Tooltip title={checked ? "Hide Category" : "Show Category"}>
        <FormControlLabel
          control={
            <Checkbox onChange={handleChange} name="checkedB" color="primary" />
          }
          label="Show"
          className={classes.formControlLabelStyle}/>
      </Tooltip>
      <AddAttributeForCategory />
      <HandleEmptyTextField />
    </div>
  );
}