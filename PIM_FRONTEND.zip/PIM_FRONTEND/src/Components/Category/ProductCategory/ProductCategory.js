import React, { useContext } from "react";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import { productCategory } from "./ProductCategoryStyles";
import ProductCategories from "../ProductCategory/ProductCategories";
import EditCategory from "../ProductCategory/EditCategoryProperties";
import CreateCategory from "../ProductCategory/Properties";
import GlobalState from "../../../Context/GlobalState";
import Overlay from "../../UI/Overlay";
import AddSubCategory from "./AddSubCategory";
import UncategorisedProductsList from "./UncategorisedProductCategory/UncategorisedProductsList";

export default function ProductCategory() {
  const classes = productCategory();
  const 
  { 
    value2, 
    value3, 
    value8, 
    value39, 
    value123,
    value152,
  } = useContext(GlobalState);
  const [isProductCategoryTree] = value2;
  const [isCreatCategory] = value3;
  const [isEditCategory] = value8;
  const [showAddSubCategory] = value39;
  const [showLoader] = value123;
  const [showUncategorisedProducts] = value152;

  const handleCategoryPageDisplay = () => {
    if (isProductCategoryTree)
    {
      if (showLoader) return <Overlay />;
      else return <ProductCategories />;
    }
    else if (showUncategorisedProducts) return <UncategorisedProductsList/>
    else if (isCreatCategory === true && isEditCategory === true) 
    {
      if (showLoader) return <Overlay />;
      else return <EditCategory />;
    } 
    else if (isCreatCategory === true && isEditCategory === false) return <CreateCategory />;
    else if (showAddSubCategory) return <AddSubCategory />;
  };

  return (
    <>
      <Grid container className={classes.container}>
        <Grid item className={classes.item} sm={12}>
          <Paper className={classes.paper}>
            <div className={classes.divStyle}>
              {handleCategoryPageDisplay()}
            </div>
          </Paper>
        </Grid>
      </Grid>
    </>
  );
}