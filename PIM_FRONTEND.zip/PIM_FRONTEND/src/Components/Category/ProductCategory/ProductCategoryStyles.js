import { makeStyles } from "@material-ui/styles";


export const propertiesStyle = makeStyles((theme) => ({
  typography: {
    textAlign: "center",
    fontSize: "22px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingTop: "15px",
  },
  header: {
    display: "flex",
    justifyContent: "flex-end",
  },
  iconButton1: {
    width: "20px",
  },
  iconButton2: {
    width: "25px",
  },
  body: {
    paddingTop: "50px",
    paddingLeft: "20px",
  },
  formControlLabelStyle: {
    paddingTop: "20px",
    paddingLeft: "20px",
  },
  buttonDivStyle: {
    paddingTop: "20px",
    paddingLeft: "22px",
    paddingBottom: "10px",
  },
  addButtonStyle: {
    borderRadius: "8px",
    background: "#7000FF",
    color: "white",
    textTransform: "none",
    width: "150px",
    fontSize: "14px",
    height: "30px",
    "&:hover": {
      background: "#7000FF",
      color: "#FFFFFF !important",
    },
  },
  chipsList: {
    display: "flex",
    justifyContent: "center",
    flexWrap: "wrap",
    listStyle: "none",
    margin: 0,
  },
  divStyle: {
    paddingLeft: "20px",
    paddingTop: "10px",
  },
  attributeListStyle: {
    width: "90%",
    position: "relative",
    overflow: "auto",
    maxHeight: 200,
    border: "1px solid #EBE9E7 ",
    paddingLeft: "10px",
  },
}));

export const textFieldAlertStyle = makeStyles((theme) => ({
  buttonOk: {
    backgroundColor: "#7000FF",
    borderRadius: "8px",
    opacity: "1",
    textAlign: "left",
    fontSize: "18px",
    lineHeight: "24px",
    letterSpacing: "0px",
    color: "#FFFFFF !important",
    textTransform: "none",
    width: "160px",
    height: "46px",
    right: "150px",
    bottom: "5px",
    "&:hover": {
      background: "#7000FF",
      color: "#FFFFFF !important",
    },
  },
  dialogAction: {
    justifyContent: "center",
  },
  errorAlertText: {
    // textAlign: "center",
    paddingLeft: "5px",
    fontColor: "black",
  },
  errorPopupTitle: {
    textAlign: "left",
    fontSize: "24px",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  text: {
    textAlign: "center",
    fontSize: "18px",
    lineHeight: "27px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingBottom: "20px",
  },
  title: {
    textAlign: "left",
    fontSize: "28px",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
}));

export const addSubCategoryStyle = makeStyles((theme) => ({
  typography: {
    textAlign: "center",
    fontSize: "22px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingTop: "15px",
  },
  header: {
    display: "flex",
    justifyContent: "flex-end",
  },
  iconButton1: {
    width: "20px",
  },
  iconButton2: {
    width: "25px",
  },
  body: {
    paddingTop: "20px",
    paddingLeft: "20px",
  },
  root: {
    paddingTop: "5px",
  },
}));

export const editCategoryStyle = makeStyles((theme) => ({
  typography: {
    textAlign: "center",
    fontSize: "22px",
    lineHeight: "19px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingTop: "15px",
    paddingBottom: "10px",
  },
  typography2: {
    textAlign: "center",
    fontSize: "20px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingTop: "15px",
    paddingBottom: "10px",
  },
  typography3: {
    textAlign: "center",
    fontSize: "22px",
    lineHeight: "19px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingTop: "15px",
    paddingBottom: "10px",
  },
  header: {
    display: "flex",
    justifyContent: "flex-end",
  },
  iconButton1: {
    width: "20px",
  },
  iconButton2: {
    width: "25px",
  },
  iconButton3: {
    width: "22px",
  },
  body: {
    paddingTop: "50px",
    paddingLeft: "20px",
  },
}));

export const categoryHeaderStyle = makeStyles(() => ({
  createEditTitleStyle: {
    display: "flex",
    justifyContent: "flex-start",
    paddingLeft: "12px",
    alignItems: "center",
    marginBottom: "5px",
    marginTop: "-5px"
  },
  buttonHeaderStyle: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  breadCrumbStyle: {
    paddingLeft: "10px",
    fontSize: "14px",
    marginTop: "5px"
  },
}))

export const productCategory = makeStyles((theme) => ({
  paper: {
    padding: "8px",
    height: "90vh",
    position: "relative",
    paddingTop: "30px",
    borderBottom: "none",
  },
  typography: {
    textAlign: "center",
    fontSize: "25px",
    lineHeight: "19px",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    fontWeight: "Regular",
    paddingRight: "410px",
    paddingTop: "10px",
  },
  divStyle: {
    flexGrow: "1",
    overflow: "auto",
    minHeight: "100%",
    minWidth: "100%",
    height: "100%",
    width: "100%",
  },
}));

export const productCategories = makeStyles((theme) => ({
  searchBox: {
    marginRight: "10px",
    marginTop: "7px"
  },
  header: {
    display: "flex",
    justifyContent: "flex-end",
  },
  iconButton1: {
    width: "20px",
  },
  iconButton2: {
    width: "25px",
  },
  body: {
    paddingTop: "10px",
  },
  underlinedButton: {
    position: "relative",
    marginTop: "15px",
    marginRight: "5px",
    float:"right", 
    textDecoration: "underline", 
    fontWeight: "Bold",
  },
  actionItemsContainer: {
    flexWrap: 'nowrap',
    '& .create-new': {
      display: 'flex',
      flexBasis: '100px',
      flexGrow: 3,
      '& button': {
        maxHeight: '36px'
      }
    },
    '& .search-box': {
      flexBasis: '500px',
      flexGrow: 5,
      justifyContent: 'flex-end'
    },
    '& .delete-icon': {
      display: 'flex',
      flexBasis: '40px',
      justifyContent: 'flex-end'
    }
  },
}));

export const listStyles = makeStyles((theme) => ({
  listTextStyle: {
    textAlign: "left",
    fontSize: "17px",
    fontWeight: "Regular",
    letterSpacing: "0px",
    color: "#7000FF",
    opacity: "1",
    "&:hover": {
      color: "#7000FF",
    },
  },

  listItemStyle: {
    background: "#FAFAFA",
    height: "44px",
    marginTop: "10px",
  },

  listIconStyle: {
    width: "25px",
    minWidth: "0px"
  }
}));