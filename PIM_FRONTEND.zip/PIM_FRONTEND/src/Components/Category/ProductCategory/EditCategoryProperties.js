import React, { useContext, useState } from "react";
import { editCategoryStyle, categoryHeaderStyle } from "./ProductCategoryStyles";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import { ReactComponent as Save } from "../../../Asset/save.svg";
import GlobalState from "../../../Context/GlobalState";
import { useMutation, useQuery } from "@apollo/react-hooks";
import { UPDATE_CATEGORY } from "../../Query";
import CategorySingleDeletePopup from "./CategorySingleDeletePopup";
import Tooltip from "@material-ui/core/Tooltip";
import Grid from "@material-ui/core/Grid";
import { ReactComponent as Add } from "../../../Asset/pluse-purple.svg";
import BreadCrumb from "../../UI/BreadCrumb";
import AlertDialog from "../../UI/AlertDialog";
import { dialogTitle } from "./../../../Utilities/Constants";
import { transformTailoredAttributes, handleMandatoryAttribute , handleIsDateValid , handleIsDataValueEmptyString , handleIsMultiSelectEmpty } from "./../../../Utilities/CommonFunctions";
import TabsForEditCategoryPage from "./TabsForEditCategoryPage";
import { GET_ALL_ATTRIBUTES } from "./../../Query";

export default function EditCategoryProperties() {
  const classes = editCategoryStyle();
  const headerClasses = categoryHeaderStyle();
  const {
    value2,
    value3,
    value4,
    value10,
    value11,
    value28,
    value37,
    value38,
    value39,
    value56,
    value58,
    value74,
    value81,
    value109,
    value146,
    value147,
    value211,
    value123,
  } = useContext(GlobalState);

  const [, setIsProductCategoryTree] = value2;
  const [editText] = value4;
  const [categoryIdForEdit] = value10;
  const [parentCategoryId] = value11;
  const [, setIsCreateCategory] = value3;
  const [, setTextFieldValidate] = value28;
  const [selectedChannelIDForHeader] = value37;
  const [categoryEditAttributeChipData, setCategoryChipData] = value38;
  const [, setShowAddSubCategory] = value39;
  const [globalChannelID] = value56;
  const [selectedLanguageInHeader] = value58;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetCategoryTree] = value109;
  const [firstName] = value146;
  const [lastName] = value147;
  const [selectedCategoryTailoringAttributes] = value211;
  const [, setShowLoader] = value123;

  const [editHidden, setEditHidden] = useState(false);
  const [categoryName] = useState(editText);
  const [isAlertDialogOpen, setIsAlertDialogOpen] = useState(false);
  const [setOpen] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');

  const { data: attributeData } = useQuery(GET_ALL_ATTRIBUTES, {
    variables: {
      filter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
  });

  const [editTree] = useMutation(UPDATE_CATEGORY, {
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while Updating a Category!",
        severity: "error",
      });
    },
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Category Edited succesfully",
        severity: "success",
      });
    },
  });

  const handleSave = async () => {
    if (editText === "") {
      setTextFieldValidate(true);
    } else {
      var supportedAttributeList = [];

      categoryEditAttributeChipData?.map((attribute) => {
        const attributeValue = {
          id: attribute.key,
        };
        supportedAttributeList.push(attributeValue);
      });
      const errors = [];
      selectedCategoryTailoringAttributes?.forEach(tailoredAttribute => {
        const attribute = attributeData?.attributes.getAllAttributes.filter(attributeVal => attributeVal.attributeId === tailoredAttribute.attributeId);
        const { isMandatory } =  attribute?.length > 0 && attribute[0];
        const dataValue = handleMandatoryAttribute(tailoredAttribute)
        const isDateValid = handleIsDateValid(dataValue);

        const multiSelectEmpty = handleIsMultiSelectEmpty(dataValue);
        const isDataValueEmptyString = handleIsDataValueEmptyString(dataValue);
        const isTailoredAttributeAssociated = categoryEditAttributeChipData.some(data => data.key === tailoredAttribute.attributeId);
        if (isMandatory && (!dataValue || !isDateValid || multiSelectEmpty || isDataValueEmptyString) && isTailoredAttributeAssociated) {
          errors.push(attribute[0].name[0].text);
        }
      });
      if (errors?.length > 0 && supportedAttributeList?.length > 0) {
        handleOpen();
        const alertInfoStr = <Typography><strong>{errors.join(', ')}</strong> field(s) cannot be Empty, please enter the values!</Typography>;
        setAlertMessage(alertInfoStr);
        return;
      }
      setShowOverlay(true);
      const tailoredAttributes = transformTailoredAttributes(selectedCategoryTailoringAttributes);
      await editTree({
        variables: {
          category: [
            {
              id: categoryIdForEdit,
              parentCategoryId: parentCategoryId,
              name: [
                {
                  languageCode: selectedLanguageInHeader,
                  text: editText,
                },
              ],
              ranking: 1,
              isActive: editHidden,
              supportedAttributes: supportedAttributeList,
              tailoringAttributes: tailoredAttributes,
            },
          ],
          user: `${firstName} ${lastName}`,
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
        },
      });
      setResetCategoryTree(true);
    }
  };

  const handleAddButtonClick = () => {
    setShowAddSubCategory(true);
    setIsProductCategoryTree(false);
    setIsCreateCategory(false);
    setShowAddSubCategory(true);
    setCategoryChipData([]);
  };

  const renderAddSubCategory = () => {
    return (
      <Tooltip title="Add Sub Category">
        <IconButton onClick={handleAddButtonClick}>
          <Add width="20px" />
        </IconButton>
      </Tooltip>
    );
  };

  const handleBreadCrumbClick = () => {
    setShowLoader(true);
    setTimeout(() => {
      setShowLoader(false);
    }, 300);
    setIsProductCategoryTree(true);
    setIsCreateCategory(false);
  };

  const handleClose = () => {
    setOpen(false);
    setIsAlertDialogOpen(false);
  };

  const handleOpen = () => {
    setIsAlertDialogOpen(true);
  };

  return (
    <div className={classes.root}>
      <Grid container>
        <Grid item xs={4}>
          <BreadCrumb
            breadCrumbLink={"Product Category"}
            breadCrumbTitle={categoryName}
            style={headerClasses.breadCrumbStyle}
            handleClick={handleBreadCrumbClick}
          />
        </Grid>
        <Grid item xs={8} className={headerClasses.buttonHeaderStyle}>
          <IconButton
            classes={
              globalChannelID === selectedChannelIDForHeader
                ? { label: classes.iconButton1 }
                : { label: classes.iconButton3 }
            }
            onClick={handleSave}
          >
            <Save />
          </IconButton>
          {globalChannelID === selectedChannelIDForHeader && (
            <>
              {renderAddSubCategory()}
              <CategorySingleDeletePopup />
            </>
          )}
        </Grid>
      </Grid>
      <Grid container>
        <Grid item xs={4} className={headerClasses.createEditTitleStyle}>
          <Typography
            component="h1"
            variant="h4"
            className={
              globalChannelID === selectedChannelIDForHeader
                ? classes.typography
                : classes.typography3
            }
          >
            {categoryName}
          </Typography>
        </Grid>
      </Grid>
      <TabsForEditCategoryPage
        editHidden={editHidden}
        setEditHidden={setEditHidden}
      />
      <AlertDialog
        isDialogOpen={isAlertDialogOpen}
        handleClose={handleClose}
        alertType={dialogTitle.ALERT}
        alertMessage={alertMessage} />
    </div>
  );
}
