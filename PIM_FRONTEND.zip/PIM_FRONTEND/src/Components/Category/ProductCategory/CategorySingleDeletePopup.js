import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import IconButton from "@material-ui/core/IconButton";
import { ReactComponent as Delete } from "../../../Asset/delete.svg";
import { ReactComponent as DisabledDelete } from "../../../Asset/disabled_delete.svg"
import { ReactComponent as DeletePopup } from "../../../Asset/deletePopup.svg";
import { popUpStyle } from "../CategoryStyles";
import { useMutation } from "@apollo/react-hooks";
import { DELETE_CATEGORY } from "../../Query";
import GlobalState from "../../../Context/GlobalState";
import { Tooltip } from "@material-ui/core";
import { dialogMessage, dialogTitle } from "../../../Utilities/Constants";

export default function CategorySingleDeletePopup() {
  const classes = popUpStyle();
  const [open, setOpen] = React.useState(false);
  const { value2, value3, value10, value12, value37, value58, value74, value81, value109, value146, value147, value225 } =
    useContext(GlobalState);
    const [, setIsProductCategoryTree] = value2;
  const [, setIsCreateCategory] = value3;
  const [categoryIdForEdit] = value10;
  const [, setCheckedKeyDelete] = value12;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetCategoryTree] = value109;
  const [firstName] = value146;
  const [lastName] = value147;
  const [categoryState] = value225

  const [deleteTreeNode] = useMutation(DELETE_CATEGORY, {
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while Deleting a Category!",
        severity: "error",
      });
    },
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Category Deleted succesfully",
        severity: "success",
      });
    },
  });

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setCheckedKeyDelete([]);
  };

  const handleDelete = async () => {
    setShowOverlay(true);
    await deleteTreeNode({
      variables: {
        category: [{ id: categoryIdForEdit }],
        user: `${firstName} ${lastName}`,
        channelFilter: {
          channelId: selectedChannelIDForHeader,
          languageCode: selectedLanguageInHeader,
        },
      },
    });
    setResetCategoryTree(true);
    setCheckedKeyDelete([]);
    setOpen(false);
    setIsCreateCategory(false);
    setIsProductCategoryTree(true);
  };

  return (
    <div>
      {categoryState === 'RESTRICT_DELETE' ? 
       <Tooltip title="Disabled as this is the Root Category" disableFocusListener disableTouchListener>
        <IconButton size="small" disableRipple style={{cursor: 'default', backgroundColor: 'transparent'}} >
          <DisabledDelete width={"25px"}  />
        </IconButton>
       </Tooltip> :
       <Tooltip title="Delete selected category">
        <IconButton color="primary" onClick={handleClickOpen} size="small" >
          <Delete width={"25px"}  />
        </IconButton>
       </Tooltip>
      }
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="xs"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle className={classes.title}>{dialogTitle.CONFIRMATION}</DialogTitle>
        <DialogContent>
          <DeletePopup className={classes.deleteImage} />

          <DialogContentText
            id="alert-dialog-description"
            className={classes.text}
          >
          {dialogMessage.DELETE_CATEGORY_MSG}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" color="primary" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={handleDelete}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
