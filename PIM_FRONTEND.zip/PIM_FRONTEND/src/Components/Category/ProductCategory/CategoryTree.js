import React, { useContext, useEffect } from "react";
import Tree, { TreeNode } from "rc-tree";
import "rc-tree/assets/index.css";
import "../treeStyle.css";
import { treeViewStyles } from "../CategoryStyles";
import { ReactComponent as Folder } from "../../../Asset/category.svg";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";
import GlobalState from "../../../Context/GlobalState";
import { useQuery, useMutation } from "@apollo/react-hooks";
import { GET_CATEGORY_TREE, MOVE_CATEGORY_WITHIN_TREE } from "../../Query";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";
import userPermission from "../../../Utilities/userPermissionHook";
import {
  getHasDeletePermission,
  switcherIcon,
  handleCategoryAttributeInEdit
} from "../../../Utilities/CommonFunctions";
import { Grid } from "@material-ui/core";

export default function CategoryTree() {
  const classes = treeViewStyles();

  const {
    value2,
    value3,
    value4,
    value8,
    value9,
    value10,
    value11,
    value12,
    value36,
    value39,
    value38,
    value37,
    value40,
    value41,
    value58,
    value74,
    value81,
    value109,
    value123,
    value145,
    value146,
    value147,
    value211,
    value225
  } = useContext(GlobalState);
  const [, setIsProductCategoryTree] = value2;
  const [, setIsCreateCategory] = value3;
  const [, setText] = value4;
  const [, setIsEditCategory] = value8;
  const [, setCheckBoxValue] = value9;
  const [, setCategoryIdForEdit] = value10;
  const [, setParentCategoryId] = value11;
  const [checkedCategoryIdForDelete, setCheckedCategoryIdForDelete] = value12;
  const [, setCategoryChipData] = value36;
  const [, setShowAddSubCategory] = value39;
  const [, setCategoryEditChipData] = value38;
  const [selectedChannelIDForHeader] = value37;
  const [, setShowAttributes] = value40;
  const [, setEditAttributeListData] = value41;
  const [selectedLanguageInHeader] = value58;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [resetCategoryTree, setResetCategoryTree] = value109;
  const [, setShowLoader] = value123;
  const [listOfCategoryFromAPI, setListOfCategoryFromAPI] = value145;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setSelectedCategoryTailoringAttributes] = value211;
  const [, setCategoryState] = value225


  const [role, , , , delePermission] = userPermission("category");

  const hasDeletePermission = getHasDeletePermission(role, delePermission);

  const [dragAndDrop] = useMutation(MOVE_CATEGORY_WITHIN_TREE, {
    onError: (e) => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while Drag and Drop",
        severity: "error",
      });
    },
    onCompleted: () => {
      setResetCategoryTree(true);
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Category Drag and Drop is successful",
        severity: "success",
      });
    },
  });

  const includeCategoryDetails = true;

  const { loading, error, data, refetch } = useQuery(GET_CATEGORY_TREE, {
    variables: {
      includeCategoryDetails,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
   notifyOnNetworkStatusChange: true,
  });

  useEffect(() => {
    console.log({ checkedCategoryIdForDelete } + "inside effect");

    if (
      selectedChannelIDForHeader !== null &&
      selectedChannelIDForHeader !== undefined &&
      includeCategoryDetails !== null &&
      resetCategoryTree !== false &&
      selectedLanguageInHeader !== null &&
      selectedLanguageInHeader !== undefined
    ) {
      refetch();
    }
  }, [
    checkedCategoryIdForDelete,
    selectedChannelIDForHeader,
    selectedLanguageInHeader,
    resetCategoryTree,
  ]);

  const onSelect = async (info, obj) => {
    await setCategoryState(obj.node.value?.state)
    await setShowLoader(true);
    await setIsProductCategoryTree(false);
    setTimeout(() => {
      setShowLoader(false);
    }, 2000);
    await setCategoryIdForEdit(obj.node.key);
    await setIsCreateCategory(true);
    await setText(obj.node.value?.name[0]?.text);
    await setIsEditCategory(true);
    obj.node.value.isActive === false
      ? await setCheckBoxValue(false)
      : await setCheckBoxValue(true);
    await setParentCategoryId(obj.node.value.parentCategoryId);
    await setCategoryChipData([]);
    await setShowAddSubCategory(false);
    await setShowAttributes(false);
    handleCategoryAttributeInEdit(
      obj.node.key,
      listOfCategoryFromAPI,
      setEditAttributeListData,
      setCategoryEditChipData,
      setSelectedCategoryTailoringAttributes
    );
  };

  const onDragStart = (info) => {
    console.log("start", info);
  };

  const onDragEnter = (info) => {
    console.log("enter", info);
  };

  const onDrop = (info) => {
    setShowOverlay(true);
    const parentKey = info.dragNode.value.parentCategoryId;
    console.log("drop", info);
    const dropKey = info.node.props.eventKey;
    const dropParentId = info.node.props.value.parentCategoryId;
    const dragKey = info.dragNode.props.eventKey;
    const dropPos = info.node.props.pos.split("-");
    const dropPosition =
      info.dropPosition - Number(dropPos[dropPos?.length - 1]);

    dragAndDrop({
      variables: {
        category: [{ id: dragKey, parentCategoryId: parentKey }],
        destinationCategory: { id: dropKey, parentCategoryId: dropParentId },
        position: dropPosition,
        user: `${firstName} ${lastName}`,
        channelFilter: {
          channelId: selectedChannelIDForHeader,
          languageCode: selectedLanguageInHeader,
        },
      },
    });
  };

  const onCheck = (checkedKeys, info) => {
    setCheckedCategoryIdForDelete(checkedKeys.checked);
  };

  const renderLeafCategoryTreeNode = (dataTree, id) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === id) {
          return (
            <React.Fragment
              style={{ display: "flex", justifyContent: "space-evenly" }}
            >
              <TreeNode
                title={<span className={classes.title}>{i.text}</span>}
                key={item.id}
                value={item}
                disableCheckbox={item.state === 'RESTRICT_DELETE'}
                style={{
                  marginTop: "10px",
                  paddingTop: "10px",
                  background: "#FAFAFA",
                  height: "44px",
                }}
                icon={<SubCategory className={classes.subCatgeoryStyle} />}
              >
                {renderParentChildCategoryTreeNode(dataTree, item.id)}
              </TreeNode>
            </React.Fragment>
          );
        }
        return null;
      });
    });
  };

  const renderParentChildCategoryTreeNode = (dataTree, id) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId !== null && item.parentCategoryId === id) {
          return (
            <React.Fragment style={{ display: "flex" }}>
              <TreeNode
                title={<span className={classes.title}>{i.text}</span>}
                key={item.id}
                value={item}
                disableCheckbox={item.state === 'RESTRICT_DELETE'}
                style={{
                  marginTop: "10px",
                  paddingTop: "10px",
                  background: "#FAFAFA",
                  height: "44px",
                }}
                icon={<SubCategory className={classes.subCatgeoryStyle} />}
              >
                {renderLeafCategoryTreeNode(dataTree, item.id)}
              </TreeNode>
            </React.Fragment>
          );
        }
        return null;
      });
    });
  };

  const renderRootCategoryTreeNode = (dataTree) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === null) {
          return (
            <React.Fragment
              style={{
                display: "flex",
                marginBottom: "20px",
                marginTop: "20px",
              }}
            >
              <TreeNode
                title={<span className={classes.title2}>{i.text}</span>}
                key={item.id}
                value={item}
                disableCheckbox={item.state === 'RESTRICT_DELETE'}
                style={{
                  marginTop: "10px",
                  paddingLeft: "5px",
                  paddingTop: "10px",
                  background: "#FAFAFA",
                  height: "44px",
                }}
                icon={<Folder className={classes.folderStyle} />}
              >
                {renderParentChildCategoryTreeNode(dataTree, item.id)}
              </TreeNode>
            </React.Fragment>
          );
        } 
        return null;
      });
    });
  };

  function createTreeStructure() {
    if (loading) {
      setResetCategoryTree(false);
      return "loading";
    }
    if (error) {
      setResetCategoryTree(false);
      return "error";
    }
    if (data.category.getCategoryTreeByRootCategoryId !== null) {
      setResetCategoryTree(false);
      setListOfCategoryFromAPI(data?.category?.getCategoryTreeByRootCategoryId);
      const dataTree = Object.values(
        data.category.getCategoryTreeByRootCategoryId
      );
      const treeD = dataTree
        .filter(
          (value) =>
            value.state !== "DELETED" &&
            value.name !== null &&
            value.name[0]?.text !== null
        )
        .reverse()
        .sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text));

      if (
        treeD?.length === 0 ||
        (treeD?.length === 1 && treeD[0].parentCategoryId !== null)
      )  return "No Data";
      else return renderRootCategoryTreeNode(treeD);
    }
  }
  const tree = createTreeStructure();

  const renderCategoryTreeDataState = () =>
    tree === "loading" ? (
      <Spinner message="Loading Category Tree..." />
    ) : (
      renderErrorState()
    );
  const renderErrorState = () =>
    tree === "error" ? (
      <AlertBox
        message="Error occurred while loading category tree"
        severity="error"
      />
    ) : (
      renderCategoryTreeData()
    );

  const renderCategoryTreeData = () =>
    data?.category?.getCategoryTreeByRootCategoryId?.length === 0 ||
    data?.category?.getCategoryTreeByRootCategoryId === null || tree === "No Data" ? (
      <AlertBox message="No Categories Found!" severity="info" />
    ) : (
      renderCategoryTreeStructure()
    );

  const renderCategoryTreeStructure = () => {
    return (
      <Tree
        onSelect={onSelect}
        checkable={hasDeletePermission}
        virtual
        draggable
        checkedKeys={checkedCategoryIdForDelete}
        onCheck={onCheck}
        onDragStart={onDragStart}
        onDragEnter={onDragEnter}
        onDrop={onDrop}
        checkStrictly={true}
        showLine={false}
        switcherIcon={(obj) => switcherIcon(obj, data, classes)}
      >
        {createTreeStructure()}
      </Tree>
    );
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        {renderCategoryTreeDataState()}
      </Grid>
    </Grid>
  );
}
