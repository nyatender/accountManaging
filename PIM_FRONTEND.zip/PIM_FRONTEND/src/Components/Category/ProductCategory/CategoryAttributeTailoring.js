import React, { useContext } from "react";
import {
    Grid,
    TextField,
    MenuItem,
    Typography,
    InputAdornment,
    FormHelperText,
} from "@material-ui/core";
import DateFnsUtils from "@date-io/date-fns";
import {
    MuiPickersUtilsProvider,
    KeyboardDateTimePicker,
} from "@material-ui/pickers";
import AlertBox from "../../UI/AlertBox";
import { ReactTrixRTEInput, ReactTrixRTEToolbar } from "react-trix-rte";
import GlobalState from "../../../Context/GlobalState";
import {
    isEmptyObject,
    convertUTCToLocal,
    getIsLocalAdminUser,
    handleRenderAsterix,
    handleAttributeValueChange,
    renderMenuItem
} from "../../../Utilities/CommonFunctions";
import CalendarIcon from "@material-ui/icons/CalendarTodayRounded";
import userPermission from '../../../Utilities/userPermissionHook';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Chip from '@material-ui/core/Chip';
import { multiSelectStyles } from "../../Tailoring/TailoringStyles";
import "trix";

export default function CategoryAttributeTailoring() {
    const classesMultiSelect = multiSelectStyles();
    const { value21, value58, value211 } =
        useContext(GlobalState);
    const [attributeValue] = value21;
    const [selectedLanguageInHeader] = value58;
    const [selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes] = value211;
    const [role, , , updatePermission] = userPermission('productset');
    const isLocalAdminUser = getIsLocalAdminUser(role, updatePermission);

    const getExistingValue = (attr) => {
        const existingValue = selectedCategoryTailoringAttributes?.filter(
            (e) => e.attributeId === attr.attributeId
        );
        return existingValue[0] || [];
    };

    const renderDropDownControl = (attr) => {
        /* getting master data  for the drop down*/

        const attrMasterData = attributeValue.filter(
            (i) => i.attributeId === attr.attributeId
        )[0]?.attributeValues;
        const arrayOfMasterData = !!attrMasterData ? [...attrMasterData] : [];
        const existingValue = getExistingValue(attr);
        const ddValue =
            !isEmptyObject(existingValue) && existingValue.dropdownvalue
                ? existingValue.dropdownvalue
                : "";
        return (
            <Grid item xs={12}>
                <TextField
                    id={attr.attributeId}
                    select
                    fullWidth
                    value={ddValue}
                    label={`${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}`}
                    disabled={isLocalAdminUser}
                    onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                    style={{ marginBottom: "16px" }}
                >
                    {arrayOfMasterData?.length > 0 ? (
                        renderMenuItem(arrayOfMasterData)
                    ) : (
                        <MenuItem key="No Value" value="No Value" disabled>
                            <Typography>No Value</Typography>
                        </MenuItem>
                    )}
                </TextField>
            </Grid>
        );
    };
    const renderMultiSelectDropDownControl = (attr) => {
        /* getting master data  for the drop down*/
        const attrMasterData = attributeValue.filter(
            (i) => i.attributeId === attr.attributeId
        )[0]?.attributeValues;
        const arrayOfMasterData = !!attrMasterData ? [...attrMasterData] : [];
        const existingValue = getExistingValue(attr);
        const multiSelectSelectedValues = existingValue?.checkBoxListvalue || [];
        return (
            <Grid item xs={12} style={{ display: "flex" }}>
                <FormControl className={classesMultiSelect.formControl} fullWidth>
                    <InputLabel id="demo-mutiple-chip-label">{`${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}`}</InputLabel>
                    <Select
                        labelId="mutiple-chip-label"
                        id={attr.attributeId}
                        multiple
                        fullWidth
                        className={classesMultiSelect.dropdownWidth}
                        value={multiSelectSelectedValues}
                        onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                        input={<Input id="select-multiple-chip" />}
                        disabled={isLocalAdminUser}
                        renderValue={(select) => (
                            <div className={classesMultiSelect.chips}>
                                {select?.map((value) => {
                                    const label = arrayOfMasterData?.filter(item => item.attributeValueId === value)[0]?.value[0]?.text;
                                    return <Chip key={value} label={label} className={classesMultiSelect.chip} />
                                })}
                            </div>
                        )}
                    >
                        {renderMenuItem(arrayOfMasterData)}
                    </Select>
                </FormControl>
            </Grid>
        );
    };
    const renderTextFieldControl = (attr, isTextArea = false) => {
        const existingValue = getExistingValue(attr);
        const textValue =
            !isEmptyObject(existingValue) &&
                Array.isArray(existingValue.textBoxData) &&
                existingValue.textBoxData?.length &&
                existingValue.textBoxData[0]?.text
                ? existingValue.textBoxData[0]?.text
                : "";
        return (
            <Grid item xs={12}>
                <TextField
                    id={attr.attributeId}
                    fullWidth
                    disabled={isLocalAdminUser}
                    label={!!attr.name ? `${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}` : "Name Not Present"}
                    value={textValue}
                    multiline={isTextArea}
                    rows={4}
                    onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                    style={{ marginBottom: "16px" }}
                />
            </Grid>
        );
    };
    const renderRichTextControl = (attr) => {
        const existingValue = getExistingValue(attr);
        const textValue =
            !isEmptyObject(existingValue) &&
                Array.isArray(existingValue.textBoxData) &&
                existingValue.textBoxData?.length &&
                existingValue.textBoxData[0]?.text
                ? existingValue.textBoxData[0]?.text
                : "";
        return (
            <Grid item xs={12}>
                <ReactTrixRTEToolbar
                    toolbarId="react-trix-rte-editor"
                />
                <ReactTrixRTEInput
                    defaultValue={textValue}
                    toolbarId="react-trix-rte-editor"
                    onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                />
            </Grid>
        );
    };
    const renderRadioButtonControl = (attr) => {
        return (
            <Grid item xs={12}>
                <TextField
                    fullWidth
                    id={attr.attributeId}
                    label={`${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}`}
                    multiline
                    disabled={isLocalAdminUser}
                    rows={3}
                    style={{ marginBottom: "16px" }}
                />
            </Grid>
        );
    };
    const renderPriceControl = (attr) => {
        const existingValue = getExistingValue(attr);
        return (
            <Grid item xs={12}>
                <TextField
                    fullWidth
                    id={attr.attributeId}
                    label={`${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}`}
                    value={!isEmptyObject(existingValue) && existingValue.pricevalue}
                    InputProps={{
                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                    disabled={isLocalAdminUser}
                    onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                    style={{ marginBottom: "16px" }}
                />
            </Grid>
        );
    };
    const renderDateControl = (attr) => {
        const existingValue = getExistingValue(attr);
        return (
            <Grid item xs={12}>
                <FormHelperText >
                    {`${attr.name[0].text}${handleRenderAsterix(attr.isMandatory)}`}
                </FormHelperText>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDateTimePicker
                        id={attr.attributeId}
                        ampm={false}
                        format="yyyy-MM-dd HH:mm"
                        invalidDateMessage={"invaild date/time"}
                        invalidLabel={null}
                        minDateMessage={null}
                        placeholder="yyyy-MM-dd HH:mm"
                        value={
                            !isEmptyObject(existingValue) &&
                            convertUTCToLocal(existingValue.dateTimevalue)
                        }
                        fullWidth
                        disabled={isLocalAdminUser}
                        keyboardIcon={<CalendarIcon fontSize="small" color={!isLocalAdminUser && "primary"} />}
                        onChange={(e) => handleAttributeValueChange(e, attr, selectedCategoryTailoringAttributes, setSelectedCategoryTailoringAttributes,selectedLanguageInHeader)}
                        style={{ marginBottom: "16px" }}
                    />
                </MuiPickersUtilsProvider>
            </Grid>
        );
    };

    const renderNoAttributeFoundAlert = () => {
        return (
            <AlertBox
                message={
                    "No associated attributes found with this category."
                }
                severity="info"
            />
        );
    }

    const renderUIControls = () => {
      return (
        <>
          {selectedCategoryTailoringAttributes.map((item) => {
            const { isMandatory, name } = attributeValue.filter(
              (attribute) => attribute.attributeId === item.attributeId
            )[0];
            const tailoredAttribute = { ...item, isMandatory, name };
            if (item.inputControl === "DROPDOWN_LIST") {
              return renderDropDownControl(tailoredAttribute);
            } else if (item.inputControl === "TEXT_FIELD") {
              return renderTextFieldControl(tailoredAttribute);
            } else if (item.inputControl === "TEXT_AREA") {
              return renderTextFieldControl(tailoredAttribute, true);
            } else if (item.inputControl === "TEXT_EDITOR") {
              return renderRichTextControl(tailoredAttribute);
            } else if (item.inputControl === "RADIO_BUTTON_LIST") {
              return renderRadioButtonControl(tailoredAttribute);
            } else if (item.inputControl === "PRICE") {
              return renderPriceControl(tailoredAttribute);
            } else if (item.inputControl === "DATE") {
              return renderDateControl(tailoredAttribute);
            } else if (item.inputControl === "LISTBOX") {
              return renderMultiSelectDropDownControl(tailoredAttribute);
            } else {
              return renderTextFieldControl(tailoredAttribute);
            }
          })}
        </>
      );
    };

    const renderControls = () => {
        if (
            !Array.isArray(selectedCategoryTailoringAttributes) ||
            (Array.isArray(selectedCategoryTailoringAttributes) &&
                selectedCategoryTailoringAttributes?.length === 0)
        ) {
            return renderNoAttributeFoundAlert()
        }
        return renderUIControls()
    };
    return (
        <Grid container >
            <Grid item xs={12} fullWidth style={{ padding: "2px" }}>
                {renderControls()}
            </Grid>
        </Grid>
    );
}
