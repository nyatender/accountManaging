import React, { useContext, useState, useEffect } from "react";
import { propertiesStyle } from "./ProductCategoryStyles";
import GlobalState from "../../../Context/GlobalState";
import { useQuery } from "@apollo/react-hooks";
import { GET_CATEGORY_TREE } from "../../Query";
import Button from "@material-ui/core/Button";
import FormLabel from "@material-ui/core/FormLabel";
import { ReactComponent as Plus } from "./../../../Asset/plus.svg";
import Chip from "@material-ui/core/Chip";
import AttributeListForCategory from "./../../UI/CheckboxListing";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";

export default function AddAttributeForCategory() {
  const classes = propertiesStyle();
  const { value36, value37, value58 } = useContext(GlobalState);
  const [showAttributes, setshowAttributes] = useState(false);
  const [listData, setlistData] = useState([]);
  const [emptyAttribute, setEmptyAttribute] = useState(false);
  const [categoryAttributeChipData, setCategoryChipData] = value36;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;

  const includeCategoryDetails = true;
  const {
    loading: categoryLoading,
    error: categoryError,
    data: categoryData,
  } = useQuery(GET_CATEGORY_TREE, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      includeCategoryDetails,
    },
  });

  useEffect(() => {
    handleAttributeList();
  }, [categoryData]);

  const handleDelete = (chipToDelete) => () => {
    setCategoryChipData((chips) =>
      chips.filter((chip) => chip.key !== chipToDelete.key)
    );
    var obj = { key: chipToDelete.key, value: chipToDelete.value };
    setlistData([...listData, obj]);
  };

  const handleAssociate = () => {
    setshowAttributes(!showAttributes);
  };

  let newarray = [];
  const handleAttributeList = () => {
    if (categoryData) {
      let apiData =
        categoryData.category.getCategoryTreeByRootCategoryId.filter(
          (value) => value.state !== "DELETED"
        );

      apiData[0]?.totalSupportedAttributes?.map((controlData) => {
        var obj = {
          key: controlData.attributeId,
          value: controlData.name[0].text,
        };
        newarray.push(obj);
      });
      setlistData(newarray);
      if (JSON.stringify(newarray) === "[]") {
        setEmptyAttribute(true);
      }
    }
  };

  const handleAttributes = () => {
    if (categoryLoading) {
      return (
        <div style={{ textAlign: "center" }}>
          <Spinner message="Loading Attributes..." topHeight="0px" />
        </div>
      );
    }

    if (categoryError) {
      return (
        <AlertBox
          message="Error occurred while loading attributes"
          severity="error"
        />
      );
    }
    if (categoryData) {
      return (
        <AttributeListForCategory
          listData={listData}
          setListData={setlistData}
          emptyAttributeList={emptyAttribute}
          chipData={categoryAttributeChipData}
          setChipData={setCategoryChipData}
        />
      );
    }
  };
  return (
    <div 
    className={classes.root}>
      <div 
      style={{ paddingTop: "20px" }}>
        <FormLabel style={{ color: "#7A7D8E", fontSize: "18px", paddingLeft: "22px" }}>
          Attribute
        </FormLabel>
        <br></br>
        <div 
        className={classes.buttonDivStyle}>
          <Button
            onClick={handleAssociate}
            size="medium"
            className={classes.addButtonStyle}
            color="primary"
            startIcon={<Plus height="16px" width="13px" />}>
            Add Attribute(s)
          </Button>
        </div>
      </div>
      {JSON.stringify(categoryAttributeChipData) !== "[]" && (
        <div>
          <div component="ul" className={classes.chipsList}>
            {categoryAttributeChipData.map((data) => {
              let icon;

              return (
                <li key={data.key} style={{ padding: "5px" }}>
                  <Chip
                    icon={icon}
                    label={data.value}
                    onDelete={handleDelete(data)}
                    className={classes.chip}
                  />
                </li>
              );
            })}
          </div>
        </div>
      )}
      <>{showAttributes === true && handleAttributes()}</>
    </div>
  );
}
