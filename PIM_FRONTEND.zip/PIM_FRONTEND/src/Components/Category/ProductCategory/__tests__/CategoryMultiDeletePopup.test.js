import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import CategoryDeletePopup from "../CategoryDeletePopup";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import {ReactComponent as DisabledDeleteIcon }  from "../../../../Asset/disabled-multi-delete.svg";
import { Tooltip } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import IconButton from "@material-ui/core/IconButton";
import { act } from "react-dom/test-utils";

let wrapper;
beforeEach(() => {
  wrapper = mount(
    <GlobalContextProvider>
    <ApolloProvider client={client}>
      <CategoryDeletePopup />
    </ApolloProvider>
    </GlobalContextProvider>
  );
});
describe("CategoryDeletePopup snapshot test ", () => {
  it("matches Category Multi Delete Popup snap shot", () => {
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });
  it('should render Delete Icon when checkedCategoryForDelete is empty', ()=>{
    expect(wrapper.find(Tooltip).props().title).toBe("Delete Category(s)");
    expect(wrapper.find(DisabledDeleteIcon).exists()).toBeTruthy()
});

});

describe('CategoryDeletePopup Functionality test',()=>{

  it('should open dialog popup ON deleteIcon click',
  ()=>
  {
      act(
        ()=>{ 
          wrapper.find(IconButton).props().onClick(); 
        });
      wrapper.update();
      expect(wrapper.find(Dialog).props().open).toBeTruthy();
  })

  it('should call onclose function of dialog component',
  ()=>
  {
    act(
      ()=>{ wrapper.find(IconButton).first().props().onClick(); })
      wrapper.update();
   act(
      ()=>{
         wrapper.find(Dialog).props().onClose(); 
    });
    wrapper.update()
    expect(wrapper.find(Dialog).props().open).toBeFalsy()

})
  it('should close dialog popup onclick of cancel Button',
  ()=>{ act(
        ()=>{ 
        wrapper.find(IconButton).first().props().onClick(); 
    });
    wrapper.update();
    act(
      ()=>{ wrapper.find(Button).first().props().onClick(); }
      );
    wrapper.update();
    expect(wrapper.find(Dialog).props().open).toBeFalsy();
 })

 
});
