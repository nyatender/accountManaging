import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import CategoryTree from "../CategoryTree";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"

describe("snapshot test ", () => {
  it("matches Category Tree snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <CategoryTree />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
