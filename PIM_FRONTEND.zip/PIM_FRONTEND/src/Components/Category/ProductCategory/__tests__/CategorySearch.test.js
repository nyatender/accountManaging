import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import CategorySearch from "../CategorySearch";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import { act } from "react-dom/test-utils";
import { wait } from "@apollo/react-testing";
import AlertBox from "../../../UI/AlertBox";
import { Checkbox, ListItemIcon, ListItemText } from "@material-ui/core";
import { ReactComponent as SubCategory } from "../../../../Asset/sub-category.svg";

const propsSearchResult = [
  {
    id: "101",
    name: [
      {
        text: "Category-1",
      },
    ],
  },
  {
    id: "102",
    name: [
      {
        text: "Category-2",
      },
    ],
  },
  {
    id: "103",
    name: [
      {
        text: "Category-3",
      },
    ],
  },
];

const propsContext = {
  userRole: {
    name: "SystemAdmin",
    permission: [
      {
        create: true,
        delete: true,
        module: "category",
        permissionId: null,
        read: true,
        update: true,
        __typename: "PermissionSchema",
      },
    ],
    __typename: "RoleSchema",
  },
};

const propsWithNoSearchResult = [];

const getComponent = (props) => {
  let container;
  act(() => {
    container = mount(
      <GlobalContextProvider mockData={propsContext}>
        <CategorySearch searchResultData={props} />
      </GlobalContextProvider>
    );
  });
  return container;
};

describe("snapshot test ", () => {
  it("matches Category Search snap shot", () => {
    const subject = getComponent(propsSearchResult);
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });
});

describe("Category search functional testing", () => {
  it("should check checkbox Functionality works properly", async () => {
    let container;
    container = getComponent(propsSearchResult);
    await act(() => wait(500));
    container.update();
    expect(container.find(Checkbox).first().props().checked).toBeFalsy();
    act(() => {
      container
        .find(Checkbox)
        .first()
        .props()
        .onChange({ target: { checked: true } });
    });
    container.update();
    expect(container.find(Checkbox).first().props().checked).toBeTruthy();
  });

  it("should render AlertBox with No data found message when no categories are found", async () => {
    let container;
    container = getComponent(propsWithNoSearchResult);
    await act(() => wait(500));
    container.update();
    let alertBox = container.find(AlertBox).first();

    expect(alertBox.exists()).toBeTruthy();
    expect(alertBox.prop("message")).toEqual("No data found");
  });

  it("ListItemText contains appropiate category name ", async () => {
    let container;
    container = getComponent(propsSearchResult);
    await act(() => wait(500));
    container.update();
    let listItemText = container.find(ListItemText).first();

    expect(listItemText.exists()).toBeTruthy();
    listItemText.simulate("click");
    await act(() => wait(500));
    container.update();
    expect(listItemText.prop("primary")).toEqual("Category-1");
  });

  it("ListItemIcon should be present ", async () => {
    let container;
    container = getComponent(propsSearchResult);
    await act(() => wait(500));
    container.update();
    let listItemIcon = container.find(ListItemIcon).first();
    expect(listItemIcon.exists()).toBeTruthy();
    let icon = listItemIcon.find(SubCategory).first();
    expect(icon.exists()).toBeTruthy();
  });
});
