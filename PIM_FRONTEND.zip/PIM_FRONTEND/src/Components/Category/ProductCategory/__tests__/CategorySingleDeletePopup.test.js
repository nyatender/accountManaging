import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import CategorySingleDeletePopup from "../CategorySingleDeletePopup";
import { client } from "../../../App";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import IconButton from "@material-ui/core/IconButton";
import { Tooltip } from "@material-ui/core";
import { act } from "react-dom/test-utils";
import { ReactComponent as Delete } from "../../../../Asset/delete.svg";
import { ReactComponent as DisabledDelete } from "../../../../Asset/disabled_delete.svg";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";

let wrapper;
beforeEach(() => {
  wrapper = mount(
    <GlobalContextProvider>
    <ApolloProvider client={client}>
      <CategorySingleDeletePopup />
    </ApolloProvider>
    </GlobalContextProvider>
  );
});
describe("CategorySingleDeletePopup snapshot test ", () => {
  it("matches Category Single Delete Popup snap shot", () => {
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });
  it('should render Delete Icon when category is not root category', 
  ()=>{
     expect(wrapper.find(Tooltip).props().title).toBe("Delete selected category");
     expect(wrapper.find(Delete).exists()).toBeTruthy()
 })

});

describe('CategorySingleDeletePopup Functionality test',()=>{

  it('should call onclose function of dialog component',()=>{ act( ()=>
    { 
      wrapper.find(IconButton).first().props().onClick(); 
    })
      wrapper.update();
    act( ()=>{ wrapper.find(Dialog).props().onClose();});
    wrapper.update()
    expect(wrapper.find(Dialog).props().open).toBeFalsy()

})

it('should open dialog popup ON deleteIcon click',()=>{ act(
      ()=>{ 
        wrapper.find(IconButton).props().onClick(); 
      });
    wrapper.update();
    expect(wrapper.find(Dialog).props().open).toBeTruthy();
})

  it('should close dialog popup onclick of cancel Button', ()=>{ act(
        ()=>{ 
        wrapper.find(IconButton).first().props().onClick(); 
        });
        wrapper.update();
        act(
          ()=>{ wrapper.find(Button).first().props().onClick(); }
          );
        wrapper.update();
        expect(wrapper.find(Dialog).props().open).toBeFalsy();
 });

 it('should render DisabledDelete Icon when category is root category', 
 ()=>{
  let context={
    categoryState:"RESTRICT_DELETE"
  }
  wrapper = mount(
    <GlobalContextProvider mockData={context}>
    <ApolloProvider client={client}>
      <CategorySingleDeletePopup />
    </ApolloProvider>
    </GlobalContextProvider>
  );
  expect(wrapper.find(Tooltip).props().title).toBe("Disabled as this is the Root Category");
     expect(wrapper.find(DisabledDelete).exists()).toBeTruthy()
})

 
});
