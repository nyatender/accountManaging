import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import TabsForEditCategoryPage from "../TabsForEditCategoryPage";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";

const props={
  editHidden: false,
  setEditHidden:()=>{/**/}
}

describe("TabsForEditCategoryPage Component ", () => {
  it("matches TabsForEditCategoryPage snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <TabsForEditCategoryPage {...props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
