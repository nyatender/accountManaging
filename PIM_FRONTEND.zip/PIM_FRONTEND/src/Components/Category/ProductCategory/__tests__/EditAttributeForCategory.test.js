import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import EditAttributeForCategory from "../EditAttributeForCategory";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"

describe("EditAttributeForCategory Component ", () => {
  it("matches EditAttributeForCategory snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <EditAttributeForCategory />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
