import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import Properties from "../Properties";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"

describe("Properties Component ", () => {
  it("matches Properties snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <Properties />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
