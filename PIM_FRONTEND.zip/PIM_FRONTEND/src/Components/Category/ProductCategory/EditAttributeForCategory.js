import React, { useContext } from "react";
import { propertiesStyle } from "./ProductCategoryStyles";
import GlobalState from "../../../Context/GlobalState";
import Button from "@material-ui/core/Button";
import FormLabel from "@material-ui/core/FormLabel";
import { ReactComponent as Plus } from "./../../../Asset/plus.svg";
import Chip from "@material-ui/core/Chip";
import AttributeListForCategory from "./../../UI/CheckboxListing";

export default function EditAttributeForCategory() {
  const classes = propertiesStyle();
  const { value37, value38, value40, value41, value56 } =
    useContext(GlobalState);
  const [showAttributes, setShowAttributes] = value40;
  const [selectedChannelIDForHeader] = value37;
  const [categoryEditAttributeChipData, setCategoryEditChipData] = value38;
  const [listData, setlistData] = value41;
  const [globalChannelID] = value56;

  const handleDelete = (chipToDelete) => () => {
    setCategoryEditChipData((chips) =>
      chips.filter((chip) => chip.key !== chipToDelete.key)
    );
    var obj = { key: chipToDelete.key, value: chipToDelete.value };
    setlistData([...listData, obj]);
  };

  const handleAssociate = () => {
    setShowAttributes(!showAttributes);
  };

  const handleAttributes = () => {
      return (
        <AttributeListForCategory
          listData={listData}
          setListData={setlistData}
          chipData={categoryEditAttributeChipData}
          setChipData={setCategoryEditChipData}
        />
      );
  };
  return (
    <div className={classes.root}>
      <div style={{ paddingTop: "20px" }}>
        <FormLabel
          style={{ color: "#7A7D8E", fontSize: "18px", paddingLeft: "22px" }}
        >
          Attribute
        </FormLabel>
        <br></br>
        <div className={classes.buttonDivStyle}>
          <Button
            startIcon={<Plus height="16px" width="13px" />}
            onClick={handleAssociate}
            className={classes.addButtonStyle}
            size="medium"
            color="primary"
          >
            Add Attribute(s)
          </Button>
        </div>
      </div>
      {JSON.stringify(categoryEditAttributeChipData) !== "[]" ? (
        <div>
          <div component="ul" className={classes.chipsList}>
            {categoryEditAttributeChipData.map((data) => {
              let icon;

              return (
                <li key={data.key} style={{ padding: "5px" }}>
                  <Chip
                    icon={icon}
                    label={data.value}
                    onDelete={
                      data.value === "React" ? undefined : handleDelete(data)
                    }
                    className={classes.chip}
                    disabled={globalChannelID !== selectedChannelIDForHeader}
                  />
                </li>
              );
            })}
          </div>
        </div>
      ) : null}
      <>{showAttributes === true ? handleAttributes() : <div></div>}</>
    </div>
  );
}
