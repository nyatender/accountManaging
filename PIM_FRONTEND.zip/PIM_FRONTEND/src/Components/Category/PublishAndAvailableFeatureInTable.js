import React, { useContext, useState } from "react";
import GlobalState from "../../Context/GlobalState";
import Tooltip from "@material-ui/core/Tooltip";
import IconButton from "@material-ui/core/IconButton";
import { ReactComponent as PublishIcon } from "./../../Asset/Publish_icon.svg";
import { ReactComponent as PublishedIcon } from "./../../Asset/published.svg";
import { ReactComponent as ShowIcon } from "./../../Asset/showIcon.svg";
import { ReactComponent as HiddenIcon } from "./../../Asset/hideIcon.svg";
import { useMutation } from "@apollo/react-hooks";
import { UPDATE_IS_PUBLISHED } from "../Query";
import { dialogMessage, dialogTitle } from "../../Utilities/Constants";
import { PublishProductDialogStyles } from "../Tailoring/ProductPublish/PublishProductStyles";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Button from "@material-ui/core/Button";

const PublishProductStatus = ({ row }) => {
  const classes = PublishProductDialogStyles();
  const { value37, value56, value60, value74, value81, value108, value134, value146, value147, value190 } =
    useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [globalChannelId] = value56;
  const [showAllProductTable] = value60;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetAllProductsTable] = value108;
  const [, setIsPublishProduct] = value134;
  const [firstName] = value146;
  const [lastName] = value147;
  const [notifications, setNotifications] = value190
  const [productPublishPopupInTable, setProductPublishPopupInTable] =
    useState(false);

  const [updateIsPublishedForProductInTable] = useMutation(
    UPDATE_IS_PUBLISHED,
    {
      onError: (e) => {
        setIsPublishProduct(false);
        setShowOverlay(false);
        setSnackbarData({
          show: true,
          message: `Product Does not meet the minimum criteria for publishing : ${e.networkError.result.errors[0].message}`,
          severity: "error",
        });
      },
      onCompleted: (response) => {
        setShowOverlay(false);
        const notificationList = response.product.updateIsPublished[0].notifications
        if (notificationList && notificationList?.length > 0) {
          const notificationArray = [...notifications]
          let notifiList = []
          notificationList.map(({ skuNotification }) => {
            return skuNotification.ruleNotification && skuNotification.ruleNotification?.length > 0 &&
              skuNotification.ruleNotification.filter(element => element !== null).map(rule => {
                return {
                  message: rule.message,
                  sku: skuNotification.sku,
                  notificationId: rule.ruleNotificationId
                }
              })
          }).map(element => notifiList.unshift(...element))
          const filterOldNotifications = notificationArray.filter(notify => notifiList.findIndex(element => element.sku === notify.sku) === -1)
          notifiList?.forEach(notificationObject => filterOldNotifications.unshift(notificationObject))
          setNotifications(filterOldNotifications)
          setIsPublishProduct(false)
          setSnackbarData({
            show: true,
            message: "Product does not meet the minimum criteria for publishing to local market. Please check the notifications.",
            severity: "warning",
          })
        }
        else {
          setIsPublishProduct(true)
          setSnackbarData({
            show: true,
            message: "Product published to local market",
            severity: "success",
          })
          if (showAllProductTable) setResetAllProductsTable(true)
        }
      },
    }
  );

  const handleProductPublishPopupOpen = () => {
    setProductPublishPopupInTable(true);
  };

  const handlePopupClose = () => {
    setProductPublishPopupInTable(false);
  };

  const handlePublishInProductTable = () => {
    setShowOverlay(true);
    setIsPublishProduct(true);
    updateIsPublishedForProductInTable({
      variables: {
        product: [
          {
            channelId: selectedChannelIDForHeader,
            productId: row.productId,
            productType: row.productType,
            isPublished: true,
            updatedBy: `${firstName} ${lastName}`,
          },
        ],
      },
    });
    setProductPublishPopupInTable(false);
  };

  const renderPublishOrHideIcon = () => globalChannelId === selectedChannelIDForHeader ? renderPublishIcon() : renderHideIcon()

  const renderPublishIcon = () => {
    return(
      <Tooltip title={row?.isPublished ? "Published" : "Publish"} placement="top">
      <span>
        <IconButton
          onClick={handleProductPublishPopupOpen}
          disabled={row?.isPublished}
        >
          {row?.isPublished ? (
            <PublishedIcon height="22px" />
          ) : (
            <PublishIcon height="20px" />
          )}
        </IconButton>
      </span>
    </Tooltip>
    )
  }

  const renderHideIcon = () => {
    return (
      <Tooltip title={row?.isAvailable ? "Show" : "Hide"} placement="top">
      <span>
        <IconButton disabled>
          {row?.isAvailable ? (
            <ShowIcon height="18px" />
          ) : (
            <HiddenIcon height="20px" />
          )}
        </IconButton>
      </span>
    </Tooltip>
    )
  }
  return (
    <>
      {renderPublishOrHideIcon()}
      <Dialog
        open={productPublishPopupInTable}
        onClose={handlePopupClose}
        maxWidth="xs"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle className={classes.titleStyle}>
          {dialogTitle.CONFIRMATION}
        </DialogTitle>
        <DialogContent>
          <div className={classes.publishImageStyle}><PublishIcon /></div>
          <DialogContentText
            id="alert-dialog-description"
            className={classes.dialogMessageStyle}
          >
            {dialogMessage.SINGLE_PRODUCT_PUBLISH_CONFIRMATION_MSG}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            variant="outlined"
            size="medium"
            color="primary"
            onClick={handlePopupClose}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="medium"
            color="primary"
            onClick={handlePublishInProductTable}
          >
            Publish
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default PublishProductStatus;
