import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import DeleteSingleProduct from "../DeleteSingleProductPopup";
import { client } from "../../App";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import IconButton from "@material-ui/core/IconButton";
import { act } from "react-dom/test-utils";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";
import { Tooltip } from "@material-ui/core";
import { ReactComponent as Delete } from "./../../../Asset/delete.svg";
import { ReactComponent as DisabledDelete } from './../../../Asset/disabled_delete.svg'

let props={
  row:{
    categoryId: null,
    channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
    createdAt: "2021-02-12T22:59:50.75343",
    isAvailable: false,
    isPublished: false,
    parentProductId: "ab16f4cf-9830-444e-9ce3-050ad75c2606",
    phaseOutDate: "",
    productId: "f9b742dc-8a91-45bf-9ad3-1fc170a2bbb9",
    productName: null,
    productSource: "PIM",
    productType: "PRODUCT_VARIANT",
    publishedDate: "",
    ranking: 1,
    sku: "10946158",
    state: "UPDATED",
    __typename: "ProductSchema"
  }
}
let wrapper;
beforeEach(() => {
  wrapper = mount(
    <GlobalContextProvider>
    <ApolloProvider client={client}>
      <DeleteSingleProduct {...props} />
    </ApolloProvider>
    </GlobalContextProvider>
  );
});
describe("DeleteSingleProduct Component ", () => {
  it("matches DeleteSingleProduct snap shot", () => {
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });
  it('should render Delete Icon when product is not from INFOR', ()=>{
     expect(wrapper.find(Tooltip).props().title).toBe("Delete Product");
     expect(wrapper.find(Delete).exists()).toBeTruthy()
 });

});

describe('DeleteMultiProduct Functionality test',()=>{

  it('should open dialog popup in deleteIcon click',
  ()=>{
      act(()=>{ wrapper.find(IconButton).props().onClick(); });
      wrapper.update();

      expect(wrapper.find(Dialog).props().open).toBeTruthy();
      expect(wrapper.find(DialogTitle).text()).toBe("Confirmation");
      expect(wrapper.find(DialogContentText).text()).toEqual("Do you really want to delete the selected product?")
  })

  it('should call onclose function of dialog component',
  ()=>{
   act(
      ()=>{ wrapper.find(IconButton).props().onClick(); });
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBeTruthy();

    act(
      ()=>{ wrapper.find(Dialog).props().onClose(); });
    wrapper.update();
    expect(wrapper.find(Dialog).props().open).toBeFalsy()

});
  it('should close dialog popup onclick of cancel Button',
  ()=>
  {
    act(
      ()=>{ 
      wrapper.find(IconButton).first().props().onClick(); })
      wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBeTruthy()

    act(
      ()=>{ wrapper.find(Button).first().props().onClick(); })
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBeFalsy();
});

  it('should close dialog popup onclick of Delete Button',
  ()=>{
    act(()=>
    { 
      wrapper.find(IconButton).first().props().onClick(); 
    })
    wrapper.update();

    act(()=>
    { 
      wrapper.find(Button).last().props().onClick(); 
    })
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBe(true)
  });

  it('should render DisabledDelete Icon when product is from INFOR', ()=>{
     props={
       row:{
        categoryId: null,
        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        createdAt: "2021-05-05T06:54:26.987353",
        isAvailable: false,
        isPublished: false,
        parentProductId: "b671ff93-7ff8-4b1b-8296-b48094a462ab",
        phaseOutDate: null,
        productId: "d7bbdd7b-adcc-4dd2-a71d-ba1675005052",
        productName: null,
        productSource: "INFOR",
        productType: "PRODUCT_VARIANT",
        publishedDate: "2021-05-05T07:25:00",
        ranking: 0,
        sku: "ITE-10990483-L",
        state: "UPDATED",
        __typename: "ProductSchema"
       }
     }
     wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <DeleteSingleProduct {...props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
      expect(wrapper.find(Tooltip).props().title).toBe("Cannot delete Infor product");
      expect(wrapper.find(DisabledDelete).exists()).toBeTruthy()
  })

});
