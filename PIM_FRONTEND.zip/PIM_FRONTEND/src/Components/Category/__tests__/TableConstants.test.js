import { getProductType, getProductName, columnName, Title, columns, contextActions, getProductStatus } from "../TableConstants";

describe("getProductType function Test ", () => {
  const propsWithConfigurableType = {
    productType: "PRODUCT",
    sku: "10950192",
  };
  const propsWithVariantType = {
    productType: "PRODUCT_VARIANT",
    sku: "10950193",
  }
  const propsWithBundleType = 
  {
    productType: "BUNDLE",
    sku: "10950194",
  };

  it("matches CONFIGURABLE Image snap shot", () => {
    expect(getProductType(propsWithConfigurableType)).toMatchSnapshot();
  });
  it("matches VARIANT Image snap shot", () => {
    expect(getProductType(propsWithVariantType)).toMatchSnapshot();
  });
  it("matches BUNDLE Image snap shot", () => {
    expect(getProductType(propsWithBundleType)).toMatchSnapshot();
  });
});

describe("getProductName function Test ", () => {
  const propsWithProductName = {
    productName: [
      {
        text: "Motion PX",
      },
    ],
  };

  const propsWithNoName = {
    productName: null
  };

  it("matches Product Name snap shot", () => {
    expect(getProductName(propsWithProductName)).toMatchSnapshot();
  });
  it("matches Name is empty snap shot", () => {
    expect(getProductName(propsWithNoName)).toMatchSnapshot();
  });
});

describe("columnName function Test ", () => {
  it("matches Column Name snap shot", () => {
    expect(columnName("SKU")).toMatchSnapshot();
  });

});

describe("Title function Test ", () => {
  it("matches Title All Products snap shot", () => {
    expect(Title()).toMatchSnapshot();
  });
});

describe("Column function Test ", () => {
  it("matches Column snap shot", () => {
    expect(columns()).toMatchSnapshot();
  });
});


describe("contextActions function Test ", () => {
  it("matches Context Actions function when showMove is true snapshot", () => {
    expect(contextActions(true)).toMatchSnapshot();
  });
});

describe("contextActions function Test ", () => {
  it("matches Context Actions function when showMove is false snapshot", () => {
    expect(contextActions(false)).toMatchSnapshot();
  });
});

describe("getProductStatus function Test ", () => {
  it("matches getProductStatus Released status snapshot", () => {
    expect(getProductStatus("2021-08-13T17:00:25","2021-10-10T17:00:25.836652")).toMatchSnapshot();
  });
});

describe("getProductStatus function Test ", () => {
  it("matches getProductStatus Created status snapshot", () => {
    expect(getProductStatus("2022-09-13T17:00:25","2022-10-10T17:00:25.836652")).toMatchSnapshot();
  });
});

describe("getProductStatus function Test ", () => {
  it("matches getProductStatus Phased Out status snapshot", () => {
    expect(getProductStatus("2021-09-02T06:00:00","2021-09-09T06:00:00")).toMatchSnapshot();
  });
});
