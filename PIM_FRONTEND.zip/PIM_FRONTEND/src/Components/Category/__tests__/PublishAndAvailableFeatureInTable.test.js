import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import PublishAndAvailableFeatureInTable from "../PublishAndAvailableFeatureInTable";
import { client } from "../../App";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider"

const props = {
   row: []
}

describe("PublishAndAvailableFeatureInTable Component ", () => {
  it("matches PublishAndAvailableFeatureInTable snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <PublishAndAvailableFeatureInTable props={props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
