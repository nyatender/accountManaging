import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import DeleteMultiProduct from "../DeletePopup";
import { client } from "../../App";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import IconButton from "@material-ui/core/IconButton";
import { act } from "react-dom/test-utils";

let wrapper;
beforeEach(() => {
  wrapper = mount(
    <GlobalContextProvider>
    <ApolloProvider client={client}>
      <DeleteMultiProduct />
    </ApolloProvider>
    </GlobalContextProvider>
  );
});

describe("DeleteMultiProduct Component ", () => {
  it("matches DeleteMultiProduct snap shot", () => {
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

});

describe('DeleteMultiProduct Functionality test',()=>{

  it('should open dialog popup in deleteIcon click',()=>{
      let button = wrapper.find(IconButton);
      act(()=>{ button.at(0).props().onClick(); })
      wrapper.update();
      expect(wrapper.find(Dialog).exists()).toBeTruthy()
      expect(wrapper.find(Dialog).props().open).toBeTruthy()
      expect(wrapper.find(DialogTitle).text()).toBe("Confirmation")
      expect(wrapper.find(DialogContentText).text()).toEqual("Do you really want to delete the selected products?")
  });
  it('should call onclose function of dialog popup',()=>
  {
    let button = wrapper.find(IconButton);
    act(
      ()=>{ 
        button.at(0).props().onClick(); 
      });
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBeTruthy();
    act(()=>{ wrapper.find(Dialog).props().onClose(); });
    wrapper.update();
    expect(wrapper.find(Dialog).props().open).toBe(false)

});
  it('should close dialog popup onclick of cancel Button',()=>
  {

    act(()=>{ wrapper.find(IconButton).first().props().onClick(); })
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBeTruthy()

    act(()=>{ wrapper.find(Button).first().props().onClick(); })
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBe(false)
});
  it('should close dialog popup onclick of Delete Button',()=>
  {
    act(()=>{ wrapper.find(IconButton).first().props().onClick(); })
    wrapper.update();

    act(()=>{ wrapper.find('[variant="contained"]').first().props().onClick(); })
    wrapper.update();

    expect(wrapper.find(Dialog).props().open).toBe(false)
  });

});

