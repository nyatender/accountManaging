import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import TableMenu from "../TableMenu";
import { client } from "../../App";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider"

describe("TableMenu Component ", () => {
  it("matches TableMenu snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <TableMenu />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
