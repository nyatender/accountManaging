import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import BrandProductsDataTable from "../BrandProductDataTable";
import { client } from "../../App";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider"

describe("BrandProductsDataTable Component ", () => {
  const props = {
    tableData: jest.fn(),
    columns: jest.fn(),
  };

  it("matches BrandProductsDataTable snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <BrandProductsDataTable {...props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
