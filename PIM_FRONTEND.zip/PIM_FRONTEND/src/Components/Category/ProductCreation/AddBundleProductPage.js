import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import DialogActions from "@material-ui/core/DialogActions";
import GlobalState from "../../../Context/GlobalState";
import { addPopupStyle, stepperStyle } from "./ProductCreationStyle";
import { useLazyQuery, useMutation } from "@apollo/react-hooks";
import {
  CREATE_PRODUCT,
  GET_PRODUCTS_BY_CATEGORY,
  GET_ALL_PRODUCTS,
  GET_PRODUCTS_BY_BRAND,
  VALIDATE_SKU_NAME_UNIQUENESS,
} from "../../Query";
import Alert from "@material-ui/lab/Alert";
import { useHistory } from "react-router-dom";
import Stepper from "../../UI/Stepper";
import AddNewProductScreen from "./AddNewProductScreen";
import { getSteps, dialogMessage } from "../../../Utilities/Constants";
import AddVariantAttribute from "./VariantAttribute/AddVariantAttribute";
import { Grid } from "@material-ui/core";
import CreateBundle from "./BundleSets/CreateBundle";
import ShowBUndleSets from "./BundleSets/BundleSetListings";
import AddProductsToBundle from "./BundleSets/AddChildProductsToBundle/AddProductsToBundle";
import {
  handleTailoringDetails,
  handleMoveToTailor,
  handleIsMandatory,
  handleIsDefault,
  getProductInfoForBundleSet
} from "../../../Utilities/CommonFunctions";

export default function AddBundleProductPage({
  isCategory,
  value,
  setRadioValue,
  itemNumberValue,
  setItemNumber,
  productName,
  setProductName,
  errorMessage,
  setErrorMessage,
  errorHandler,
  setErrorHandler,
  activeStep,
  setActiveStep,
  validationState,
  setValidationState,
  maxRank,
  handleClose,
  handleResetContext
}) {
  const stepperStyles = stepperStyle();
  const classes = addPopupStyle();
  const {
    value1,
    value6,
    value13,
    value24,
    value27,
    value37,
    value58,
    value66,
    value69,
    value70,
    value74,
    value81,
    value92,
    value93,
    value105,
    value108,
    value110,
    value125,
    value127,
    value134,
    value136,
    value146,
    value147,
    value214,
    newBundleSetAccordian,
  } = useContext(GlobalState);
  const [brand] = value1;
  const [openAddProductPopup] = value27;
  const [categoryKey] = value6;
  const [listOfMandatoryLocalBundleSet] = value13;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [, setRowDetails] = value24;
  const [, setSkuValue] = value66;
  const [, setPublishDateForProduct] = value69;
  const [, setProductDetail] = value70;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [selectedVariantAttributeList] = value92;
  const [selectedAttributeIdList] = value93;
  const [isCreateBundleSet, setIsCreateBundleSet] = value105;
  const [, setResetAllProductsTable] = value108;
  const [bundleSetDetails] = value110;
  const [checkBoxListForSelectedBundleSet] = value125;
  const [isMandatorySetList] = value127;
  const [valueForNewBundleSetAccordian] = newBundleSetAccordian;
  const [, setIsPublishProduct] = value134;
  const [, setIsProductAvailable] = value136;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setSelectedNavigationModule] = value214

  const steps = getSteps(value, isCreateBundleSet);
  const history = useHistory();

  const handleValidation = () => {
    if (validationLoading) {
      setShowOverlay(true);
    }
    if (validationError) {
      setShowOverlay(false);
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else {
      setShowOverlay(false);
      const validateResult =
        validationResult && validationResult.product.validateProductSKUAndName;

      if (validateResult === "0") {
        setErrorHandler(false);
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        setValidationState();
      } else if (validateResult === "1") {
        setErrorHandler(true);
        setErrorMessage(dialogMessage.SKU_ALREADY_EXISTS_MSG);
        setValidationState(1);
      } else if (validateResult === "2") {
        setErrorHandler(true);
        setErrorMessage(dialogMessage.NAME_ALREADY_EXISTS_MSG);
        setValidationState(2);
      }
    }
  };

  const [
    getValidation,
    {
      loading: validationLoading,
      error: validationError,
      data: validationResult,
    },
  ] = useLazyQuery(VALIDATE_SKU_NAME_UNIQUENESS, {
    fetchPolicy: "cache-and-network",
    onCompleted: () => handleValidation(),
  });

  const [createCategorizedProduct, { data: dataResponseForCategory }] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_PRODUCTS_BY_CATEGORY,
          variables: {
            categoryId: categoryKey,
            channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader },
          }
        },
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
            },
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            channelFilter: {
              languageCode: selectedLanguageInHeader,
              channelId: selectedChannelIDForHeader
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING"
            }
          },
        },
      ],
      onCompleted: () => {
        setShowOverlay(false);
      },
      ignoreResults: false,
    });

  const [createUncategorizedProduct, { data: dataResponseForUnCategorized }] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              languageCode: selectedLanguageInHeader,
              channelId: selectedChannelIDForHeader,
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortDirection: "DESCENDING",
              sortBy: "CreatedAt",
            },
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            channelFilter: {
              languageCode: selectedLanguageInHeader,
              channelId: selectedChannelIDForHeader,
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
            }
          },
        }
      ],
      onCompleted: () => {
        setShowOverlay(false);
      },
      ignoreResults: false,
    });

  const handleUnCategorizedBundleProductSave = async () => {
    let productSetIdList = [];
    checkBoxListForSelectedBundleSet
      ?.sort(function (a, b) {
        return a.ranking - b.ranking;
      })
      .map((bundleSet, index) => {
        let product = bundleSet.products?.map(function (prod) {
          delete prod.name;
          delete prod.sku;
          delete prod.productType;
          return prod;
        });

        var productSet = {
          productSetId: bundleSet.productSetId,
          name: bundleSet.name,
          isMandatory: handleIsMandatory(isMandatorySetList,bundleSet?.productSetId),
          products: product,
          ranking: bundleSet.ranking,
          tailoringAttributes: bundleSet.tailoringAttributes,
          productSetAttributes: bundleSet.productSetAttributes,
          isMasterData: bundleSet.isMasterData,
          isDefault: handleIsDefault(index),
          createdBy: `${firstName} ${lastName}`,
          updatedBy: `${firstName} ${lastName}`,
        };
        productSetIdList.push(productSet);
      });
    try {
      setShowOverlay(true);
      await createUncategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: null,
            ranking: 0,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo: null,
          },
          productSet: productSetIdList,
        },
      });
      setResetAllProductsTable(true);
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleCategorizedBundleProductSave = async () => {
    let productSetIdList = [];
    checkBoxListForSelectedBundleSet
      ?.sort(function (a, b) {
        return a.ranking - b.ranking;
      })
      .map((bundleSet) => {
        var productSet = {
          productSetId: bundleSet.productSetId,
          isMandatory: handleIsMandatory(isMandatorySetList,bundleSet?.productSetId),
        };
        productSetIdList.push(productSet);
      });
    try {
      setShowOverlay(true);
      await createCategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: categoryKey,
            ranking: maxRank + 1,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo: null,
          },
          productSet: productSetIdList,
        },
      });
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleUnCategorizedBundleProductSaveWithLastStep = async () => {
    let productSetIdList = [];
    let products = [];
    let productsUp = [];

    for (let i = 0; i < bundleSetDetails?.length; i++) {
      let newBS = bundleSetDetails[i];
      if (!newBS.hasOwnProperty("isNewlyAdded")) {
        //   this is global
        productsUp = newBS.productsList.map((val) => val);
        products = getProductInfoForBundleSet(productsUp);
        var newProductToPost = {
          productSetId: newBS.id,
          name: [{ text: newBS.name, languageCode: selectedLanguageInHeader }],
          productSetAttributes: [],
          tailoringAttributes: [],
          products: products,
          isMasterData: true,
          isMandatory: handleIsMandatory(isMandatorySetList,newBS?.id),
          isDefault: handleIsDefault(i),
          ranking: i,
          createdBy: `${firstName} ${lastName}`,
          updatedBy: `${firstName} ${lastName}`,
        };
      } else {
        //this is local

        let allAttributes = [];
        selectedVariantAttributeList.forEach((attr) => {
            const temp = handleTailoringDetails(undefined, attr, selectedLanguageInHeader);
            allAttributes.push(temp);
        });

        productsUp = newBS?.productsList?.map((val) => val);
        products = getProductInfoForBundleSet(productsUp);
        const productSetAttributes = selectedAttributeIdList.map((element) => {
          return {
            id: element,
            entityType: "ATTRIBUTE",
          };
        });

        var newProductToPost = {
          name: [{ text: newBS.name, languageCode: selectedLanguageInHeader }],
          productSetId: "",
          productSetAttributes: productSetAttributes,
          tailoringAttributes: allAttributes,
          products: products,
          isMasterData: false,
          isDefault: handleIsDefault(i),
          ranking: i,
          createdBy: `${firstName} ${lastName}`,
          isMandatory: handleIsMandatory(listOfMandatoryLocalBundleSet,newBS?.keyForMandatory),
          updatedBy: `${firstName} ${lastName}`,
        };
      }
      productSetIdList.push(newProductToPost);
    }
  
    try {
      setShowOverlay(true);
      await createUncategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: null,
            ranking: maxRank + 1,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo: null,
          },
          productSet: productSetIdList,
        },
      });
      handleResetContext();
      setResetAllProductsTable(true);
    } catch (e) {
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleProductSave = () => {
    if (activeStep === 1 && value === "BUNDLE") {
      if (isCategory) handleCategorizedBundleProductSave();
      else handleUnCategorizedBundleProductSave();
    } else if (activeStep === 4 && value == "BUNDLE") {
      handleUnCategorizedBundleProductSaveWithLastStep();
      // new name with same format..
    }
  };

  const handleNext = () => {
    if (activeStep === 0) {
      setShowOverlay(true);
      getValidation({
        variables: {
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader,
          },
          productFilter: {
            sku: itemNumberValue.trim(),
          },
          name: productName.trim(),
        },
      });
    } else setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    if (activeStep === 0) {
      setActiveStep(0);
      handleClose();
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  //function to handle the dialog content based on the active step in the stepper
  const handleDialogContent = () => {
    if (activeStep === 0 && openAddProductPopup)
      return (
        <AddNewProductScreen
          value={value}
          setRadioValue={setRadioValue}
          itemNumberValue={itemNumberValue}
          productName={productName}
          setItemNumber={setItemNumber}
          setErrorHandler={setErrorHandler}
          setErrorMessage={setErrorMessage}
          setProductName={setProductName}
          validationState={validationState}
          errorHandler={errorHandler}
          errorMessage={errorMessage}
        />
      );

    if (activeStep === 1 && value === "BUNDLE") {
      setIsCreateBundleSet(false);
      return <ShowBUndleSets setActiveStep={setActiveStep} />;
    }
    if (activeStep === 2 && value === "BUNDLE")
      return <AddVariantAttribute productType={value} />;
    if (activeStep === 3 && value === "BUNDLE") return <CreateBundle />;
    if (activeStep === 4 && value === "BUNDLE") return <AddProductsToBundle />;
  };

  const handleProductCheckInBundleSet = () => {
    var isProductPresentArray = [];
    for (let i = 0; i < bundleSetDetails?.length; i++) {
      let localBundleSet = bundleSetDetails[i];
      if (localBundleSet.hasOwnProperty("isNewlyAdded")) {
        //this is local bundle set
        var hasNoProduct =
          localBundleSet?.productsList === undefined ||
          localBundleSet?.productsList?.length === 0
        isProductPresentArray.push(hasNoProduct);
      }
    }
    return isProductPresentArray.includes(true);
  };

  const detailAboutProductInLocal = handleProductCheckInBundleSet();

  const renderCloseOrNextButton = () =>  activeStep === 1 && value === "BUNDLE" ? handleClose: handleNext

  const handleButtonChange = () => {
    return (
      <DialogActions>
        {activeStep !== 0 && (
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
        )}
        <Button
          variant="outlined"
          size="large"
          color="primary"
          onClick={handleBack}
        >
          {activeStep === 0 ? "Cancel" : "Previous Step"}
        </Button>
        <Button
          variant="contained"
          size="large"
          color="primary"
          disabled={
            itemNumberValue === "" ||
            productName.trim() === "" ||
            (activeStep === 1 &&
              value === "BUNDLE" &&
              JSON.stringify(checkBoxListForSelectedBundleSet) === "[]") ||
            (valueForNewBundleSetAccordian.filter((bundleSetVal) => {
              if (bundleSetVal.BundleSetName)
                return (
                  bundleSetVal.BundleSetName === null || bundleSetVal.BundleSetName === ""
                );
              else if (activeStep === 3) return true;
            }).length > 0) ||
            detailAboutProductInLocal && activeStep === 4
          }
          onClick={
            activeStep === steps.length - 1 || activeStep == 4
              ? handleProductSave
              : renderCloseOrNextButton()
          }
        >
          {activeStep === steps.length - 1 ||
            activeStep == 4 ||
            (activeStep === 1 && value === "BUNDLE")
            ? "Save and View"
            : "Next Step"}
        </Button>
      </DialogActions>
    );
  };
  return (
    <>
      <Grid item xs={9}>
        {value === "PRODUCT_VARIANT" || value === "" ? null : (
          <div className={stepperStyles.stepper}>
            <Stepper value={value} steps={steps} activeStep={activeStep} />
          </div>
        )}
      </Grid>
      <Grid item xs={9}>
        {handleDialogContent()}
        {errorHandler && (activeStep !== 0 || value === "PRODUCT_VARIANT") && (
          <div className={classes.errorDivStyle}>
            <Alert style={{ fontSize: "16px" }} severity="error">
              {dialogMessage.ADD_PRODUCTS_FAILURE_MSG + ":" + errorMessage}
            </Alert>
          </div>
        )}

        {errorHandler !== true &&
          (dataResponseForCategory !== undefined ||
            dataResponseForUnCategorized !== undefined)
          ? handleMoveToTailor(
            setSnackbarData,
            isCategory,
            setRowDetails,
            setSkuValue,
            setPublishDateForProduct,
            setIsProductAvailable,
            setProductDetail,
            setIsPublishProduct,
            history,
            setSelectedNavigationModule,
            dataResponseForCategory,
            dataResponseForUnCategorized
          )
          : null}
      </Grid>
      <Grid item xs={9} style={{ display: "flex", justifyContent: "flex-end" }}>
        {handleButtonChange()}
      </Grid>
    </>
  );
}
