import React, { useState, useContext } from "react";
import Button from "@material-ui/core/Button";
import DialogActions from "@material-ui/core/DialogActions";
import GlobalState from "../../../Context/GlobalState";
import { addPopupStyle } from "./ProductCreationStyle";
import { useMutation } from "@apollo/react-hooks";
import {
  GET_PRODUCTS_VARIANT_TREE,
  ASSOCIATE_PRODUCT_SET_TO_BUNDLE,
} from "../../Query";
import Alert from "@material-ui/lab/Alert";
import Overlay from "../../UI/Overlay";
import Stepper from "../../UI/Stepper";
import { getStepsForAddBundleSet, dialogMessage } from "../../../Utilities/Constants";
import AddVariantAttribute from "./VariantAttribute/AddVariantAttribute";
import { Grid } from "@material-ui/core";
import CreateBundle from "./BundleSets/CreateBundle";
import ShowBUndleSets from "./BundleSets/BundleSetListings";
import AddProductsToBundle from "./BundleSets/AddChildProductsToBundle/AddProductsToBundle";
import { handleTailoringDetails, handleIsMandatory,handleIsDefault, getProductInfoForBundleSet } from '../../../Utilities/CommonFunctions'

export default function AddProductPopupFromLocal(props) {
  const classes = addPopupStyle();
  const {
    value13,
    value24,
    value27,
    value37,
    value58,
    value74,
    value81,
    value92,
    value93,
    value94,
    value95,
    value97,
    value98,
    value105,
    value106,
    value110,
    value111,
    value117,
    value125,
    value126,
    value127,
    value146,
    value147,
    valueForCheckBoxBundleSet,
    newBundleSetAccordian,
    value168,
    value181,
    value183,
    value184,
    value185,
    value186,
    value187,
    value188,
    value189
  } = useContext(GlobalState);
  const [listOfMandatoryLocalBundleSet,setListOfMandatoryLocalBundleSet] = value13;
  const [openAddProductPopup, setOpenAddProductPopup] = value27;
  const [selectedChannelIDForHeader] = value37;
  const [defaultLanguageCode] = value58;
  const [, setSnackbarData] = value74;
  const [showOverlay, setShowOverlay] = value81;
  const [selectedVariantAttributeList, setSelectedVariantAttributeList] =
    value92;
  const [selectedAttributeIdList, setSelectedAttributeIdList] = value93;
  const [, setProductListForSelectedAttribute] = value94;
  const [, setSelectedChildProductList] = value95;
  const [, setCheckBoxListForVariantAttribute] = value97;
  const [, setCheckBoxListForChildProduct] = value98;
  const [, setIsCreateBundleSet] = value105;
  const [, setSelectedSupportedItems] = value106;
  const [bundleSetDetails, setBundleSetDetails] = value110;
  const [, setCheckBoxListForBundleSet] = value111;
  const [
    checkBoxListForSelectedBundleSet,
    setCheckBoxListForSelectedBundleSet,
  ] = value125;
  const [, setSelectedBundleSetId] = value126;
  const [isMandatorySetList, setIsMandatorySetList] = value127;
  const [, setValueOfCheckboxBundleSet] =
    valueForCheckBoxBundleSet;
  const [valueForNewBundleSetAccordian, setValueForNewBundleSetAccordian] =
    newBundleSetAccordian;
  const [rowDetails] = value24;
  const [firstName,] = value146;
  const [lastName,] = value147;
  const [bundleSetTailoredAttributes, setBundleSetTailoredAttributes] = value117;
  const [defaultBundleSet] = value168;
  const [, setAttributeListForFilterInCreateProduct] = value181;
  const [, setTailoredFilterAttributeValue] = value183;
  const [, setAdditionalFilterList] = value184;
  const [, setNumberOfFilterAvailable] = value185;
  const [, setSelectedAttributeDetailsOfFirstFilter] = value186;
  const [, setSelectedAttributeDetailsOfSecondFilter] = value187;
  const [, setSelectedAttributeIdOfFirstFilter] = value188;
  const [, setSelectedAttributeIdOfSecondFilter] = value189;


  const [itemNumberValue, setItemNumber] = useState("");
  const [productName, setProductName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [value, setRadioValue] = useState("BUNDLE");
  const [errorHandler, setErrorHandler] = useState(false);
  const [activeStep, setActiveStep] = React.useState(0);

  const steps = getStepsForAddBundleSet();

  const [associateProductSetToBundle] = useMutation(
    ASSOCIATE_PRODUCT_SET_TO_BUNDLE,
    {
      refetchQueries: [
        {
          query: GET_PRODUCTS_VARIANT_TREE,
          variables: {
            channelId: selectedChannelIDForHeader,
            productId: rowDetails.productId,
          },
        },
        
      ],
      awaitRefetchQueries: true,
      onCompleted: () => {

        setShowOverlay(false);
        setSnackbarData({
          show: true,
          message: "Bundle set(s) Added succesfully",
          severity: "success",
        });
      },
      onError: (e) => {
        setShowOverlay(false);
        setSnackbarData({
          show: true,
          message: `Error occured while adding Bundle Set(s) to a Bundle product: ${e.networkError.result.errors[0].message}`,
          severity: "error",
        });
      },
    }
  );

  const handleAddGlobaLocallBundleSet = async () => {
    let productsUp = [];
    let products = [];
    let productSetIdList = [];

    for (let i = 0; i < bundleSetDetails?.length; i++) {
      let newBS = bundleSetDetails[i];
      if (!newBS.hasOwnProperty("isNewlyAdded")) {
        //   this is global
        productsUp = newBS.productsList.map((val) => val);
        var newProductToPost = {
          productSetId: newBS.id,
          isMasterData: true,
          isDefault: defaultBundleSet !== "" ? false : handleIsDefault(i),
          name: [{ "text": newBS.name, "languageCode": defaultLanguageCode }],
          products: getProductInfoForBundleSet(productsUp),
          isMandatory: handleIsMandatory(isMandatorySetList,newBS?.id)
        };
      }

      else {
        //this is local
        let allAttributes = [...bundleSetTailoredAttributes]
        selectedVariantAttributeList.forEach(attr => {
          if (!allAttributes.some(attribute => attribute.attributeId === attr.key)) {
            const temp = handleTailoringDetails(undefined, attr, defaultLanguageCode)
            allAttributes.push(temp)
          }
        })
        productsUp = newBS.productsList.map((val) => val);
        products = getProductInfoForBundleSet(productsUp);
        const productSetAttributes = selectedAttributeIdList.map(element => {
          return {
            id: element,
            entityType: 'ATTRIBUTE'
          }
        })
        var newProductToPost = {
          name: [{ "text": newBS.name, "languageCode": defaultLanguageCode }],
          productSetId: "",
          productSetAttributes: productSetAttributes,
          tailoringAttributes: allAttributes,
          products: products,
          isMasterData: false,
          isMandatory:  handleIsMandatory(listOfMandatoryLocalBundleSet,newBS?.keyForMandatory),
          isDefault: defaultBundleSet !== "" ? false : handleIsDefault(i),
          ranking: i,
          createdBy: `${firstName} ${lastName}`,
          updatedBy: `${firstName} ${lastName}`,
        };
      }
      productSetIdList.push(newProductToPost);
    }

    try {

      const channelFilter = {
        channelId: selectedChannelIDForHeader,
        languageCode: defaultLanguageCode
      }

      const productSetFilter = {
        productId: props.data.productId,
        productSets: productSetIdList,
        productSetId: ""
      }

      setShowOverlay(true);
      await associateProductSetToBundle({
        variables: {
          channelFilter,
          user: `${firstName} ${lastName}`,
          productSetFilter
        },
      });
      handleClose();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleAddGlobalBundleSet = async () => {
    const productSets = checkBoxListForSelectedBundleSet.map((obj,index) => ({ productSetId: obj.productSetId, products: getProductInfoForBundleSet(obj.products), isMasterData: true, isDefault: defaultBundleSet !== "" ? false : handleIsDefault(index), name: obj.name }));
    const channelFilter = {
      channelId: selectedChannelIDForHeader,
      languageCode: defaultLanguageCode,
    };

    setShowOverlay(true);
    await associateProductSetToBundle({
      variables: {
        channelFilter,
        user: `${firstName} ${lastName}`,
        productSetFilter: {
          productId: props.data.productId,
          productSets
        }
      },
    });
    handleClose();
  }

  const handleProductSave = () => {
    if (activeStep === 0) {
      handleAddGlobalBundleSet()
    } else {
      handleAddGlobaLocallBundleSet();
    }
  };

  const handleClose = () => {
    setOpenAddProductPopup(false);
    setValueOfCheckboxBundleSet([])
    setBundleSetTailoredAttributes([])
    setListOfMandatoryLocalBundleSet([])
    setRadioValue("");
    setItemNumber("");
    setErrorHandler(false);
    setErrorMessage("");
    setSelectedVariantAttributeList([]);
    setSelectedChildProductList([]);
    setSelectedAttributeIdList([]);
    setCheckBoxListForVariantAttribute([]);
    setActiveStep(0);
    setCheckBoxListForChildProduct([]);
    setIsCreateBundleSet(false);
    setSelectedSupportedItems([]);
    setProductListForSelectedAttribute([]);
    setProductName("");
    setBundleSetDetails([
      {
        id: "set1",
        name: "Bundle Set 1",
        productsList: []
      },
      {
        id: "set2",
        name: "Bundle Set 2",
        productsList: []
      },
      {
        id: "set3",
        name: "Bundle Set 3",
        productsList: [],
      },
    ]);
    setSelectedBundleSetId([]);
    setIsMandatorySetList([]);
    setCheckBoxListForBundleSet([]);
    setCheckBoxListForSelectedBundleSet([]);
    setValueForNewBundleSetAccordian([]);
    setAttributeListForFilterInCreateProduct([]);
    setTailoredFilterAttributeValue([]);
    setAdditionalFilterList([]);
    setNumberOfFilterAvailable(0);
    setSelectedAttributeDetailsOfFirstFilter([]);
    setSelectedAttributeDetailsOfSecondFilter([]);
    setSelectedAttributeIdOfFirstFilter("");
    setSelectedAttributeIdOfSecondFilter("");
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    if (activeStep === 0) {
      setActiveStep(0);
      handleClose();
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };


  const handleDialogContent = () => {

    if ((activeStep === 0 && value === "BUNDLE" && openAddProductPopup)) {
      setIsCreateBundleSet(true);
      return <ShowBUndleSets
        setActiveStep={setActiveStep}
        activeStep={activeStep}
        value={value}
        setRadioValue={setRadioValue}
      />;
    }
    if (activeStep === 1 && value === "BUNDLE") {
      return <AddVariantAttribute productType={value} />;
    }
    if (activeStep === 2 && value === "BUNDLE") return <CreateBundle />;
    if (activeStep === 3 && value === "BUNDLE")
      return <AddProductsToBundle />;
  };

  const renderSaveOrNext = () => activeStep === 0 && value === "BUNDLE" ? handleProductSave : handleNext

  const isActiveStepZeroAndProductTypeBundle = () => activeStep === 0 && value === "BUNDLE"

  const handleNextButtonDisable = () => {
    return (
      valueForNewBundleSetAccordian.filter((bundleSetValue) => {
        if (bundleSetValue.BundleSetName)
          return (
            bundleSetValue.BundleSetName === null ||
            bundleSetValue.BundleSetName === ""
          );
        else if (activeStep === 2) return true;
      }).length > 0
    );
  };

  const handleSaveButtonDisable = () => {
    return (
      isActiveStepZeroAndProductTypeBundle() &&
      JSON.stringify(checkBoxListForSelectedBundleSet) === "[]"
    );
  };

  const handleButtonChange = () => {
    if (value === "PRODUCT" || value === "BUNDLE") {
      return (
        openAddProductPopup && (
          <DialogActions>
            {activeStep !== 0 && (
              <Button
                variant="outlined"
                size="large"
                color="primary"
                onClick={handleClose}
              >
                Cancel
              </Button>
            )}
            <Button
              variant="outlined"
              size="large"
              color="primary"
              onClick={handleBack}
            >
              {activeStep === 0 ? "Cancel" : "Previous Step"}
            </Button>
            <Button
              variant="contained"
              size="large"
              color="primary"
              disabled={handleSaveButtonDisable() || handleNextButtonDisable()}
              onClick={
                activeStep === steps.length - 1
                  ? handleProductSave
                  : renderSaveOrNext()
              }
            >
              {activeStep === steps.length - 1 ||
              isActiveStepZeroAndProductTypeBundle()
                ? "Save and View"
                : "Next Step"}
            </Button>
          </DialogActions>
        )
      );
    } else {
      return (
        <DialogActions>
        {activeStep !== 0 && (
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
        )}
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            disabled={
              value === "" || itemNumberValue === "" || productName === ""
            }
            variant="contained"
            size="large"
            onClick={handleProductSave}
            color="primary"
          >
            Save
          </Button>
        </DialogActions>
      );
    }
  };

  return (
    <Grid className={classes.gridStyle} container>
      {showOverlay ? <Overlay /> : null}

    <Grid item xs={9}>
      {value === "PRODUCT_VARIANT" || value === "" ? null : (
        <div style={{ display: "flex", paddingTop: "10px" }}>
          <Stepper value={value} activeStep={activeStep} steps={steps} />
        </div>
      )}
    </Grid>
      <Grid item xs={9}>
        {handleDialogContent()}
        {errorHandler && (
          <div className={classes.errorDivStyle}>
            <Alert
              severity="error"
              style={{ paddingLeft: "10px", fontSize: "16px" }}
            >
              {dialogMessage.ADD_PRODUCTS_FAILURE_MSG} : {errorMessage}
            </Alert>
          </div>
        )}
        </Grid>
        <Grid item xs={9} style={{ display: "flex", justifyContent: "flex-end" }}>
        {handleButtonChange()}
      </Grid>

    </Grid>
  );
}
