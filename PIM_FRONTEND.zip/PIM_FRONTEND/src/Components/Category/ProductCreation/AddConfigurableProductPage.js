import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import DialogActions from "@material-ui/core/DialogActions";
import GlobalState from "../../../Context/GlobalState";
import { addPopupStyle, stepperStyle } from "./ProductCreationStyle";
import { useLazyQuery, useMutation } from "@apollo/react-hooks";
import {
  CREATE_PRODUCT,
  GET_PRODUCTS_BY_CATEGORY,
  GET_ALL_PRODUCTS,
  GET_PRODUCTS_BY_BRAND,
  UPDATE_SUPPORTED_ATTRIBUTES_FOR_PRODUCT,
  VALIDATE_SKU_NAME_UNIQUENESS,
} from "../../Query";
import Alert from "@material-ui/lab/Alert";
import { useHistory } from "react-router-dom";
import Stepper from "../../UI/Stepper";
import AddNewProductScreen from "./AddNewProductScreen";
import { getSteps, dialogMessage } from "../../../Utilities/Constants";
import AddVariantAttribute from "./VariantAttribute/AddVariantAttribute";
import AddChildProduct from "./AddChildProductToConfigurable/AddChildProduct";
import { Grid } from "@material-ui/core";
import { handleMoveToTailor } from "../../../Utilities/CommonFunctions";

export default function AddConfigurableProductPage({
  isCategory,
  value,
  setRadioValue,
  itemNumberValue,
  setItemNumber,
  productName,
  setProductName,
  errorMessage,
  setErrorMessage,
  errorHandler,
  setErrorHandler,
  activeStep,
  setActiveStep,
  validationState,
  setValidationState,
  maxRank,
  handleClose,
  handleResetContext
}) {
  const stepperStyles = stepperStyle();
  const classes = addPopupStyle();
  const {
    value1,
    value6,
    value24,
    value27,
    value37,
    value58,
    value66,
    value69,
    value70,
    value74,
    value81,
    value92,
    value93,
    value95,
    value105,
    value106,
    value108,
    value134,
    value136,
    value146,
    value147,
    value214
  } = useContext(GlobalState);
  const [brand] = value1;
  const [openAddProductPopup] = value27;
  const [categoryKey] = value6;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [, setRowDetails] = value24;
  const [, setSkuValue] = value66;
  const [, setPublishDateForProduct] = value69;
  const [, setProductDetail] = value70;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [selectedVariantAttributeList] = value92;
  const [selectedAttributeIdList] = value93;
  const [selectedChildProductList] = value95;
  const [isCreateBundleSet] = value105;
  const [selectedSupportedItems] = value106;
  const [, setResetAllProductsTable] = value108;
  const [, setIsPublishProduct] = value134;
  const [, setIsProductAvailable] = value136;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setSelectedNavigationModule] = value214

  const steps = getSteps(value, isCreateBundleSet);
  const history = useHistory();

  const [updateSupportedAttributes] = useMutation(
    UPDATE_SUPPORTED_ATTRIBUTES_FOR_PRODUCT,
    {
      onCompleted: () => {
        setShowOverlay(false);
      },
    }
  );

  

  const [createCategorizedProduct, {data: dataResponseForCategory}] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_PRODUCTS_BY_CATEGORY,
          variables: {
            categoryId: categoryKey,
            channelFilter: {channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
          }
        },
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING"
            },
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING"
            }
          },
        },
      ],
      ignoreResults: false,
      onCompleted: () => {
        setShowOverlay(false);
      }
    });

  const [createUncategorizedProduct, {data: dataResponseForUnCategorized}] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize:50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING"
            }
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            channelFilter: {
              channelId:selectedChannelIDForHeader,
              languageCode:selectedLanguageInHeader,
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize:50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING"
            }
          },
        },
      ],
      ignoreResults: false,
      onCompleted: () => {
        setShowOverlay(false);
      }
    });

    const handleValidation = () => {
      if (validationLoading) {
        setShowOverlay(true);
      }

      if (validationError) {
        setShowOverlay(false);
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        setShowOverlay(false);
        const validateResult = validationResult?.product.validateProductSKUAndName;
        if (validateResult === "0") {
          setErrorHandler(false);
          setActiveStep((prevActiveStep) => prevActiveStep + 1);
          setValidationState();
        } else if (validateResult === "2") {
          setErrorHandler(true);
          setErrorMessage(dialogMessage.NAME_ALREADY_EXISTS_MSG);
          setValidationState(2);
        } else if (validateResult === "1") {
          setErrorHandler(true);
          setErrorMessage(dialogMessage.SKU_ALREADY_EXISTS_MSG);
          setValidationState(1);
        } 
      }
    };
  
    const [
      getValidation,
      {
        loading: validationLoading,
        error: validationError,
        data: validationResult,
      }
    ] = useLazyQuery(VALIDATE_SKU_NAME_UNIQUENESS, {
      fetchPolicy: "cache-and-network",
      onCompleted: () => handleValidation()
    });

  const handleUncategorizedProductSave = async () => {
    let childProductsList = [];
    let variantAttributeList = [];
    selectedChildProductList?.map((product, index) => {
      var obj = {
        ranking: index + 1,
        productId: product.key,
        isDefault: index === 0 ? true : false,
      };
      childProductsList.push(obj);
      return null;
    });

    selectedAttributeIdList?.map((attribute) => {
      var obj = {
        attributeId: attribute,
      };
      variantAttributeList.push(obj);
      return null;
    });
    try {
      setShowOverlay(true);
      await createUncategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: null,
            ranking: 0,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo:
              JSON.stringify(selectedChildProductList) === "[]"
                ? null
                : childProductsList,
            variantAttribute:
              JSON.stringify(selectedAttributeIdList) === "[]"
                ? null
                : variantAttributeList,
          },
        },
      });
      await updateSupportedAttributes({
        variables: {
          supportedAttributes: selectedSupportedItems,
          user: `${firstName} ${lastName}`,
          sku: itemNumberValue.trim(),
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader
          }
        },
      });
      setResetAllProductsTable(true);
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleCategorizedProductSave = async () => {
    let childProductsList = [];
    selectedChildProductList?.map((product, index) => {
      var obj = {
        ranking: index,
        productId: product.key,
        isDefault: index === 0 ? true : false,
      };
      childProductsList.push(obj);
      return null;
    });
    try {
      setShowOverlay(true);
      await createCategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: categoryKey,
            ranking: maxRank + 1,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo:
              JSON.stringify(selectedChildProductList) === "[]"
                ? null
                : childProductsList,
            variantAttribute:
              JSON.stringify(selectedAttributeIdList) === "[]"
                ? null
                : selectedAttributeIdList,
          },
        },
      });
      await updateSupportedAttributes({
        variables: {
          supportedAttributes: selectedSupportedItems,
          user: `${firstName} ${lastName}`,
          sku: itemNumberValue.trim(),
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader
          }
        },
      });
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleProductSave = () => {
    if (isCategory) handleCategorizedProductSave();
    else handleUncategorizedProductSave();
  };

  const handleNext = () => {
    if (activeStep === 0) {
      setShowOverlay(true);
      getValidation({
        variables: {
          channelFilter: {
            channelId: selectedChannelIDForHeader,
            languageCode: selectedLanguageInHeader
          },
          productFilter: {
            sku: itemNumberValue.trim()
          },
          name: productName.trim()
        }
      });
    } else setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    if (activeStep === 0) {
      setActiveStep(0);
      handleClose();
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  //function to handle the dialog content based on the active step in the stepper
  const handleDialogContent = () => {
    if (activeStep === 0 && openAddProductPopup)
      return (
        <AddNewProductScreen
          value={value}
          itemNumberValue={itemNumberValue}
          setRadioValue={setRadioValue}
          productName={productName}
          setItemNumber={setItemNumber}
          setErrorHandler={setErrorHandler}
          setErrorMessage={setErrorMessage}
          setProductName={setProductName}
          errorHandler={errorHandler}
          errorMessage={errorMessage}
          validationState={validationState}
        />
      );

    if (activeStep === 1 && value === "PRODUCT")
      return <AddVariantAttribute productType={value} />;

    if (activeStep === 2 && value === "PRODUCT") return <AddChildProduct />;
  };

  const handleButtonChange = () => {
    return (
      <DialogActions>
        {activeStep !== 0 && (
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
        )}
        <Button
          variant="outlined"
          size="large"
          color="primary"
          onClick={handleBack}
        >
          {activeStep === 0 ? "Cancel" : "Previous Step"}
        </Button>
        <Button
          variant="contained"
          size="large"
          color="primary"
          disabled={
            itemNumberValue === "" ||
            productName.trim() === "" ||
            (activeStep === steps.length - 1 &&
              value === "PRODUCT" &&
              JSON.stringify(selectedChildProductList) === "[]") ||
            (activeStep === 1 &&
              value === "PRODUCT" &&
              JSON.stringify(selectedVariantAttributeList) === "[]")
          }
          onClick={
            activeStep === steps.length - 1 ? handleProductSave : handleNext
          }
        >
          {activeStep === steps.length - 1 ? "Save and View" : "Next Step"}
        </Button>
      </DialogActions>
    );
  };

  return (
    <>
      <Grid item xs={9}>
        {value === "PRODUCT_VARIANT" || value === "" ?null:(
          <div className={stepperStyles.stepper}>
            <Stepper value={value} activeStep={activeStep} steps={steps} />
          </div>
        )}
      </Grid>
      <Grid item xs={9}>
        { handleDialogContent() }
        {errorHandler && (activeStep !== 0 || value === "PRODUCT_VARIANT") && (
          <div className={classes.errorDivStyle}>
            <Alert severity="error" style={{ fontSize:"16px" }}>
              {dialogMessage.ADD_PRODUCTS_FAILURE_MSG + ":" + errorMessage}
            </Alert>
          </div>
        )}
        {errorHandler !== true &&
          (dataResponseForCategory !== undefined || dataResponseForUnCategorized !== undefined) ? handleMoveToTailor(
            setSnackbarData,
            isCategory,
            setRowDetails,
            setSkuValue,
            setPublishDateForProduct,
            setIsProductAvailable,
            setProductDetail,
            setIsPublishProduct,
            history,
            setSelectedNavigationModule,
            dataResponseForCategory,
            dataResponseForUnCategorized
          )
          : null}
      </Grid>
      <Grid item xs={9} style={{ display: "flex", justifyContent: "flex-end" }}>
        {handleButtonChange()}
      </Grid>
    </>
  );
}
