import React, { useContext } from "react";
import { addPopupStyle } from "./ProductCreationStyle";
import Variant from "../../../Asset/single-item.svg";
import Product from "../../../Asset/products.svg";
import Bundle from "../../../Asset/bundle.svg";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormLabel from "@material-ui/core/FormLabel";
import { FormHelperText, Grid, TextField } from "@material-ui/core";
import RegexTextField from "../../UI/RegexTextField";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import GlobalState from "../../../Context/GlobalState";

export const RadioButtonComponent = ({ image, radioValue, radioName, imageName }) => {
  const classes = addPopupStyle();
  return (
    <Grid item xs={3} style={{ display: "flex" }}>
      <div style={{ paddingTop: "25px" }}>
        <Radio
          value={radioValue}
          color="primary"
          size="small"
          style={{ padding: "0px" }}
          name={radioName}
        />
      </div>
      <div style={{paddingLeft: "10px" }}>
        <img
          className={classes.radioImgStyle}
          height="50px"
          width="50px"
          alt="no pic"
          src={image}
        />
        <FormHelperText style={{display: "block",fontSize:"16px"}}>{imageName}</FormHelperText>
      </div>
    </Grid>
  );
};

export default function AddNewProduct({
  value,
  setRadioValue,
  itemNumberValue,
  productName,
  setItemNumber,
  setErrorHandler,
  setErrorMessage,
  setProductName,
  errorHandler,
  errorMessage,
  validationState,
}) {
  const { value92, value93, valueForBundleSetNameFromModal } =
    useContext(GlobalState);
  const [, setSelectedVariantAttributeList] = value92;
  const [, setSelectedAttributeIdList] = value93;
  const classes = addPopupStyle();
  const onlyAlphanumericRegex = /[^a-z0-9- ]/gi;
  const [, setBundleSetProductNameFromMoal] = valueForBundleSetNameFromModal;

  const handleChange = (event) => {
    setRadioValue(event.target.value);
    setErrorHandler(false);
    setErrorMessage("");
    setSelectedAttributeIdList([]);
    setSelectedVariantAttributeList([]);
  };

  return (
    <>
      <DialogTitle className={classes.title} disableTypography>
        Add New Product
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={1}>
          <Grid
            item
            xs={12}
            style={{ paddingLeft: "5px", paddingBottom: "30px" }}
          >
            <RegexTextField
              regex={onlyAlphanumericRegex}
              error={validationState === 1 && errorHandler}
              value={itemNumberValue}
              label="SKU *"
              helperText={validationState === 1 && errorHandler && errorMessage}
              style={{ width: "100%" }}
              onChange={(event) => {
                setItemNumber(event.target.value);
                setErrorHandler(false);
                setErrorMessage("");
              }}
            />
          </Grid>
          <Grid
            xs={12}
            item
            style={{ paddingLeft: "5px", paddingBottom: "30px" }}
          >
            <TextField
              id="productName"
              error={validationState === 2 && errorHandler}
              type="text"
              label="Product Name *"
              style={{ width: "100%" }}
              value={productName}
              helperText={validationState === 2 && errorHandler && errorMessage}
              onChange={(event) => {
                setProductName(event.target.value);
                setBundleSetProductNameFromMoal(event.target.value);
                setErrorHandler(false);
                setErrorMessage("");
              }}
            />
          </Grid>
          <Grid item xs={12} style={{ paddingBottom: "60px" }}>
            <FormLabel style={{ textTransform: "none", color: "#7000FF" }}>
              Type *
            </FormLabel>
            <RadioGroup
              aria-label="productType"
              value={value}
              name="productType"
              onChange={handleChange}
            >
              <Grid
                container
                spacing={1}
                style={{ display: "flex", paddingTop: "20px" ,justifyContent:"space-around"}}
              >
                <RadioButtonComponent
                  image={Variant}
                  radioName="variant-radio-button"
                  radioValue="PRODUCT_VARIANT"
                  imageName={"Simple Item"}
                />

                <RadioButtonComponent
                  image={Product}
                  radioName="product-radio-button"
                  radioValue="PRODUCT"
                  imageName={"Configurable"}
                />
                <RadioButtonComponent
                  image={Bundle}
                  radioName="bundle-radio-button"
                  radioValue="BUNDLE"
                  imageName={"Bundle"}
                />
              </Grid>
            </RadioGroup>
          </Grid>
        </Grid>
      </DialogContent>
    </>
  );
}
