import React, { useContext } from "react";
import {
  Button,
  FormHelperText,
} from "@material-ui/core";
import GlobalState from "../../../../Context/GlobalState";

export function FilterMenuField({
  classes,
  selectedIndexValue,
  handleAttributeList,
  handleAttributeSelectionFilter,
  renderControls,
  handleSetFilter,
  index,
}) {
  const { value186, value187, value188, value189 } = useContext(GlobalState);
  const [selectedAttributeDetailsOfFirstFilter] = value186;
  const [selectedAttributeDetailsOfSecondFilter] = value187;
  const [selectedAttributeIdOfFirstFilter] = value188;
  const [selectedAttributeIdOfSecondFilter] = value189;
  return (
    <div>
      <FormHelperText className={classes?.textStyle}>
        Select Attribute
      </FormHelperText>
      {selectedIndexValue === 1
        ? handleAttributeList(
            handleAttributeSelectionFilter,
            selectedAttributeIdOfFirstFilter
          )
        : selectedIndexValue === 2 &&
          handleAttributeList(
            handleAttributeSelectionFilter,
            selectedAttributeIdOfSecondFilter
          )}
      <FormHelperText className={classes?.textStyle}>=</FormHelperText>
      <FormHelperText className={classes?.textStyle}>
        Set Attribute Value
      </FormHelperText>
      {selectedIndexValue === 1
        ? renderControls(selectedAttributeDetailsOfFirstFilter)
        : selectedIndexValue === 2 &&
          renderControls(selectedAttributeDetailsOfSecondFilter)}
      <Button
        color="primary"
        disabled={
          (selectedIndexValue === 1 &&
            selectedAttributeDetailsOfFirstFilter[0]?.key === "none") ||
          (selectedIndexValue === 2 &&
            selectedAttributeDetailsOfSecondFilter[0]?.key === "none")
        }
        id={index}
        size="small"
        className={classes?.setFilterButtonStyle}
        onClick={(event) => handleSetFilter(event)}
      >
        Set Filter
      </Button>
    </div>
  );
}

export default FilterMenuField;
