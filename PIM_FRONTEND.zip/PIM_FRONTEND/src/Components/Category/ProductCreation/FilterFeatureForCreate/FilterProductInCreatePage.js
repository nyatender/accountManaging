import React, { useContext } from "react";
import { filterStyle } from "./FilterFeatureStyle";
import { Button, Tooltip } from "@material-ui/core";
import GlobalState from "../../../../Context/GlobalState";
import { ReactComponent as Plus } from "../../../../Asset/add_icon.svg";
import FilterDropDown from "./FilterDropDown";

function FilterProductInCreatePage({ isDisabled }) {
  const classes = filterStyle();
  const {
    value185,
  } = useContext(GlobalState);
  const [numberOfFilterAvailable, setNumberOfFilterAvailable] = value185;

  const handleAdd = () => {
    /* function to handle number of filter added*/
    var count = numberOfFilterAvailable + 1;
    setNumberOfFilterAvailable(count);
  };

  return (
    <div style={{ display: "flex", flexWrap: "wrap" }}>
      {numberOfFilterAvailable >= 1 && <FilterDropDown index={1} />}
      {numberOfFilterAvailable === 2 && <FilterDropDown index={2} />}

      {numberOfFilterAvailable < 2 && (
        <div className={classes.divStyle}>
          <Tooltip title="Add Additional Filter" placement="top">
            <Button
              variant="outlined"
              onClick={handleAdd}
              size={"small"}
              style={{ height: "35px" }}
              disabled={isDisabled}
            >
              <Plus width="15px" />
            </Button>
          </Tooltip>
        </div>
      )}
    </div>
  );
}

export default FilterProductInCreatePage;
