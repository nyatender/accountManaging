import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import FilterDropDown from "../FilterDropDown";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import { act } from "react-dom/test-utils";
import { wait } from "@apollo/react-testing";
import { Button } from "@material-ui/core";
import {StyledMenu} from "../../../../../Utilities/CommonStyle"
import FilterMenuField from "../FilterMenuField";

const props = 1
const propsContext = {
  attributeListForFilterInCreateProduct: [
    {
          inputControl: "TEXT_FIELD",
          key: "ffa75760-690a-45d0-940d-aa9301b3a2ac",
          textBoxData: [
            {
              text: 'Attribute Test'
            }
          ],
          name: "Text field attribute",
    }
  ],
  selectedAttributeDetailsOfFirstFilter: [
    {
      key: "ffa75760-690a-45d0-940d-aa9301b3a2ac",
      inputControl: "TEXT_FIELD",
      name: "Text field attribute",
      attributeValue: null,
      index: 1
   }
  ]
};

const getFilterDropDownComponent = (indexValue) => {
  let container;
  act(() => {
    container = mount(
      <GlobalContextProvider mockData={propsContext}>
      <FilterDropDown index={indexValue}/>
      </GlobalContextProvider>
    );
  });
  return container;
};

describe("FilterDropDown Component ", () => {
  it("matches FilterDropDown snap shot", () => {
    const subject = getFilterDropDownComponent(props)
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});

describe("FilterDropDown functional testing ", () => 
{
  it("Button should be present and should have Name as Set Filter when index is 0", async () => {
    let container;
    container = getFilterDropDownComponent(0);
    await act(() => wait(500));
    container.update();
    let button = container.find(Button).first();

    expect(button.exists()).toBeTruthy();
    expect(button.prop("id")).toEqual(0);
    expect(button.prop("color")).toEqual("none");
    expect(button.text()).toBe("Set Filteradd_icon.svg")
  });

  it("StyledMenu should be present and renders properly ", async () => 
  {
    let container;
    container = getFilterDropDownComponent(props);
    await act(() => wait(500));
    container.update();
    let menu = container.find(StyledMenu)
    expect(menu.exists()).toBeTruthy();
  });

  it("Menu is open and FilterMenuField is rendered properly", async () => {
    let container;
    container = getFilterDropDownComponent(props);
    await act(() => wait(500));
    container.update();
    let button = container.find(Button).first();
    button.simulate("click");
    await act(() => wait(300));
    container.update();
    expect(container.find(StyledMenu).first().prop("open")).toBe(true);
    expect(container.find(FilterMenuField)).toBeTruthy();
  });

  it("FilterMenuField render correct index value ", async () => 
  {
    let container;
    container = getFilterDropDownComponent(props);
    await act(() => wait(500));
    container.update();
    let button = container.find(Button).first();
    button.simulate("click");
    await act(() => wait(500));
    container.update();
    expect(container.find(FilterMenuField).prop("index")).toEqual(1);
    
  })

  it("Button name is Text field when index is 1 ", async () => 
  {
    let container;
    container = getFilterDropDownComponent(props);
    await act(() => wait(500));
    container.update();
    let button = container.find(Button).first();
    expect(button.text()).toEqual("Text field attributeadd_icon.svg");
  })

})
