import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import FilterProductInCreatePage from "../FilterProductInCreatePage";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider"

const props = {
    isDisabled : false
}

describe("FilterProductInCreatePage Component ", () => {
  it("matches FilterProductInCreatePage snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <FilterProductInCreatePage props={props}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
