import React, { useState, useContext } from "react";
import { filterStyle } from "./FilterFeatureStyle";
import { Button, TextField, Typography} from "@material-ui/core";
import GlobalState from "../../../../Context/GlobalState";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import { ReactComponent as Plus } from "../../../../Asset/add_icon.svg";
import Input from "@material-ui/core/Input";
import FormControl from "@material-ui/core/FormControl";
import Chip from "@material-ui/core/Chip";
import {
  isEmptyObject,
  getExistingFilterValue,
  handleTextEllipsis
} from "../../../../Utilities/CommonFunctions";
import FilterMenuField from "./FilterMenuField";
import { selectProps } from "../../../../Utilities/Constants";
import {StyledMenu,chipStyle} from "../../../../Utilities/CommonStyle"

function FilterDropDown({index}) {
  const classes = filterStyle();
  const chipStyleClasses= chipStyle();
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedIndexValue, setSelectedIndexValue] = useState(0);
  const {
    value181,
    value183,
    value184,
    value186,
    value187,
    value188,
    value189,
  } = useContext(GlobalState);
  const [attributeListForFilterInCreateProduct] = value181;
  const [tailoredFilterAttributeValue, setTailoredFilterAttributeValue] =
    value183;
  const [additionalFilterList, setAdditionalFilterList] = value184;
  const [selectedAttributeDetailsOfFirstFilter, setSelectedAttributeDetailsOfFirstFilter] = value186;
  const [selectedAttributeDetailsOfSecondFilter, setSelectedAttributeDetailsOfSecondFilter] = value187;
  const [, setSelectedAttributeIdOfFirstFilter] = value188;
  const [, setSelectedAttributeIdOfSecondFilter] = value189;

  const handleFilterDropDownClick = (event, indexValue) => {
    setAnchorEl(event.currentTarget);
    setSelectedIndexValue(indexValue);
  };

  const handleFilterDropDownClose = () => {
    setAnchorEl(null);
    setSelectedIndexValue(0);
  };

  function getExistingValueIndex(attribute) {
    for (let i = 0; i < attribute?.length; i++) {
      if (attribute[i].index === selectedIndexValue) return i;
    }
    return -1;
  }

  const renderAttributeValue = (event, attributeVal) => {
    return {
      attributeId: attributeVal.key,
      inputControl: attributeVal.inputControl,
      index: selectedIndexValue,
      attributeValue: event.target.value,
    };
  };

  const handleAttributeValueSelection = (e, attr) => {
    let existingAttributeValue = [...tailoredFilterAttributeValue];
    let temp = {};
    switch (attr.inputControl) {
      case "TEXT_FIELD": {
        temp = renderAttributeValue(e,attr);
        break;
      }
      case "DROPDOWN_LIST": {
        temp = renderAttributeValue(e,attr);
        break;
      }
      case "LISTBOX": {
        temp = renderAttributeValue(e,attr);
        break;
      }
      default: {
        break;
      }
    }
    /* If value for filter already exists then override the old value */
    const indexOfExistingValue = getExistingValueIndex(existingAttributeValue);
    if (indexOfExistingValue !== -1) {
      existingAttributeValue[indexOfExistingValue] = temp;
    } else {
      /*Else Append the new value */
      existingAttributeValue.push(temp);
    }
    setTailoredFilterAttributeValue(existingAttributeValue);
  };

  const getListOfAttribute = () => {
    if (attributeListForFilterInCreateProduct !== null) {
      return attributeListForFilterInCreateProduct.map((attribute) => (
        <MenuItem
          key={attribute.key}
          name={attribute}
          value={attribute.key}
          style={{ width: "130px" }}
        >
          {handleTextEllipsis(attribute?.name, classes.menuItemStyle)}
        </MenuItem>
      ));
    }
  };

  //function to handle attribute selection in filter
  const handleAttributeList = (handleFunction, value) => {
    return (
      <Select
        onChange={(event, item) => handleFunction(event, item)}
        value={value || " "}
        style={{ width: "150px" }}
        MenuProps={{
          classes: { paper: classes.menuPaper },
          anchorOrigin: {
            vertical: "bottom",
            horizontal: "left",
          },
          transformOrigin: {
            vertical: "top",
            horizontal: "left",
          },
          getContentAnchorEl: null,
        }}
      >
        {getListOfAttribute()}
      </Select>
    );
  };
  const renderDropDownControl = (attr) => {
    /* getting existing value  for the drop down*/
    const existingValueForControl = getExistingFilterValue(
      attr[0],
      tailoredFilterAttributeValue,
      selectedIndexValue
    );
    const dropDownValue =
      !isEmptyObject(existingValueForControl) &&
      existingValueForControl?.attributeValue
        ? existingValueForControl.attributeValue
        : "";
    return (
      <div style={{ display: "flex" }}>
        <TextField
          id={attr[0].key}
          select
          value={dropDownValue}
          style={{ width: "150px" }}
          SelectProps={selectProps}
          onChange={(e) => handleAttributeValueSelection(e, attr[0])}
        >
          {attr[0]?.attributeValue?.map((option) => (
            <MenuItem
              key={option.attributeValueId}
              value={option.attributeValueId}
            >
              <Typography>{option?.value[0]?.text}</Typography>
            </MenuItem>
          ))}
        </TextField>
      </div>
    );
  };

  const renderMultiSelectDropDownControl = (attr) => {
    /* getting existing value  for the multi select drop down*/
    const existingValueForControl = getExistingFilterValue(
      attr[0],
      tailoredFilterAttributeValue,
      selectedIndexValue
    );
    const multiSelectSelectedValues =
      existingValueForControl?.attributeValue || [];
    return (
      <div style={{ display: "flex" }}>
        <FormControl>
          <Select
            id={attr[0].key}
            multiple
            value={multiSelectSelectedValues}
            onChange={(e) => handleAttributeValueSelection(e, attr[0])}
            input={<Input id="select-multiple-chip" />}
            style={{ width: "150px" }}
            renderValue={(select) => (
              <div className={chipStyleClasses.chips}>
                {select?.map((value) => {
                  const label = attr[0]?.attributeValue?.filter(
                    (item) => item.attributeValueId === value
                  )[0]?.value[0]?.text;
                  return <Chip key={value} label={label} className={chipStyleClasses.chip} />;
                })}
              </div>
            )}
          >
            {attr[0]?.attributeValue.map((option) => (
              <MenuItem
                key={option.attributeValueId}
                value={option.attributeValueId}
              >
                <Typography>{option?.value[0]?.text}</Typography>
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    );
  };

  const renderTextFieldControl = (attr) => {
    /* getting existing value  for the text field*/
    const existingValueForControl = getExistingFilterValue(
      attr[0],
      tailoredFilterAttributeValue,
      selectedIndexValue
    );
    const textValue =
      !isEmptyObject(existingValueForControl) &&
      existingValueForControl.length !== 0
        ? existingValueForControl.attributeValue
        : "";
    return (
      <div style={{ display: "flex" }}>
        <TextField
          id={attr[0].key}
          value={textValue}
          style={{ width: "150px" }}
          onChange={(e) => handleAttributeValueSelection(e, attr[0])}
        />
      </div>
    );
  };

  const renderControls = (item) => {
    if (item.length !== 0) {
      if (item[0].inputControl === "DROPDOWN_LIST") {
        return renderDropDownControl(item);
      } else if (item[0].inputControl === "TEXT_FIELD") {
        return renderTextFieldControl(item);
      } else if (item[0].inputControl === "LISTBOX") {
        return renderMultiSelectDropDownControl(item);
      }
    }
  };

  const renderDefaultButtonTitle = () => "Set Filter"

  const handleButtonName = (indexValue) => {
    if (selectedAttributeDetailsOfFirstFilter?.length > 0 && indexValue === 1)
      return handleTextEllipsis(
        selectedAttributeDetailsOfFirstFilter[0]?.name,
        classes.menuItemStyle
      );
    else if (
      selectedAttributeDetailsOfSecondFilter?.length > 0 &&
      indexValue === 2
    )
      return handleTextEllipsis(
        selectedAttributeDetailsOfSecondFilter[0]?.name,
        classes.menuItemStyle
      );
    else return renderDefaultButtonTitle();
  };

  

  const handleSetFilter = () => {
    var filteredValue = [];

    tailoredFilterAttributeValue.forEach((value) => {
      var obj = {
        attributeId: value.attributeId,
        attributeValue: value.attributeValue,
        inputControl: value.inputControl,
      };
      filteredValue.push(obj);
    });
    setAdditionalFilterList(filteredValue);
    handleFilterDropDownClose();
  };


  const handleAttributeSelectionFilter = (event, item) => {
    var attributeList = [
      {
        inputControl: item?.props?.name?.inputControl,
        key: item?.props?.name?.key,
        name: item?.props?.name?.name,
        attributeValue: item?.props?.name?.attributeValues,
        index: selectedIndexValue,
      },
    ];

    if (selectedIndexValue === 1) {
      setSelectedAttributeIdOfFirstFilter(event.target.value);
      setSelectedAttributeDetailsOfFirstFilter(attributeList);
      if (item?.props?.name?.key === "none") {
        var keyRemovedValue = tailoredFilterAttributeValue.filter(
          (value) => value?.index === 1
        )[0]?.attributeId;
        setTailoredFilterAttributeValue(
          tailoredFilterAttributeValue.filter((value) => value.index !== 1)
        );
        setAdditionalFilterList(
          additionalFilterList.filter(
            (attribute) => attribute?.attributeId !== keyRemovedValue
          )
        );
      } else {
        setTailoredFilterAttributeValue(
          tailoredFilterAttributeValue.filter((value) => value.index !== 1)
        );
      }
    }

    if (selectedIndexValue === 2) {
      setSelectedAttributeIdOfSecondFilter(event.target.value);
      setSelectedAttributeDetailsOfSecondFilter(attributeList);
      if (item?.props?.name?.key === "none") {
        var keyRemovedVal = tailoredFilterAttributeValue.filter(
          (value) => value?.index === 2
        )[0]?.attributeId;
        setTailoredFilterAttributeValue(
          tailoredFilterAttributeValue.filter((value) => value.index !== 2)
        );
        setAdditionalFilterList(
          additionalFilterList.filter(
            (attribute) => attribute?.attributeId !== keyRemovedVal
          )
        );
      } else {
        setTailoredFilterAttributeValue(
          tailoredFilterAttributeValue.filter((value) => value.index !== 2)
        );
      }
    }
  };

  return (
    <div className={classes.divStyle} id={index}>
      <Button
        variant="outlined"
        size="medium"
        endIcon={<Plus width="15px" />}
        onClick={(event) => handleFilterDropDownClick(event, index)}
        tabIndex={index}
        id={index}
        className={classes.buttonStyle}
        color={handleButtonName(index) !== "Set Filter" ? "primary" : "none"}
      >
        {handleButtonName(index)}
      </Button>
      <StyledMenu
        tabIndex={index}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleFilterDropDownClose}
        arrow
        style={{ width: "220px", padding: "3px" }}
      >
        {Boolean(anchorEl) && (
          <FilterMenuField
            classes={classes}
            selectedIndexValue={selectedIndexValue}
            handleAttributeList={handleAttributeList}
            handleAttributeSelectionFilter={handleAttributeSelectionFilter}
            handleSetFilter={handleSetFilter}
            renderControls={renderControls}
            index={index}
          />
        )}
      </StyledMenu>
    </div>
  );
}

export default FilterDropDown;
