import { makeStyles } from "@material-ui/styles";

export const filterStyle = makeStyles(() => ({
   menuPaper:{
       maxHeight:"190px",
       maxWidth:"130px"
   },
   buttonStyle: {
    width:"160px",
    color: "#4d4f5c"
   },
   textStyle: {
       color: "#7a7d8e",
       fontSize: "13px",
   },
   setFilterButtonStyle: {
    display: "block",
     width:"20px",
    fontWeight:"bold"
   },
   divStyle: {
    padding: "8px 8px 0px 0px"
   },
   menuItemStyle:  {
    whiteSpace: "nowrap !important",
    overflow: "hidden !important",
    textOverflow: "ellipsis",
    display:"block",
  }
  }));
