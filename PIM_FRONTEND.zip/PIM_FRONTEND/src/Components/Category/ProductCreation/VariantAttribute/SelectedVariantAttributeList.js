import React, { useContext } from "react";
import IconButton from "@material-ui/core/IconButton";
import { selectedVariantAttributeListStyle } from "../ProductCreationStyle";
import { Grid, Tooltip } from "@material-ui/core";
import { StyledCardContent } from "../../../../Utilities/CommonStyle";
import GlobalState from "../../../../Context/GlobalState";
import { ReactComponent as Clear } from "../../../../Asset/clear-red.svg";
import Card from "@material-ui/core/Card";
import Typography from "@material-ui/core/Typography";

function SelectedVariantAttributeList({
  setSearchResults,
  setSearchTerm,
  setIsSearcResultEmpty,
}) {
  const classes = selectedVariantAttributeListStyle();
  const { value92, value93, value95, value97 } = useContext(GlobalState);
  const [selectedVariantAttributeList, setSelectedVariantAttributeList] =
    value92;
  const [selectedAttributeIdList, setSelectedAttributeIdList] = value93;
  const [, setSelectedChildProductList] = value95;
  const [checkBoxListForVariantAttribute, setCheckBoxListForVariantAttribute] =
    value97;

  const handleClear = (event, item) => {
    setSelectedVariantAttributeList(
      selectedVariantAttributeList.filter((x) => x !== item)
    );
    setSelectedAttributeIdList(
      selectedAttributeIdList.filter((x) => x !== item.key)
    );
    setSelectedChildProductList([]);
    setCheckBoxListForVariantAttribute(
      checkBoxListForVariantAttribute.filter((x) => x !== item)
    );
    setSearchTerm("");
    setSearchResults([]);
    setIsSearcResultEmpty(false);
  };

  return (
    <Grid
      container
      justify="center"
      className={classes.fullWidth}
      direction="column"
    >
      <Grid item xs={12} className={classes.gridItemStyle} >
        {selectedVariantAttributeList.map((item, index) => (
          <div className={classes.divCard}>
            <Card>
              <StyledCardContent>
                <Grid container spacing={0} style={{ display: "flex" }}>
                  <Grid item xs={10} style={{ display: "flex" }}>
                    <Tooltip title={item.value} placement="top-start">
                      <Typography className={classes.typographyStyle}>
                        {item.value}
                      </Typography>
                    </Tooltip>
                  </Grid>
                  <Grid item xs={2}>
                    <Tooltip title="Remove from the list" placement="top">
                      <IconButton onClick={(event) => handleClear(event, item)}>
                        <Clear height="17px" />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                </Grid>
              </StyledCardContent>
            </Card>
          </div>
        ))}
      </Grid>
    </Grid>
  );
}

export default SelectedVariantAttributeList;
