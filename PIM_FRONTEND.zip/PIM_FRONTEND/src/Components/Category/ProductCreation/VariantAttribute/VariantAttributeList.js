import React, { useEffect, useContext } from "react";
import { variantAttributeListStyle } from "../ProductCreationStyle";
import { GET_ALL_ATTRIBUTES } from "../../../Query";
import { useQuery } from "@apollo/react-hooks";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Spinner from "../../../UI/Spinner";
import GlobalState from "../../../../Context/GlobalState";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Checkbox from "@material-ui/core/Checkbox";
import { Grid, List, Tooltip } from "@material-ui/core";
import { dialogMessage } from "../../../../Utilities/Constants";
import Alert from "@material-ui/lab/Alert";
import { getListOfAttributesForFilter } from "../../../../Utilities/CommonFunctions";
import Search from "../../../UI/Search";

function VariantAttributeList({
  searchResults,
  setSearchResults,
  searchTerm,
  setSearchTerm,
  isSearchResultEmpty,
  setIsSearcResultEmpty,
  productType,
}) {
  const classes = variantAttributeListStyle();
  const {
    value37,
    value58,
    value91,
    value92,
    value93,
    value95,
    value97,
    value160,
    value162,
    value181
  } = useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [variantAttributeList, setVariantAttributeList] = value91;
  const [selectedVariantAttributeList, setSelectedVariantAttributeList] =
    value92;
  const [selectedAttributeIdList, setSelectedAttributeIdList] = value93;
  const [, setSelectedChildProductList] = value95;
  const [checkBoxListForVariantAttribute, setCheckBoxListForVariantAttribute] =
    value97;
  const [, setSelectedSimpleProductList] = value160;
  const [, setSelectedVariantAttributeIdListForConfigurable] = value162;
  const [, setAttributeListForFilterInCreateProduct] = value181;

  const handleFetchPolicy = () => {
    if (JSON.stringify(selectedVariantAttributeList) === "[]") return 'network-only'
    else return 'cache-first'
  }

  const {
    loading: attributeLoading,
    error: attributeError,
    data: attributeData,
  } = useQuery(GET_ALL_ATTRIBUTES, {
    variables: {
      filter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
    fetchPolicy: handleFetchPolicy()
  });


  useEffect(() => {
    if (JSON.stringify(selectedVariantAttributeList) === "[]") {
      handleAttributeList();
    }
  }, [attributeData]);

  let listOfVariantAttribute = [];
  const handleAttributeList = () => {
    if (attributeLoading) {
      return <div>Loading ...</div>;
    }

    if (attributeError) {
      return <div>Error ...</div>;
    }
    if (attributeData) {
      let apiData = attributeData.attributes.getAllAttributes;

      apiData
        ?.filter(
          (attributeValue) =>
            attributeValue.types.includes(productType) &&
            attributeValue.isEditable === true
        )
        ?.map((controlData) => {
          var obj = {
            key: controlData.attributeId,
            value: controlData.name[0].text,
            inputControl: controlData.inputControl,
            name: controlData.name,
            attributeValues: controlData.attributeValues,
            //entityType: controlData.type
          };
          listOfVariantAttribute.push(obj);
          return null;
        });

      getListOfAttributesForFilter(apiData, setAttributeListForFilterInCreateProduct);
      setVariantAttributeList(listOfVariantAttribute);
    }
  };



  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;
    setSelectedVariantAttributeIdListForConfigurable([]);

    if (isChecked === true) {
      setSelectedVariantAttributeList((prevArray) => [...prevArray, item]);
      setSelectedAttributeIdList((prevArray) => [...prevArray, item.key]);
      setCheckBoxListForVariantAttribute((prevArray) => [...prevArray, item]);
      setSelectedChildProductList([]);
      setSelectedSimpleProductList([]);
    }
    if (searchResults.length === 1) {
      setSearchTerm("");
      setSearchResults([]);
    }
    if (checkBoxListForVariantAttribute.includes(item) && isChecked === false) {
      setCheckBoxListForVariantAttribute(
        checkBoxListForVariantAttribute.filter((x) => x !== item)
      );
      setSelectedVariantAttributeList(
        selectedVariantAttributeList.filter((x) => x !== item)
      );
      setSelectedAttributeIdList(
        selectedAttributeIdList.filter((x) => x !== item.key)
      );
      setSelectedChildProductList([]);
      setSelectedSimpleProductList([]);
    }
  };

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
    const results = variantAttributeList.filter((attribute) =>
      attribute.value.toLowerCase().includes(event.target.value.toLowerCase())
    );
    setSearchResults(results);
    setIsSearcResultEmpty(false);
    if (JSON.stringify(results) === "[]") {
      setIsSearcResultEmpty(true);
    }
  };

  //function to list data based on searchResults or variantList
  const handleList = (listData) => {
    return listData
      .sort((a, b) => a.value.localeCompare(b.value))
      .map((item, index) => (
        <ListItem key={item.key} role={undefined} dense button>
          <ListItemIcon>
            <Checkbox
              edge="start"
              key={item.key}
              value={item}
              onChange={(event) => handleCheck(event, item)}
              tabIndex={-1}
              disableRipple
              color="primary"
              checked={checkBoxListForVariantAttribute.includes(item)}
            />
          </ListItemIcon>
          <Tooltip title={item.value} placement="top-start">
            <ListItemText
              id={item.key}
              primary={item.value}
              className={classes.listTextStyle}
              disableTypography
            />
          </Tooltip>
        </ListItem>
      ));
  };

  //function for clear button in search field
  const handleClear = () => {
    setSearchTerm("");
    setSearchResults([]);
    setIsSearcResultEmpty(false);
  };

  const attributeListData = !!searchTerm ? searchResults : variantAttributeList;

  const renderAttributeList = () => attributeLoading ? <Spinner message="Loading Attribute List" topHeight="0px" /> : renderAlertOrList();

  const renderAlertOrList = () => isSearchResultEmpty ? <Alert severity="info">{dialogMessage.SEARCH_RESULTS_MSG}</Alert> : handleList(attributeListData);

  return (
    <Grid
      container
      justify="center"
      className={`${classes.flexSection} ${classes.fullWidth}`}
      direction="column"
      style={{ border: "1px solid #EBE9E7" }}
    >
      <Grid item xs={12} className={classes.searchGrid}>
        <Search
          className={classes.searchBox}
          searchTerm={searchTerm}
          handleSearch={handleSearch}
          handleClearSearch={handleClear}
          width={"100%"}
        />
      </Grid>

      <Grid item xs={12} className={classes.gridItemStyle}>
        <div style={{height:"40vh"}}>
          <List>
            {renderAttributeList()}
          </List>
        </div>
      </Grid>
    </Grid>
  );
}

export default VariantAttributeList;
