import React, { useState, useContext } from "react";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { addVariantAttributeStyle } from "../ProductCreationStyle";
import VariantAttributeList from "./VariantAttributeList";
import { Grid } from "@material-ui/core";
import SelectedVariantAttributeList from "./SelectedVariantAttributeList";
import { dialogMessage } from "../../../../Utilities/Constants";
import GlobalState from "../../../../Context/GlobalState";
import Alert from "@material-ui/lab/Alert";

export default function AddVariantAttribute({ productType }) {
  const { value159 } = useContext(GlobalState);
  const classes = addVariantAttributeStyle();
  const [searchResults, setSearchResults] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isSearchResultEmpty, setIsSearcResultEmpty] = React.useState(false);
  const [openAddSimpleProductPopup] = value159;

  return (
    <div>
      <DialogTitle className={classes.dialogTitle} disableTypography>
        {productType === "PRODUCT"
          ? dialogMessage.ADD_VARIANT_ATTRIBUTE_MSG
          : dialogMessage.ADD_SUPPORTED_ATTRIBUTE_MSG}
      </DialogTitle>

      <div className={classes.dialogContentDisplay}>
        <DialogContentText className={classes.contentText1}>
          {productType === "PRODUCT"
            ? dialogMessage.VARIANT_ATTRIBUTE_DIALOG_CONTEXT_MSG1
            : dialogMessage.SUPPORTED_ATTRIBUTE_DIALOG_CONTEXT_MSG1}
        </DialogContentText>
        <DialogContentText className={classes.contentText2}>
          {productType === "PRODUCT"
            ? dialogMessage.VARIANT_ATTRIBUTE_DIALOG_CONTEXT_MSG2
            : dialogMessage.SUPPORTED_ATTRIBUTE_DIALOG_CONTEXT_MSG2}
        </DialogContentText>
      </div>

      <Grid container spacing={24}>
        <Grid item xs={12} sm={6} style={{ paddingRight: "1em" }}>
          <VariantAttributeList
            searchResults={searchResults}
            setSearchResults={setSearchResults}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            isSearchResultEmpty={isSearchResultEmpty}
            setIsSearcResultEmpty={setIsSearcResultEmpty}
            productType={productType}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <SelectedVariantAttributeList
            setSearchResults={setSearchResults}
            setSearchTerm={setSearchTerm}
            setIsSearcResultEmpty={setIsSearcResultEmpty}
          />
        </Grid>
      </Grid>

      <DialogContentText className={classes.footerText}>
        {dialogMessage.SELECT_ATTRIBUTES_MSG}
      </DialogContentText>
      <DialogContentText>
        {openAddSimpleProductPopup ? (
          <div style={{ fontStyle: "normal" }}>
            <Alert severity="info" style={{ fontSize: "13px" }}>
              <b>{dialogMessage.CHANGE_VARIANT_ATTRIBUTE_MSG} </b>
            </Alert>{" "}
          </div>
        ) : null}
      </DialogContentText>
    </div>
  );
}
