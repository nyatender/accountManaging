import { GET_ALL_ATTRIBUTES } from "../../../../Query";

module.exports = {
    context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
    },
    response: [
        {
            request: {
                query: GET_ALL_ATTRIBUTES,
                variables: {
                    filter: {
                        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                        languageCode: "en_GB"
                    }
                }
            },
            result: JSON.parse(`{
                "data": {
                    "attributes": {
                        "getAllAttributes": [
                            {
                                "attributeId": "ffa75760-690a-45d0-940d-aa9301b3a2ac",
                                "name": [
                                  {
                                    "text": "Item Group",
                                    "languageCode": "en_GB",
                                    "__typename": "TextTranslationOutput"
                                  }
                                ],
                                "isMandatory": false,
                                "inboundPropertyName": "ibd001_citg",
                                "scope": "GLOBAL",
                                "source": "INFOR_ITEM",
                                "inputControl": "TEXT_FIELD",
                                "isEditable": true,
                                "isDeletable": true,
                                "attributeCode": "ItemGroup",
                                "types": [
                                  "PRODUCT_VARIANT"
                                ],
                                "attributeValues": [],
                                "__typename": "AttributeOutputType"
                              },
                              {
                                "attributeId": "3060c224-c192-4ab9-8650-420af03fe0d2",
                                "name": [
                                  {
                                    "text": "EAN Code",
                                    "languageCode": "en_GB",
                                    "__typename": "TextTranslationOutput"
                                  }
                                ],
                                "isMandatory": false,
                                "inboundPropertyName": "ibd001_cean",
                                "scope": "GLOBAL",
                                "source": "INFOR_ITEM",
                                "inputControl": "TEXT_FIELD",
                                "isEditable": true,
                                "isDeletable": true,
                                "attributeCode": "EANCode",
                                "types": [
                                  "PRODUCT_VARIANT"
                                ],
                                "attributeValues": [],
                                "__typename": "AttributeOutputType"
                              }
                        ],
                        "__typename": "AttributeQuery"
                    }
                }
            }`)
        }
    ]
}