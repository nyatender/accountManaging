import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import SelectedVariantAttributeList from "../SelectedVariantAttributeList";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import IconButton from "@material-ui/core/IconButton";
import { act } from "react-dom/test-utils";

describe("SelectedVariantAttributeList Component ", () => {
  it("matches SelectedVariantAttributeList snap shot", () => {
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <SelectedVariantAttributeList />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it ("Should work without crashing", ()=>{
    let mockcontext = {
      selectedVariantAttributeList: [
        {
          attributeValues: [],
          inputControl: "TEXT_FIELD",
          key: "fe463873-690a-4dc6-80ed-a2c77cef22dc",
          name: [{text: 'BrandId', languageCode: 'en_GB', __typename: 'TextTranslationOutput'}],
          value: "BrandId"
        }
      ],
      selectedAttributeIdList: ['fe463873-690a-4dc6-80ed-a2c77cef22dc'],
      checkBoxListForVariantAttribute: [{
        attributeValues: [],
        inputControl: "TEXT_FIELD",
        key: "fe463873-690a-4dc6-80ed-a2c77cef22dc",
        name: [{text: 'BrandId', languageCode: 'en_GB', __typename: 'TextTranslationOutput'}],
        value: "BrandId"
      }],
    }
    let props = {
      setSearchResults: jest.fn(),
      setSearchTerm: jest.fn(),
      setIsSearcResultEmpty: jest.fn()
    }
    let wrapper;
    act(()=> {
      wrapper = mount(
        <GlobalContextProvider mockData={mockcontext}>
          <ApolloProvider client={client}>
            <SelectedVariantAttributeList {...props} />
          </ApolloProvider>
        </GlobalContextProvider>
      );
    })
    act(() => wrapper.find(IconButton).props().onClick())
    wrapper.update();
    expect(wrapper.find(IconButton).exists()).not.toBeTruthy();
  })
});
