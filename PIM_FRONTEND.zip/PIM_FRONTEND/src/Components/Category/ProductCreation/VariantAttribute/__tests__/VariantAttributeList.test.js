import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import VariantAttributeList from "../VariantAttributeList";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider"
import { act } from "react-dom/test-utils";
import {context, response} from "../__mocks__/VariantAttributeList_mocks";
import { MockedProvider, wait } from "@apollo/react-testing";
import Spinner from "../../../../UI/Spinner";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Checkbox from "@material-ui/core/Checkbox";

describe("VariantAttributeList Component ", () => {
  it("matches VariantAttributeList snap shot", () => {
    const props = {
      productType: "PRODUCT"
    }
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <VariantAttributeList props={props}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it("should display loading spinner during network request", async()=>{
    let wrapper;
    const props = {
      productType: "PRODUCT"
    }
    act(()=>{
      wrapper = mount(
        <GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
            <VariantAttributeList props={props}/>
          </MockedProvider>
        </GlobalContextProvider>
      );
    })
    expect(wrapper.find(Spinner).text()).toContain("Loading Attribute List");
  })

  it("should display list of attributes without error", async()=>{
    let wrapper;
    act(()=>{
      wrapper = mount(
        <GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
            <VariantAttributeList productType="PRODUCT_VARIANT"/>
          </MockedProvider>
        </GlobalContextProvider>
      );
    })
    await act(()=> wait(500));
    wrapper.update();
    expect(wrapper.find(ListItemIcon).length).toBe(2);
  })
  it("should be able to check list of attributes", async()=>{
    let wrapper;
    const props = {
      searchResults: [],
      setSearchResults: jest.fn(),
      searchTerm: "",
      setSearchTerm: jest.fn(),
      isSearchResultEmpty: false,
      setIsSearcResultEmpty: jest.fn(),
      productType: "PRODUCT_VARIANT"
    }
    act(() => {
      wrapper = mount(
        <GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
            <VariantAttributeList {...props}/>
          </MockedProvider>
        </GlobalContextProvider>
      );
    })
    await act(()=> wait(400));
    wrapper.update();
    act(()=> wrapper.find(Checkbox).first().props().onChange({target: { checked: true}}));
    wrapper.update();
    expect(wrapper.find(Checkbox).first().props().checked).toBeTruthy();
  })
});
