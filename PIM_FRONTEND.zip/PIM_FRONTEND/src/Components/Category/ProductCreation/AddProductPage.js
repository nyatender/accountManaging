import React, { useState, useContext } from "react";
import GlobalState from "../../../Context/GlobalState";
import { addPopupStyle } from "./ProductCreationStyle";
import { useQuery } from "@apollo/react-hooks";
import { GET_PRODUCTS_BY_CATEGORY } from "../../Query";
import AddSimpleProductPage from "./AddSimpleProductPage";
import AddConfigurableProductPage from "./AddConfigurableProductPage";
import AddBundleProductPage from "./AddBundleProductPage";
import Overlay from "../../UI/Overlay";
import { Grid } from "@material-ui/core";
import { getMaxRank } from "../../../Utilities/CommonFunctions";

export default function AddProductPage({ isCategory }) {
  const classes = addPopupStyle();
  const {
    value6,
    value13,
    value27,
    value37,
    value81,
    value92,
    value93,
    value94,
    value95,
    value97,
    value98,
    value105,
    value106,
    value110,
    value111,
    value125,
    value126,
    value127,
    value117,
    valueForCheckBoxBundleSet,
    newBundleSetAccordian,
    value134,
    value181,
    value183,
    value184,
    value185,
    value186,
    value187,
    value188,
    value189,
    value214,
    value58,
    value219
  } = useContext(GlobalState);
  const [openAddProductPopup, setOpenAddProductPopup] = value27;
  const [categoryKey] = value6;
  const [, setListOfMandatoryLocalBundleSet] = value13;
  const [selectedChannelIDForHeader] = value37;
  const [showOverlay] = value81;
  const [, setSelectedVariantAttributeList] = value92;
  const [, setSelectedAttributeIdList] = value93;
  const [, setProductListForSelectedAttribute] = value94;
  const [, setSelectedChildProductList] = value95;
  const [, setCheckBoxListForVariantAttribute] = value97;
  const [, setCheckBoxListForChildProduct] = value98;
  const [, setIsCreateBundleSet] = value105;
  const [, setSelectedSupportedItems] = value106;
  const [, setBundleSetDetails] = value110;
  const [, setCheckBoxListForBundleSet] = value111;
  const [, setCheckBoxListForSelectedBundleSet] = value125;
  const [, setSelectedBundleSetId] = value126;
  const [, setIsMandatorySetList] = value127;
  const [, setValueOfCheckboxBundleSet] = valueForCheckBoxBundleSet;
  const [, setValueForNewBundleSetAccordian] = newBundleSetAccordian;
  const [, setBundleSetTailoredAttributes] = value117;
  const [, setIsPublishProduct] = value134;
  const [, setAttributeListForFilterInCreateProduct] = value181;
  const [, setTailoredFilterAttributeValue] = value183;
  const [, setAdditionalFilterList] = value184;
  const [, setNumberOfFilterAvailable] = value185;
  const [, setSelectedAttributeDetailsOfFirstFilter] = value186;
  const [, setSelectedAttributeDetailsOfSecondFilter] = value187;
  const [, setSelectedAttributeIdOfFirstFilter] = value188;
  const [, setSelectedAttributeIdOfSecondFilter] = value189;
  const [, setSelectedNavigationModule] = value214;
  const [, setPageNumberForProductListInPopup] = value219;
  const [selectedLanguageInHeader] = value58;

  const [validationState, setValidationState] = useState();
  const [itemNumberValue, setItemNumber] = useState("");
  const [productName, setProductName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [value, setRadioValue] = useState("");
  const [errorHandler, setErrorHandler] = useState(false);
  const [activeStep, setActiveStep] = React.useState(0);

  const { loading, error, data } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: {
      categoryId: categoryKey,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
    skip: !openAddProductPopup || categoryKey === "" || isCategory === false,
  });

  const handleClose = () => {
    setSelectedNavigationModule("allProducts");
    handleResetContext();
  };

  const handleResetContext = () => {
    setOpenAddProductPopup(false);
    setValueOfCheckboxBundleSet([]);
    setBundleSetTailoredAttributes([]);
    setListOfMandatoryLocalBundleSet([]);
    setRadioValue("");
    setItemNumber("");
    setErrorHandler(false);
    setErrorMessage("");
    setSelectedVariantAttributeList([]);
    setSelectedChildProductList([]);
    setSelectedAttributeIdList([]);
    setCheckBoxListForVariantAttribute([]);
    setCheckBoxListForChildProduct([]);
    setActiveStep(0);
    setIsCreateBundleSet(false);
    setSelectedSupportedItems([]);
    setProductListForSelectedAttribute([]);
    setProductName("");
    setBundleSetDetails([
      {
        id: "set1",
        name: "Bundle Set 1",
        productsList: [],
      },
      {
        id: "set2",
        name: "Bundle Set 2",
        productsList: [],
      },
      {
        id: "set3",
        name: "Bundle Set 3",
        productsList: [],
      },
    ]);
    setCheckBoxListForBundleSet([]);
    setCheckBoxListForSelectedBundleSet([]);
    setSelectedBundleSetId([]);
    setIsMandatorySetList([]);
    setValueForNewBundleSetAccordian([]);
    setIsPublishProduct(false);
    setValidationState();
    setAttributeListForFilterInCreateProduct([]);
    setTailoredFilterAttributeValue([]);
    setAdditionalFilterList([]);
    setNumberOfFilterAvailable(0);
    setSelectedAttributeDetailsOfFirstFilter([]);
    setSelectedAttributeDetailsOfSecondFilter([]);
    setSelectedAttributeIdOfFirstFilter("");
    setSelectedAttributeIdOfSecondFilter("");
    setPageNumberForProductListInPopup(1);
  };

  const maxRank = getMaxRank(loading, error, data);

  const renderProductCreation = () =>
    value === "" || value === "PRODUCT_VARIANT"
      ? renderSimpleProductCreation()
      : renderConfigurableOrBundleCreation();

  const renderSimpleProductCreation = () => {
    return (
      <AddSimpleProductPage
        isCategory={isCategory}
        value={value}
        setRadioValue={setRadioValue}
        itemNumberValue={itemNumberValue}
        setItemNumber={setItemNumber}
        productName={productName}
        setProductName={setProductName}
        errorHandler={errorHandler}
        setErrorHandler={setErrorHandler}
        errorMessage={errorMessage}
        setErrorMessage={setErrorMessage}
        validationState={validationState}
        activeStep={activeStep}
        handleClose={handleClose}
        handleResetContext={handleResetContext}
        maxRank={maxRank}
      />
    );
  };

  const renderConfigurableOrBundleCreation = () =>
    value === "PRODUCT" ? renderConfigurableCreation() : renderBundleCreation();

  const renderConfigurableCreation = () => {
    return (
      <AddConfigurableProductPage
        isCategory={isCategory}
        value={value}
        setRadioValue={setRadioValue}
        itemNumberValue={itemNumberValue}
        setItemNumber={setItemNumber}
        productName={productName}
        setProductName={setProductName}
        errorHandler={errorHandler}
        setErrorHandler={setErrorHandler}
        errorMessage={errorMessage}
        setErrorMessage={setErrorMessage}
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        handleClose={handleClose}
        maxRank={maxRank}
        validationState={validationState}
        setValidationState={setValidationState}
        handleResetContext={handleResetContext}
      />
    );
  };

  const renderBundleCreation = () => {
    return (
      <AddBundleProductPage
        isCategory={isCategory}
        value={value}
        setRadioValue={setRadioValue}
        itemNumberValue={itemNumberValue}
        setItemNumber={setItemNumber}
        productName={productName}
        setProductName={setProductName}
        errorHandler={errorHandler}
        setErrorHandler={setErrorHandler}
        errorMessage={errorMessage}
        setErrorMessage={setErrorMessage}
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        handleClose={handleClose}
        maxRank={maxRank}
        validationState={validationState}
        setValidationState={setValidationState}
        handleResetContext={handleResetContext}
      />
    );
  };

  return (
    <Grid className={classes.gridStyle} container>
      {showOverlay ? <Overlay /> : null}
      {renderProductCreation()}
    </Grid>
  );
}
