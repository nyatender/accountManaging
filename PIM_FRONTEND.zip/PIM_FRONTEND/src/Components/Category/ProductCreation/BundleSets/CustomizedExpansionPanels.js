import React, { useContext } from "react";
import { withStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import BundleSetDataTable from "./BundleSetDataTable";
import Checkbox from "@material-ui/core/Checkbox";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import GlobalState from "../../../../Context/GlobalState";
import { FormControlLabel, Grid, Switch, IconButton } from "@material-ui/core";
import DeleteIcon from "@material-ui/icons/Delete";
import { customizedExpansionPanelStyle } from "../ProductCreationStyle";

const AccordionStyle = withStyles({
  root: {
    border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "none",
    marginBottom: "10px",
    "&:not(:last-child)": {
      borderBottom: 0,
    },
    borderRadius: "5px",
    "&:before": {
      display: "none",
    },
    "&$expanded": {
      margin: "auto",
    },
    cursor: "default",
  },
  expanded: {},
})(Accordion);

const AccordionDetailsStyle = withStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
}))(AccordionDetails);

const AccordionSummaryStyle = withStyles({
  root: {
    backgroundColor: "rgba(0, 0, 0, .03)",
    borderBottom: "1px solid rgba(0, 0, 0, .125)",
    borderRadius: "5px",
    marginBottom: -1,
    height: "40px",
    minHeight: 0,
    cursor: "default",
  },
  content: {
    "&$expanded": {
      margin: "12px 0",
    },
    cursor: "default",
  },
  expanded: { minHeight: "0 !important" },
})(AccordionSummary);
export default function CustomizedExpansionPanels({
  data,
  id,
  expanded,
  setExpanded,
  bundleSetData,
  bundleSetId,
  disableCheckbox
}) {
  const classes = customizedExpansionPanelStyle();
  const { name } = data;
  const { value125, value126, value127, valueForCheckBoxBundleSet } = useContext(GlobalState);
  const [
    checkBoxListForSelectedBundleSet,
    setCheckBoxListForSelectedBundleSet,
  ] = value125;
  const [selectedBundleSetId, setSelectedBundleSetId] = value126;
  const [isMandatorySetList, setIsMandatorySetList] = value127;
  const [valueOfCheckboxBundleSet, setValueOfCheckboxBundleSet] = valueForCheckBoxBundleSet;
  

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };
  const handleClickCheckbox = (e) => {
    var isChecked = e.target.checked;
    var bundleSetIdValue = e.target.value;
    const setValue = bundleSetData.filter(
      (value) => value.productSetId === e.target.value
    );
    const bundle = { ...setValue };
    if (isChecked === true) {
      setCheckBoxListForSelectedBundleSet((prevArray) => [
        ...prevArray,
        bundle[0],
      ]);
      setSelectedBundleSetId((prevArray) => [...prevArray, bundleSetIdValue]);
      setValueOfCheckboxBundleSet([...valueOfCheckboxBundleSet, bundle[0]]);
    }
    if (isChecked === false) {
      setCheckBoxListForSelectedBundleSet(
        checkBoxListForSelectedBundleSet.filter(
          (x) => x.productSetId !== bundle[0].productSetId
        )
      );
      setValueOfCheckboxBundleSet(
        valueOfCheckboxBundleSet.filter(
          (x) => x.productSetId !== bundle[0].productSetId
        )
      );
      setSelectedBundleSetId(
        selectedBundleSetId.filter((v) => v !== bundleSetIdValue)
      );
      setIsMandatorySetList(
        isMandatorySetList.filter((x) => x !== bundleSetIdValue)
      );
    }
    e.stopPropagation();
  };

  const handleIsMandatorySet = (e) => {
    var isChecked = e.target.checked;
    var bundleSetIdValue = e.target.value;

    if (isChecked) {
      setIsMandatorySetList((prevArray) => [...prevArray, bundleSetIdValue]);
    }
    if (isChecked === false) {
      setIsMandatorySetList(
        isMandatorySetList.filter((x) => x !== bundleSetIdValue)
      );
    }
    e.stopPropagation();
  };


  const handleDelete = (e,setId) => {
    e.stopPropagation();
    setValueOfCheckboxBundleSet(valueOfCheckboxBundleSet.filter((val) => val.productSetId !== setId));
    setCheckBoxListForSelectedBundleSet(
      checkBoxListForSelectedBundleSet.filter(
        (x) => x.productSetId !== setId
      )
    );
    setSelectedBundleSetId(
      selectedBundleSetId.filter((v) => v !== setId)
    );
  }
  return (
    <>
      <AccordionStyle
        square
        expanded={expanded === `panel_${id}`}
        onChange={handleChange(`panel_${id}`)}
      >
        <AccordionSummaryStyle
          aria-controls={`panel_${id}d-content`}
          id={`panel_${id}d-header`}
          expandIcon={<ExpandMoreIcon />}
        >
          <Grid container>
            <Grid item sm={1}>
              {!disableCheckbox &&
                <Checkbox
                  size="small"
                  value={bundleSetId}
                  color="primary"
                  onClick={(e) => handleClickCheckbox(e)}
                  id={id}
                  checked={selectedBundleSetId.includes(bundleSetId)}
                />
              }
            </Grid>
            <Grid item sm={6}>
              <Typography className={classes.typographyStyle}>
                {" "}
                {name === " " ? "-----" : `${name}`}
              </Typography>
            </Grid>
            <Grid item sm={5} style={{display:"flex",justifyContent:"flex-end"}}>
              <div className={classes.divStyle}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={isMandatorySetList.includes(bundleSetId)}
                      onClick={handleIsMandatorySet}
                      color="primary"
                      value={bundleSetId}
                      disabled={!selectedBundleSetId.includes(bundleSetId)}
                    />
                  }
                  labelPlacement="start"
                  label="Mandatory Set"
                  disableTypography={true}
                  classes={{ label: classes.label }}
                />

                {disableCheckbox &&
                <IconButton disabled={!disableCheckbox}  onClick={(e) => handleDelete(e,bundleSetId)}>
                  <DeleteIcon style={{ width: "20px", height: "20px" }} color="error"/>
                </IconButton>}
              </div> 
            </Grid>
          </Grid>
        </AccordionSummaryStyle>

        <AccordionDetailsStyle>
          <BundleSetDataTable data={data.productsData} />
        </AccordionDetailsStyle>
      </AccordionStyle>
    </>
  );
}
