import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import BundleSetDataTable from "../BundleSetDataTable";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";

const mockProps = {
    data: [
      {
        name: null,
        productId: "6628dfd0-8519-4ebe-9664-fb99860dc886",
        productType: "PRODUCT",
        ranking: 0,
        sku: "PIM-4574855",
      },
      {
        name: null,
        productId: "8207c3ee-d45b-4183-aad9-c3a4a8135b60",
        productType: "PRODUCT_VARIANT",
        ranking: 0,
        sku: "22356572"
      },
      {
        name: null,
        productId: "781736e5-e3b2-4325-8487-0e7ddcc4bcb4",
        productType: "BUNDLE",
        ranking: 0,
        sku: "PIS-Bundle1" 
      }
    ]
}

describe("BundleSetDataTable Component ", () => {
  it("matches BundleSetDataTable snap shot", () => {
    const props = {...mockProps, data:[]}
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <BundleSetDataTable {...props}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it ("renders BundleSetDataTable without crashing", ()=>{
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <BundleSetDataTable {...mockProps}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(wrapper.find({title: "Product"}).exists()).toBeTruthy();
    expect(wrapper.find({title: "Bundle"}).exists()).toBeTruthy();
    expect(wrapper.find({title: "Product Variant"}).exists()).toBeTruthy();
  })
});
