import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import CreateBundle from "../CreateBundle";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";

const mockContext = {
  valueForNewBundleSetAccordian: [
    {
        id: "set1",
        name: "Bundle Set 1",
        productsList: [],
    },
  ]
}
describe("CreateBundle Component ", () => {
  it("matches CreateBundle snap shot", () => {
    const subject = mount(
      <GlobalContextProvider mockData={mockContext}>
      <ApolloProvider client={client}>
        <CreateBundle/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
