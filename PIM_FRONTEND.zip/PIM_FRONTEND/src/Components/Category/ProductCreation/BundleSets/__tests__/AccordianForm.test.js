import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import AccordianForm from "../AccordianForm";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import { act } from "react-dom/test-utils";
import { TextField } from "@material-ui/core";

const props = {
    renderForm:jest.fn(),
    elem: [
        {
            BundleSetName: "BTE-Set",
            bundleSetName_64: ""
        },
        {
            BundleSetName: "ITE-Set",
            bundleSetName_37: ""
        }
    ],
    setElem: jest.fn()
}
describe("AccordianForm Component ", () => {
  it("matches AccordianForm snap shot", () => {
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <AccordianForm {...props}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it("renders AccordianForm Component without crashing", ()=>{
      let wrapper;
      act(()=>{
          wrapper = mount(
            <GlobalContextProvider>
              <ApolloProvider client={client}>
                <AccordianForm {...props}/>
              </ApolloProvider>
            </GlobalContextProvider>
          );
      })
      const mockEvent = {
        target: {
          name: "text field",
          value: "text value"
        },
        preventDefault: jest.fn(),
        persist: jest.fn()
      }
      act(() => wrapper.find(TextField).first().props().onChange(mockEvent));
      wrapper.update();
      expect(props.setElem).toHaveBeenCalled();
  })

});