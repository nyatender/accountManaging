import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import CustomizedExpansionPanels from "../CustomizedExpansionPanels";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import { act } from "react-dom/test-utils";
import Checkbox from "@material-ui/core/Checkbox";

const props = {
    data: {
        detailedTailoringAttributes: [],
        isDefault: false,
        isMandatory: false,
        isMasterData: true,
        name: "Test Bundle Set",
        productSetAttributes: [
            {entityType: "ATTRIBUTE", id: "b2a7ee31-6607-47d0-99c7-784fcf5dfd67"}
        ],
        productSetId: "9aee0ecb-6b25-4072-a409-c48f4a8ff19f",
        productsData: [
            {
                name: null,
                productId: "08c4787b-bb42-4f03-abd7-a179c5ac4db7",
                productType: "PRODUCT_VARIANT",
                ranking: 2,
                sku: "10954347",
            },
            {
                name: null,
                productId: "86b815e7-8dfe-4846-8811-50e5408b7ccc",
                productType: "PRODUCT_VARIANT",
                ranking: 0,
                sku: "49475747",
            },
            {
                name: "Connexx 9.2.10",
                productId: "cdc26cf3-90a7-453d-8634-2cf62091ac9a",
                productType: "PRODUCT_VARIANT",
                ranking: 1,
                sku: "PIM-365476574"
            }
        ],
        tailoringAttributes: [
            {
                attributeId: "b2a7ee31-6607-47d0-99c7-784fcf5dfd67",
                checkBoxListvalue: null,
                checkBoxvalue: false,
                dateTimevalue: "0001-01-01T00:00:00",
                dropdownvalue: null,
                inputControl: "IMAGE",
                pricevalue: 0,
                radioButtonListvalue: null
            }
        ]
    },
    id: 140,
    expanded: "panel_0",
    setExpanded: jest.fn(),
    bundleSetData: [
        {
            createdBy: "varun sateesh",
            detailedTailoringAttributes: [],
            isDefault: false,
            isMandatory: false,
            isMasterData: true,
            name: [{languageCode: "en_GB", text: "Test Bundle Set"}],
            productSetAttributes: [{entityType: "ATTRIBUTE", id: "b2a7ee31-6607-47d0-99c7-784fcf5dfd67"}],
            productSetId: "9aee0ecb-6b25-4072-a409-c48f4a8ff19f",
            products: [
                {
                    name: null,
                    productId: "08c4787b-bb42-4f03-abd7-a179c5ac4db7",
                    productType: "PRODUCT_VARIANT",
                    ranking: 2,
                    sku: "10954347",
                },
                {
                    name: null,
                    productId: "86b815e7-8dfe-4846-8811-50e5408b7ccc",
                    productType: "PRODUCT_VARIANT",
                    ranking: 0,
                    sku: "49475747",
                },
                {
                    name: "Connexx 9.2.10",
                    productId: "cdc26cf3-90a7-453d-8634-2cf62091ac9a",
                    productType: "PRODUCT_VARIANT",
                    ranking: 1,
                    sku: "PIM-365476574",
                }
            ],
            ranking: 140,
            tailoringAttributes: [{
                attributeId: "b2a7ee31-6607-47d0-99c7-784fcf5dfd67",
                checkBoxListvalue: null,
                checkBoxvalue: false,
                dateTimevalue: "0001-01-01T00:00:00",
                dropdownvalue: null,
                inputControl: "IMAGE",
                pricevalue: 0,
                radioButtonListvalue: null,
            }]
        }
    ],
    bundleSetId: "9aee0ecb-6b25-4072-a409-c48f4a8ff19f",
    disableCheckbox: undefined
}
describe("CustomizedExpansionPanels Component ", () => {
    it("matches CustomizedExpansionPanels snap shot", () => {
      const wrapper = mount(
        <GlobalContextProvider>
        <ApolloProvider client={client}>
          <CustomizedExpansionPanels {...props}/>
        </ApolloProvider>
        </GlobalContextProvider>
      );
      expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });

    it("should work checkbox properly", ()=>{
        let wrapper;
        act(()=>{
            wrapper = mount(
                <GlobalContextProvider>
                <ApolloProvider client={client}>
                  <CustomizedExpansionPanels {...props}/>
                </ApolloProvider>
                </GlobalContextProvider>
              );
        })
        const mockEvent = {
            target: {
                checked:true,
                value:"9aee0ecb-6b25-4072-a409-c48f4a8ff19f"
            },
            stopPropagation: jest.fn()
        }
        act(()=>{
            wrapper.find(Checkbox).props().onClick(mockEvent);
        })
        wrapper.update();
        expect(wrapper.find(Checkbox).props().checked).toBeTruthy();
    })
})