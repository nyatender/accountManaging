import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import BundleSetListings from "../BundleSetListings";
import { client } from "../../../../App";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import { act } from "react-dom/test-utils";
import {context, response} from "../__mocks__/BundleSetListings_mocks";
import { MockedProvider } from "@apollo/react-testing";
import Spinner from "../../../../UI/Spinner";

describe("BundleSetListings Component ", () => {
  it("matches BundleSetListings snap shot", () => {
    const wrapper = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <BundleSetListings />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });

  it("should display loading message during network request", ()=>{
    let wrapper;
    act(()=>{
      wrapper = mount(
        <GlobalContextProvider mockData={context}>
        <MockedProvider mocks={response}>
          <BundleSetListings />
        </MockedProvider>
        </GlobalContextProvider>
      );
    })
    expect(wrapper.find(Spinner).text()).toBe("Loading Bundle Sets...");
  })

  it("should display error message during network request fails", async ()=>{
    let wrapper;
    let mockContext = {...context, selectedChannelIDForHeader:"fakeID"}
    await act(async()=>{
      wrapper = mount(
        <GlobalContextProvider mockData={mockContext}>
        <MockedProvider mocks={response}>
          <BundleSetListings />
        </MockedProvider>
        </GlobalContextProvider>
      );
    })
    expect(wrapper.text()).toContain("Error occurred while loading Bundle Sets");
  })

  it("should render BundleSetListings component without crashing", async()=>{
    let wrapper;
    await act(async()=>{
      wrapper = mount(
        <GlobalContextProvider mockData={context}>
        <MockedProvider mocks={response}>
          <BundleSetListings />
        </MockedProvider>
        </GlobalContextProvider>
      );
    })
    expect(wrapper.find('[data-testid="bundle-set-listing"]').exists()).toBeTruthy()
  })
});
