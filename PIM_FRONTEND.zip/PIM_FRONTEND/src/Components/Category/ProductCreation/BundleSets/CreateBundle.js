import React, { useState, useContext, useEffect } from "react";
import { createBundleSetStyle } from "../ProductCreationStyle";
import Typography from "@material-ui/core/Typography";
import AddIcon from "@material-ui/icons/Add";
import IconButton from "@material-ui/core/IconButton";
import CustomizedExpansionPanels from "./CustomizedExpansionPanels";
import GlobalState from "../../../../Context/GlobalState";
import AccordianForm from "./AccordianForm";
import uuid from "react-uuid";

function CreateBundle() {
  const classes = createBundleSetStyle();
  const [expanded, setExpanded] = useState("");
  const {
    value92,
    valueForCheckBoxBundleSet,
    newBundleSetAccordian,
  } = useContext(GlobalState);
  const [valueOfCheckboxBundleSet] =
    valueForCheckBoxBundleSet;
  const [selectedVariantAttributeList] =
    value92;
  const [valueForNewBundleSetAccordian, setValueForNewBundleSetAccordian] =
    newBundleSetAccordian;


  const renderForm = () => {
    const arr = selectedVariantAttributeList.map((val, index) => val.value);
    const inputState = {};
    inputState["bundleSetName_" + window?.crypto?.getRandomValues(new Uint8Array(1))] = "";
    inputState["keyForMandatory"] = uuid();
    for (let i = 0; i < arr?.length; i++) {
      inputState[arr[i]] = "";
    }
    return setValueForNewBundleSetAccordian((prev) => [...prev, inputState]);
  };

  useEffect(function () {
    if (valueForNewBundleSetAccordian?.length < 1) {
      renderForm();
    }
  }, []);

  const handleBundleSetDisplay = () => {
    let newArray = [];
    valueOfCheckboxBundleSet.map((user, i) => {
      const bundleSet = {
        name: user.name[0].text,
        isMandatory: user.isMandatory,
        productsData: user.products,
        productSetId: user.productSetId
      };
      newArray.push(bundleSet);
    });
    return newArray;
  };

  const handleExpansion = (user, i) => {
    return (
      <CustomizedExpansionPanels
        data={user}
        id={i}
        expanded={expanded}
        setExpanded={setExpanded}
        disableCheckbox={true}
        bundleSetId={user.productSetId}
      />
    );
  };
  const tempData = handleBundleSetDisplay();
  
  return (
    <div style={{width:"100%"}}>
        <div className={classes.header}>
          <Typography
            component="h4"
            variant="h4"
            className={classes.typography1}
          >
            Create Bundle Sets
          </Typography>
          <IconButton
            classes={{ label: classes.iconButton1 }}
            style={{ marginRight: "1%" }}
            onClick={renderForm}
          >
            <AddIcon />
          </IconButton>
        </div>

      <div className={classes.bundleSetList}>
            {tempData?.map((user, i) => handleExpansion(user, i))}
              <AccordianForm
                renderForm={renderForm}
                elem={valueForNewBundleSetAccordian}
                setElem={setValueForNewBundleSetAccordian}
              />
      </div>
    </div>
  );
}

export default CreateBundle;
