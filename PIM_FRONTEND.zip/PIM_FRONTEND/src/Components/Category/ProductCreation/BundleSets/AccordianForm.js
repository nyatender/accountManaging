import React, { useEffect, useState, useContext } from "react";
import { createBundleSetStyle } from "../ProductCreationStyle";
import { Grid, FormControlLabel } from "@material-ui/core";
import Switch from "@material-ui/core/Switch";
import IconButton from "@material-ui/core/IconButton";
import GlobalState from "../../../../Context/GlobalState";
import TextField from "@material-ui/core/TextField";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import DeleteIcon from "@material-ui/icons/Delete";
import { withStyles } from "@material-ui/core/styles";

const AccordionStyle = withStyles({
  root: {
    border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "none",
    marginBottom: "10px",
    "&:not(:last-child)": {
      borderBottom: 0,
    },
    borderRadius: "5px",
    "&:before": {
      display: "none",
    },
    "&$expanded": {
      margin: "auto",
    },
    cursor: "default",
  },
  expanded: {},
})(Accordion);

const AccordionDetailsStyle = withStyles((theme) => ({
  root: {
    // padding: theme.spacing(2),
  },
}))(AccordionDetails);

const AccordionSummaryStyle = withStyles({
  root: {
    backgroundColor: "rgba(0, 0, 0, .03)",
    borderBottom: "1px solid rgba(0, 0, 0, .125)",
    borderRadius: "5px",
    marginBottom: -1,
    height: "40px",
    minHeight: 0,
    cursor: "default",
  },
  content: {
    "&$expanded": {
      margin: "12px 0",
    },
    cursor: "default",
    justifyContent: "flex-end",
  },
  expanded: { minHeight: "0 !important" },
})(AccordionSummary);

function AccordianFormComp({ renderForm, elem, setElem }) {
  const classes = createBundleSetStyle();
  const [expanded, setExpanded] = useState(0);

  const { newBundleSetAccordian, value13, value92, value117 } =
    useContext(GlobalState);
  const [listOfMandatoryLocalBundleSet, setListOfMandatoryLocalBundleSet] =
    value13;
  const [valueForNewBundleSetAccordian, setValueForNewBundleSetAccordian] =
    newBundleSetAccordian;
  const [selectedVariantAttributeList] = value92;
  const [, setBundleSetTailoredAttributes] = value117;

  const selectedList = [
    { inputControl: "TEXT_FIELD", value: "BundleSetName" },
    ...selectedVariantAttributeList,
  ];

  useEffect(function () {
    setBundleSetTailoredAttributes([]);
    renderForm();
  }, []);

  const handleChange1 = (e, index) => {
    e.preventDefault();
    e.persist();

    setElem((prev) => {
      return prev.map((item, i) => {
        if (i !== index) return item;
        return {
          ...item,
          [e.target.name]: e.target.value,
        };
      });
    });
  };

  useEffect(
    function () {
      setValueForNewBundleSetAccordian(elem);
    },
    [elem]
  );

  const handleAccordionChange = (e, index) => {
    setExpanded(index);
  };

  const handleMandatoryField = (bundleSetKey) => {
    if (listOfMandatoryLocalBundleSet?.includes(bundleSetKey)) {
      setListOfMandatoryLocalBundleSet(
        listOfMandatoryLocalBundleSet.filter(
          (bundleSetId) => bundleSetId !== bundleSetKey
        )
      );
    } else setListOfMandatoryLocalBundleSet((prevArray) => [
        ...prevArray,
        bundleSetKey,
      ]);
  };

  const renderInputs = () => {
    return elem.map((item, i) => {
      return (
        <AccordionStyle
          expanded={expanded === i}
          onChange={(e) => handleAccordionChange(e, i)}
        >
          <AccordionSummaryStyle
            expandIcon={<ExpandMoreIcon expanded={true} />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            style={{ backgroundColor: "rgba(0, 0, 0, .03)", height: 40 }}
          >
            <div>
              <FormControlLabel
                control={
                  <Switch
                    checked={listOfMandatoryLocalBundleSet?.includes(
                      item?.keyForMandatory
                    )}
                    color="primary"
                    disabled={false}
                    onClick={() => handleMandatoryField(item?.keyForMandatory)}
                  />
                }
                labelPlacement="start"
                label="Mandatory Set"
                disableTypography={true}
                classes={{ label: classes.label }}
              />
              <IconButton
                onClick={(e) =>
                  setElem((val) => val.filter((idx) => idx !== i))
                }
              >
                <DeleteIcon
                  style={{ width: "20px", height: "20px" }}
                  color="error"
                />
              </IconButton>
            </div>
          </AccordionSummaryStyle>
          <Grid
            noValidate
            autoComplete="off"
            container
            xs={12}
            md={12}
            spacing={3}
          >
            {selectedList.map((attribute, index) => (
              <AccordionDetailsStyle>
                <Grid item md={12} xs={12} key={index}>
                  {attribute.value === "BundleSetName" && (
                    <TextField
                      required
                      id={attribute.key}
                      label={attribute.value}
                      name={attribute.value}
                      value={valueForNewBundleSetAccordian[i]?.BundleSetName}
                      onChange={(e) => handleChange1(e, i)}
                      style={{ margin: "16px", width: "50em" }}
                    />
                  )}
                </Grid>
              </AccordionDetailsStyle>
            ))}
          </Grid>
        </AccordionStyle>
      );
    });
  };

  return <div>{renderInputs()}</div>;
}

const AccordianForm = React.memo(AccordianFormComp);
export default AccordianForm;
