import React, { useContext, useEffect } from "react";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { addChildProductStyle } from "../../ProductCreationStyle";
import ProductListForBundle from "./ProductListForBundle";
import { Grid, Button } from "@material-ui/core";
import { dialogMessage,SEARCH_CONTEXT } from "../../../../../Utilities/Constants";
import BundleSetWithProduct from "./BundleSetWithProduct";
import GlobalState from "../../../../../Context/GlobalState";

export default function AddProductsToBundle() {
  const classes = addChildProductStyle();
  const { value98, value110, value111, valueForCheckBoxBundleSet, value95, newBundleSetAccordian } = useContext(GlobalState);
  const [checkBoxListForChildProduct, setCheckBoxListForChildProduct] = value98;
  const [bundleSetDetails, setBundleSetDetails] = value110;
  const [checkBoxListForBundleSet, setCheckBoxListForBundleSet] = value111;
  const [valueOfCheckboxBundleSet] = valueForCheckBoxBundleSet;
  const [selectedChildProductList, setSelectedChildProductList] = value95;
  const [valueForNewBundleSetAccordian] = newBundleSetAccordian;


  useEffect(function () {
    let newObj2 = {};
    let newArr = [];

    for (let i = 0; i < valueOfCheckboxBundleSet?.length; i++) {
      let obj = valueOfCheckboxBundleSet[i];
      newObj2 = { "id": obj.productSetId, "name": obj.name[0].text, "productsList": obj.products, isGlobal: true };
      newArr.push(newObj2);
    }

    valueForNewBundleSetAccordian.map((val, index) => {
      newObj2 = { "id": index, "name": val['BundleSetName'], "isNewlyAdded": true, isGlobal: false, "keyForMandatory": val?.keyForMandatory };
      newArr.push(newObj2);
    });
    setBundleSetDetails(newArr);

  }, [])

  const handleAssociate = () => {
    const clonedData = [...bundleSetDetails];

    clonedData.forEach(obj => {
      if (Object.keys(obj).includes("isNewlyAdded")) {
        if (checkBoxListForBundleSet[0] === obj["id"]) {
          if (!obj.productsList) {
            obj.productsList = selectedChildProductList
          }
          else {
            obj.productsList.push(...selectedChildProductList)
          }
        }
      }
    });

    const localSet = clonedData.filter(set => set.hasOwnProperty('isNewlyAdded'))
    const jsonObject = localSet[0]?.productsList?.map(JSON.stringify)
    const uniqueSet = [...new Set(jsonObject)]
    const uniqueArray = uniqueSet?.map(JSON.parse)
    clonedData?.forEach(element => {
      if (element.hasOwnProperty('isNewlyAdded')) {
        element.productsList = uniqueArray
      }
    })

    setCheckBoxListForChildProduct([]);
    setSelectedChildProductList([])
    setBundleSetDetails(clonedData);
    setCheckBoxListForBundleSet([]);
  };

  return (
    <div>
      <DialogTitle className={classes.dialogTitle} disableTypography>
        {dialogMessage.ADD_PRODUCTS_TO_BUNDLESET_MSG}
      </DialogTitle>

      <div className={classes.dialogContentDisplay}>
        <DialogContentText className={classes.contentText1}>
          {dialogMessage.PRODUCT_CATALOG_MESSAGE}
        </DialogContentText>
        <DialogContentText className={classes.contentText2}>
          {dialogMessage.BUNDLE_SET_MESSAGE}
        </DialogContentText>

        <DialogContentText className={classes.contentText3}>
          <Button
            color="primary"
            style={{ textDecoration: "underline", fontWeight: "Bold" }}
            onClick={handleAssociate}
            disabled={
              JSON.stringify(checkBoxListForChildProduct) === "[]" ||
              JSON.stringify(checkBoxListForBundleSet) === "[]"
            }
          >
            Add to Bundle Set
          </Button>
        </DialogContentText>
      </div>

      <Grid container spacing={24}>
        <Grid item xs={12} sm={6} className={classes.gridItemStyle}>
          <ProductListForBundle
            searchTermContext={SEARCH_CONTEXT.bundleProductCreatePage}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <BundleSetWithProduct
            setBundleSetDetails={setBundleSetDetails}
            bundleSetDetails={bundleSetDetails}
          />
        </Grid>
      </Grid>

      <DialogContentText className={classes.footerText}>
      {dialogMessage.SELECT_PRODUCT_TO_ADD_MSG}
      </DialogContentText>
    </div>
  );
}
