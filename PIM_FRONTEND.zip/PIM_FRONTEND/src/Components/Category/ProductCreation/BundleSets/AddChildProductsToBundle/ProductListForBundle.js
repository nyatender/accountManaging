import React, { useState, useEffect, useContext } from "react";
import { useQuery } from "@apollo/react-hooks";
import Pagination from "@material-ui/lab/Pagination";
import {
  Grid,
  ListItemText,
  ListItem,
  ListItemIcon,
  Checkbox,
  Tooltip,
} from "@material-ui/core";
import GlobalState from "../../../../../Context/GlobalState";
import {
  GET_PAGINATION_INFO,
  GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE,
} from "../../../../Query";
import Spinner from "../../../../UI/Spinner";
import { variantAttributeListStyle } from "../../ProductCreationStyle";
import AlertBox from "../../../../UI/AlertBox";
import FilterProductFunctionality from "../../FilterFeatureForCreate/FilterProductInCreatePage";
import { getProductNameAndSKU } from "../../../../../Utilities/CommonFunctions";
import { ellipsisTextStyle } from "../../../../../Utilities/CommonStyle";
import {SEARCH_CONTEXT} from "../../../../../Utilities/Constants";
import Search from "../../../../Search/search";

export default function ProductListForBundle({searchTermContext}) {
  const classes = variantAttributeListStyle();
  const textClasses = ellipsisTextStyle();
  const 
  { 
    value37, 
    value58,  
    value95, 
    value98, 
    value184,
    value218,
    value219
  } = useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [selectedChildProductList, setSelectedChildProductList] = value95;
  const [checkBoxListForChildProduct, setCheckBoxListForChildProduct] = value98;
  const [additionalFilterList] = value184;
  const [productSearchTerm] = value218;
  const [pageNumberForProductListInPopup, setPageNumberForProductListInPopup] = value219;

  const [ productListForSelectedAttributes, setProductListForSelectedAttributes] = useState([]);


  const {
    loading: paginationInfoLoading,
    error: paginationInfoError,
    data: paginationInfoData,
  } = useQuery(GET_PAGINATION_INFO, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      pageSize: 25,
    },
  });
  const {
    loading: productLoading,
    error: productError,
    data: productData,
  } = useQuery(GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      variantAttributeFilters: [],
      additionalAttributeFilters: additionalFilterList,
      paginationFilter: {
        pageNumber: pageNumberForProductListInPopup,
        pageSize: 50,
        sortBy: "CreatedAt",
        sortDirection: "DESCENDING",
      },
      searchFilter: productSearchTerm[searchTermContext]
    },
  });

  const handleProductList = () => {
    if (productLoading) {
      return <div>Loading ...</div>;
    }

    if (productError) {
      return <div>Error ...</div>;
    }
    if (productData.product.getProductsByChannelAndAttributes) {
      let apiData = productData.product.getProductsByChannelAndAttributes;

      setProductListForSelectedAttributes(apiData);
    }
  };
  const handleCheckboxChange = (event, item) => {
    const isChecked = event.target.checked;
    if (isChecked) {
      setCheckBoxListForChildProduct((prev) => [...prev, item]);
      setSelectedChildProductList((prev) => [...prev, item]);
    } else {
      setCheckBoxListForChildProduct(
        checkBoxListForChildProduct.filter(
          (elm) => elm.productId !== item.productId
        )
      );
      setSelectedChildProductList(
        selectedChildProductList.filter(
          (elm) => elm.productId !== item.productId
        )
      );
    }
  };

  useEffect(() => {
    handleProductList();
  }, [productData]);

  const handlePageChange = (e, page) => {
    setPageNumberForProductListInPopup(page);
  };

  const listData =  productListForSelectedAttributes;

  const renderPagination = () => {
    return (
      listData?.length > 25 && (
        <div className={classes.pagination}>
          <Pagination
            count={
              paginationInfoData &&
              paginationInfoData.product.getPaginationInfo.pageCount
            }
            color="primary"
            size="medium"
            onChange={handlePageChange}
          />
        </div>
      )
    );
  };

  return (
    <Grid
      container
      justify="center"
      className={classes.flexSection}
      direction="column"
      style={{ border: "1px solid #EBE9E7" }}>
      <Grid
        item
        xs={12}
        className={classes.searchGrid}
        style={{ padding: "6px" }}>
        <Search searchContext={SEARCH_CONTEXT.bundleProductCreatePage} isSearchInPopup={true} />
        <FilterProductFunctionality isDisabled={listData?.length === 0} />
      </Grid>
      <Grid
        item
        xs={12}
        className={classes.gridItemStyle}
        style={{ maxHeight: "215px" }}>
        <div className={classes.box}>
          <div className={classes.productList}>
            {productLoading || paginationInfoLoading ? (
              <Spinner message="Loading products..." topHeight="0px" />
            ) : null}
            {productError || paginationInfoError ? (
              <AlertBox
                message="Error occurred while loading products"
                severity="error"
              />
            ) : null}
            {!productLoading && !productError && listData?.length === 0 ? (
              <AlertBox message="No Products Found" severity="info" />
            ) : null}
            {!productLoading &&
              !productError &&
              listData
                ?.filter((val) => val.productType !== "BUNDLE")
                ?.map((item, index) => (
                  <ListItem key={item.productId} role={undefined} dense button>
                    <ListItemIcon>
                      <Checkbox
                        edge="start"
                        key={item.productId}
                        value={item}
                        onChange={(event) => handleCheckboxChange(event, item)}
                        tabIndex={-1}
                        disableRipple
                        color="primary"
                        checked={checkBoxListForChildProduct.some(checkedValue => checkedValue.productId === item.productId)}
                      />
                    </ListItemIcon>
                    <Tooltip
                      title={getProductNameAndSKU(item)}
                      placement="top-start"
                    >
                      <ListItemText
                        id={item.productId}
                        className={textClasses.textStyle}
                        style={{ width: "200px" }}
                        primary={getProductNameAndSKU(item)}
                        disableTypography
                      >
                        {item.name}
                      </ListItemText>
                    </Tooltip>
                  </ListItem>
                ))}
          </div>
          {(productLoading && pageNumberForProductListInPopup === 1) ||
          productError ||
          productListForSelectedAttributes?.length === 0 ||
          listData?.length === 0
            ? null
            : renderPagination()}
        </div>
      </Grid>
    </Grid>
  );
}