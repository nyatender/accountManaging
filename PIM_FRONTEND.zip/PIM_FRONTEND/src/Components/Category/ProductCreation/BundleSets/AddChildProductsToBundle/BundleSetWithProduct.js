import React, { useContext } from "react";
import {
  selectedChildProductListStyle,
} from "../../ProductCreationStyle";
import {
  Collapse,
  List,
  ListItem,
  ListItemText,
  IconButton,
  FormLabel,
  Checkbox,
  Tooltip,
  Grid
} from "@material-ui/core";
import IndeterminateCheckBoxIcon from "@material-ui/icons/IndeterminateCheckBox";
import { ReactComponent as Clear } from "../../../../../Asset/clear-red.svg";
import AddBoxIcon from "@material-ui/icons/AddBox";
import GlobalState from "../../../../../Context/GlobalState";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import {reorderList} from "../../../../../Utilities/CommonFunctions";
import {ellipsisTextStyle} from "../../../../../Utilities/CommonStyle";

function BundleSetWithProduct({ setBundleSetDetails, bundleSetDetails }) {
  const classes = selectedChildProductListStyle();
  const textClasses = ellipsisTextStyle();
  const { value111 } = useContext(GlobalState);
  const [checkBoxListForBundleSet, setCheckBoxListForBundleSet] = value111;
  const [expandBundleSetIds, setExpandBundleSetIds] = React.useState([]);

  const handleChange = (e, id) => {
    var isChecked = e.target.checked;
    if (isChecked === true) {
      setCheckBoxListForBundleSet((prevArray) => [...prevArray, id]);
    }
    if (checkBoxListForBundleSet.includes(id) && isChecked === false) {
      setCheckBoxListForBundleSet(
        checkBoxListForBundleSet.filter((x) => x !== id)
      );
    }
  };

  const handleExpand = (bundleSetId) => {
    let existingExpandedBundleSet = [...expandBundleSetIds];
    const index = existingExpandedBundleSet.indexOf(bundleSetId);
    if (index > -1) {
      existingExpandedBundleSet.splice(index, 1);
    } else {
      existingExpandedBundleSet.push(bundleSetId);
    }
    setExpandBundleSetIds(existingExpandedBundleSet);
  };

  const handleRemoveItem = (event, item, product) => {
    const clonedData = [...bundleSetDetails];
    let newProductslist = [];

    clonedData?.forEach((obj) => {
      if (Object.keys(obj).includes("isNewlyAdded")) {
        if (item.id === obj.id) {
          newProductslist = obj.productsList.filter(
            (val) => val.productId !== product.productId
          );
          obj["productsList"] = newProductslist;
        }
      }
    });
    setBundleSetDetails(clonedData);
  };
  
  const onDragEnd = (result) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    if (result.destination.index === result.source.index) {
      return;
    }

    const items = reorderList(
      bundleSetDetails,
      result.source.index,
      result.destination.index
    );

    setBundleSetDetails(items);
  };

  const onProductDragEnd = (result, bundleSetIndex) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    if (result.destination.index === result.source.index) {
      return;
    }

    const clonedData = [...bundleSetDetails];

    const items = reorderList(
      clonedData[bundleSetIndex]?.productsList,
      result.source.index,
      result.destination.index
    );

    clonedData[bundleSetIndex].productsList = items;

    setBundleSetDetails(clonedData);
  };

  const renderAddOrMinusIcon = (item) => expandBundleSetIds.includes(item.id) ? <IndeterminateCheckBoxIcon color="primary" /> : <AddBoxIcon color="primary" />

  //function to render bundleSet with products
  const renderOldBundleSet = (bundleSet) => {
    return (
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="droppable">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef}>
              {bundleSet?.map((item, index) => (
                <Draggable
                  key={index.toString()}
                  draggableId={index.toString()}
                  index={index}
                >
                  {(providedDraggable) => (
                    <div
                      key={index.toString()}
                      ref={providedDraggable.innerRef}
                      {...providedDraggable.draggableProps}
                      {...providedDraggable.dragHandleProps}
                    >
                      <Checkbox
                        color="primary"
                        checked={checkBoxListForBundleSet.includes(item.id)}
                        onChange={(event) => handleChange(event, item.id)}
                        name={item.name}
                        disabled={item.isGlobal}
                      />
                      {item?.productsList?.length > 0 ? (
                        <IconButton
                          aria-label="expand"
                          color="primary"
                          onClick={() => handleExpand(item.id)}
                        >
                          {renderAddOrMinusIcon(item)}
                        </IconButton>
                      ) : null}

                      <FormLabel className={classes.formLabel}>
                        <Tooltip title={item?.name} placement="top-start">
                          <span className={textClasses.textStyle}>
                            {item.name}{" "}
                          </span>
                        </Tooltip>
                        <span className={classes.spanStyle}>
                          {item?.productsList?.length}
                        </span>{" "}
                      </FormLabel>

                      <Collapse
                        in={expandBundleSetIds.includes(item.id)}
                        timeout="auto"
                        unmountOnExit
                        className={classes.collapsableArea}
                      >
                        {handleProductList(item, item, index)}
                      </Collapse>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    );
  };

  const handleIsNameNull = (productVal) => productVal?.name === null ? productVal.sku : `${productVal?.name} (${productVal?.sku})`

  const renderProductNameOrSku = (productVal) => {
    return productVal?.productName === null ||
    productVal?.productName?.length === 0 ||
    productVal?.productName === undefined
      ? handleIsNameNull(productVal)
      : `${productVal?.productName[0]?.text} (${productVal?.sku})`;
  };

  //function to handle Products list for a bundle set
  const handleProductList = (item, bundleSet, bundleSetIndex) => {
    return (
      <DragDropContext
        onDragEnd={(event) => onProductDragEnd(event, bundleSetIndex)}
      >
        <Droppable droppableId="droppableProduct">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef}>
              <List component="div" disablePadding>
                {item.productsList?.length > 0 && (
                  item.productsList.map((i, index) => {
                    return (
                      <Draggable
                        key={i.productId}
                        draggableId={i.productId}
                        index={index}
                      >
                        {(providedDraggable) => (
                          <div
                            ref={providedDraggable.innerRef}
                            {...providedDraggable.draggableProps}
                            {...providedDraggable.dragHandleProps}
                          >
                            <ListItem
                              style={{
                                paddingLeft: "40px",
                                paddingBottom: "2px",
                                paddingTop: "2px",
                              }}
                              key={index}
                            >
                              <Tooltip
                                title={
                                  renderProductNameOrSku(i)
                                }
                                placement="top-start"
                              >
                                <ListItemText
                                  id={i?.productId}
                                  className={textClasses.textStyle}
                                  primary={
                                    renderProductNameOrSku(i)
                                  }
                                  disableTypography
                                />
                              </Tooltip>
                              {item.isNewlyAdded ? (
                                <IconButton
                                  onClick={(event) =>
                                    handleRemoveItem(event, bundleSet, i)
                                  }
                                >
                                  <Clear height="12px" />
                                </IconButton>
                              ) : null}
                            </ListItem>
                          </div>
                        )}
                      </Draggable>
                    );
                  })
                )}
              </List>
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    );
  };

  return (
    <Grid
      container
      justify="center"
      className={classes.flexSection}
      direction="column"
    >
      <Grid item xs={12} className={classes.gridItemStyle}>
        {renderOldBundleSet(bundleSetDetails)}
      </Grid>
    </Grid>
  );
}

export default BundleSetWithProduct;
