import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import BundleSetWithProduct from "../BundleSetWithProduct";
import { client } from "../../../../../App";
import GlobalContextProvider from "../../../../../../Providers/GlobalContextProvider";

const props = {
    bundleSetDetails: []
}

describe("BundleSetWithProduct Component ", () => {
  it("matches BundleSetWithProduct snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <BundleSetWithProduct props={props}/>
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
