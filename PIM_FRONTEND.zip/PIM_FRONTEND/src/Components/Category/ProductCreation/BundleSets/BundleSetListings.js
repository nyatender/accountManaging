import React, { useState, useContext } from "react";
import { createBundleSetStyle } from "../ProductCreationStyle";
import Typography from "@material-ui/core/Typography";
import CustomizedExpansionPanels from "./CustomizedExpansionPanels";
import GlobalState from "../../../../Context/GlobalState";
import Button from "@material-ui/core/Button";
import { GET_BUNDLE_SET_FOR_READ } from "../../../Query";
import { useQuery } from "@apollo/react-hooks";
import Spinner from "../../../UI/Spinner";
import AlertBox from "../../../UI/AlertBox"

export default function BundleSetListings({setActiveStep, setRadioValue = () => {/* */ } }) {
  const classes = createBundleSetStyle();
  const { value105, value37, value58, value146, value147, value150, value170 } = useContext(GlobalState);
  const [expanded, setExpanded] = useState("panel_0");
  const [, setIsCreateBundleSet] = value105;
  const [selectedChannelIDForHeader] = value37;
  const [, activeStepFromTailoringSet] = value150;
  const [selectedLanguageInHeader] = value58;
  const [firstName] = value146;
  const [lastName] = value147;
  const [productSetsForBundle] = value170;

  const {
    loading: bundleSetLoading,
    error: bundleSetError,
    data: bundleSetData,
  } = useQuery(GET_BUNDLE_SET_FOR_READ, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
  });

  const handleClick = () => {
    setRadioValue("BUNDLE");
    setIsCreateBundleSet(true);
    activeStepFromTailoringSet(prev => prev + 1);
    setActiveStep(prev => prev + 1);
  };

  const handleBundleSetDisplay = () => {
    if (bundleSetLoading) {
      return "loading";
    }
    if (bundleSetError) {
      return "error";
    }
    let newArray = [];
    {
      let apiData =
      bundleSetData?.productSet.getProductSet?.filter(
        (value) =>
          !productSetsForBundle.some((x) => x.productSetId == value.productSetId)
      );
      apiData?.map((item, i) => {
        let products = item.products?.map(function (product) {
          delete product.__typename;
          return product;
        });
        let tailoringAttributes = item.tailoringAttributes?.map(function (
          attribute
        ) {
          delete attribute.__typename;
          return attribute;
        });
        let detailedTailoringAttributes = item.detailedTailoringAttributes?.map(
          function (detailedAttribute) {
            delete detailedAttribute.__typename;
            return detailedAttribute;
          }
        );
        let productSetAttributes = item.productSetAttributes?.map(function (
          productAttributes
        ) {
          delete productAttributes.__typename;
          return productAttributes;
        });

        const bundleSet = {
          name: item.name!== null ? item.name[0]?.text : "----",
          isMandatory: item.isMandatory,
          productsData: products,
          productSetId: item.productSetId,
          tailoringAttributes: tailoringAttributes,
          productSetAttributes: productSetAttributes,
          isMasterData: item.isMasterData,
          isDefault: item.isDefault,
          detailedTailoringAttributes: detailedTailoringAttributes,
        };
        newArray.push(bundleSet);
      });
    }
    return newArray;
  };

  const handleExpansion = (data, i) => {
    const bundleData = [
      {
        productSetId: data.productSetId,
        name: [
          {
            languageCode: selectedLanguageInHeader,
            text: data.name,
          },
        ],
        products: data.productsData,
        productSetAttributes: data.productSetAttributes,
        tailoringAttributes: data.tailoringAttributes,
        isMandatory: data.isMandatory,
        isMasterData: data.isMasterData,
        isDefault: data.isDefault,
        detailedTailoringAttributes: data.detailedTailoringAttributes,
        createdBy: `${firstName} ${lastName}`,
        updatedBy: `${firstName} ${lastName}`,
        ranking: i,
      },
    ];
    return (
      <CustomizedExpansionPanels
        data={data}
        id={i}
        bundleSetId={data.productSetId}
        bundleSetData={bundleData}
        expanded={expanded}
        setExpanded={setExpanded}
      />
    );
  };
  const tempData = handleBundleSetDisplay();

  const renderGlobalBundleSet = () => tempData == "loading" ? <Spinner topHeight="0vh" message="Loading Bundle Sets..." /> : renderAlertOrData();

  const renderAlertOrData = () => tempData == "error" ? <AlertBox message="Error occurred while loading Bundle Sets" severity="error"/> : renderBundleSetData();

  const renderBundleSetData = () => {
    return tempData
      .sort((a, b) => a.name?.localeCompare(b.name))
      .map((data, i) => handleExpansion(data, i));
  };
  return (
      <div style={{width:"100%"}} data-testid="bundle-set-listing">
          <div className={classes.header}>
            <Typography component="h6" variant="h6">
              Select Bundle Set(s)
            </Typography>
            <Button
              color="primary"
              style={{
                textDecoration: "underline",
                fontWeight: "Bold",
              }}
              onClick={handleClick}
            >
              Create New
            </Button>
          </div>
          <div className={classes.bundleSetList}>
          {renderGlobalBundleSet()}
          </div>
      </div>
  );
}
