import { GET_BUNDLE_SET_FOR_READ } from "../../../../Query";

module.exports = {
    context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
    },
    response: [
        {
            request: {
                query: GET_BUNDLE_SET_FOR_READ,
                variables: {
                    channelFilter: {
                        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21", 
                        languageCode: "en_GB"
                    }
                }
            },
            result: JSON.parse(`{
                "data": {
                    "productSet": {
                      "getProductSet": [
                        {
                            "productSetId": "024fb751-bc57-4ef8-8c75-f7a25e42d06f",
                            "products": [
                              {
                                "productId": "60aee028-50a6-4c6b-9d44-be1575a90ae5",
                                "ranking": 3,
                                "productType": "PRODUCT_VARIANT",
                                "name": "Pure Charge \u0026 Go 5nx - Tailored",
                                "sku": "778899",
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "cdc26cf3-90a7-453d-8634-2cf62091ac9a",
                                "ranking": 2,
                                "productType": "PRODUCT_VARIANT",
                                "name": "Connexx 9.2.10",
                                "sku": "PIM-365476574",
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "08c4787b-bb42-4f03-abd7-a179c5ac4db7",
                                "ranking": 1,
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "sku": "10954347",
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "86b815e7-8dfe-4846-8811-50e5408b7ccc",
                                "ranking": 0,
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "sku": "49475747",
                                "__typename": "ProductSetToProductOutputType"
                              }
                            ],
                            "productSetAttributes": [
                              {
                                "entityType": "ATTRIBUTE",
                                "id": "b2a7ee31-6607-47d0-99c7-784fcf5dfd67",
                                "__typename": "SupportedAttributeOutputType"
                              }
                            ],
                            "name": [
                              {
                                "languageCode": "en_GB",
                                "text": "BS-444",
                                "__typename": "TextTranslationOutput"
                              }
                            ],
                            "detailedTailoringAttributes": [],
                            "tailoringAttributes": [
                              {
                                "attributeId": "b2a7ee31-6607-47d0-99c7-784fcf5dfd67",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": null,
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "IMAGE",
                                "pricevalue": 0,
                                "__typename": "TailoringAttributeOutputType"
                              }
                            ],
                            "isMandatory": false,
                            "isMasterData": true,
                            "isDefault": false,
                            "createdBy": "USER",
                            "updatedBy": "USER",
                            "__typename": "ProductSetOutputType"
                          },
                          {
                            "productSetId": "028d8ed8-bd25-46c7-8262-d10c7c6d791c",
                            "products": [
                              {
                                "productId": "d084fc92-e9ea-4310-bcd5-5f0ba2a6d4e9",
                                "ranking": 1,
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "sku": "Simple-prod",
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "c8e2b7b9-d243-4053-b5ad-7bfd38a8d6e5",
                                "ranking": 2,
                                "productType": "PRODUCT",
                                "name": null,
                                "sku": "Confignew2",
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "05eb779c-4676-491f-8af7-ea485d157245",
                                "ranking": 3,
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "sku": "Simple1",
                                "__typename": "ProductSetToProductOutputType"
                              }
                            ],
                            "productSetAttributes": [
                              {
                                "entityType": "ATTRIBUTE",
                                "id": "6c2c405c-3f7a-49d3-b07a-bbaab7d63204",
                                "__typename": "SupportedAttributeOutputType"
                              },
                              {
                                "entityType": "ATTRIBUTE",
                                "id": "ebcd5c3e-04a5-474e-8299-6cdc385eb69a",
                                "__typename": "SupportedAttributeOutputType"
                              },
                              {
                                "entityType": "ATTRIBUTE",
                                "id": "020bcb93-7936-45df-b026-b8b93f97af3f",
                                "__typename": "SupportedAttributeOutputType"
                              }
                            ],
                            "name": [
                              {
                                "languageCode": "en_GB",
                                "text": "2qa",
                                "__typename": "TextTranslationOutput"
                              }
                            ],
                            "detailedTailoringAttributes": [
                              {
                                "attributeId": "6c2c405c-3f7a-49d3-b07a-bbaab7d63204",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": null,
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "TEXT_FIELD",
                                "pricevalue": 0,
                                "__typename": "ExtendedTailoringAttributeOutputType"
                              },
                              {
                                "attributeId": "ebcd5c3e-04a5-474e-8299-6cdc385eb69a",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": "c87d3201-2056-4ed8-9876-a6674a58c348",
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "DROPDOWN_LIST",
                                "pricevalue": 0,
                                "__typename": "ExtendedTailoringAttributeOutputType"
                              }
                            ],
                            "tailoringAttributes": [
                              {
                                "attributeId": "6c2c405c-3f7a-49d3-b07a-bbaab7d63204",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": null,
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "TEXT_FIELD",
                                "pricevalue": 0,
                                "__typename": "TailoringAttributeOutputType"
                              },
                              {
                                "attributeId": "ebcd5c3e-04a5-474e-8299-6cdc385eb69a",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": "c87d3201-2056-4ed8-9876-a6674a58c348",
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "DROPDOWN_LIST",
                                "pricevalue": 0,
                                "__typename": "TailoringAttributeOutputType"
                              },
                              {
                                "attributeId": "020bcb93-7936-45df-b026-b8b93f97af3f",
                                "checkBoxvalue": false,
                                "checkBoxListvalue": null,
                                "dropdownvalue": null,
                                "radioButtonListvalue": null,
                                "dateTimevalue": "0001-01-01T00:00:00",
                                "inputControl": "TEXT_FIELD",
                                "pricevalue": 0,
                                "__typename": "TailoringAttributeOutputType"
                              }
                            ],
                            "isMandatory": false,
                            "isMasterData": true,
                            "isDefault": false,
                            "createdBy": "USER",
                            "updatedBy": "USER",
                            "__typename": "ProductSetOutputType"
                          }
                      ],
                      "__typename": "ProductSetQuery"
                    }
                }
            }`)
        }
    ]
}