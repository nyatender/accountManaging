import React from "react";
import Item from "../../../../Asset/single-item.svg";
import Product from "../../../../Asset/products.svg";
import Bundle from "../../../../Asset/bundle.svg";
import Tooltip from "@material-ui/core/Tooltip";
import { bundleSetDataTableStyle } from "../ProductCreationStyle";

export default function BundleSetDataTable(props) {
  const classes = bundleSetDataTableStyle();

  const getProductType = (row) => {
    if (row.productType === "PRODUCT_VARIANT") {
      return (
        <Tooltip title="Product Variant" placement="top">
          <img height="15px" width="15px" alt={row.name} src={Item} />
        </Tooltip>
      );
    } else if (row.productType === "PRODUCT") {
      return (
        <Tooltip title="Product" placement="top">
          <img height="18px" width="18px" alt={row.name} src={Product} />
        </Tooltip>
      );
    } else if (row.productType === "BUNDLE") {
      return (
        <Tooltip title="Bundle" placement="top">
          <img height="18px" width="18px" alt={row.name} src={Bundle} />
        </Tooltip>
      );
    }
  };

  return (
    <>
      <table style={{ width: "100%" }}>
        <tr>
          <th className={classes.tableHeaderStyle}>TYPE</th>
          <th className={classes.tableHeaderStyle}>NAME</th>
          <th className={classes.tableHeaderStyle}>SKU</th>
        </tr>
        {props.data?.map((row) => (
          <tr key={row.productId}>
            <td style={{ textAlign: "center" }}>{getProductType(row)}</td>
            <td className={classes.tableDataStyle}>
              {row.name === null ? "------" : row.name}
            </td>
            <td className={classes.tableDataStyle}>{row.sku}</td>
          </tr>
        ))}
      </table>
    </>
  );
}
