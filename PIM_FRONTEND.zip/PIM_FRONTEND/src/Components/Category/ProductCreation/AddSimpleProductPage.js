import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import DialogActions from "@material-ui/core/DialogActions";
import GlobalState from "../../../Context/GlobalState";
import { addPopupStyle } from "./ProductCreationStyle";
import { useMutation } from "@apollo/react-hooks";
import {
  CREATE_PRODUCT,
  GET_PRODUCTS_BY_CATEGORY,
  GET_ALL_PRODUCTS,
  GET_PRODUCTS_BY_BRAND,
} from "../../Query";
import Alert from "@material-ui/lab/Alert";
import { useHistory } from "react-router-dom";
import AddNewProductScreen from "./AddNewProductScreen";
import { dialogMessage } from "../../../Utilities/Constants";
import { Grid } from "@material-ui/core";
import { handleMoveToTailor } from "../../../Utilities/CommonFunctions";

export default function AddSimpleProductPage({
  isCategory,
  value,
  setRadioValue,
  itemNumberValue,
  setItemNumber,
  productName,
  setProductName,
  errorMessage,
  setErrorMessage,
  errorHandler,
  setErrorHandler,
  activeStep,
  validationState,
  maxRank,
  handleClose,
  handleResetContext
}) {
  const classes = addPopupStyle();
  const {
    value1,
    value6,
    value24,
    value27,
    value37,
    value58,
    value66,
    value69,
    value70,
    value74,
    value81,
    value108,
    value134,
    value136,
    value146,
    value214,
    value147
  } = useContext(GlobalState);

  const [brand] = value1;
  const [categoryKey] = value6;
  const [openAddProductPopup] = value27;
  const [selectedChannelIDForHeader] = value37;
  const [, setRowDetails] = value24;
  const [selectedLanguageInHeader] = value58;
  const [, setSkuValue] = value66;
  const [, setPublishDateForProduct] = value69;
  const [, setProductDetail] = value70;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [, setResetAllProductsTable] = value108;
  const [, setIsPublishProduct] = value134;
  const [, setIsProductAvailable] = value136;
  const [firstName] = value146;
  const [lastName] = value147;
  const [, setSelectedNavigationModule] = value214

  const history = useHistory();

  const [createCategorizedProduct, { data: dataResponseForCategory }] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_PRODUCTS_BY_CATEGORY,
          variables: {
            categoryId: categoryKey,
            channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
          },
        },
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              languageCode: selectedLanguageInHeader,
              channelId: selectedChannelIDForHeader,
            },
            paginationFilter: {
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
              pageNumber: 1,
              pageSize: 50,
            },
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
            },
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader,
            },
          },
        },
      ],
      onCompleted: () => {
        setShowOverlay(false);
      },
      ignoreResults: false,
    });

  const [createUncategorizedProduct, { data: dataResponseForUnCategorized }] =
    useMutation(CREATE_PRODUCT, {
      refetchQueries: [
        {
          query: GET_ALL_PRODUCTS,
          variables: {
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader,
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
            },
          },
        },
        {
          query: GET_PRODUCTS_BY_BRAND,
          variables: {
            brandId: brand,
            channelFilter: {
              channelId: selectedChannelIDForHeader,
              languageCode: selectedLanguageInHeader,
            },
            paginationFilter: {
              pageNumber: 1,
              pageSize: 50,
              sortBy: "CreatedAt",
              sortDirection: "DESCENDING",
            },
          },
        },
      ],
      ignoreResults: false,
      onCompleted: () => {
        setShowOverlay(false);
      },
    });

  const handleUncategorizedProductSave = async () => {
    try {
      setShowOverlay(true);
      await createUncategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: null,
            ranking: 0,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo: null,
            variantAttribute: null,
          },
        },
      });
      setResetAllProductsTable(true);
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleCategorizedProductSave = async () => {
    try {
      setShowOverlay(true);
      await createCategorizedProduct({
        variables: {
          product: {
            channelId: selectedChannelIDForHeader,
            productType: value,
            sku: itemNumberValue.trim(),
            productName: [
              {
                text: productName.trim(),
                languageCode: selectedLanguageInHeader,
              },
            ],
            categoryId: categoryKey,
            ranking: maxRank + 1,
            createdBy: `${firstName} ${lastName}`,
            isAvailable: true,
            childrenProductsInfo: null,
            variantAttribute: null,
          },
        },
      });
      handleResetContext();
    } catch (e) {
      console.log(e);
      setShowOverlay(false);
      setErrorHandler(true);
      setErrorMessage(e?.networkError?.result.errors[0].message);
    }
  };

  const handleProductSave = () => {
    isCategory ? handleCategorizedProductSave() : handleUncategorizedProductSave()
  };

  //function to handle the dialog content based on the active step in the stepper
  const handleDialogContent = () => {
    if (activeStep === 0 && openAddProductPopup) 
      return (
        <AddNewProductScreen
          value={value}
          setRadioValue={setRadioValue}
          itemNumberValue={itemNumberValue}
          productName={productName}
          setItemNumber={setItemNumber}
          setErrorHandler={setErrorHandler}
          setErrorMessage={setErrorMessage}
          setProductName={setProductName}
          errorHandler={errorHandler}
          errorMessage={errorMessage}
          validationState={validationState}
        />
      );
  };

  const handleButtonChange = () => {
    return (
      openAddProductPopup && (
        <DialogActions>
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            disabled={
              value === "" || itemNumberValue === "" || productName.trim() === ""
            }
            variant="contained"
            size="large"
            onClick={handleProductSave}
            color="primary"
          >
            Save
          </Button>
        </DialogActions>
      )
    );
  };

  const condition = activeStep !== 0 || value === "PRODUCT_VARIANT"
  return (
    <>
      <Grid item xs={9}>
        {handleDialogContent()}
        {errorHandler && condition && (
          <div className={classes.errorDivStyle}>
            <Alert severity="error" style={{ fontSize: "16px" }}>
              {dialogMessage.ADD_PRODUCTS_FAILURE_MSG + ":" + errorMessage}
            </Alert>
          </div>
        )}

        {errorHandler !== true &&
          (dataResponseForCategory !== undefined ||
            dataResponseForUnCategorized !== undefined)
          && handleMoveToTailor(
            setSnackbarData,
            isCategory,
            setRowDetails,
            setSkuValue,
            setPublishDateForProduct,
            setIsProductAvailable,
            setProductDetail,
            setIsPublishProduct,
            history,
            setSelectedNavigationModule,
            dataResponseForCategory,
            dataResponseForUnCategorized
          )}
      </Grid>
      <Grid item xs={9} style={{ display: "flex", justifyContent: "flex-end" }}>
        {handleButtonChange()}
      </Grid>
    </>
  );
}
