import { makeStyles } from "@material-ui/styles";

export const stepperStyle = makeStyles(() => ({
  stepper: {
    display: "flex",
    paddingTop: "10px",
    paddingLeft: "1.5em"
  }
}))
export const addPopupStyle = makeStyles(() => ({
  title: {
    textAlign: "left",
    fontSize: "24px",
    lineHeight: "28px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  dialogAction: {
    justifyContent: "center",
    paddingBottom: "10px",
  },
  dialogPaper: {
    width: "800px",
  },
  errorDivStyle: {
    paddingBottom: "5px",
    width: "135vh",
  },
  gridStyle: {
    alignItems: "center",
    justify: "center",
    height: "100%",
    justifyContent: "center"
  },
  buttonCancel: {
    border: "1px solid #7000FF",
    borderRadius: "8px",
    opacity: "1",
    textAlign: "left",
    fontSize: "16px",
    lineHeight: "24px",
    letterSpacing: "0px",
    color: "#7000FF",
    textTransform: "none",
    width: "160px",
    height: "46px",
    right: "15px",
    bottom: "5px",
  },
  buttonSave: {
    backgroundColor: "#7000FF",
    borderRadius: "8px",
    opacity: "1",
    textAlign: "left",
    fontSize: "16px",
    lineHeight: "24px",
    letterSpacing: "0px",
    color: "#FFFFFF !important",
    textTransform: "none",
    width: "160px",
    height: "46px",
    right: "10px",
    bottom: "5px",
    "&:hover": {
      background: "#7000FF",
      color: "#FFFFFF !important",
    },
  },
  radioImgStyle: {
    padding: "10px",
    border: "1px solid #EBE9E7",
  },
  imgStyle: {
    padding: "20px",
    border: "1px solid #EBE9E7",
  },
  textFieldStyle: {
    paddingLeft: "30px",
    paddingTop: "30px",
  },
}));

export const addVariantAttributeStyle = makeStyles((theme) => ({
  root: {
    width: "100%",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 500,
    },
    "@media (min-height: 901px)": {
      maxHeight: 700,
    },
  },
  typographyStyle: {
    fontSize: "16px",
    color: "#FF0000E !important",
    paddingBottom: "5px",
    paddingLeft: "10px",
  },
  contentText1: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    flexBasis: "50%"
  },
  contentText2: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: ".5em"
  },
  footerText: {
    textAlign: "left",
    fontSize: "14px",
    fontStyle: "italic",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "20px",
    paddingTop: "2px",
  },
  dialogTitle: {
    textAlign: "left",
    fontSize: "22px",
    padding: 0,
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  gridItemStyle: {
    paddingLeft: "30px",
    paddingRight: "30px",
  },
  dialogContentDisplay: {
    display: "flex",
  },
}));

export const variantAttributeListStyle = makeStyles(() => ({
  search: {
    border: "1px outset grey",
    borderRadius: "8px",
    display: "flex",
    width: "300px",
    height: "35px",
  },
  divider: {
    height: "45px",
    margin: "4px",
  },
  flexSection: {
    flexGrow: "1",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
    border: "1px solid #EBE9E7",
    width: "100%",
  },
  fullWidth: {
    width: "100%",
  },
  iconButton: {},
  divButton: {
    borderLeft: "none",
    borderRight: "1px outset transparent",
    borderRadius: "8px",
    backgroundColor: "#7000FF",
    left: "500px",
    width: "50px",
    height: "35px",
  },
  divSearch: {
    paddingRight: "100px",
  },
  iconSearch: {
    width: "25px",
    height: "10px",
  },
  searchGrid: {
    border: "1px solid #EBE9E7",
    padding: "20px",
  },
  gridItemStyle: {
    paddingLeft: "30px",
    paddingRight: "30px",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: "230px",
  },
  listTextStyle: {
    fontSize: "15px",
    color: "#7A7D8E",
    textAlign: "left",
    letterSpacing: "0px",
    opacity: "1",
    whiteSpace: "nowrap !important",
    width: "160px",
    overflow: "hidden !important",
    textOverflow: "ellipsis",
    display: "inline-block",
  },
}));

export const selectedVariantAttributeListStyle = makeStyles(() => ({
  flexSection: {
    flexGrow: "1",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
    border: "1px solid #EBE9E7",
    width: "100%",
    overflow: "auto",
    maxHeight: "400px",
  },
  divCard: {
    paddingTop: "7px",
    paddingBottom: "7px",
  },
  gridItemStyle: {
    flexGrow: "1",
    overflow: "auto",
    maxHeight: "330px",
  },
  typographyStyle: {
    fontSize: "14px",
    color: "#7A7D8E",
    paddingTop: "8px",
    whiteSpace: "nowrap !important",
    width: "210px",
    overflow: "hidden !important",
    textOverflow: "ellipsis",
    display: "inline-block",
  },
  cardGridStyle: {
    display: "flex",
    paddingTop: "7px",
    paddingBottom: "7px",
  },
}));

export const addChildProductStyle = makeStyles((theme) => ({
  root: {
    width: "100%",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 500,
    },
    "@media (min-height: 901px)": {
      maxHeight: 700,
    },
  },
  typographyStyle: {
    fontSize: "16px",
    color: "#FF0000E !important",
    paddingBottom: "5px",
    paddingLeft: "10px",
  },
  contentText1: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "30px",
    paddingTop: "8px",
    flexBasis: "50%"
  },
  contentText2: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingTop: "8px",
    flexGrow: "100"
  },
  contentText3: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
  },
  footerText: {
    textAlign: "left",
    fontStyle: "italic",
    fontSize: "14px",
    paddingLeft: "20px",
    paddingTop: "5px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
  },
  dialogTitle: {
    textAlign: "left",
    fontSize: "22px",
    paddingLeft: "30px",
    paddingTop: "0px",
    paddingBottom: "0",
    lineHeight: "38px",
    letterSpacing: "0px",
    opacity: "1",
    color: "#000000",
  },
  gridItemStyle: {
    paddingRight: "30px",
    paddingLeft: "30px",
  },
  dialogContentDisplay: {
    display: "flex",
    paddingBottom: "0px",
  },
}));

export const selectedChildProductListStyle = makeStyles(() => ({
  flexSection: {
    flexGrow: "1",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
    border: "1px solid #EBE9E7",
    width: "100%",
    overflow: "auto",
    maxHeight: "400px",
  },
  divCard: {
    paddingTop: "7px",
    paddingBottom: "7px",
  },
  gridItemStyle: {
    paddingLeft: "30px",
    paddingRight: "30px",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: "330px",
  },
  typographyStyle: {
    fontSize: "14px",
    color: "#7A7D8E",
    paddingTop: "8px",
    whiteSpace: "nowrap !important",
    width: "210px",
    overflow: "hidden !important",
    textOverflow: "ellipsis",
    display: "inline-block",
  },
  imgStyle: {
    background: "transparent",
    opacity: "1",
    paddingTop: "9px",
  },
  cardGridStyle: {
    display: "flex",
    paddingTop: "7px",
    paddingBottom: "7px",
  },
  collapsableArea: {
    marginLeft: "12%",
  },
  formLabel: {
    color: "black",
  },
  spanStyle: {
    paddingLeft: "10px",
    fontSize: "12px",
    color: "grey",
  },
}));

export const createBundleSetStyle = makeStyles((theme) => ({
  root: {
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 500,
    },
    "@media (min-height: 901px)": {
      maxHeight: 700,
    },
    padding: 2,
    border: "1px solid rgba(0, 0, 0, .125)",
    marginTop: "1%",
    marginRight: "6%",
    marginBottom: "2%",
    marginLeft: "6%",
  },
  typographyStyle: {
    fontSize: "16px",
    color: "#FF0000E !important",
    paddingBottom: "5px",
    paddingLeft: "10px",
  },
  contentText1: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "30px",
  },
  contentText2: {
    textAlign: "left",
    fontSize: "14px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "190px",
  },
  footerText: {
    textAlign: "left",
    fontSize: "14px",
    fontStyle: "italic",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "20px",
    paddingTop: "5px",
  },
  dialogTitle: {
    textAlign: "left",
    fontSize: "22px",
    paddingLeft: "30px",
    paddingBottom: "0",
    paddingTop: "0px",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  gridItemStyle: {
    paddingLeft: "30px",
    paddingRight: "30px",
  },
  dialogContentDisplay: {
    display: "inline-flex",
  },
  heading: {
    fontSize: "0.9375rem",
    flexBasis: "33.33%",
    flexShrink: 0,
  },
  typography1: {
    textAlign: "center",
    fontSize: "20px",
    lineHeight: "19px",
    fontWeight: "Bold",
    letterSpacing: "0px",
    color: "#4D4F5C",
    opacity: "1",
    paddingRight: "280px",
    "@media (min-width: 1501px)": {
      paddingRight: "450px",
    },
    "@media (max-width: 1500px)": {
      paddingRight: "260px",
    },
    "@media (max-width: 1295px)": {
      paddingRight: "200px",
    },
    "@media (max-width: 1294px)": {
      paddingRight: "30px",
    },
    "@media (max-width: 890px)": {
      paddingRight: "0px",
    },
  },

  header: {
    display: "flex",
    justifyContent: "space-between",
  },
  secondaryHeading: {
    fontSize: "0.9375rem",
  },
  label1: {
    textAlign: "left",
    fontSize: "15px",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#BFBFBF",
    textTransform: "uppercase",
    opacity: "1",
    paddingTop: "17px",
    paddingLeft: "10px",
  },
  label2: {
    paddingLeft: "70px",
    textAlign: "left",
    fontSize: "16px",
    lineHeight: "52px",
    letterSpacing: "0px",
    color: "#BFBFBF",
    opacity: "1",
  },
  iconButton2: {
    width: "25px",
    color: "#BFBFBF",
  },
  bundleSetList: {
    flexGrow: "1",
    overflow: "auto",
    maxHeight: "410px",
    paddingRight: "10px"
  },
  label: {
    fontSize: "16px !important",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    textTransform: "none"
  },
}));

export const customizedExpansionPanelStyle = makeStyles(() => ({
  label: {
    fontSize: "16px !important",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    textTransform: "none"
  },
  typographyStyle: {
    textAlign: "left",
    fontSize: "15px",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    marginTop: "9px",
    justifyContent: "flex-start",
  },
  divStyle: {
    display: "flex",
    marginLeft: "40px"
  }
}))

export const bundleSetDataTableStyle = makeStyles(() => ({
  tableHeaderStyle: {
    textAlign: "center",
    fontSize: "15px",
    lineHeight: "20px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    textTransform: "uppercase",
    opacity: "1",
  },
  tableDataStyle: {
    textAlign: "center",
    fontSize: "15px",
    color: "#7A7D8E",
  },
}));


