import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import AddProductPopupFromLocal from "../AddProductPopupFromLocal";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";

const props = {
    data: []
}

describe("AddProductPopupFromLocal Component ", () => {
  it("matches AddProductPopupFromLocal snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <AddProductPopupFromLocal props={props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
