import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import { ThemeProvider } from "@material-ui/core/styles";
import theme from "../../../../Components/Theme";
import AddBundleProductPage from "../AddBundleProductPage";


describe('AddBundleProductPage snapshot testing', () => {
        const props = {
            value: "BUNDLE",
            productName: "BUNDLE"
        }
        const wrapper = mount(
            <GlobalContextProvider>
                <ApolloProvider client={client}>
                <ThemeProvider theme={theme}>
                    <AddBundleProductPage
                      {...props} />
                </ThemeProvider>
                </ApolloProvider>
            </GlobalContextProvider> 
        );
    it('basic snapshot testing to mount the component', () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
     });
     
});