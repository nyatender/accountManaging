import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import { ThemeProvider } from "@material-ui/core/styles";

import theme from "../../../../Components/Theme";

import AddConfigurableProductPage from "../AddConfigurableProductPage";


describe('AddConfigurableProductPage snapshot testing', () => {
        const props = {
            value: "PRODUCT",
            productName: "PRODUCT"
        }
        const wrapper = mount(
            <GlobalContextProvider>
                <ApolloProvider client={client}>
                <ThemeProvider theme={theme}>
                    <AddConfigurableProductPage
                      {...props} />
                </ThemeProvider>
                </ApolloProvider>
            </GlobalContextProvider> 
        );
    it('basic snapshot testing to mount the component', () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
     });
     
});