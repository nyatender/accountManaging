import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import { client } from "../../../App";
import AddProductPage from "../AddProductPage";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";
import { ThemeProvider } from "@material-ui/core/styles";

import theme from "../../../../Components/Theme";

describe('AddProductPage snapshot testing', () => {
    let isCategory = true;
    const wrapper = mount(
        <GlobalContextProvider>
            <ApolloProvider client={client}>
            <ThemeProvider theme={theme}>
                <AddProductPage {...isCategory} />
            </ThemeProvider>
            </ApolloProvider>
        </GlobalContextProvider> 
    );
    it('basic snapshot testing to mount the component with isCategory set to false', () => {
        expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });

});