import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import AddSimpleProductPage from "../AddSimpleProductPage";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider";

const props = {
    value: "PRODUCT_VARIANT",
    productName: "PRODUCT_VARIANT"
}

describe("AddSimpleProductPage Component ", () => {
  it("matches AddSimpleProductPage snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <AddSimpleProductPage props={props} />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
