import React, { useEffect, useContext, useState } from "react";
import { variantAttributeListStyle } from "../ProductCreationStyle";
import { Divider, Grid, List, Tooltip } from "@material-ui/core";
import { GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE } from "../../../Query";
import { useQuery } from "@apollo/react-hooks";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Spinner from "../../../UI/Spinner";
import GlobalState from "../../../../Context/GlobalState";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Checkbox from "@material-ui/core/Checkbox";
import { dialogMessage, SEARCH_CONTEXT } from "../../../../Utilities/Constants";
import Alert from "@material-ui/lab/Alert";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FilterProductFunctionality from "../FilterFeatureForCreate/FilterProductInCreatePage";
import Search from "../../../Search/search";

function ProductCatalog({ isSelectAllChecked, setSelectAllChecked, searchTermContext }) {
  const classes = variantAttributeListStyle();
  const {
    value37,
    value58,
    value93,
    value94,
    value95,
    value98,
    value160,
    value162,
    value184,
    value218
  } = useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [selectedAttributeIdList] = value93;
  const [productListForSelectedAttribute, setProductListForSelectedAttribute] =
    value94;
  const [selectedChildProductList, setSelectedChildProductList] = value95;
  const [checkBoxListForChildProduct, setCheckBoxListForChildProduct] = value98;
  const [selectedSimpleProductList] = value160;
  const [selectedVariantAttributeIdListForConfigurable] = value162;
  const [additionalFilterList] = value184;
  const [productSearchTerm] = value218;

  const [pageNum] = useState(1);

  const {
    loading: productLoading,
    error: productError,
    data: productData,
    refetch,
  } = useQuery(GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE, {
    variables: {
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
      variantAttributeFilters:
        JSON.stringify(selectedAttributeIdList) === "[]"
          ? selectedVariantAttributeIdListForConfigurable
          : selectedAttributeIdList,
      additionalAttributeFilters: additionalFilterList,
      paginationFilter: {
        pageNumber: pageNum,
        pageSize: 100,
        sortBy: "CreatedAt",
        sortDirection: "DESCENDING",
      },
      searchFilter: productSearchTerm[searchTermContext]
    },
  });

  useEffect(() => {
      handleProductList();
      if (
        selectedChannelIDForHeader !== null &&
        selectedChannelIDForHeader !== undefined &&
        selectedLanguageInHeader !== null &&
        selectedLanguageInHeader !== undefined &&
        productSearchTerm[searchTermContext] !== ""
      ) {
        refetch();
      }
  }, [productData]);

  let newarray = [];
  const handleProductList = () => {
    if (productData) {
      let apiData =
        productData.product.getProductsByChannelAndAttributes.filter(
          (value) =>
            !selectedSimpleProductList.some((x) => x.key == value.productId)
        );

      apiData
        ?.filter((value) => value.productType === "PRODUCT_VARIANT")
        .map((product) => {
          var obj = {
            key: product.productId,
            value:
              product?.productName !== null &&
              product?.productName?.length !== 0 &&
              product?.productName !== undefined
                ? `${product?.productName[0]?.text} (${product.sku})`
                : `${product.sku}`,
            sku: product.sku,
          };
          newarray.push(obj);
          return null;
        });

      setProductListForSelectedAttribute(newarray);
    }
  };

  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;
    if (isChecked === true) {
      setSelectedChildProductList((prevArray) => [...prevArray, item]);
      setCheckBoxListForChildProduct((prevArray) => [...prevArray, item]);
    }
    if (checkBoxListForChildProduct.some(checkedValue => checkedValue.key === item.key) && isChecked === false) {
      setSelectAllChecked(false);
      setCheckBoxListForChildProduct(
        checkBoxListForChildProduct.filter((x) => x.key !== item.key)
      );
      setSelectedChildProductList(
        selectedChildProductList.filter((x) => x.key !== item.key)
      );
    }
  };

  //function to handle select all items checkbox
  const handleCheckAll = (event) => {
    var isCheckedAll = event.target.checked;
    setSelectedChildProductList([]);
    setCheckBoxListForChildProduct([]);
    setSelectAllChecked(false);
    if (isCheckedAll) {
      setSelectAllChecked(true);
      productListForSelectedAttribute.map((item, index) => {
        setSelectedChildProductList((prevArray) => [...prevArray, item]);
        setCheckBoxListForChildProduct((prevArray) => [...prevArray, item]);
        return null;
      });
    }
  };


  //function to list the products with checkbox
  const handleListWithCheckBox = (productList) => {
    if (productList?.length > 0) {
      return productList
        ?.sort((a, b) => a.value.localeCompare(b.value))
        ?.map((item, index) => (
          <ListItem key={item.key} role={undefined} dense button>
            <ListItemIcon>
              <Checkbox
                edge="start"
                key={item.key}
                value={item}
                onChange={(event) => handleCheck(event, item)}
                tabIndex={-1}
                disableRipple
                color="primary"
                checked={checkBoxListForChildProduct.some(checkedValue => checkedValue.key === item.key)}
              />
            </ListItemIcon>
            <Tooltip title={item.value} placement="top-start">
              <ListItemText
                id={item.key}
                primary={item.value}
                className={classes.listTextStyle}
                disableTypography
              />
            </Tooltip>
          </ListItem>
        ));
    } else
      return <Alert severity="info">{dialogMessage.SEARCH_RESULTS_MSG}</Alert>;
  };

  //listData stores search result or entire product list
  const listData =  productListForSelectedAttribute;

  const renderProductCatalog = () =>
    productLoading ? (
      <Spinner message="Loading Product List..." topHeight="0px" />
    ) : (
      renderAlertOrData()
    );

  const renderAlertOrData = () =>
    productError ? (
      <Alert severity="error">{dialogMessage.PRODUCT_LOAD_ERROR_MSG}</Alert>
    ) : (
      renderProductDataOrNoProductAlert()
    );

    const renderProductDataOrNoProductAlert = () =>
    productData?.product.getProductsByChannelAndAttributes?.length === 0 ? (
      <Alert severity="info"> {dialogMessage.EMPTY_PRODUCT_LIST_MSG}</Alert>
    ) : (
      renderProductData()
    );

  const renderProductData = () => {
    return (
      <>
        {selectedAttributeIdList?.length !== 0 &&
          productListForSelectedAttribute?.length !== 0  && (
            <>
              <FormControlLabel
                control={
                  <Checkbox
                    disableRipple
                    color="primary"
                    onChange={handleCheckAll}
                    checked={isSelectAllChecked}
                  />
                }
                label="Select All"
                className={classes.listTextStyle}
              />
              <Divider />
            </>
          )}

        {handleListWithCheckBox(listData)}
      </>
    );
  };

  return (
    <Grid
      container
      justify="center"
      className={classes.flexSection}
      direction="column"
      style={{ border: "1px solid #EBE9E7" }}
    >
      <Grid
        item
        xs={12}
        className={classes.searchGrid}
        style={{ padding: "8px" }}
      >
          <Search searchContext={SEARCH_CONTEXT.configurableProductCreatePage} isSearchInPopup={true} />
        <FilterProductFunctionality
          isDisabled={
            productData?.product?.getProductsByChannelAndAttributes?.length ===
            0
          }
        />
      </Grid>

      <Grid
        item
        xs={12}
        className={classes.gridItemStyle}
        style={{ maxHeight: "215px" }}
      >
        <div style={{ height: "28vh" }}>
          <List>{renderProductCatalog()}</List>
        </div>
      </Grid>
    </Grid>
  );
}

export default ProductCatalog;
