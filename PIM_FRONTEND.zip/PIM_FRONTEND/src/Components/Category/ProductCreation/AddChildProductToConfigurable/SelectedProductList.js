import React, { useContext, useEffect } from "react";
import IconButton from "@material-ui/core/IconButton";
import { selectedChildProductListStyle } from "../ProductCreationStyle";
import { Grid, Tooltip } from "@material-ui/core";
import { StyledCardContent } from "../../../../Utilities/CommonStyle";
import GlobalState from "../../../../Context/GlobalState";
import { ReactComponent as Clear } from "../../../../Asset/clear-red.svg";
import Item from "../../../../Asset/single-item.svg";
import Card from "@material-ui/core/Card";
import Typography from "@material-ui/core/Typography";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { GET_SUPPORTED_ATTRIBUTES_FOR_PRODUCT } from "../../../Query";
import { useQuery } from "@apollo/react-hooks";
import {reorderList} from "../../../../Utilities/CommonFunctions"

function SelectedProductList({ setSelectAllChecked }) {
  const classes = selectedChildProductListStyle();
  const { value37, value58, value95, value98, value106 } =
    useContext(GlobalState);
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [selectedChildProductList, setSelectedChildProductList] = value95;
  const [checkBoxListForChildProduct, setCheckBoxListForChildProduct] = value98;
  const [, setSelectedSupportedItems] = value106;

  const { loading, data, startPolling, stopPolling } = useQuery(
    GET_SUPPORTED_ATTRIBUTES_FOR_PRODUCT,
    {
      variables: {
        channelFilter: {
          channelId: selectedChannelIDForHeader,
          languageCode: selectedLanguageInHeader,
        },
        productFilter: {
          sku: selectedChildProductList[0]?.sku,
          productId: selectedChildProductList[0]?.key,
        },
      },
    }
  );

  //To get the list of supported attributes for first product in the selected list
  useEffect(() => {
    if (!loading || JSON.stringify(selectedChildProductList) !== "[]") {
      let existingSupportedAttributes = [];
      if (
        data?.product.getProductSupportedAttributesBySKUandChannel
          .supportedAttributes !== null
      ) {
        /* Not considering __typename key while sending the list for update */
        data?.product.getProductSupportedAttributesBySKUandChannel.supportedAttributes.forEach(
          (item) => {
            existingSupportedAttributes.push({
              id: item.id,
              entityType: item.entityType,
            });
          }
        );
      }
      setSelectedSupportedItems(existingSupportedAttributes);
    }
    startPolling(9000);
    return stopPolling;
  }, [loading, selectedChildProductList]);

  //function to remove the products from the selected list
  const handleRemoveItem = (event, item) => {
    setSelectAllChecked(false);
    setSelectedChildProductList(
      selectedChildProductList.filter((x) => x !== item)
    );
    setCheckBoxListForChildProduct(
      checkBoxListForChildProduct.filter((x) => x !== item)
    );
  };

  const onDragEnd = (result) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    if (result.destination.index === result.source.index) {
      return;
    }

    const items = reorderList(
      selectedChildProductList,
      result.source.index,
      result.destination.index
    );

    setSelectedChildProductList(items);
  };

  return (
    <Grid
      container
      justify="center"
      className={classes.flexSection}
      direction="column"
    >
      <Grid item xs={12} className={classes.gridItemStyle}>
        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable droppableId="droppable">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef}>
                {selectedChildProductList.map((item, index) => (
                  <Draggable
                    key={item.key}
                    draggableId={item.key}
                    index={index}
                  >
                    {(providedDraggable) => (
                      <div
                        className={classes.divCard}
                        ref={providedDraggable.innerRef}
                        {...providedDraggable.draggableProps}
                        {...providedDraggable.dragHandleProps}
                      >
                        <Card>
                          <StyledCardContent>
                            <Grid
                              container
                              spacing={0}
                              style={{ display: "flex" }}
                            >
                              <Grid item xs={10} style={{ display: "flex" }}>
                                <img
                                  className={classes.imgStyle}
                                  alt="type"
                                  height="25px"
                                  width="30px"
                                  src={Item}
                                />
                                <Tooltip
                                  title={item.value}
                                  placement="top-start"
                                >
                                  <Typography
                                    className={classes.typographyStyle}
                                  >
                                    {item.value}
                                  </Typography>
                                </Tooltip>
                              </Grid>
                              <Grid item xs={2}>
                                <Tooltip
                                  title="Remove from the list"
                                  placement="top"
                                >
                                  <IconButton
                                    onClick={(event) =>
                                      handleRemoveItem(event, item)
                                    }
                                  >
                                    <Clear height="17px" />
                                  </IconButton>
                                </Tooltip>
                              </Grid>
                            </Grid>
                          </StyledCardContent>
                        </Card>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </Grid>
    </Grid>
  );
}

export default SelectedProductList;
