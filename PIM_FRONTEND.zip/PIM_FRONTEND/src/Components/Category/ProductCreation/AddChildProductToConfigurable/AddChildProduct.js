import React, { useState } from "react";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { addChildProductStyle } from "../ProductCreationStyle";
import ProductCatalog from "./ProductCatalog";
import { Grid } from "@material-ui/core";
import { dialogMessage, SEARCH_CONTEXT } from "../../../../Utilities/Constants";
import SelectedProductList from "./SelectedProductList";

export default function AddChildProduct() {
  const classes = addChildProductStyle();
  const [isSelectAllChecked, setSelectAllChecked] = useState(false);

  return (
    <div>
      <DialogTitle className={classes.dialogTitle} disableTypography>
        {dialogMessage.ADD_PRODUCTS_TO_CONFIGURABLE_MSG}
      </DialogTitle>

      <div className={classes.dialogContentDisplay}>
        <DialogContentText className={classes.contentText1}>
          {dialogMessage.PRODUCT_CATALOG_MESSAGE}
        </DialogContentText>
        <DialogContentText className={classes.contentText2}>
          {dialogMessage.SELECTED_PRODUCT_MESSAGE}
        </DialogContentText>
      </div>

      <Grid container spacing={24}>
        <Grid item xs={12} sm={6} className={classes.gridItemStyle}>
          <ProductCatalog
            isSelectAllChecked={isSelectAllChecked}
            setSelectAllChecked={setSelectAllChecked}
            searchTermContext={SEARCH_CONTEXT.configurableProductCreatePage}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <SelectedProductList setSelectAllChecked={setSelectAllChecked} />
        </Grid>
      </Grid>

      <DialogContentText className={classes.footerText}>
        {dialogMessage.SELECT_PRODUCT_MSG}
      </DialogContentText>
    </div>
  );
}
