import { GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE } from "../../../../Query";

module.exports = {
  context: {
    selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
    selectedLanguageInHeader: "en_GB",
    productListForSelectedAttribute: []
  },
  response: [
    {
      request: {
        query: GET_PRODUCTS_BY_CHANNEL_ATTRIBUTE,
        variables: {
          channelFilter: {
            channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            languageCode: "en_GB",
          },
          variantAttributeFilters: [],
          additionalAttributeFilters: [],
          paginationFilter: {
            pageNumber: 1,
            pageSize: 100,
            sortBy: "CreatedAt",
            sortDirection: "DESCENDING",
          },
        },
      },
      result: JSON.parse(`{
                    "data": {
                        "product": {
                            "getProductsByChannelAndAttributes": [
                                {
                                    "sku": "1083e673",
                                    "name": null,
                                    "productName": [
                                        {
                                            "text": "e673",
                                            "languageCode": "en_GB"
                                        }
                                    ],
                                    "productId": "2b501dfb-bdf7-4e0a-a1b9-7add65a579ac",
                                    "categoryId": null,
                                    "channelId": null,
                                    "createdAt": "0001-01-01T00:00:00",
                                    "publishedDate": "0001-01-01T00:00:00",
                                    "ranking": 0,
                                    "productType": "PRODUCT_VARIANT",
                                    "parentProductId": null,
                                    "isAvailable": false,
                                    "__typename": "TextTranslationOutput"
                                },
                                {  "sku": "10753243",
                                    "name": null,
                                    "productName": [
                                        {
                                            "text": "Rule2",
                                            "languageCode": "en_GB"
                                        }],
                                    "productId": "dac69d52-04c7-40b4-b6e9-048f9a2000d4",
                                    "categoryId": null,
                                    "channelId": null,
                                    "createdAt": "0001-01-01T00:00:00",
                                    "publishedDate": "0001-01-01T00:00:00",
                                    "ranking": 0,
                                    "productType": "PRODUCT_VARIANT",
                                    "parentProductId": null,
                                    "isAvailable": false,
                                    "__typename": "TextTranslationOutput"
                                }
                            ]
                        }
                    }
            }`),
    },
  ],
};
