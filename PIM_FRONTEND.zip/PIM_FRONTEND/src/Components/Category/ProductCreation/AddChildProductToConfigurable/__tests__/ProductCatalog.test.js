import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import ProductCatalog from "../ProductCatalog";
import GlobalContextProvider from "../../../../../Providers/GlobalContextProvider";
import {act} from "react-dom/test-utils";
import Spinner from "../../../../UI/Spinner";
import {context, response} from "../__mocks__/ProductCatalog_mocks";
import { MockedProvider, wait } from "@apollo/react-testing";

let wrapper;
let props = {
  isSelectAllChecked: [],
  setSelectAllChecked: jest.fn(),
  searchTermContext: "configurableProductCreatePage",
};
    beforeEach(async ()=>{
       
        act(() =>{
            wrapper = mount(
                <GlobalContextProvider mockData={context}>
                    <MockedProvider mocks={response} addTypename={false}>
                    <ProductCatalog {...props}/>
                    </MockedProvider>
                </GlobalContextProvider>
            )
        })
        await act(()=> wait(500));
        wrapper.update();
    })


describe("ProductCatalog Component ", () => {
  it("matches ProductCatalog snap shot", () => {
    expect(EnzymeToJson(wrapper)).toMatchSnapshot();
  });
});

describe("ProductCatalog functional tests", ()=>
{
    it("Should render Spinner while loading products",async() => {
      let container;
      act(()=>{
        container = mount(
              <GlobalContextProvider mockData={context}>
                  <MockedProvider  mocks={response} addTypename={false}>
                      <ProductCatalog {...props}/>
                  </MockedProvider>
              </GlobalContextProvider>);
      });
        expect(container.find(Spinner).exists()).toBeTruthy();
        expect(container.find(Spinner).prop("message")).toEqual("Loading Product List...");
    });
});
