import { makeStyles } from "@material-ui/styles";

export const movePopupStyle = makeStyles(() => ({
  dialogTitle: {
    textAlign: "left",
    fontSize: "28px",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
    paddingLeft: "10px",
  },
 
  flexColScroll: {
    flexGrow: "1",
    overflow: "auto",
    minHeight: "100%",
    border: "1px solid #EBE9E7",
    paddingLeft: "15px",
    height: '400px',
    width:"100%"
  },

}));

export const moveAndAssociateCommonStyle = makeStyles(()=>({
  contentText1: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "10px",
  },
  contentText2: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "290px",
  },
  footerText: {
    textAlign: "left",
    fontSize: "16px",
    fontStyle: "italic",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "10px",
  },
  dialogContentDisplay: {
    display: "inline-flex",
  },
  dialogContainer: {
    display: "inline-flex",
    paddingLeft: "10px",
  },
}))

export const associatePopupStyle = makeStyles((theme) => ({
  root: {
    width: "100%",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 500,
    },
    "@media (min-height: 901px)": {
      maxHeight: 700,
    },
  },
  typographyStyle: {
    fontSize: "14px",
    color: "#FF534B !important",
    paddingBottom: "5px",
    paddingLeft: "10px",
  },
 

  dialogTitle: {
    textAlign: "left",
    fontSize: "22px",
    paddingLeft: "10px",
    paddingBottom: "0",
    lineHeight: "38px",
    letterSpacing: "0px",
    color: "#000000",
    opacity: "1",
  },
  
  flexColScroll: {
    flexGrow: "1",
    overflow: "auto",
    minHeight: "100%",
    border: "1px solid #EBE9E7",
    padding: "10px",
    height: "400px",
    width:"100%"
  },
  
  
  formControl: {
    margin: 0,
    width: "72%",
  },
  formBody: {
    paddingLeft: "20px",
    width: "90%",
  },
}));

export const moveProductCatalogStyle = makeStyles(() => ({
  search: {
    border: "1px outset grey",
    borderRadius: "8px",
    display: "flex",
    width: "300px",
    height: "35px",
  },
  divider: {
    height: "45px",
    margin: "4px",
  },
  flexColScroll: {
    flexGrow: "1",
    overflow: "auto",
    minHeight: "100%",
    border: "1px solid #EBE9E7",
    paddingLeft: "15px",
    maxHeight: '315px',
  },
  flexSection: {
    flexGrow: "1",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
    width:"100%"
  },
  iconButton: {},
  input: {
    paddingLeft: '10px'
  },
  divButton: {
    borderLeft: "none",
    borderRight: "1px outset transparent",
    borderRadius: "8px",
    backgroundColor: "#7000FF",
    left: "500px",
    width: "50px",
    height: "35px",
  },
  divSearch: {
    paddingRight: "100px",
  },
  iconSearch: {
    width: "25px",
    height: "10px",
  },
  searchGrid: {
    border: "1px solid #EBE9E7",
    paddingTop: "10px",
    paddingBottom: "10px",
    paddingLeft: "78px",
  },
}));

export const treeViewStyles = makeStyles((theme) => ({
  title: {
    textAlign: "left",
    fontSize: "16px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "8px",
  },
  root: {
    width: "100%",
    position: "relative",
    flexGrow: "1",
    overflow: "auto",
    maxHeight: 200,
    "@media (max-height: 812px)": {
      maxHeight: 300,
    },
    "@media (min-height: 901px)": {
      maxHeight: 400,
    },
  },
  title2: {
    textAlign: "left",
    fontSize: "17px",
    letterSpacing: "0px",
    color: "#7A7D8E",
    opacity: "1",
    paddingLeft: "4px",
  },
  icon1: {
    width: "15px",
    height: "14px",
  },
  icon2: {
    width: "12px",
    height: "12px",
  },
  subCatgeoryStyle: {
    width: "20px",
    height: "13px",
    paddingRight: "3px",
  },
  folderStyle: {
    width: "22px",
    height: "15px",
    paddingRight: "5px",
  },
  radioButtonStyle: {
    bottom: "12px",
    right: "3px",
  },
}));



export const searchListStyles = makeStyles((theme) => ({
  listItemTextStyle:{
    color:"#7A7D8E", 
    fontSize:"17px"
  },

  listItemIconStyle: {
    width: "25px", 
    minWidth: "0px"
  }

}))
