import React, { useState } from "react";
import { moveProductCatalogStyle } from "./MoveAssociateStyles";
import TreeView from "./MoveAndAssociateTreeView";
import { Grid } from "@material-ui/core";
import { SearchBoxStyle } from "./../CategoryStyles";
import Search from "./../../UI/Search";
import MoveAndAssociateCategoryTreeSearch from "./MoveAndAssociateCategoryTreeSearch";

function AssociateProductCatalog() {
  const classes = moveProductCatalogStyle();
  const classesSearchBox = SearchBoxStyle();
  const [searchVariable, setSearchVariable] = useState('');
  const [associateCategoryTreeData, setAssociateCategoryTreeData] = useState([]);
  const [searchResult, setSearchResult] = useState([]);

  const handleSearchBoxChange = (event) => {
    setSearchVariable(event.target.value);
    const results = associateCategoryTreeData.filter(
      (category) =>
        category.state !== "DELETED" &&
        category.isActive === true &&
        category.name !== null &&
        category.name[0]?.text !== null &&
        category?.name[0]?.text
          .toLowerCase()
          .includes(event.target.value.toLowerCase())
    );
    setSearchResult(results);
  };

  const renderCategoryData = () =>
  searchVariable.trim() !== "" ? (
    <MoveAndAssociateCategoryTreeSearch searchResultData={searchResult} />
  ) : (
    <TreeView setCategoryTreeData={setAssociateCategoryTreeData}/>
  );
  
  const handleClearSearch = () => {
    setSearchVariable("");
  };

  return (
    <Grid
      container
      className={classes.flexSection}
      justify="center"
      direction="column"
    >
      <Grid item xs={12} className={classesSearchBox.searchGrid}>
        <div>
          <Search
          searchTerm={searchVariable}
          className={classesSearchBox.searchBox}
          handleSearch={handleSearchBoxChange}
          handleClearSearch={handleClearSearch}
          width={"100%"}
        />
        </div>
      </Grid>
      <Grid item xs={12} className={classes.flexColScroll}>
        {renderCategoryData()}
      </Grid>
    </Grid>
  );
}

export default AssociateProductCatalog;
