import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { movePopupStyle, moveAndAssociateCommonStyle } from "./MoveAssociateStyles";
import GlobalState from "../../../Context/GlobalState";
import Container from "@material-ui/core/Container";
import MoveProductCatalog from "./MoveProductCatalog";
import { GET_PRODUCTS_BY_CATEGORY, MOVE_PRODUCT } from "../../Query";
import { useQuery, useMutation } from "@apollo/react-hooks";
import {getMaxRank,renderSelectedProductRowCard} from "../../../Utilities/CommonFunctions"

export default function MovePopup() {
  const classes = movePopupStyle();
  const classesCommonStyle = moveAndAssociateCommonStyle();
  const {
    value10,
    value14,
    value16,
    value17,
    value18,
    value19,
    value37,
    value74,
    value81,
    value58,
    value146,
    value147
  } = useContext(GlobalState);
  const [categoryKey] = value10;
  const [selectedRows] = value16;
  const [, setClearSelectedRows] = value17;
  const [checkBoxValueForCard, setCheckBoxForCard] = value18;
  const [openMovePopup, setOpenMovePopup] = value14;
  const [treeRadioForCopy, setTreeRadioForCopy] = value19;
  const [selectedChannelIDForHeader] = value37;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [selectedLanguageInHeader] = value58;
  const [firstName] = value146;
  const [lastName] = value147;

  const sourceCategoryId = categoryKey;
  const destinationCategoryId = treeRadioForCopy;

  const [moveProduct] = useMutation(MOVE_PRODUCT, {
    refetchQueries: [
      {
        query: GET_PRODUCTS_BY_CATEGORY,
        variables: {
          categoryId: sourceCategoryId,
          channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
          searchFilter: ""
        },
      },
      {
        query: GET_PRODUCTS_BY_CATEGORY,
        variables: {
          categoryId: destinationCategoryId,
          channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
          searchFilter: ""
        },
      },
    ],
    awaitRefetchQueries: true,
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Product Moved succesfully To a Category",
        severity: "success",
      });
    },
    onError: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occured while moving a product to a category",
        severity: "error",
      });
    },
  });

  const { loading, error, data } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: {
      categoryId: treeRadioForCopy,
      channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
    },
    skip: !openMovePopup || treeRadioForCopy === ""
  });

  const handleClose = () => {
    setClearSelectedRows(true);
    setOpenMovePopup(false);
    setTreeRadioForCopy("");
    setCheckBoxForCard([]);
  };

  const handleCheck = async (event, item) => {
    var isChecked = event.target.checked;
    if (isChecked === true) {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
    }
    if (checkBoxValueForCard.includes(item) && isChecked === false) {
      setCheckBoxForCard(checkBoxValueForCard.filter((x) => x !== item));
    }
  };

  const handleMove = () => {
    setShowOverlay(true);
    if (checkBoxValueForCard.length === 1) {
      checkBoxValueForCard.map((item) => {
        moveProduct({
          variables: {
            moveProductsFrom: [
              {
                productId: item.productId,
                parentProductId: null,
                categoryId: item.categoryId,
                ranking: item.ranking,
                productType: item.productType,
              },
            ],
            moveProductsTo: [
              {
                productId: item.productId,
                parentProductId: null,
                categoryId: treeRadioForCopy,
                ranking: maxRank + 1,
                productType: item.productType,
              },
            ],
            user: `${firstName} ${lastName}`,
            channel: selectedChannelIDForHeader,
          },
        });
        return null;
      });
      setClearSelectedRows(true);
      setOpenMovePopup(false);
      setTreeRadioForCopy("");
      setCheckBoxForCard([]);
    } else {
      handleMultiProductMove();
    }
  };

  const maxRank = getMaxRank(loading,error,data);

  const handleMultiProductMove = () => {
    var sourceArray = [];
    var destinationArray = [];
    for (var index = 0; index < checkBoxValueForCard.length; index++) {
      const sourceArrayValue = {
        productId: checkBoxValueForCard[index].productId,
        parentProductId: null,
        categoryId: checkBoxValueForCard[index].categoryId,
        ranking: checkBoxValueForCard[index].ranking,
        productType: checkBoxValueForCard[index].productType,
      };

      const destinationArrayValue = {
        productId: checkBoxValueForCard[index].productId,
        parentProductId: null,
        categoryId: treeRadioForCopy,
        ranking: maxRank + index + 1,
        productType: checkBoxValueForCard[index].productType,
      };

      sourceArray.push(sourceArrayValue);
      destinationArray.push(destinationArrayValue);
    }

    moveProduct({
      variables: {
        moveProductsFrom: sourceArray,
        moveProductsTo: destinationArray,
        user: `${firstName} ${lastName}`,
        channel: selectedChannelIDForHeader,
      },
    });

    setClearSelectedRows(true);
    setOpenMovePopup(false);
    setTreeRadioForCopy("");
    setCheckBoxForCard([]);
  };

  return (
    <div>
      <Dialog
        open={openMovePopup}
        onClose={handleClose}
        fullWidth={true}
        maxWidth="md"
        disableBackdropClick={true}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle className={classes.dialogTitle} disableTypography>
          Move items to
        </DialogTitle>

        <div className={classesCommonStyle.dialogContentDisplay}>
          <DialogContentText className={classesCommonStyle.contentText1}>
            Your Selected Items
          </DialogContentText>
          <DialogContentText className={classesCommonStyle.contentText2}>
            Product Categories
          </DialogContentText>
        </div>

        <div className={classesCommonStyle.dialogContainer}>
          <Container maxWidth="sm" className={classes.flexColScroll}>
            <br />
            {renderSelectedProductRowCard(selectedRows,handleCheck,checkBoxValueForCard)}
          </Container>
          <Container maxWidth="sm">
            <MoveProductCatalog />
          </Container>
        </div>

        <DialogContentText className={classesCommonStyle.footerText}>
          Select the product(s) and category where you want to move
        </DialogContentText>

        <DialogActions>
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="large"
            color="primary"
            onClick={handleMove}
            disabled={checkBoxValueForCard === 0 || treeRadioForCopy === ""}
          >
            Move
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
