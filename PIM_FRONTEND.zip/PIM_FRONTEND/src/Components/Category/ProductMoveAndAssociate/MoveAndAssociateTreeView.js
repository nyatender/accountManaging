import React, { useContext, useEffect } from "react";
import Tree, { TreeNode } from "rc-tree";
import "rc-tree/assets/index.css";
import "./../treeStyle.css";
import { treeViewStyles } from "./MoveAssociateStyles";
import { ReactComponent as Folder } from "../../../Asset/category.svg";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";
import { useQuery } from "@apollo/react-hooks";
import { GET_CATEGORY_TREE } from "../../Query";
import { Radio } from "@material-ui/core";
import GlobalState from "../../../Context/GlobalState";
import { switcherIcon } from "../../../Utilities/CommonFunctions";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";

export default function TreeView({ setCategoryTreeData }) {
  const classes = treeViewStyles();

  const { value19, value37, value58, value109 } = useContext(GlobalState);
  const [treeRadioForCopy, setTreeRadioForCopy] = value19;
  const [selectedChannelIDForHeader] = value37;
  const [selectedLanguageInHeader] = value58;
  const [resetCategoryTree, setResetCategoryTree] = value109;
  const includeCategoryDetails = true;

  const { loading, error, data, refetch } = useQuery(GET_CATEGORY_TREE, {
    variables: {
      includeCategoryDetails,
      channelFilter: {
        channelId: selectedChannelIDForHeader,
        languageCode: selectedLanguageInHeader,
      },
    },
  });

  useEffect(() => {
    if (
      selectedChannelIDForHeader !== null &&
      selectedChannelIDForHeader !== undefined &&
      includeCategoryDetails !== null &&
      resetCategoryTree !== false
    ) {
      refetch();
    }
  }, [selectedChannelIDForHeader]);

  const handleChange = (event) => {
    setTreeRadioForCopy(event.target.value);
  };

  const treeLoopThree = (dataTree, id) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === id) {
          return (
            <TreeNode
              title={
                <span className={classes.title}>
                  <SubCategory className={classes.subCatgeoryStyle} />
                  {i.text}
                </span>
              }
              key={item.id}
              value={item}
              style={{ paddingBottom: "10px" }}
              icon={
                <Radio
                  checked={treeRadioForCopy === item.id}
                  onChange={handleChange}
                  value={item.id}
                  name="radio-button-demo"
                  color="primary"
                  size="small"
                  className={classes.radioButtonStyle}
                  disableTouchRipple={true}
                  disableRipple={true}
                />
              }
            >
              {treeLoopTwo(dataTree, item.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  const treeLoopTwo = (dataTree, id) => {
    return dataTree.map((subCategory) => {
      return subCategory.name?.map((subCatName) => {
        if (
          subCategory.parentCategoryId !== null &&
          subCategory.parentCategoryId === id
        ) {
          return (
            <TreeNode
              title={
                <span className={classes.title}>
                  <SubCategory className={classes.subCatgeoryStyle} />
                  {subCatName.text}
                </span>
              }
              key={subCategory.id}
              value={subCategory}
              style={{ paddingBottom: "10px" }}
              icon={
                <Radio
                  checked={treeRadioForCopy === subCategory.id}
                  onChange={handleChange}
                  value={subCategory.id}
                  name="radio-button-demo"
                  color="primary"
                  size="small"
                  className={classes.radioButtonStyle}
                  disableTouchRipple={true}
                  disableRipple={true}
                />
              }
            >
              {treeLoopThree(dataTree, subCategory.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  const treeLoopOne = (dataTree) => {
    return dataTree.map((item) => {
      return item.name?.map((i) => {
        if (item.parentCategoryId === null) {
          return (
            <TreeNode
              title={
                <span className={classes.title2}>
                  {" "}
                  <Folder className={classes.folderStyle} />
                  {i.text}
                </span>
              }
              key={item.id}
              value={item}
              style={{ paddingBottom: "10px", paddingTop: "5px" }}
              icon={
                <Radio
                  checked={treeRadioForCopy === item.id}
                  onChange={handleChange}
                  value={item.id}
                  name="radio-button-demo"
                  color="primary"
                  size="small"
                  className={classes.radioButtonStyle}
                  disableTouchRipple={true}
                  disableRipple={true}
                />
              }
            >
              {treeLoopTwo(dataTree, item.id)}
            </TreeNode>
          );
        }
        return null;
      });
    });
  };

  function createTreeStructure() {
    if (loading) {
      setResetCategoryTree(false);
      return "loading";
    }
    if (error) {
      setResetCategoryTree(false);
      return "error";
    }
    if (data.category.getCategoryTreeByRootCategoryId !== null) {
      setResetCategoryTree(false);
      setCategoryTreeData(data?.category?.getCategoryTreeByRootCategoryId);
      const dataTree = Object.values(
        data.category.getCategoryTreeByRootCategoryId
      );
      const treeData = dataTree
        .filter(
          (value) =>
            value.isActive === true &&
            value.state !== "DELETED" &&
            value.name !== null &&
            value.name[0]?.text !== null
        )
        .reverse()
        .sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text));
      if (
        treeData?.length === 0 ||
        (treeData?.length === 1 && treeData[0].parentCategoryId !== null)
      )
        return null;
      else return treeLoopOne(treeData);
    }
  }
  const tree = createTreeStructure();

  const renderCategoryTreeDataState = () =>
    tree === "loading" ? (
      <Spinner message="Loading Category Tree..." topHeight="10px" />
    ) : (
      renderErrorState()
    );

  const renderErrorState = () =>
    tree === "error" ? (
      <AlertBox
        message="Error occurred while loading category tree"
        severity="error"
      />
    ) : (
      renderCategoryTreeDataOrAlert()
    );
  const renderCategoryTreeDataOrAlert = () =>
    data?.category?.getCategoryTreeByRootCategoryId?.length === 0 ||
    data?.category?.getCategoryTreeByRootCategoryId === null ||
    tree === null ? (
      <AlertBox message="No Categories Found!" severity="info" />
    ) : (
      renderCategoryTreeData()
    );

  const renderCategoryTreeData = () => {
    return (
      <Tree
        virtual
        showLine={false}
        style={{ height: "315px", paddingBottom: "50px" }}
        switcherIcon={(obj) => switcherIcon(obj, data, classes)}
      >
        {createTreeStructure()}
      </Tree>
    );
  };

  return <div style={{ height: "310px" }}>{renderCategoryTreeDataState()}</div>;
}
