import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import AssociateCustomerGroupPopup from "../AssociateCustomerGroupsPopup";
import { client } from "../../../App";
import GlobalContextProvider from "../../../../Providers/GlobalContextProvider"

describe("AssociateCustomerGroupPopup Component ", () => {
  it("matches AssociateCustomerGroupPopup snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
      <ApolloProvider client={client}>
        <AssociateCustomerGroupPopup />
      </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

});
