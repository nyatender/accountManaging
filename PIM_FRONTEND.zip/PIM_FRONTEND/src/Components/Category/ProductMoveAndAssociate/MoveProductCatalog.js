import React, { useState } from "react";
import { moveProductCatalogStyle } from "./MoveAssociateStyles";
import TreeView from "./MoveAndAssociateTreeView";
import { Grid } from "@material-ui/core";
import { SearchBoxStyle } from "./../CategoryStyles";
import Search from "./../../UI/Search";
import MoveAndAssociateCategoryTreeSearch from "./MoveAndAssociateCategoryTreeSearch";

function MoveProductCatalog() {
  const classes = moveProductCatalogStyle();
  const classesSearchBox = SearchBoxStyle();
  const [searchVariable, setSearchVariable] = useState("");
  const [moveCategoryTreeData, setMoveCategoryTreeData] = useState([]);
  const [searchResult, setSearchResult] = useState([]);

  const handleSearchBoxChange = (event) => {
    setSearchVariable(event.target.value);
    const results = moveCategoryTreeData.filter(
      (category) =>
        category.state !== "DELETED" &&
        category.name !== null &&
        category.isActive === true &&
        category.name[0]?.text !== null &&
        category?.name[0]?.text
          .toLowerCase()
          .includes(event.target.value.toLowerCase())
    );
    setSearchResult(results);
  };

  const handleClearSearch = () => {
    setSearchVariable("");
  };

  const renderCategoryData = () =>
    searchVariable.trim() !== "" ? (
      <MoveAndAssociateCategoryTreeSearch searchResultData={searchResult} />
    ) : (
      <TreeView setCategoryTreeData={setMoveCategoryTreeData} />
    );

  return (
    <Grid
      container
      justify="center"
      className={classes.flexSection}
      direction="column"
    >
      <Grid item xs={12} className={classesSearchBox.searchGrid}>
        <div>
          <Search
            className={classesSearchBox.searchBox}
            searchTerm={searchVariable}
            handleSearch={handleSearchBoxChange}
            handleClearSearch={handleClearSearch}
            width={"100%"}
          />
        </div>
      </Grid>
      <Grid item xs={12} className={classes.flexColScroll}>
        {renderCategoryData()}
      </Grid>
    </Grid>
  );
}

export default MoveProductCatalog;
