import React, { useContext, useState } from "react";
import { Grid, Checkbox } from "@material-ui/core";
import { useQuery } from "@apollo/react-hooks";
import { moveProductCatalogStyle } from "./MoveAssociateStyles";
import GlobalState from "../../../Context/GlobalState";
import { GET_ALL_CUSTOMER_GROUPS } from "../../Query";
import Spinner from "../../UI/Spinner";
import AlertBox from "../../UI/AlertBox";
import Search from "./../../UI/Search";
import { SearchBoxStyle } from "./../CategoryStyles";

function AssociateCustomerGroups() {
  const classesSearchBox = SearchBoxStyle();
  const { value133, value37 } = useContext(GlobalState);
  const classes = moveProductCatalogStyle();
  const [customerGroups, setCustomerGroups] = useState([]);
  const [filteredCustomerGroups, setFilteredCustomerGroups] = useState([]);
  const [searchVariable, setSearchVariable] = useState("");

  const [selectedCustomerGroups, setSelectedCustomerGroups] = value133;
  const [selectedChannelIDForHeader] = value37;

  const channelFilter = {
    channelId: selectedChannelIDForHeader,
  };
  const { loading, error } = useQuery(GET_ALL_CUSTOMER_GROUPS, {
    variables: {
      channelFilter,
      showAssociatedChannels: false,
    },
    onCompleted: (data) => {
      setCustomerGroups(data.customerGroup.getCustomerGroupsByChannel);
      setFilteredCustomerGroups(data.customerGroup.getCustomerGroupsByChannel);
    },
  });

  const handleCheck = (event, customerGroupId) => {
    const isChecked = event.target.checked;
    isChecked
      ? setSelectedCustomerGroups((prevCustomerGroups) => [
          ...prevCustomerGroups,
          customerGroupId,
        ])
      : setSelectedCustomerGroups(
          selectedCustomerGroups.filter((id) => id !== customerGroupId)
        );
  };

  const handleClearSearch = () => {
    setSearchVariable("");
    setFilteredCustomerGroups(customerGroups);
  };
  const handleSearchBoxChange = (event) => {
    setSearchVariable(event.target.value);
    const filteredCgs = customerGroups.filter((customerGroup) =>
      customerGroup.name
        .toLowerCase()
        .includes(event.target.value.toLowerCase())
    );
    setFilteredCustomerGroups(filteredCgs);
  };

  const renderCustomerGroup = () =>
    loading ? renderLoader() : renderCustomerGroupList();

  const renderLoader = () => (
    <Spinner message="Loading customer groups..." topHeight={"10px"} />
  );

  const renderCustomerGroupList = () =>
    error ? renderError() : renderCGList();

  const renderError = () => (
    <AlertBox message="Error in fetching customer groups" severity="info" />
  );

  const renderCGList = () => {
    return (
      <>
        {filteredCustomerGroups?.length > 0 ? (
          filteredCustomerGroups.map((customerGroup) => (
            <div>
              <Checkbox
                key={customerGroup.customerGroupId}
                color={"primary"}
                checked={selectedCustomerGroups.includes(
                  customerGroup.customerGroupId
                )}
                onChange={(event) =>
                  handleCheck(event, customerGroup.customerGroupId)
                }
              />
              {customerGroup.name}
            </div>
          ))
        ) : (
          <AlertBox message="No customer groups available" severity="info" />
        )}
      </>
    );
  };

  return (
    <>
      <Grid
        container
        justify="center"
        className={classes.flexSection}
        direction="column"
      >
        <Grid item xs={12} className={classesSearchBox.searchGrid}>
          <div>
            <Search
              className={classesSearchBox.searchBox}
              searchTerm={searchVariable}
              handleSearch={handleSearchBoxChange}
              handleClearSearch={handleClearSearch}
            />
          </div>
        </Grid>
        <Grid item xs={12} className={classes.flexColScroll}>
          <div style={{height:"310px"}}>{renderCustomerGroup()}</div>
        </Grid>
      </Grid>
    </>
  );
}

export default AssociateCustomerGroups;
