import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { associatePopupStyle, moveAndAssociateCommonStyle } from "./MoveAssociateStyles";
import GlobalState from "../../../Context/GlobalState";
import Container from "@material-ui/core/Container";
import AssociateProductCatalog from "./AssociateProductCatalog";
import {
  GET_PRODUCTS_BY_CATEGORY,
  COPY_PRODUCT_WITHIN_CATEGORY,
} from "../../Query";
import { useMutation } from "@apollo/react-hooks";
import { dialogMessage } from "../../../Utilities/Constants";
import {renderSelectedProductRowCard} from "../../../Utilities/CommonFunctions"

export default function AssociatePopup() {
  const classes = associatePopupStyle();
  const classesCommonStyle = moveAndAssociateCommonStyle();
  const {
    value15,
    value16,
    value17,
    value18,
    value19,
    value37,
    value74,
    value81,
    value58,
    value146,
    value147
  } = useContext(GlobalState);
  const [selectedRows] = value16;
  const [, setClearSelectedRows] = value17;
  const [openAssociatePopup, setOpenAssociatePopup] = value15;
  const [treeRadioForCopy, setTreeRadioForCopy] = value19;
  const [checkBoxValueForCard, setCheckBoxForCard] = value18;
  const [selectedChannelIDForHeader] = value37;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [selectedLanguageInHeader] = value58;
  const [firstName] = value146;
  const [lastName] = value147;

  const destinationCategoryId = treeRadioForCopy;

  const [copyProduct] = useMutation(COPY_PRODUCT_WITHIN_CATEGORY, {
    refetchQueries: [
      {
        query: GET_PRODUCTS_BY_CATEGORY,
        variables: {
          categoryId: destinationCategoryId,
          channelFilter: { channelId: selectedChannelIDForHeader, languageCode: selectedLanguageInHeader},
        },
      },
    ],
    awaitRefetchQueries: true,
    onError: () => {
      setShowOverlay(false);
      setSnackbarData({
        show:true,
        message: "Error occured while associating a product to a category",
        severity: "error",
      })
    },
    onCompleted: () => {
      setShowOverlay(false);
      setSnackbarData({
        show:true,
        message: "Product Associated succesfully To a Category",
        severity: "success",
      })},
  });

  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;
    if (isChecked === true) {
      setCheckBoxForCard((prevArray) => [...prevArray,item]);
    }
    if (checkBoxValueForCard.includes(item) && isChecked === false) {
      setCheckBoxForCard(checkBoxValueForCard.filter((x) => x !== item));
    }
  };

  const handleCopy = () => {
    setShowOverlay(true);
    var productIdList = [];

    checkBoxValueForCard.map((item) => {
       var obj = {
         productId: item.productId
       }
       productIdList.push(obj);
       return null;
    })

      copyProduct({
        variables: {
          product: productIdList,
          category: [
            {
              id: treeRadioForCopy,
            },
          ],
          user: `${firstName} ${lastName}`,
          channel: selectedChannelIDForHeader,
        },
      });
    setTreeRadioForCopy("");
  };

  const handleClose = () => {
    setClearSelectedRows(true);
    setOpenAssociatePopup(false);
    setTreeRadioForCopy("");
    setCheckBoxForCard([]);
  };

  return (
    <div>
      <Dialog
        open={openAssociatePopup}
        onClose={handleClose}
        fullWidth={true}
        disableBackdropClick={true}
        maxWidth="md"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle className={classes.dialogTitle} disableTypography>
          Associate Items to
        </DialogTitle>

        <div className={classesCommonStyle.dialogContentDisplay}>
          <DialogContentText className={classesCommonStyle.contentText1}>
            {dialogMessage.POPUP_MSG}
          </DialogContentText>
          <DialogContentText className={classesCommonStyle.contentText2}>
            Product Categories
          </DialogContentText>
        </div>

        <div className={classesCommonStyle.dialogContainer}>
          <Container maxWidth="sm" className={classes.flexColScroll}>
            {renderSelectedProductRowCard(selectedRows,handleCheck,checkBoxValueForCard)}
          </Container>
          <Container maxWidth="sm">
            <AssociateProductCatalog />
          </Container>
        </div>

        <DialogContentText className={classesCommonStyle.footerText}>
          Select the product(s) and category where you want to Associate
        </DialogContentText>

        <DialogActions>
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="large"
            color="primary"
            onClick={handleCopy}
            disabled={checkBoxValueForCard === 0 || treeRadioForCopy === ""}
          >
            Associate
          </Button>
          <Button
            variant="contained"
            size="large"
            color="primary"
            onClick={handleClose}
          >
            Done
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
