import React, { useContext } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { associatePopupStyle, moveAndAssociateCommonStyle } from "./MoveAssociateStyles";
import GlobalState from "../../../Context/GlobalState";
import Container from "@material-ui/core/Container";
import AssociateCustomerGroups from "./AssociateCustomerGroups";
import {CREATE_PRODUCT_CUSTOMER_GROUP_ASSOCIATION} from "../../Query";
import { useMutation } from "@apollo/react-hooks";
import { dialogMessage } from "../../../Utilities/Constants";
import {renderSelectedProductRowCard} from "../../../Utilities/CommonFunctions"

export default function AssociateCustomerGroupsPopup() {
  const classes = associatePopupStyle();
  const classesCommonStyle = moveAndAssociateCommonStyle();
  const {
    value16,
    value17,
    value18,
    value37,
    value74,
    value81,
    value131,
    value133,
    value146,
    value147
  } = useContext(GlobalState);
  const [selectedRows] = value16;
  const [, setClearSelectedRows] = value17;
  const [openAssociateCustomerGroupsPopup, setOpenAssociateCustomerGroupsPopup] = value131;
  const [checkBoxValueForCard, setCheckBoxForCard] = value18;
  const [selectedChannelIDForHeader] = value37;
  const [, setSnackbarData] = value74;
  const [, setShowOverlay] = value81;
  const [selectedCustomerGroups, setSelectedCustomerGroups] = value133;
  const [firstName] = value146;
  const [lastName] = value147;

  const selectedProductIds = checkBoxValueForCard.map(product=>product.productId)

  const [associateCustomerGroups] = useMutation(CREATE_PRODUCT_CUSTOMER_GROUP_ASSOCIATION, {
    onCompleted: () => {
      setShowOverlay(false);
      handleComplete()
      setSnackbarData({
        show: true,
        message: "Product(s) associated successfully to customer group(s)",
        severity: "success",
      });
    },
    onError: () => {
      setShowOverlay(false);
      setSnackbarData({
        show: true,
        message: "Error occurred while associating product(s) to customer group(s)",
        severity: "error",
      });
    },
  });

  const handleCheck = (event, item) => {
    var isChecked = event.target.checked;

    if (isChecked === true) {
      setCheckBoxForCard((prevArray) => [...prevArray, item]);
    }
    if (checkBoxValueForCard.includes(item) && isChecked === false) {
      setCheckBoxForCard(checkBoxValueForCard.filter((x) => x !== item));
    }
  };

  const handleComplete = () => {
    setClearSelectedRows(true);
    setOpenAssociateCustomerGroupsPopup(false);
    setSelectedCustomerGroups([]);
    setCheckBoxForCard([]);
  };

  const handleAssociation = () => {
    setShowOverlay(true)
    associateCustomerGroups({
      variables: {
        productIds: selectedProductIds,
        customerGroupIds: selectedCustomerGroups,
        channelId: selectedChannelIDForHeader,
        createdBy: `${firstName} ${lastName}`,
      },
    })
  }

  return (
    <div>
      <Dialog
        open={openAssociateCustomerGroupsPopup}
        onClose={handleComplete}
        fullWidth={true}
        disableBackdropClick={true}
        maxWidth="md"
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >

        <DialogTitle className={classes.dialogTitle} disableTypography>
          Associate Items to
        </DialogTitle>

        <div className={classesCommonStyle.dialogContentDisplay}>
          <DialogContentText className={classesCommonStyle.contentText1}>
            {dialogMessage.POPUP_MSG}
          </DialogContentText>
          <DialogContentText className={classesCommonStyle.contentText2}>
            Customer groups
          </DialogContentText>
        </div>

        <div className={classesCommonStyle.dialogContainer}>
          <Container maxWidth="sm" className={classes.flexColScroll}>
            {renderSelectedProductRowCard(selectedRows,handleCheck,checkBoxValueForCard)}
          </Container>
          <Container maxWidth="sm">
            <AssociateCustomerGroups />
          </Container>
        </div>

        <DialogContentText className={classesCommonStyle.footerText} style={{marginTop: '15px'}}>
          Select the product(s) and customer group(s) you want to Associate
        </DialogContentText>

        <DialogActions>
          <Button
            variant="outlined"
            size="large"
            color="primary"
            onClick={handleComplete}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="large"
            color="primary"
            onClick={handleAssociation}
            disabled={checkBoxValueForCard.length === 0 || selectedCustomerGroups.length === 0}
          >
            Associate
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
