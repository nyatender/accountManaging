import React, { useContext } from "react";
import { searchListStyles } from "./MoveAssociateStyles";
import GlobalState from "../../../Context/GlobalState";
import AlertBox from "../../UI/AlertBox";
import { ReactComponent as SubCategory } from "../../../Asset/sub-category.svg";
import {
  Radio,
  ListItemText,
  ListItem,
  List,
  ListItemIcon,
} from "@material-ui/core";

function CategorySearch({ searchResultData }) {
  const classes = searchListStyles();
  const { value19 } = useContext(GlobalState);
  const [categoryIdForMoveOrAssociate, setCategoryIdForMoveOrAssociate] =
    value19;

  const handleRadioCheck = (event) => {
    setCategoryIdForMoveOrAssociate(event.target.value);
  };

  return (
    <div style={{ height: "310px" }}>
      {searchResultData?.length > 0 ? (
        <List component="list" aria-label="search result">
          {searchResultData
            ?.sort((a, b) => a?.name[0]?.text?.localeCompare(b?.name[0]?.text))
            ?.map((category, index) => (
              <ListItem key={index} style={{ padding: "5px" }}>
                <Radio
                  edge="start"
                  color="primary"
                  value={category.id}
                  onChange={handleRadioCheck}
                  tabIndex={index}
                  disableTouchRipple
                  size="small"
                  disableRipple
                  checked={categoryIdForMoveOrAssociate === category?.id}
                />
                <ListItemIcon className={classes.listItemIconStyle}>
                  <SubCategory width={"18px"} height={"14px"} />
                </ListItemIcon>
                <ListItemText
                  disableTypography
                  className={classes.listItemTextStyle}
                >
                  {category.name[0].text}
                </ListItemText>
              </ListItem>
            ))}
        </List>
      ) : (
        <AlertBox message={"No data found"} severity="info" />
      )}
    </div>
  );
}

export default CategorySearch;
