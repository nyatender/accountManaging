import React from "react";
import { ThemeProvider } from "@material-ui/core/styles";
import theme from "./Theme";
import "../App.css";
import { ApolloClient } from "apollo-client";
import { HttpLink } from "apollo-link-http";
import { InMemoryCache } from "apollo-cache-inmemory";
import { ApolloProvider } from "react-apollo";
import Cookies from 'js-cookie'
import * as queryString from 'query-string'
import LoginCheck from './LoginCheck'
import Login from './Login'
import { BrowserRouter } from 'react-router-dom';
  import GlobalContextProvider from "./../Providers/GlobalContextProvider";

export const client = new ApolloClient({
  link: new HttpLink({
    //uri: process.env.NODE_ENV === 'development' ? 'https://dev-shopxp.sivantos.com/graphql/' : 'https://wsadeerlmgreps.audiology-solutions.net/pimservice/graphql/',
    //uri: 'https://dev-shopxp.sivantos.com/graphql/'
    uri: process.env.REACT_APP_API_URL
  }),
  headers: {
    "Content-Type": "application/json",
    //"Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS, GET, POST, PUT, PATCH, DELETE",
    "Access-Control-Allow-Credentials": true,
  },
  cache: new InMemoryCache(),
});

function App() {
  const isLoginPath = window.location.pathname === '/login'

  const token = queryString.parse(window.location.hash).id_token
  token && Cookies.set('token', token)

  return (
    <GlobalContextProvider>
      <ApolloProvider client={client}>
        <ThemeProvider theme={theme}>
          <BrowserRouter>
            {(isLoginPath || !Cookies.get('token')) ?
              <Login /> :
              <LoginCheck token={Cookies.get('token')} />
            }
          </BrowserRouter>
        </ThemeProvider>
      </ApolloProvider>
    </GlobalContextProvider>
  );
}

export default App;
