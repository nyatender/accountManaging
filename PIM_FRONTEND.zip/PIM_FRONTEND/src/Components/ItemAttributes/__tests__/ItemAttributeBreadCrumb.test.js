import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import ItemAttributeBreadCrumb from "../ItemAttributeBreadCrumb";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";

describe("ItemAttributeBreadCrumb snapshot test", () => {
    it("ItemAttributeBreadCrumb should match its snapshot", () => {
     const wrapper = mount(
        <GlobalContextProvider>
            <ItemAttributeBreadCrumb productSku={"sku"} breadCrumbStyle={{}}/>
        </GlobalContextProvider>);
     expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
});