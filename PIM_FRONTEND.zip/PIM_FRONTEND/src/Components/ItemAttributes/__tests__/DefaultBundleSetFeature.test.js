import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import DefaultBundleSetFeature from "../DefaultBundleSetFeature";
import GlobalContextProvider from '../../../Providers/GlobalContextProvider';
import { ApolloProvider } from "react-apollo";
import { client } from "../../App";
import { MockedProvider, wait } from "@apollo/react-testing";
import { ReactComponent as DisabledDefault } from "../../../Asset/disabled-default.svg";
import { ReactComponent as Default } from "../../../Asset/default.svg";
import { IconButton } from "@material-ui/core";
import { act } from "react-dom/test-utils";
import {context, response} from "../__mocks__/DefaultBundleSetFeature_mocks";

describe("DefaultBundleSetFeature Component", () => {
    it("matches DefaultBundleSetFeature snapshot", () => {
      const wrapper = mount(
      <GlobalContextProvider>
          <ApolloProvider client={client}>
            <DefaultBundleSetFeature />
          </ApolloProvider>
      </GlobalContextProvider>
      );
      expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });

    it("Should render DisabledDefault icon in local channel", () => {
      let mockcontext = {...context, globalChannelID: "FakeglobalChannelID"}
      const wrapper = mount(<GlobalContextProvider mockData={mockcontext}>
        <MockedProvider mocks={response} addTypename={false}>
            <DefaultBundleSetFeature />
        </MockedProvider>
      </GlobalContextProvider>);
      expect(wrapper.find(DisabledDefault).exists()).toBeTruthy();
    })

    it("Should render Default icon in global channel", () => {
      const wrapper = mount(<GlobalContextProvider mockData={context}>
        <MockedProvider mocks={response} addTypename={false}>
            <DefaultBundleSetFeature />
        </MockedProvider>
      </GlobalContextProvider>);
      expect(wrapper.find(Default).exists()).toBeTruthy();
    })

    it("Should change the tooltip title based on clicking default button", async () => {
      let wrapper;
      act(()=>{
        wrapper = mount(<GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
              <DefaultBundleSetFeature />
          </MockedProvider>
        </GlobalContextProvider>);
      })
      const button = wrapper.find(IconButton);
      button.simulate('click');
      await act(()=> wait(0));
      wrapper.update();
      expect(wrapper.find({title: 'Remove Default Bundle set'}).exists()).toBeTruthy();
    })
})