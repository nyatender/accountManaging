import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import DeleteDeassociateProduct from "../DeleteDeassociateProduct";
import GlobalContextProvider from '../../../Providers/GlobalContextProvider';
import { ApolloProvider } from "react-apollo";
import { client } from "../../App";

describe("DeleteDeassociateProduct Component", () => {
    it("matches DeleteDeassociateProduct snapshot", () => {
      const wrapper = mount(
      <GlobalContextProvider>
          <ApolloProvider client={client}>
            <DeleteDeassociateProduct />
          </ApolloProvider>
      </GlobalContextProvider>
      );
      expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
})