import React from "react";
import { mount } from "enzyme";
import { ApolloProvider } from "react-apollo";
import EnzymeToJson from "enzyme-to-json";
import ItemAttributes from "../ItemAttributes";
import { client } from "../../App";
import GlobalContextProvider from "../../../Providers/GlobalContextProvider";
import { MockedProvider } from "@apollo/react-testing";
import { act } from "react-dom/test-utils";
import {context} from "../__mocks__/ItemAttributes_mocks";

const createWrapper = (mockContext) => {
  return mount(<GlobalContextProvider mockData={mockContext}>
    <MockedProvider>
      <ItemAttributes/>
    </MockedProvider>
  </GlobalContextProvider>);
}

describe("ItemAttributes Component ", () => {
  it("matches ItemAttributes snap shot", () => {
    const subject = mount(
      <GlobalContextProvider>
        <ApolloProvider client={client}>
          <ItemAttributes />
        </ApolloProvider>
      </GlobalContextProvider>
    );
    expect(EnzymeToJson(subject)).toMatchSnapshot();
  });

  it("display Item Attributes title when product type is PRODUCT_VARIANT", async () => {
    let wrapper;
    await act(async()=>{
      wrapper = createWrapper(context);
    })
    expect(wrapper.find('[data-testid="h6-title"]').first().text()).toBe("Item Attributes")
  })

  it("display Group Attributes title when product type is PRODUCT", async () => {
    let wrapper;
    let productDetailOfTree = context.productDetailOfTree;
    productDetailOfTree.productType = "PRODUCT";
    const mockContext = {...context, productDetailOfTree}
    await act(async()=>{
      wrapper = createWrapper(mockContext);
    })
    expect(wrapper.find('[data-testid="h6-title"]').first().text()).toBe("Group Attributes")
  })

  it("display Bundle Attributes title when product type is BUNDLE", async()=>{
    let wrapper;
    let productDetailOfTree = context.productDetailOfTree;
    productDetailOfTree.productType="BUNDLE"
    let mockContext = {...context, productDetailOfTree}
    await act(async() => {
      wrapper = createWrapper(mockContext);
    })
    expect(wrapper.find('[data-testid="h6-title"]').first().text()).toBe("Bundle Attributes");
  })
});
