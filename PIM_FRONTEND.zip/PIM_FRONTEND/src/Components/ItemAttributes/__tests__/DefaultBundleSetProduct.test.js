import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import DefaultBundleSetProduct from "../DefaultBundleSetProduct";
import GlobalContextProvider from '../../../Providers/GlobalContextProvider';
import { ApolloProvider } from "react-apollo";
import { client } from "../../App";
import { MockedProvider, wait } from "@apollo/react-testing";
import { ReactComponent as DisabledDefault } from "../../../Asset/disabled-default.svg";
import { ReactComponent as Default } from "../../../Asset/default.svg";
import { act } from "react-dom/test-utils";
import {context, response} from "../__mocks__/DefaultBundleSetProduct_mocks";
import { IconButton } from "@material-ui/core";

describe("DefaultBundleSetProduct Component", () => {
    it("matches DefaultBundleSetProduct snapshot", () => {
      const wrapper = mount(
      <GlobalContextProvider>
          <ApolloProvider client={client}>
            <DefaultBundleSetProduct />
          </ApolloProvider>
      </GlobalContextProvider>
      );
      expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });

    it("Should render DisabledDefault icon in local channel", () => {
      let mockContext = {...context, globalChannelID:"FakeGlobalChannelID"}
      const wrapper = mount(<GlobalContextProvider mockData={mockContext}>
        <MockedProvider mocks={response} addTypename={false}>
            <DefaultBundleSetProduct />
        </MockedProvider>
      </GlobalContextProvider>);
      expect(wrapper.find(DisabledDefault).exists()).toBeTruthy();
    })

    it("Should render Default icon in global channel", () => {
      const wrapper = mount(<GlobalContextProvider mockData={context}>
        <MockedProvider mocks={response} addTypename={false}>
            <DefaultBundleSetProduct />
        </MockedProvider>
      </GlobalContextProvider>);
      expect(wrapper.find(Default).exists()).toBeTruthy();
    })

    it('Should disable the icon when clicked on "set default bundleset product" icon', async ()=>{
      let wrapper;
      await act(async () =>{
        wrapper = mount(<GlobalContextProvider mockData={context}>
          <MockedProvider mocks={response} addTypename={false}>
              <DefaultBundleSetProduct />
          </MockedProvider>
        </GlobalContextProvider>);
      })
      const button = wrapper.find(IconButton);
      button.simulate('click');
      await act(()=> wait(500));
      wrapper.update();
      expect(wrapper.find(DisabledDefault).exists()).toBeTruthy();
    })
})