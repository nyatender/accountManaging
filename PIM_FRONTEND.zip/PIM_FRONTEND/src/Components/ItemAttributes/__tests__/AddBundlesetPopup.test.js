import React from "react";
import { mount } from "enzyme";
import EnzymeToJson from "enzyme-to-json";
import AddBundlesetPopup from "../AddBundlesetPopup";
import GlobalContextProvider from '../../../Providers/GlobalContextProvider';
import { ApolloProvider } from "react-apollo";
import { client } from "../../App";

describe("AddBundlesetPopup Component", () => {
    it("matches AddBundlesetPopup snapshot", () => {
        const wrapper = mount(
            <GlobalContextProvider>
                <ApolloProvider client={client}>
                  <AddBundlesetPopup open={true} data={{name:"test"}}/>
                </ApolloProvider>
            </GlobalContextProvider>
            );
      expect(EnzymeToJson(wrapper)).toMatchSnapshot();
    });
})