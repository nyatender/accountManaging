import {
    GET_PRODUCTS_VARIANT_TREE,
    UPDATE_PRODUCT_SET,
    GET_PRODUCT_SET_BY_ID
  } from "../../Query";

  module.exports = {
      context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        globalChannelID: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
        firstName: "varun",
        lastName: "sateesh",
        rowDetails: {
            categoryId: null,
            channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            createdAt: "2021-08-06T12:50:06.437372",
            isAvailable: true,
            isPublished: false,
            phaseOutDate: null,
            productId: "1d4ee28e-5193-4060-87a2-d8a7b47953bf",
            productName: [
                {text: "100022200", languageCode: "en_GB", __typename: "TextTranslationOutput"}
            ],
            productSource: "PIM",
            productType: "BUNDLE",
            publishedDate: "0001-01-01T00:00:00",
            ranking: 0,
            sku: "TestBundleProduct-100002",
            __typename: "ProductSchema"

        },
        productDetailOfTree: {
            isDefault: false,
            name: null,
            productId: "0000bb37-a8ca-4438-9328-d175d95c6af4",
            productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
            productType: "PRODUCT_VARIANT",
            ranking: 0,
            sku: "10971202",
            __typename: "ProductSetToProductOutputType"
        },
        productSetsForBundle: [
            {
                isDefault: true,
                isMasterData: true,
                name: [{text: "1 - New Global Bundle set", __typename: "TextTranslationOutput"}],
                productSetAttributes: null,
                productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                products: [
                    {
                        isDefault: false,
                        name: null,
                        productId: "01106a3f-1393-43aa-9a35-3de05d78d31m",
                        productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d9e",
                        productType: "PRODUCT",
                        ranking: 0,
                        sku: "P-171240",
                        __typename: "ProductSetToProductOutputType"
                    },
                    {
                        isDefault: true,
                        name: null,
                        productId: "00e83a0d-9e73-4c3c-a806-1e75d3cf233b",
                        productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d9e",
                        productType: "PRODUCT_VARIANT",
                        ranking: 0,
                        sku: "10937963",
                        __typename: "ProductSetToProductOutputType"
                    },
                    {
                        isDefault: false,
                        name: null,
                        productId: "00f786a1-4b1c-4697-81f4-7e8d7d5a542f",
                        productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d9e",
                        productType: "PRODUCT_VARIANT",
                        ranking: 0,
                        sku: "10964462",
                        __typename: "ProductSetToProductOutputType"
                    }
                ],
                ranking: 0,
                tailoringAttributes: null,
                __typename: "ProductSetOutputType"
            },
            {
                isDefault: false,
                isMasterData: false,
                name: [{text: "BundleSet-100029290", __typename: "TextTranslationOutput"}],
                productSetAttributes: null,
                productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
                products: [
                    {
                        isDefault: true,
                        name: null,
                        productId: "0019c6cd-f9be-40f7-b5b1-3b8f38b20ca4",
                        productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
                        productType: "PRODUCT_VARIANT",
                        ranking: 1,
                        sku: "10988912",
                        __typename: "ProductSetToProductOutputType"
                    },
                    {
                        isDefault: false,
                        name: null,
                        productId: "0000bb37-a8ca-4438-9328-d175d95c6af4",
                        productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
                        productType: "PRODUCT_VARIANT",
                        ranking: 0,
                        sku: "10971202",
                        __typename: "ProductSetToProductOutputType"
                    }
                ],
                ranking: 0,
                tailoringAttributes: null,
                __typename: "ProductSetOutputType"
            }
        ]
      },
      response: [
          {
              request:{
                query: GET_PRODUCT_SET_BY_ID,
                variables: {
                    channelFilter: {
                        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21", 
                        languageCode: "en_GB",
                    },
                    productSetFilter: {
                        productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56"
                    }
                }
              },
              result: JSON.parse(`{
                "data": {
                  "productSet": {
                    "getProductSetById": {
                      "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                      "name": [
                        {
                          "languageCode": "en_GB",
                          "text": "BundleSet-100029290",
                          "__typename": "TextTranslationOutput"
                        }
                      ],
                      "products": [
                        {
                          "isDefault": true,
                          "productId": "0019c6cd-f9be-40f7-b5b1-3b8f38b20ca4",
                          "ranking": 1,
                          "productType": "PRODUCT_VARIANT",
                          "name": null,
                          "sku": "10988912",
                          "createdDate": "2021-08-06T12:50:06.706695",
                          "__typename": "ProductSetToProductOutputType"
                        },
                        {
                          "isDefault": false,
                          "productId": "0000bb37-a8ca-4438-9328-d175d95c6af4",
                          "ranking": 0,
                          "productType": "PRODUCT_VARIANT",
                          "name": "miniReceiver 2.0 1R S",
                          "sku": "10971202",
                          "createdDate": "2021-08-06T12:50:06.706677",
                          "__typename": "ProductSetToProductOutputType"
                        }
                      ],
                      "productSetAttributes": [],
                      "tailoringAttributes": [],
                      "detailedTailoringAttributes": [],
                      "isMasterData": false,
                      "isMandatory": false,
                      "isDefault": false,
                      "ranking": 0,
                      "createdAt": "2021-08-06T12:50:06.706317",
                      "createdBy": "USER",
                      "updatedBy": "varun sateesh",
                      "__typename": "ProductSetOutputType"
                    },
                    "__typename": "ProductSetQuery"
                  }
                }
              }`)
          },
          {
              request:{
                query: UPDATE_PRODUCT_SET,
                variables: {
                    channelFilter: {
                        channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21", 
                        languageCode: "en_GB"
                    },
                    productSet: {
                        createdBy: "USER",
                        isDefault: false,
                        isMandatory: false,
                        isMasterData: false,
                        name: [{text: "BundleSet-100029290", languageCode: "en_GB"}],
                        productSetAttributes: [],
                        productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
                        products: [
                            {productId: "0019c6cd-f9be-40f7-b5b1-3b8f38b20ca4", ranking: 1, isDefault: false},
                            {productId: "0000bb37-a8ca-4438-9328-d175d95c6af4", ranking: 0, isDefault: true}
                        ],
                        tailoringAttributes: [],
                        updatedBy: "varun sateesh",
                        ranking: 0
                    }
                }
              },
              result: JSON.parse(`{
                "data": {
                  "productSet": {
                    "updateProductSet": {
                      "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                      "name": [
                        {
                          "text": "BundleSet-100029290",
                          "languageCode": "en_GB",
                          "__typename": "TextTranslationOutput"
                        }
                      ],
                      "createdBy": "USER",
                      "updatedBy": "varun sateesh",
                      "isMandatory": false,
                      "__typename": "ProductSetOutputType"
                    },
                    "__typename": "ProductSetMutation"
                  }
                }
              }`)
          },
          {
              request:{
                query: GET_PRODUCTS_VARIANT_TREE,
                variables: {
                    channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                    productId: "1d4ee28e-5193-4060-87a2-d8a7b47953bf"
                }
              },
              result: JSON.parse(`{
                "data": {
                  "product": {
                    "getProductVariantsTreeByChannelAndProduct": [
                      {
                        "productId": "1d4ee28e-5193-4060-87a2-d8a7b47953bf",
                        "parentProductId": null,
                        "categoryId": null,
                        "sku": "TestBundleProduct-100002",
                        "name": null,
                        "productType": "BUNDLE",
                        "isPublished": false,
                        "isAvailable": true,
                        "publishedDate": "0001-01-01T00:00:00",
                        "channelId": null,
                        "isDefault": false,
                        "ranking": 0,
                        "createdAt": "0001-01-01T00:00:00",
                        "updatedAt": "0001-01-01T00:00:00",
                        "updatedBy": null,
                        "variantAttribute": null,
                        "productSets": [
                          {
                            "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                            "isMasterData": true,
                            "ranking": 0,
                            "isDefault": true,
                            "name": [
                              {
                                "text": "1 - New Global Bundle set",
                                "__typename": "TextTranslationOutput"
                              }
                            ],
                            "productSetAttributes": null,
                            "tailoringAttributes": null,
                            "products": [
                              {
                                "productId": "01106a3f-1393-43aa-9a35-3de05d78d39e",
                                "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                                "sku": "P-171240",
                                "productType": "PRODUCT",
                                "name": null,
                                "ranking": 0,
                                "isDefault": false,
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "00e83a0d-9e73-4c3c-a806-1e75d3cf233b",
                                "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                                "sku": "10937963",
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "ranking": 0,
                                "isDefault": true,
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "00f786a1-4b1c-4697-81f4-7e8d7d5a5410",
                                "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                                "sku": "10964462",
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "ranking": 0,
                                "isDefault": false,
                                "__typename": "ProductSetToProductOutputType"
                              }
                            ],
                            "__typename": "ProductSetOutputType"
                          },
                          {
                            "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                            "isMasterData": false,
                            "ranking": 0,
                            "isDefault": false,
                            "name": [
                              {
                                "text": "BundleSet-100029290",
                                "__typename": "TextTranslationOutput"
                              }
                            ],
                            "productSetAttributes": null,
                            "tailoringAttributes": null,
                            "products": [
                              {
                                "productId": "0019c6cd-f9be-40f7-b5b1-3b8f38b20ca4",
                                "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                                "sku": "10988912",
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "ranking": 1,
                                "isDefault": false,
                                "__typename": "ProductSetToProductOutputType"
                              },
                              {
                                "productId": "0000bb37-a8ca-4438-9328-d175d95c6af4",
                                "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                                "sku": "10971202",
                                "productType": "PRODUCT_VARIANT",
                                "name": null,
                                "ranking": 0,
                                "isDefault": true,
                                "__typename": "ProductSetToProductOutputType"
                              }
                            ],
                            "__typename": "ProductSetOutputType"
                          }
                        ],
                        "__typename": "ProductSchema"
                      }
                    ],
                    "__typename": "ProductQuery"
                  }
                }
              }`)
          }
      ]
  }