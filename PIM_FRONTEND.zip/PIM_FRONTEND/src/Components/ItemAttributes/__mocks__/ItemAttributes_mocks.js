  module.exports = {
      context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        globalChannelID: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        showMultiDeleteInRelations: true,
        productDetailOfTree: {
            isDefault: false,
            name: null,
            productId: "0000bb37-a8ca-4438-9328-d175d95c6af4",
            productSetId: "0f3d79c5-6e00-4a70-845e-83da63decc56",
            productType: "PRODUCT_VARIANT",
            ranking: 0,
            sku: "10971202",
            __typename: "ProductSetToProductOutputType"
        }
      },
      response: ""
  }