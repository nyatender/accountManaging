import {
    UPDATE_DEFAULT_BUNDLE_SET,
    GET_PRODUCTS_VARIANT_TREE,
    GET_TAILORING_ATTRIBUTES
  } from "../../Query";

module.exports = {
    context: {
        selectedChannelIDForHeader: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        globalChannelID: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
        selectedLanguageInHeader: "en_GB",
        defaultBundleSet: "",
        firstName: "varun",
        lastName: "sateesh",
        productDetailOfTree: {
            isDefault: true,
            isMasterData: true,
            productSetAttributes: null,
            ranking: 0,
            tailoringAttributes: null,
            name:[
            {
                text: "1 - New Global Bundle set", __typename: "TextTranslationOutput"
            }
            ],
            productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
            products:
            [
            {
                isDefault: false,
                productId: "01106a3f-1393-43aa-9a35-3de05d78d39j",
                productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7j",
                name: null,
                ranking: 0,
                productType: "PRODUCT",
                sku: "P-171240",
                __typename: "ProductSetToProductOutputType"
            },
            {
                isDefault: true,
                productId: "00e83a0d-9e73-4c3c-a806-1e75d3cf233b",
                productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7j",
                name: null,
                ranking: 0,
                productType: "PRODUCT_VARIANT",
                sku: "10937963",
                __typename: "ProductSetToProductOutputType"
            },
            {
                isDefault: false,
                productId: "00f786a1-4b1c-4697-81f4-7e8d7d5a5423",
                productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d76",
                ranking: 0,
                name: null,
                sku: "10964462",
                productType: "PRODUCT_VARIANT",
                __typename: "ProductSetToProductOutputType"
            }],
            __typename: "ProductSetOutputType"
        },
        rowDetails: {
            categoryId: null,
            channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            createdAt: "2021-08-06T12:50:06.437372",
            isAvailable: true,
            isPublished: false,
            phaseOutDate: null,
            productId: "1d4ee28e-5193-4060-87a2-d8a7b47953bf",
            productName: {
            languageCode: "en_GB",
            text: "100022200",
            __typename: "TextTranslationOutput"
            },
            productSource: "PIM",
            productType: "BUNDLE",
            publishedDate: "0001-01-01T00:00:00",
            ranking: 0,
            sku: "TestBundleProduct-100002",
            __typename: "ProductSchema"
        }
    },
    response: [
    {
        request: {
            query: GET_TAILORING_ATTRIBUTES,
            variables: {
                sku: "10937963", 
                channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21"
            }
        },
        result: JSON.parse(`{
            "data": {
            "product": {
                "getProductAttributesBySkuAndChannel": {
                "publishedDate": "2021-07-31T04:27:00",
                "phaseOutDate": null,
                "useInforPhaseOutDate": false,
                "systemAttributes": null,
                "tailoringAttributes": [
                    {
                    "attributeId": "0799d1d6-529a-4847-bb46-7ace5a449132",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": null,
                    "inputControl": "TEXT_FIELD",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": [
                        {
                        "languageCode": "en_GB",
                        "text": "99e953d1-6dcf-4a72-aa2a-cca2118bdd28",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "c8260e0c-7768-463e-828b-7b450f1b99e9",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": null,
                    "inputControl": "TEXT_FIELD",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": [
                        {
                        "languageCode": "en_GB",
                        "text": "ACC. TV TRANSMITTER SET",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "3029cf13-64e0-4adb-851c-f01f3ae6e66a",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": null,
                    "inputControl": "TEXT_FIELD",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": [
                        {
                        "languageCode": "en_GB",
                        "text": "afc0bdd3-c8c3-4450-92ee-e751838fbd7e",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "5228eb7f-db87-4cfb-a131-89a46c10b1a4",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": null,
                    "inputControl": "TEXT_FIELD",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": [
                        {
                        "languageCode": "en_GB",
                        "text": "",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "8bbc53c0-4e62-4d68-b25a-720a9a8e169a",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": null,
                    "inputControl": "TEXT_FIELD",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": [
                        {
                        "languageCode": "en_GB",
                        "text": "",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "9e93bb05-1353-4c8e-89a4-3fd5b4e615f7",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": "21c1506f-5d65-434a-8aa6-52bbf586d1f1",
                    "inputControl": "DROPDOWN_LIST",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": null,
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    },
                    {
                    "attributeId": "fb3a5228-da9c-4f7f-80e3-771584db4e81",
                    "checkBoxvalue": false,
                    "checkBoxListvalue": null,
                    "dropdownvalue": "4c77e839-1a62-45fe-b4a9-9518e0776db9",
                    "inputControl": "DROPDOWN_LIST",
                    "radioButtonListvalue": null,
                    "pricevalue": 0,
                    "dateTimevalue": "0001-01-01T00:00:00",
                    "textBoxData": null,
                    "imageURL": null,
                    "__typename": "TailoringAttributeOutputType"
                    }
                ],
                "detailedTailoringAttributes": {
                    "attributeGroups": null,
                    "pLMAttributes": [
                    {
                        "attributeId": "0799d1d6-529a-4847-bb46-7ace5a449132",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Plm Parent Id",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "99e953d1-6dcf-4a72-aa2a-cca2118bdd28",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "c8260e0c-7768-463e-828b-7b450f1b99e9",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Agile Name",
                            "__typename": "TextTranslationOutput"
                        },
                        {
                            "languageCode": "fr_FR",
                            "text": "Agile Name",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "ACC. TV TRANSMITTER SET",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "3029cf13-64e0-4adb-851c-f01f3ae6e66a",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Plm Id",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "afc0bdd3-c8c3-4450-92ee-e751838fbd7e",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "5228eb7f-db87-4cfb-a131-89a46c10b1a4",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Platform",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "8bbc53c0-4e62-4d68-b25a-720a9a8e169a",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "ProductFamilyId",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "329c3adc-d177-4d7a-b7dc-15d26775ec3e",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "BrandLabelId",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "884837c4-bd7e-4874-aca9-8d3109f3d16e",
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "BrandLableName",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "isGlobal": false,
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": null,
                        "inputControl": "TEXT_FIELD",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "textBoxData": [
                        {
                            "languageCode": "en_GB",
                            "text": "",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    }
                    ],
                    "systemAttributes": [],
                    "attributes": [
                    {
                        "attributeId": "9e93bb05-1353-4c8e-89a4-3fd5b4e615f7",
                        "isGlobal": true,
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Power",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": "21c1506f-5d65-434a-8aa6-52bbf586d1f1",
                        "inputControl": "DROPDOWN_LIST",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "detailedImageURLs": [],
                        "textBoxData": null,
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    },
                    {
                        "attributeId": "fb3a5228-da9c-4f7f-80e3-771584db4e81",
                        "isGlobal": true,
                        "name": [
                        {
                            "languageCode": "en_GB",
                            "text": "Shoe Size",
                            "__typename": "TextTranslationOutput"
                        }
                        ],
                        "checkBoxvalue": false,
                        "checkBoxListvalue": null,
                        "dropdownvalue": "4c77e839-1a62-45fe-b4a9-9518e0776db9",
                        "inputControl": "DROPDOWN_LIST",
                        "radioButtonListvalue": null,
                        "pricevalue": 0,
                        "dateTimevalue": "0001-01-01T00:00:00",
                        "detailedImageURLs": [],
                        "textBoxData": null,
                        "imageURL": null,
                        "__typename": "ExtendedTailoringAttributeOutputType"
                    }
                    ],
                    "__typename": "DetailedTailoringAttributesOutputType"
                },
                "__typename": "ProductSchema"
                },
                "__typename": "ProductQuery"
            }
            }
        }`)
    },
    {
        request: {
        query: UPDATE_DEFAULT_BUNDLE_SET,
        variables: {
            channelFilter: {
                channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
                languageCode: "en_GB"
            },
            productSetFilter: {
                productId: "1d4ee28e-5193-4060-87a2-d8a7b47953bf",
                productSets: [{productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7e", isDefault: true}],
                productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7e"
            },
            user: "varun sateesh"
        }
        },
        result: {
        data: {
            bundle: {
                setDefaultProductSetToBundle: [
                {
                    productSetId: "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                    isDefault: true,
                    __typename: "ProductSetOutputType"
                }
                ],
                __typename: "BundleMutation"
            }
            }
        }
    },
    {
        request: {
        query: GET_PRODUCTS_VARIANT_TREE,
        variables: {
            channelId: "0f436535-a8c1-47c5-9bea-1942a82d6b21",
            productId: "1d4ee28e-5193-4060-87a2-d8a7b47953bf"
        }
        },
        result: JSON.parse(`
        {
        "data": {
            "product": {
            "getProductVariantsTreeByChannelAndProduct": [
                {
                "productId": "1d4ee28e-5193-4060-87a2-d8a7b47953bf",
                "parentProductId": null,
                "categoryId": null,
                "sku": "TestBundleProduct-100002",
                "name": null,
                "productType": "BUNDLE",
                "isPublished": false,
                "isAvailable": true,
                "publishedDate": "0001-01-01T00:00:00",
                "channelId": null,
                "isDefault": false,
                "ranking": 0,
                "createdAt": "0001-01-01T00:00:00",
                "updatedAt": "0001-01-01T00:00:00",
                "updatedBy": null,
                "variantAttribute": null,
                "productSets": [
                    {
                    "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                    "isMasterData": true,
                    "ranking": 0,
                    "isDefault": true,
                    "name": [
                        {
                        "text": "1 - New Global Bundle set",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "productSetAttributes": null,
                    "tailoringAttributes": null,
                    "products": [
                        {
                        "productId": "01106a3f-1393-43aa-9a35-3de05d78d39e",
                        "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                        "sku": "P-171240",
                        "productType": "PRODUCT",
                        "name": null,
                        "ranking": 0,
                        "isDefault": false,
                        "__typename": "ProductSetToProductOutputType"
                        },
                        {
                        "productId": "00e83a0d-9e73-4c3c-a806-1e75d3cf233b",
                        "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                        "sku": "10937963",
                        "productType": "PRODUCT_VARIANT",
                        "name": null,
                        "ranking": 0,
                        "isDefault": true,
                        "__typename": "ProductSetToProductOutputType"
                        },
                        {
                        "productId": "00f786a1-4b1c-4697-81f4-7e8d7d5a5410",
                        "productSetId": "e6a9f001-c9f2-4d8d-b845-68837c868d7e",
                        "sku": "10964462",
                        "productType": "PRODUCT_VARIANT",
                        "name": null,
                        "ranking": 0,
                        "isDefault": false,
                        "__typename": "ProductSetToProductOutputType"
                        }
                    ],
                    "__typename": "ProductSetOutputType"
                    },
                    {
                    "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                    "isMasterData": false,
                    "ranking": 0,
                    "isDefault": false,
                    "name": [
                        {
                        "text": "BundleSet-100029290",
                        "__typename": "TextTranslationOutput"
                        }
                    ],
                    "productSetAttributes": null,
                    "tailoringAttributes": null,
                    "products": [
                        {
                        "productId": "0000bb37-a8ca-4438-9328-d175d95c6af4",
                        "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                        "sku": "10971202",
                        "productType": "PRODUCT_VARIANT",
                        "name": null,
                        "ranking": 0,
                        "isDefault": true,
                        "__typename": "ProductSetToProductOutputType"
                        },
                        {
                        "productId": "0019c6cd-f9be-40f7-b5b1-3b8f38b20ca4",
                        "productSetId": "0f3d79c5-6e00-4a70-845e-83da63decc56",
                        "sku": "10988912",
                        "productType": "PRODUCT_VARIANT",
                        "name": null,
                        "ranking": 1,
                        "isDefault": false,
                        "__typename": "ProductSetToProductOutputType"
                        }
                    ],
                    "__typename": "ProductSetOutputType"
                    }
                ],
                "__typename": "ProductSchema"
                }
            ],
            "__typename": "ProductQuery"
            }
        }
        }
        `)
    }
    ]
}
