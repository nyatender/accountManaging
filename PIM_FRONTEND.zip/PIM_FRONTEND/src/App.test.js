import React from "react";
import App from "./Components/App";
import { shallow, mount } from "enzyme";
import { ThemeProvider } from "@material-ui/core/styles";
import { ApolloProvider } from "react-apollo";

describe("component test with Enzyme", () => {
  it("App renders without crashing", () => {
    shallow(<App />);
  });

  it("App renders without crashing mount", () => {
    mount(<App />);
  });
});

describe("App component test", () => {
  
  it("App has ThemeProvider", () => {
    const wrapper = shallow(<App />);
    expect(wrapper.find(ThemeProvider).exists()).toBe(true);
  });
  it("App has ApolloProvider", () => {
    const wrapper = shallow(<App />);
    expect(wrapper.find(ApolloProvider).exists()).toBe(true);
  });
});
