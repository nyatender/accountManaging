STATUS

[![Build Status](https://dev.azure.com/WSAudiology/Customer_SelfService_Platform/_apis/build/status/Product%20Information%20Management(PIM)/FrontEnd/pim_frontend_build_release?branchName=main)](https://dev.azure.com/WSAudiology/Customer_SelfService_Platform/_build/latest?definitionId=209&branchName=main)

[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=eCommerce%3A%3AShopXP%3A%3APIMFrontend&metric=alert_status&token=16c05ab0a91441377836c290085bdfadc103c6ad)](https://sonarcloud.io/dashboard?id=eCommerce%3A%3AShopXP%3A%3APIMFrontend)

Removed auto generated contents
Request to include contents related to pim frontend project