import React, { useState, useEffect, useContext } from 'react'
import { Card, Spacing, Dropdown, Grid, Typography } from '@wsa/echo-components/dist'
import { ACCESS_TO_FUNCTIONALITIES_HEADING, ONLINE_SHOP_DROPDOWN_LABEL } from '../../GlobalConstants'
import { GlobalContext } from '../../Context/GlobalContext'
import "./../../styles.scss";
import "./AccessToFunctionalities.css";

export default function AccessToFunctionalities() {
    const { userRoleSelected_value } = useContext(GlobalContext)
    const [, setUserRoleSelected] = userRoleSelected_value
    const [roles, setRoles] = useState([])
    const [optionSelected, setOptionSelected] = useState({ label: 'online shop', value: '' })
    useEffect(() => {
        fetch('https://localhost:44334/Common/GetRolesByApplication').then(res => res.json()).then(res => {
            const { entity } = res;
            let rolesData = entity.items;
            setRoles(rolesData);
        })
    }, [])
    let options = roles.map(item => {
        return { label: item.name, value: item}
    })
    const handleDropdown = (e) => {
        console.log(e);
        setUserRoleSelected(e)
        const option = options.filter(item => item.value === e)[0];
        console.log(option);
        setOptionSelected(option)
    }
    return (
        <Grid item colSpanS={12} colSpanL={6} colSpanM={12}>
            <Card className="accesstofunctionalities-container">
                <Typography children={ACCESS_TO_FUNCTIONALITIES_HEADING} variant="body" component="h2" />
                <Spacing mt={4} />
                <Typography children={ONLINE_SHOP_DROPDOWN_LABEL} variant='body' />
                <div className="accesstofunctionalities-dropdown">
                <Dropdown
                    placeholder='online shop'
                    options={options}
                    onChange={handleDropdown}
                    selectedItem={optionSelected}
                   
                />
            </div>
            </Card>
        </Grid>
    )
}
