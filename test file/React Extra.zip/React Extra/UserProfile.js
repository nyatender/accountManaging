
import React, { useState, useContext } from "react";
import { Typography, Button, Grid, Card, Spacing, Switch } from '@wsa/echo-components';
import PersonalInformation from "./PersonalInformation";
import { useHistory } from "react-router-dom";
import { GlobalContext } from "../../Context/GlobalContext";
import AvailableAddress from "./AvailableAddress";
import AccessToFunctionalities from "../AccessToFunctionalities/AccessToFunctionalities";
import "./UserProfile.css"

function UserProfile() {
    const {
        emailId_value,
        isAddressChecked_value,
        searchTerm_value,
        availableAddressOptions_value,
        availableAddressSearchText_value,
        skip_value,
        totalItemsCount_value,
        selectedAddress_value,
        userRoleSelected_value
    } = useContext(GlobalContext);

    const [emailId, setEmailId] = emailId_value
    const [firstName, setfirstName] = useState('');
    const [lastName, setlastName] = useState('');
    const [phoneNumber, setphoneNumber] = useState('');
    const [jobTitle, setjobTitle] = useState('');
    const [statusActive, setStatusActive] = useState(true);
    const [firstNameError, setFirstNameError] = useState(false);
    const [lastNameError, setLastNameError] = useState(false);
    const [phoneNoError, setphoneNoError] = useState(false);
    const [jobTitleError, setjobTitleError] = useState(false);
    const [firstNamerequiredError, setfirstNamerequiredError] = useState(false);
    const [lastNamerequiredError, setlastNamerequiredError] = useState(false);
    const [isAddressChecked, setIsAddressChecked] = isAddressChecked_value
    const [, setSearchTerm] = searchTerm_value
    const [, setAvailableAddressOptions] = availableAddressOptions_value;
    const [, setAvailableAddressSearchText] = availableAddressSearchText_value;
    const [, setSkip] = skip_value
    const [, setTotalItemsCount] = totalItemsCount_value
    const [selectedAddress]=selectedAddress_value
    const [userRoleSelected] =userRoleSelected_value

    let history = useHistory();

    const handleFirstNameChange = (value) => {
        setfirstNamerequiredError(false)
        if (value == "") {
            setFirstNameError(false)
            setfirstName(value);
            return
        }
        if (value.length >= 100) {
            setfirstName(value);
            setFirstNameError(true)
        } else if (value.length < 100) {

            setFirstNameError(false)
            setfirstName(value);
        }

    };
    const handleLastNameChange = (value) => {
        setlastNamerequiredError(false)
        if (value == "") {
            setLastNameError(false)
            setlastName(value);
            return
        }
        if (value.length >= 100) {
            setlastName(value);
            setLastNameError(true)
        } else if (value.length < 100) {
            setLastNameError(false)
            setlastName(value);
        }

    };
    const handlePhoneNoChange = (value) => {
        var reg = /^\d+$/;
        if (value == "") {
            setphoneNoError(false)
            setphoneNumber(value);
            return
        }
        if (reg.test(value)) {
            setphoneNoError(false)
            setphoneNumber(value);
        } else {
            setphoneNumber(value);
            setphoneNoError(true)
        }

    };
    const handleJobTitleChange = (value) => {
        if (value == "") {
            setjobTitleError(false)
            setjobTitle(value);
            return
        }
        if (value.length >= 100) {
            setjobTitle(value);
            setjobTitleError(true)
        } else if (value.length < 100) {

            setjobTitleError(false)
            setjobTitle(value);
        }

    };
    const resetData = () => {
        setEmailId('')
        setSearchTerm('')
        setAvailableAddressSearchText('')
        setAvailableAddressOptions([])
        setSkip(0)
        setTotalItemsCount(0)
        setIsAddressChecked(false)
    }
    const handelCancel = () => {
        resetData()
        history.push('/')
    }

    const handleSwitch = (newState) => {
        setStatusActive(newState);
    };
    const handleAdd = () => {
        if (firstName == "") {
            setfirstNamerequiredError(true)
        }
        if (lastName == "") {
            setlastNamerequiredError(true)
        }
        console.log("address selected",selectedAddress)
        console.log("userRoleSelected ",userRoleSelected)
        let requestdataObj={
            "Email": emailId,
            "GivenName": firstName,
            "SurName": lastName,  
            "Country": selectedAddress.shippingAddress.country,  
            "PhoneMobile": phoneNumber,
            "Language": "en",
            "Active": statusActive,
            "Company":  selectedAddress.localCustomerNumber,
            "Scopes": [   
            "410",
            "411"   
            ],
            "Roles": [
                userRoleSelected.id
            ]
      }
      console.log("requestObj ",requestdataObj)
        createUser(requestdataObj)
    }
    const createUser=(requestdata)=>{
         
    }
    return (
        <div className="userProfile-body">
            <Grid colSpanL={12} colSpanM={6} colSpanS={12} item>
                <Card>
                    <Typography component="h3" style={{ marginBottom: 'var(--echo-spacing-xxs)' }} variant="heading-m">
                        Add User {emailId}
                    </Typography>
                    <div className="userProfile-header-container">
                        <Typography component="h5" style={{ marginBottom: 'var(--echo-spacing-xxs)' }} variant="caption">
                            Status
                        </Typography>
                        <Switch
                            labelChecked="Active"
                            labelUnchecked="Inactive"
                            checked={statusActive}
                            onChange={handleSwitch}
                        />
                    </div>
                </Card>
            </Grid>
            <Spacing mt={4} />

            <Grid colSpanL={12} className="userProfile-grid-container">

                <Grid colSpanL={6} colSpanM={6} colSpanS={12} item>
                    <PersonalInformation emailId={emailId} firstName={firstName} lastName={lastName}
                        phoneNumber={phoneNumber} jobTitle={jobTitle} handleFirstNameChange={handleFirstNameChange}
                        handleJobTitleChange={handleJobTitleChange} handleLastNameChange={handleLastNameChange}
                        handlePhoneNoChange={handlePhoneNoChange} jobTitleError={jobTitleError}
                        firstNameError={firstNameError} phoneNoError={phoneNoError} lastNameError={lastNameError}
                        lastNamerequiredError={lastNamerequiredError} firstNamerequiredError={firstNamerequiredError} />
                    <Spacing mt={8} />
                    <AccessToFunctionalities /> 
                </Grid>
                <Grid colSpanL={6} colSpanM={6} colSpanS={12} className="tw-flex-grow" item>
                    <AvailableAddress />
                </Grid>

            </Grid>
            <Spacing mt={4} />
            <div className="userProfile-button-container">
                <Button className="echo-button--small" variant="primary" onClick={handelCancel}>
                    Cancel
                </Button>
                <Spacing mr={6} />
                <Button className="echo-button--small" variant="primary" onClick={handleAdd} disabled={!isAddressChecked}>
                    Add User
                </Button>
            </div>
            <Spacing mb={4} />
        </div>
    )
}

export default UserProfile;