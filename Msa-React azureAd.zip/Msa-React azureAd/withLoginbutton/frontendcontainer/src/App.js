import React from "react";
import AppRoutes from "./components/routes/AppRoutes";
import ErrorBoundary from "./components/error-boundary/ErrorBoundary";
import { ContextValue, GlobalContext } from "./components/context/gobalContext";
import { MsalProvider } from '@azure/msal-react';

function App( { instance }) {
  const globalContextValue = ContextValue();
  return (
    <div className="ddx-cloud-app" data-testid="ddx-cloud-app-test">
      <GlobalContext.Provider value={globalContextValue}>
        <MsalProvider instance={instance}>
          <ErrorBoundary>
            <AppRoutes instance={instance}/>
          </ErrorBoundary>
        </MsalProvider>
      </GlobalContext.Provider>
    </div>
  );
}

export default App;
