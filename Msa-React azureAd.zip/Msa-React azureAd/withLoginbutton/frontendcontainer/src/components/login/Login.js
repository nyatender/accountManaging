import React from 'react';
import { MsalProvider, AuthenticatedTemplate, useMsal , UnauthenticatedTemplate } from '@azure/msal-react';
import Layout from "../layout/Layout"
import { Outlet } from 'react-router-dom';
import SiemensLogin from "../siemenslogin/SiemensLogin";
import Header from "../header/Header";

const Authentication = () => {
    const { instance } = useMsal();
    let activeAccount;

    if(instance){
      activeAccount = instance.getActiveAccount();
    }

    return (
        <div>
            <AuthenticatedTemplate>
                {activeAccount ? (
                  <>
                    <Header/>
                    <Layout/>
                    <Outlet/>
                  </>

                ) : null}
            </AuthenticatedTemplate>
            <UnauthenticatedTemplate>
              <SiemensLogin/>
           </UnauthenticatedTemplate>
        </div>
    );
};

const Login = ({ instance }) => {
    return (
        <MsalProvider instance={instance}>
              <Authentication />
        </MsalProvider>
    );
};

export default Login;