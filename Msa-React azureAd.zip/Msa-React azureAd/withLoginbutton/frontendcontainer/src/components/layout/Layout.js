import React  from "react";
import { Navigation } from "../navigations/Navigation.js";

function Layout() {
  return (
    <div className="ddx-layout position-relative">
      <Navigation />
    </div>
  );
}

export default Layout;
