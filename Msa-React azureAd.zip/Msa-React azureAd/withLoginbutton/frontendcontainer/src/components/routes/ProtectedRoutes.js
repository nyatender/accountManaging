import { Navigate } from "react-router-dom";
import React from "react";
import { useIsAuthenticated } from '@azure/msal-react';

export const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useIsAuthenticated();
  console.log("value",isAuthenticated)
  if (!isAuthenticated) {
    // user is not authenticated
    return <Navigate to="/" />;
  }
  return children;
};
