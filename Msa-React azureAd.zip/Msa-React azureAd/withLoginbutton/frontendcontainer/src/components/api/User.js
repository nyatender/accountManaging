const getUserApi = () => {
  const url = `http://localhost:8080/api/v1/employees`;
  const config = (accessToken) => {
    return {
      headers: {
        Authorization: "Bearer " + accessToken,
        Accept: "application/json, text/plain, */*",
        "Content-Type": "application/json",
      },
    };
  };
  return { url, config };
};
export { getUserApi };
