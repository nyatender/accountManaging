import { MsalAuthProvider, LoginType } from "react-aad-msal";
import { Logger, LogLevel } from "msal";

// Msal Configurations
const config = {
  auth: {
    //authority: 'https://login.microsoftonline.com/38ae3bcd-9579-4fd4-adda-b42e1495d55a',
    authority: "https://login.microsoftonline.com/siemens.onmicrosoft.com",
    clientId: "0ffb1b0f-2404-41a5-b594-2360ed7bcb7d", // need to add client id /appid generated in azure
    redirectUri: "http://localhost:3000",
    //postLogoutRedirectUri: window.location.origin,
    //redirectUri: window.location.origin,
    //validateAuthority: true,
    // After being redirected to the "redirectUri" page, should user
    // be redirected back to the Url where their login originated from?
    //navigateToLoginRequestUrl: true
  },
  system: {
    logger: new Logger(
      (logLevel, message, containsPii) => {
        console.log("[MSAL]", message);
      },
      {
        level: LogLevel.Verbose,
        piiLoggingEnabled: false,
      }
    ),
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: true,
  },
};

// Authentication Parameters
const authenticationParameters = {
  scopes: ["openid", "profile", "0ffb1b0f-2404-41a5-b594-2360ed7bcb7d/.default"],
  /*  scopes: [
    `<your api registartion app id>/.default`
    ] */
};

// Options
const options = {
  loginType: LoginType.Popup,
  //loginType: LoginType.Redirect,
  tokenRefreshUri: window.location.origin + "/auth.html",
};

export const authProvider = new MsalAuthProvider(
  config,
  authenticationParameters,
  options
);
