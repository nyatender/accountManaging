import React, { useState } from 'react';

export const ContextValue = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const value = {
        auth_value: [isAuthenticated, setIsAuthenticated],
    };
    return value;
};

export const GlobalContext = React.createContext({});

