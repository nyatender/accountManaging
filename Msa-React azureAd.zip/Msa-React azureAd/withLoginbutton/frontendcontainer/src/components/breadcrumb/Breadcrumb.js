import React, { useState } from "react";
import { useLocation } from "react-router-dom";
export const Breadcrumb = () => {
  const locPath = useLocation().pathname;
  const [pathname] = useState(locPath);
  const breadcrumbArr = window.location.hash
    .split("/")
    .filter((p) => p !== "" && p !== "#");
  function toCamelCase(str) {
    let newStr = "";
    if (str) {
      let wordArr = str.split(/[-_]/g);
      for (let i in wordArr) {
        newStr +=
          " " + wordArr[i].charAt(0).toUpperCase() + wordArr[i].slice(1);
      }
    }
    return newStr;
  }
  return (
    pathname &&
    breadcrumbArr.map((breadcrumb, index) => {
      let separator = " / ";
      if (index >= breadcrumbArr.length - 1) {
        return (
          <span
            className="breadcrumb__item is-current"
            style={{ color: "#000000" }}
            key={index}
          >
            {toCamelCase(breadcrumb)}
          </span>
        );
      } else {
        return (
          <span className="breadcrumb__item" key={index}>
            <a href={breadcrumb} style={{ textDecoration: "none" }}>
              {toCamelCase(breadcrumb)}
            </a>
            {separator}
          </span>
        );
      }
    })
  );
};
