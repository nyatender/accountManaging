import React from "react";
import { Loader } from "../loader/Loader";

const CommonTable = ({ rows, columns }) => {
  return (
    <React.Fragment>
      <div className="scrollableTableWrapper" style={{ marginLeft: "5%" }}>
        <table className="table">
          <thead>
            <tr>{columns}</tr>
          </thead>
          {rows.length ? (
            <tbody>{rows}</tbody>
          ) : (
            <tbody>
              <tr key={1}>No Data</tr>
            </tbody>
          )}
        </table>
      </div>
    </React.Fragment>
  );
};

export default CommonTable;
