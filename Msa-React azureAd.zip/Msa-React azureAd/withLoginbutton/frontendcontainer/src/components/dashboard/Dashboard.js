import React from "react";
import CommonTable from "../table/Commontable";
import { customTableColumn } from "../utils/commonFunctions";
import { useTranslation } from "react-i18next";
import styles from "./Dashboard.module.scss";
import { Loader } from "../loader/Loader";
import { useDashboard } from "../hooks/useDashboard";

export function Dashboard() {
  const { rowData, isLoading } = useDashboard();

  const { t } = useTranslation();
  const trans = (key) => t(key);

  const ROWS =
    rowData.length &&
    rowData.map((r, i) => (
      <tr key={i}>
        {customTableColumn(r?.firstName)}
        {customTableColumn(r?.lastName)}
        {customTableColumn(r?.emailId)}
      </tr>
    ));

  const COLUMNS = (
    <React.Fragment>
      <th>{trans("First Name")}</th>
      <th>{trans("Last Name")}</th>
      <th>{trans("Email")}</th>
    </React.Fragment>
  );

  return (
    <React.Fragment>
      <div className={styles.header}>
        <h4 style={{ marginTop: "2%", marginLeft: "7%" }}>{trans("Users")}</h4>

        <div className={"container-fluid  " + styles.iam_commonListContainer}>
          <CommonTable rows={ROWS} columns={COLUMNS} />
        </div>
      </div>
      {isLoading && <Loader />}
    </React.Fragment>
  );
}
