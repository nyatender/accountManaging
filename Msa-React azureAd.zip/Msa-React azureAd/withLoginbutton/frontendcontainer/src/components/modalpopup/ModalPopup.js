import React from "react";
import { Modal, Button } from "react-bootstrap";
import "./modalpopup.css"

function ModalPopup({show , close , logout}){
    function handleClose(){
        close();
    }
    return(

<div>
<Modal show={show} onHide={handleClose} style={{marginTop:"12%"}}>
        <Modal.Header closeButton className="modalheader">
          <Modal.Title>Logout</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{minHeight:"210px"}}>
            <h5>Do you really want to logout?</h5>
                <p className="modalContent">
                For security reasons it is recommended to close the browser after logging out. This is especially important if you use a public device.
                </p>
        </Modal.Body>
        <Modal.Footer className="modalfooter">
          <Button  className="secondarybutton" onClick={handleClose}>
            Cancel
          </Button>
          <Button clasName="primarybutton" onClick={logout}>
            Logout
          </Button>
        </Modal.Footer>
      </Modal>

</div>
    )
}

export default ModalPopup;