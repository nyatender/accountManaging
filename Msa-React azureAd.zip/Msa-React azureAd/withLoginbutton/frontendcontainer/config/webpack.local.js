const { merge } = require("webpack-merge");
const { ModuleFederationPlugin } = require("webpack").container;
const path = require("path");
const deps = require("../package.json").dependencies;
const commonConfig = require("./webpack.common");

const devConfig = {
  mode: "development",
  devServer: {
    static: {
      directory: path.join(__dirname, "dist"),
    },
    port: 3000,
    historyApiFallback: true,
  },
  devtool:'source-map',
  plugins: [
    new ModuleFederationPlugin({
      name: "DDX Dashboard Container App",
      remotes: {
        contracts: `contracts@${getRemoteEntryUrl(3001)}`,
      },
      shared: {
        ...deps,
        react: { singleton: true, requiredVersion: deps.react },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
      },
    }),
  ],
};

function getRemoteEntryUrl(param) {
  return `//localhost:${param}/remoteEntry.js`;
}

module.exports = merge(commonConfig, devConfig);
