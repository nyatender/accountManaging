import React from "react";

export function Loader() {
  return (
    <div
      className="busyIndicator busyIndicator--withOverlay is-shown"
      data-testid="loader"
    >
      <div className="busyIndicator__ring busyIndicator__ring--medium"></div>
      <div className="busyIndicator__overlay"></div>
    </div>
  );
}
