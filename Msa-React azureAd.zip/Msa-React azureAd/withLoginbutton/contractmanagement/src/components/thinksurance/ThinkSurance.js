import React, { useEffect } from "react";

function ThinkSurance() {
  useEffect(() => {
    const config = {
      renderId: "thinkSurance",
      brokerCode: "216553745d6b9afb",
      productId: 153,
      professionAliasIds: [2987],
    };

    window.ts.load(config);
  }, []);
  return (
    <div>
      <div id="thinkSurance"></div>
    </div>
  );
}

export default ThinkSurance;
