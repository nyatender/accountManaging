import React, { Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import ThinkSurance from "../thinksurance/ThinkSurance";
import Dashboard from "../dashboard/Dashboard";

function ContractRoutes() {
  return (
    <Suspense>
      <Routes>
        <Route index element={<Dashboard />} />
        <Route path="/dashboard" element={<ThinkSurance />} />
      </Routes>
    </Suspense>
  );
}

export default ContractRoutes;
