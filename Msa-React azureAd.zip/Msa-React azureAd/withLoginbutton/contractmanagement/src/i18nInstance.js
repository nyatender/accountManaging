import i18n, { createInstance } from 'i18next';
import { initReactI18next } from 'react-i18next';

const i18nInstance = createInstance({
  fallbackLng: 'en',
  debug: false,

  ns: ['translation'],
  defaultNS: 'translation',
  react: { useSuspense: false },

  interpolation: {
    escapeValue: false, // not needed for react as it escapes by default
  },

  resources: {
    en: {
      translation: require('../public/locales/en/translation.json'),
    },
    de: {
      translation: require('../public/locales/de/translation.json'),
    },
  },
});

i18nInstance.use(initReactI18next).init();

i18n.on('languageChanged', (lng) => {
  // Un-comment the following code when the language change dropdown will be implemented
  //i18nInstance.changeLanguage(lng);
});

export default i18nInstance;
