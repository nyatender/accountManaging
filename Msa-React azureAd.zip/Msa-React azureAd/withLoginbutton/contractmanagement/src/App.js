import React, { useEffect, useState } from "react";
import axios from "axios";
import { ToastContainer } from "react-toastify";

import "react-toastify/dist/ReactToastify.min.css";
import ContractRoutes from "./components/routes/ContractRoutes";
import { Loader } from "./components/loader/Loader";
import "./index.scss";

function App() {
  let [count, setCount] = useState(0);

  // useEffect(() => {
  //   axios.interceptors.request.use((req) => {
  //     setCount(count + 1);
  //     return req;
  //   });

  //   axios.interceptors.response.use(
  //     (response) => {
  //       setCount(count - 1);
  //       return response;
  //     },
  //     (err) => {
  //       setCount(count - 1);
  //       return Promise.reject(err);
  //     }
  //   );
  // }, []);

  return (
    <div
      id="contract-management"
      className="ddx-content"
      test-id="contract-management"
    >
      <ToastContainer
        hideProgressBar={true}
        autoClose={5000}
        closeButton={false}
      />
      <ContractRoutes />

      {count > 0 && <Loader />}
    </div>
  );
}

export default App;
