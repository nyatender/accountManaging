const { merge } = require("webpack-merge");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const path = require("path");
const commonConfig = require("./webpack.common");

const devConfig = {
  mode: "development",
  devServer: {
    static: {
      directory: path.join(__dirname, "dist"),
    },
    port: 3001,
    historyApiFallback: true,
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./public/index.html",
      favicon: "./public/favicon.png",
    }),
    new CopyWebpackPlugin({
      patterns: [{ from: "./public/locales", to: "locales" }],
    }),
  ],
};

module.exports = merge(commonConfig, devConfig);
