import React from 'react';
import { MsalProvider, AuthenticatedTemplate, useMsal ,useIsAuthenticated } from '@azure/msal-react';
import { InteractionStatus } from "@azure/msal-browser";
import { loginRequest } from '../../../config/authConfig';
import Layout from "../layout/Layout"
import { Outlet } from 'react-router-dom';

const Authentication = () => {
    const { instance , inProgress , accounts} = useMsal();
    const isAuthenticated = useIsAuthenticated();
    let activeAccount;
    if(instance){
      activeAccount = instance.getActiveAccount();
    }
    if (inProgress === InteractionStatus.None && !isAuthenticated) {
      setTimeout(() => {
        if (accounts.length === 0) {
          instance.loginRedirect(loginRequest).catch((error) => console.log(error));
        }
    }, 500)
      
    };


    
    return (
        <div>
            <AuthenticatedTemplate>
                {activeAccount ? (
                  <>
                    <Layout/>
                    <Outlet/>
                  </>

                ) : null}
            </AuthenticatedTemplate>
        </div>
    );
};

const Login = ({ instance }) => {
    return (
        <MsalProvider instance={instance}>
                <Authentication />
        </MsalProvider>
    );
};

export default Login;