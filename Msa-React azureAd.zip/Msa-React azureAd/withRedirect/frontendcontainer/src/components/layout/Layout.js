import React, { useEffect, useContext } from "react";
import { Navigation } from "../navigations/Navigation.js";
import Header from "../header/Header.js";
import { GlobalContext } from "../context/gobalContext.js";

function Layout() {
/*   const { auth_value } = useContext(GlobalContext);
  const [, setIsAuthenticated] = auth_value;

  useEffect(() => {
    setIsAuthenticated(isAuthenticate);
  }, []); */

  return (
    <div className="ddx-layout position-relative">
      <Header/>
      <Navigation />
    </div>
  );
}

export default Layout;
