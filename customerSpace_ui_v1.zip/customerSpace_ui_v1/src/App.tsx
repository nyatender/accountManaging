
import AppRoutes from './components/routes/AppRoutes'
export declare type LogoutFunction = () => void
export interface IAppProps {
  logout: LogoutFunction
}

function App({ logout }: IAppProps) {
  return (
    <div>
      <AppRoutes logout={logout} />
    </div>
  )
}

export default App
