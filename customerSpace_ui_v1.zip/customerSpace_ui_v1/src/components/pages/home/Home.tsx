import React  from 'react'
import { Navigation } from '../../atoms/navigation'
import { ReactComponent as SiemensLogo } from '../../assets/Siemens.svg'
import { IMenuItemTypes } from '../../atoms/navigation/NavigationPropTypes'
import { Outlet, useNavigate , useLocation } from 'react-router-dom'
import { showModal } from '@siemens/ix-react'
import CustomModal from '../../atoms/customModal/CustomModal'
import { IHomePropTypes } from './HomeProptypes'
import { Appconstants } from '../../../constants'
import Breadcrumb from '../../atoms/breadcrumb/Breadcrumb'
import './home.css'
import { useCheckEmail } from '../../hooks/useCheckEmail'
//import { useCompanyContext } from '../company/hooks/useCompanyContext'
import Spinner from '../../atoms/spinner/Spinner'
import UserNotFound from '../userNotFound/UserNotFound'
import { Error } from '../error/Error'


function Home({ logout }: IHomePropTypes): React.ReactElement {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { isUserExist , isLoading , error} = useCheckEmail()


  async function show(): Promise<void> {
    await showModal({
      title: 'test',
      content: (
        <CustomModal
          logout={logout}
          headerText={Appconstants.company.modal.logout.title}
          bodyText={Appconstants.company.modal.logout.bodyContent}
        />
      ),
      centered: true,
      icon: 'about',
      size: 'sm',
    })
  }
  function getNavigationItems(){
    let navigationItems:IMenuItemTypes[] =[
      {
        id: 1,
        icon: 'log-out',
        name: Appconstants.company.menu.logout,
        slot: 'bottom',
        onClick: () => show(),
      }
    ]
    if(isUserExist){
      navigationItems = [ ...navigationItems,
        {
          id: 2,
          icon: 'building2',
          name: Appconstants.company.menu.companiesMenuTitle,
          onClick: () => navigate('/'),
        }, {
          id: 3,
          icon: 'user-management',
          name: Appconstants.user.menu.usersMenuTitle,
          onClick: () => navigate('/users'),
        },
      ]
    }
    return navigationItems
  }

  function ChildComponent() {
    return (
      <>
        { isUserExist &&
          <div className="breadcrumbSection">
            <Breadcrumb label={(pathname==='/')?'companies':'users'} 
              icon={!!(pathname==='/')?'building2':'user-management'} />
          </div>
        }
     
        <Outlet />
      </>
    )
  }
  return (
    <div>
      <Navigation
        logo={<SiemensLogo />}
        menuItems={getNavigationItems()}
        applicationName={Appconstants.company.appName}
        className='navigationBar'
      />
      {
        (isLoading && error === null) ? (
          <div className='homeLoader'>
            <Spinner />
          </div>
        ): (!isUserExist && error === null && !isLoading) ? <UserNotFound/>:
          (error !== null) ? <Error/>:
            <ChildComponent />
      }
    </div>
  )
}

export { Home }
