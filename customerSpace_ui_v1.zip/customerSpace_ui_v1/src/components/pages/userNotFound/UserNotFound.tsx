
import { Appconstants } from '../../../constants';
import './userNotFound.css'


const UserNotFound = () => {

  return (
    <div className="notFound" data-testid="usernotFound"><h3>{Appconstants.errorPageText}</h3></div>
      
  )

};

export default UserNotFound;