import React from 'react';
import './dashboard.css'
function Dashboard(): React.ReactElement {
  return(<div className='dashboardContainer'>
    <h3>Admin Dashboard</h3>
  </div>
  )
 
}

export default Dashboard