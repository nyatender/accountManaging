import ContentHeader from '../../atoms/contentHeader/ContentHeader'
import { useCompanyContext } from './hooks/useCompanyContext'
import './companies.css'
import { KeyValue } from '../../atoms/keyValue/KeyValue'
import { companyDataMapping, companyDetailsKeyMappings } from '../../util/util'
import { Appconstants } from '../../../constants'
import { IrearrangeCompanyData } from './CompanyPropsTypes'

function CompanyDetailsPanel() {
  const { companyDetails } = useCompanyContext()

  const renderKeyValuePairs=(infoKeys:string | string[])=>{
    const rearrangedData :IrearrangeCompanyData = {};
    for (const key of infoKeys) {
      if (companyDetails.hasOwnProperty(key)) {
        rearrangedData[key] = companyDetails[key];
      }
    }
    return Object.entries(rearrangedData)
      .filter((item) => infoKeys.includes(item[0]))
      .map((companyData, index) => {
        const mappedLabel = companyDataMapping[companyData[0]]
        return (
          <KeyValue
            key={index}
            label={mappedLabel}
            value={companyData[1]?.toString() ?? ''}
          />
        )
      })
  }
  return (
    <div className='companyDetailsPage'>
      <div>
        <ContentHeader hasBackButton={false} title={Appconstants.company.label.companyDetails} />
      </div>
      <div className='companyDetailsContainer'>
        {companyDetailsKeyMappings.map((eachInfoKeyMapItem) => (
          <div>
            {renderKeyValuePairs(eachInfoKeyMapItem.headerKeys)}
          </div>
        ))
        }
      </div>
    </div>
  )
}

export default CompanyDetailsPanel
