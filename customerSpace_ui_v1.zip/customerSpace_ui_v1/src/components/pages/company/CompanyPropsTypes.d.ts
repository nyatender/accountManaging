declare type hideAddCompanyPanel = () => void
export interface ICompany{
  companyName: string; 
  companyEmailAddress: string; 
  telephone: string; 
  country: string; 
  address: string; 
  zipCode: string
}
export interface ICompanyContextType{
  isAddCompanyPanelOpen: boolean,
  isLoading:boolean,
  companyDetails:ICompany[{Company,Email,Telephone,Country,Users,Address,ZipCode,DateCreated}]
  showEditDropdown:boolean;
  isEditCompany:boolean,
  showPanel:boolean,
  totalPages:number,
  addedCompanyId:number
  flagToCallCompanyApi:boolean
  companySearchText:string
  startPage:number,
  pageSize:number,
  selectedPageVal:number
  selectedEditData:ICompany[{Company,Email,Telephone,Country,Users,Address,ZipCode,DateCreated}]
  setIsAddCompanyPanelOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsloading:React.Dispatch<React.SetStateAction<boolean>>;
  setCompanyDetails:React.Dispatch<React.SetStateAction<>>;
  setShowEditDropdown:React.Dispatch<React.SetStateAction<boolean>>;
  setIsEditCompany:React.Dispatch<React.SetStateAction<boolean>>;
  setShowPanel:React.Dispatch<React.SetStateAction<boolean>>;
  setTotalPages:React.Dispatch<React.SetStateAction<>>;
  setAddedCompanyId:React.Dispatch<React.SetStateAction<>>;
  setSelectedEditData:React.Dispatch<React.SetStateAction<>>;
  setflagToCallCompanyApi:React.Dispatch<React.SetStateAction<boolean>>;
  setCompanySearchText:React.Dispatch<React.SetStateAction<>>;
  setPageSize:React.Dispatch<React.SetStateAction<>>;
  setStartPage:React.Dispatch<React.SetStateAction<>>;
  setSelectedPageVal:React.Dispatch<React.SetStateAction<>>;
};

export interface IAddCompanyProps{
  hideAddCompanyPanel:()=>void
  showAddCompanySidePanel: ()=>void
}

export interface ICompanyDetails{
  companyName: string; 
  generamEmailId: string; 
  telephone: string; 
  country: string; 
  address: string; 
  zipCode: string;
  CreatedBy:string
  CreationDate:[number]
  UpdatedBy:string
  UpdatedDate:[number]
  id:number
  userEntityList:[]
  userCount:number
}

export interface ICompanyData{
  companyName: string; 
  companyEmailAddress: string; 
  telephone: string; 
  country: string; 
  address: string; 
  zipCode: string
  id:number
}

export interface ICompanyIdtype{
  id:number
}


export interface ICompanyDetailsTypes{
  companyName: string; 
  generalEmailId: string; 
  billingEmailId:string;
  incidentReportingEmailId:string;
  telephone: string; 
  country: string; 
  address: string; 
  zipCode: string;
  creationDate:string;
  userCount:string;
  [key: string]: string;
}

export interface IrearrangeCompanyData{
  [key: string]: string; 
}

export interface ICompanyContextMock{
  isEditCompany:boolean,
  selectedEditData:ICompanyDetails[{
    companyName,
    companyEmailAddress,
    billingEmailId,
    incidentReportingEmailId,
    telephone,
    country,
    address,
    zipCode,
    creationDate,
    userCount
  }],
  isAddCompanyPanelOpen:boolean
}


