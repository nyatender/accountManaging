import { createContext, useState } from 'react'
import { ICompanyContextMock, ICompanyContextType } from './CompanyPropsTypes'
import { ConfigurationConstants } from '../../../constants'

let DEFAULT_STATE = {
  isAddCompanyPanelOpen: false,
  setIsAddCompanyPanelOpen: () => { },
  isLoading: false,
  setIsloading: () => { },
  companyDetails: [],
  setCompanyDetails: () => { },
  showEditDropdown: false,
  setShowEditDropdown: () => { },
  isEditCompany: false,
  setIsEditCompany: () => { },
  showPanel: false,
  setShowPanel: () => { },
  totalPages: 0,
  setTotalPages: () => { },
  addedCompanyId: 0,
  setAddedCompanyId: () => { },
  selectedEditData: [],
  setSelectedEditData: () => { },
  editedCompanyId: 0,
  setEditedCompanyId: () => { },
  flagToCallCompanyApi: true,
  setflagToCallCompanyApi: () => { },
  companySearchText: '',
  setCompanySearchText: () => { },
  startPage:0,
  setStartPage:()=>{},
  pageSize:ConfigurationConstants.number_of_record_per_page,
  setPageSize:()=>{},
  selectedPageVal:0,
  setSelectedPageVal:()=>{}
} as ICompanyContextType

export const CompanyContext = createContext<ICompanyContextType>(DEFAULT_STATE)

interface Props {
  children: React.ReactNode
  mockData?:ICompanyContextMock
}

function CompanyContextProvider({ children ,mockData }: Props) {
  DEFAULT_STATE = { ...DEFAULT_STATE, ...mockData };
  const [isAddCompanyPanelOpen, setIsAddCompanyPanelOpen] =
    useState<boolean>(DEFAULT_STATE.isAddCompanyPanelOpen)
  const [isLoading, setIsloading] = useState<boolean>(DEFAULT_STATE.isLoading)
  const [companyDetails, setCompanyDetails] = useState(DEFAULT_STATE.companyDetails)
  const [showEditDropdown, setShowEditDropdown] = useState<boolean>(DEFAULT_STATE.showEditDropdown)
  const [showPanel, setShowPanel] = useState(DEFAULT_STATE.showPanel)
  const [isEditCompany, setIsEditCompany] = useState<boolean>(DEFAULT_STATE.isEditCompany)
  const [totalPages, setTotalPages] = useState(DEFAULT_STATE.totalPages)
  const [addedCompanyId, setAddedCompanyId] = useState(DEFAULT_STATE.addedCompanyId)
  const [selectedEditData, setSelectedEditData] = useState(DEFAULT_STATE.selectedEditData)
  const [startPage, setStartPage] = useState(DEFAULT_STATE.startPage)
  const [selectedPageVal, setSelectedPageVal] = useState(DEFAULT_STATE.selectedPageVal)
  const [pageSize, setPageSize] = useState(DEFAULT_STATE.pageSize)
  
  const [flagToCallCompanyApi, setflagToCallCompanyApi] =
    useState<boolean>(DEFAULT_STATE.flagToCallCompanyApi)
  const [companySearchText, setCompanySearchText] = useState(DEFAULT_STATE.companySearchText)
  return (
    <CompanyContext.Provider
      value={{
        isAddCompanyPanelOpen,
        setIsAddCompanyPanelOpen,
        isLoading,
        setIsloading,
        companyDetails,
        setCompanyDetails,
        showEditDropdown,
        setShowEditDropdown,
        isEditCompany,
        setIsEditCompany,
        showPanel,
        setShowPanel,
        totalPages,
        setTotalPages,
        addedCompanyId,
        setAddedCompanyId,
        selectedEditData,
        setSelectedEditData,
        flagToCallCompanyApi,
        setflagToCallCompanyApi,
        companySearchText,
        setCompanySearchText,
        startPage,
        setStartPage,
        pageSize,
        setPageSize,
        selectedPageVal,
        setSelectedPageVal


      }}
    >
      {children}
    </CompanyContext.Provider>
  )
}

export default CompanyContextProvider
