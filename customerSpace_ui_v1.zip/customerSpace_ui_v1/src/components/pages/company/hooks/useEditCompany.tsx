
import { useCompanyContext } from './useCompanyContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { putAPI } from '../../api/api';
import { useToast } from '../../../atoms/toast/useToast';
import { ICompanyData } from '../CompanyPropsTypes';
import { UPDATE_COMPANY } from '../../api/urlConstants';

const useEditCompany = () => {
  const { setIsloading, setflagToCallCompanyApi } = useCompanyContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const editCompanyData = async (companyData: ICompanyData) => {
    setIsloading(true)
    const resultantData = await putAPI(UPDATE_COMPANY,companyData)
      .then((data) => {
        setIsloading(false)
        setflagToCallCompanyApi(true)
        
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          callToast("error",Appconstants.company.toast.editFailureMessage)
        }
        console.error(error)
      })
    return resultantData
  }

  return { editCompanyData }
}

export { useEditCompany }
