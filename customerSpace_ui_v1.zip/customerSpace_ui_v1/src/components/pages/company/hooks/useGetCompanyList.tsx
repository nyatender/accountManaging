//@ts-nocheck
import { useEffect, useState } from 'react'
import { useCompanyContext } from './useCompanyContext'
import { useNavigate } from "react-router-dom";
import { getAPI } from '../../api/api'
import { Appconstants } from '../../../../constants';
import { useToast } from '../../../atoms/toast/useToast';
import { ICompanyDetails } from '../CompanyPropsTypes';
import { GET_COMPANY, SEARCH_COMPANY } from '../../api/urlConstants';

export function useGetCompanyList() {
  const [rowData, setRowData] = useState<ICompanyDetails[]|null>(null)
  const {
    setIsloading,
    setTotalPages,
    addedCompanyId,
    flagToCallCompanyApi,
    setflagToCallCompanyApi,
    companySearchText,
    startPage,pageSize,
    setStartPage,
    setSelectedPageVal
  } = useCompanyContext()
  const { callToast} = useToast()
  const navigate = useNavigate();
  useEffect(() => {
    if (flagToCallCompanyApi) {
      getCompany(startPage, pageSize)
    }
  }, [addedCompanyId, flagToCallCompanyApi])

  const getCompany = async (startPage: number, pageSize: number) => {
    setflagToCallCompanyApi(false)
    setIsloading(true)
    const result:{totalPages : number , items :[ICompanyDetails]} = await getAPI(GET_COMPANY,{ params: {filter: `page=${startPage}&size=${pageSize}`}})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          callToast("error",Appconstants.company.toast.getCompanyFailureMessage)
        }
        console.error(error)
      })
    setTotalPages(result?.totalPages)
    let Data = result?.items
    let companyData :ICompanyDetails[]= Data && Data.map((item)=>{ 
      const obj = {...item} 
      obj['userCount'] = obj['userEntityList'].length 
      return obj
    })
    setRowData(companyData && companyData.length ? companyData : [])
  }

  const getCompanyDataByName = async () => {
    let dataArray:ICompanyDetails[]=[]
    setIsloading(true)
    const result = await getAPI(SEARCH_COMPANY,{  params: {
      name: companySearchText
    }})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }
        console.error(error)
      })
    if(result){
      dataArray.push(result)
    }
    setRowData(dataArray)
    setStartPage(0)
    setTotalPages(1)
    setSelectedPageVal(0)

  }

  return {
    rowData,
    getCompany,
    getCompanyDataByName
  }
}
