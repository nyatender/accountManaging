import { useCompanyContext } from './useCompanyContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { deleteAPI } from '../../api/api'
import { useToast } from '../../../atoms/toast/useToast';
import { DELETE_COMPANY } from '../../api/urlConstants';
import { ICompanyIdtype} from '../CompanyPropsTypes';


const useDeleteCompany = () => {
  const { setIsloading } = useCompanyContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const deleteCompany = async (companyId: ICompanyIdtype) => {
    setIsloading(true)
    const resultantData = await deleteAPI(DELETE_COMPANY,{data:companyId})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          let message = error.response?.data.message === Appconstants.company.toast.deleteFailureServerMessage 
            ? error.response?.data.message : Appconstants.company.toast.deleteFailureMessage
          callToast("error",message)
        }

        console.error(error)
      })
    return resultantData
  }

  return { deleteCompany }
}

export { useDeleteCompany }
