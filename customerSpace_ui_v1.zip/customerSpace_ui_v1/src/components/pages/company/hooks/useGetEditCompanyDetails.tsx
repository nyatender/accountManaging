import { useCompanyContext } from './useCompanyContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { getAPI } from '../../api/api'
import { useToast } from '../../../atoms/toast/useToast';
import { ICompanyIdtype } from '../CompanyPropsTypes';
import { GET_COMPANY_DETAILS } from '../../api/urlConstants';

const useGetEditCompanyDetails = () => {
  const { setIsloading } =
    useCompanyContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const getCompanyDetailsforEdit = async (companyId:ICompanyIdtype) => {
    setIsloading(true)
    const resultantData = await getAPI(`${GET_COMPANY_DETAILS}${companyId}`,{})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }
        else if(error.response?.status === 500){
          callToast("error",Appconstants.company.toast.getCompanyFailureMessage)
        }

        console.error(error)
      })
    return resultantData
  }

  return { getCompanyDetailsforEdit }
}

export { useGetEditCompanyDetails }