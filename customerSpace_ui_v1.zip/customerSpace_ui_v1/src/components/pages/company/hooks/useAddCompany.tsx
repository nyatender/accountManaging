import { useCompanyContext } from './useCompanyContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { postAPI } from '../../api/api'
import { useToast } from '../../../atoms/toast/useToast';
import { ICompanyData } from '../CompanyPropsTypes';
import { CREATE_COMPANY } from '../../api/urlConstants';

const useAddCompany = () => {
  const { setIsloading, setAddedCompanyId, setflagToCallCompanyApi } =
    useCompanyContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const addCompanyData = async (companyData: ICompanyData) => {
    setIsloading(true)
    const resultantData = await postAPI(CREATE_COMPANY,companyData)
      .then((data) => {
        setIsloading(false)
        setAddedCompanyId(data)
        setflagToCallCompanyApi(true)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }
        else if(error.response?.status === 500){
          let message = (error.response?.data.message === Appconstants.company.toast.serverDuplicateMsg)
            ? Appconstants.company.toast.duplicateCompanyerorMessage : Appconstants.company.toast.addFailureMessage
          callToast("error",message)
        }

        console.error(error)
      })
    return resultantData
  }

  return { addCompanyData }
}

export { useAddCompany }
