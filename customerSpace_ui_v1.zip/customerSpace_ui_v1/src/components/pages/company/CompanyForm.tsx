//@ts-nocheck
import { IAddCompanyProps, ICompanyData } from './CompanyPropsTypes'
import ContentHeader from '../../atoms/contentHeader/ContentHeader'
import './companies.css'
import { useCompanyContext } from './hooks/useCompanyContext'
import { useEffect, useState } from 'react'
import { useAddCompany } from './hooks/useAddCompany'
import { useForm } from 'react-hook-form'
import { useEditCompany } from './hooks/useEditCompany'
import { Appconstants } from '../../../constants'
import { useToast } from '../../atoms/toast/useToast'
import { Button } from '../../atoms/button/Button'

function CompanyForm({ hideAddCompanyPanel , showAddCompanySidePanel}: IAddCompanyProps) {
  const { isEditCompany, selectedEditData ,isAddCompanyPanelOpen } = useCompanyContext()
  const { callToast } = useToast()
  let initialstate = {
    companyName: '',
    generalEmailId: '',
    billingEmailId:'',
    incidentReportingEmailId:'',
    ddxToken:'',
    telephone: '',
    country: '',
    address: '',
    zipCode: '',
    id:0
  }
  const { addCompanyData } = useAddCompany()
  const { editCompanyData } = useEditCompany()
  const [, setValidation] = useState(false)
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm({
    defaultValues: initialstate,
  })

  useEffect(()=>{
    if (isEditCompany) {
      // get data and set form fields
      const fields = [
        'companyName',
        'generalEmailId',
        'billingEmailId',
        'incidentReportingEmailId',
        'ddxToken',
        'telephone',
        'country',
        'address',
        'zipCode',
        'id',
      ]
      fields.forEach((field) => setValue(field, selectedEditData[field]))
    }else{
      reset()
    }
  },[isEditCompany,isAddCompanyPanelOpen,selectedEditData])

  


  const onSubmit = async (data: ICompanyData) => {
    setValidation(true)
    if (isEditCompany) {
      const result = await editCompanyData(data)
      if (result) {
        callToast("success",Appconstants.company.toast.editSuccessMessage)
        hideAddCompanyPanel()
      }
      reset()
    } else {
      const result = await addCompanyData(data)
      if (result) {
        callToast("success",Appconstants.company.toast.addSuccessMessage)
        hideAddCompanyPanel()
      }
      reset()
    }
  }

  const handleOnSavAndaddAnother = async (data: ICompanyData) => {
    setValidation(true)
    const result = await addCompanyData(data)
    if (result) {
      callToast("success",Appconstants.company.toast.addSuccessMessage)
      reset()
      showAddCompanySidePanel()
    }
  }

  return (
    <div>
      <div className='companyFlexContainer'>
        <ContentHeader
          hasBackButton={false}
          title={isEditCompany ? Appconstants.company.label.editCompany : Appconstants.company.label.addCompany}
        />
      </div>
      <div className='companyFormContainer'>
        <form
          className={`row g-3 needs-validation`}
          noValidate
          onSubmit={handleSubmit(onSubmit)}
        >
          <div className='companyFormFields'>
            <div className="fieldgap">
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.name} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                id="validationCustom01"
                data-testid="companyName-input"
                className={` form-control ${errors.companyName ? 'is-invalid' : ''}`}
                {...register('companyName', { required: true, maxLength: 50 })}
                disabled={isEditCompany ? true : false}
              />
              {errors.companyName && errors.companyName.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
            <hr className='colorCode'/>
            <div>
              <ContentHeader
                hasBackButton={false}
                title={Appconstants.company.label.mailInbox}
              />
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.generalEmailId} <span className='requiredField'>*</span>
              </label>
              <input
                type="email"
                data-testid="generalEmailId-input"
                placeholder="emailaddress@company.com"
                className={` form-control ${errors.generalEmailId ? 'is-invalid' : ''}`}
                {...register('generalEmailId', {
                  required: true,
                  maxLength: 50,
                  pattern: {
                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    message: Appconstants.company.validation.enterValidEmail
                  },
                })}
                disabled={isEditCompany ? true : false}
              />
              {errors.generalEmailId &&
              errors.generalEmailId.type === 'maxLength' && (<span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>)}
              {errors.generalEmailId &&
             errors.generalEmailId?.message && (<span role="alert" className="invalid-feedback">{errors.generalEmailId.message}</span>)}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.billingEmailId} <span className='requiredField'>*</span>
              </label>
              <input
                type="email"
                data-testid="billingEmailId-input"
                placeholder="emailaddress@company.com"
                className={` form-control ${errors.billingEmailId ? 'is-invalid' : ''}`}
                {...register('billingEmailId', {
                  required: true,
                  maxLength: 50,
                  pattern: {
                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    message: Appconstants.company.validation.enterValidEmail
                  },
                })}
                disabled={isEditCompany ? true : false}
              />
              {errors.billingEmailId &&
              errors.billingEmailId.type === 'maxLength' && (<span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>)}
              {errors.billingEmailId &&
             errors.billingEmailId?.message && (<span role="alert" className="invalid-feedback">{errors.billingEmailId.message}</span>)}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.incidentReportingEmailId} <span className='requiredField'>*</span>
              </label>
              <input
                type="email"
                placeholder="emailaddress@company.com"
                data-testid="incidentReportingEmailId-input"
                className={` form-control ${errors.incidentReportingEmailId ? 'is-invalid' : ''}`}
                {...register('incidentReportingEmailId', {
                  required: true,
                  maxLength: 50,
                  pattern: {
                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    message: Appconstants.company.validation.enterValidEmail
                  },
                })}
                disabled={isEditCompany ? true : false}
              />
              {errors.incidentReportingEmailId &&
              errors.incidentReportingEmailId.type === 'maxLength' && (<span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>)}
              {errors.incidentReportingEmailId &&
             errors.incidentReportingEmailId?.message && (<span role="alert" className="invalid-feedback">{errors.incidentReportingEmailId.message}</span>)}
            </div>
            <hr className='colorCode'/>
            <div>
              <ContentHeader
                hasBackButton={false}
                title={Appconstants.company.label.mindsphereConfig}
              />
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.ddxToken} <span className='requiredField'>*</span>
              </label>
              
              <textarea
                type="textarea"
                data-testid="ddxToken-input"
                className={` form-control ${errors.ddxToken ? 'is-invalid' : ''}`}
                {...register('ddxToken', { required: true })}
              />
            </div>
            <hr className='colorCode'/>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.telephone} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                data-testid="telephone-input"
                className={` form-control ${errors.telephone ? 'is-invalid' : ''}`}
                {...register('telephone', { required: true, maxLength: 50 })}
              />
              {errors.telephone && errors.telephone.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.country} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                data-testid="country-input"
                className={` form-control ${errors.country ? 'is-invalid' : ''}`}
                {...register('country', { required: true, maxLength: 50 })}
              />
              {errors.country && errors.country.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>

            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.address} <span className='requiredField'>*</span>
              </label>
              <textarea
                type="textarea"
                data-testid="address-input"
                className={` form-control ${errors.address ? 'is-invalid' : ''}`}
                {...register('address', { required: true, maxLength: 500 })}
              />
              {errors.address && errors.address.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.company.label.zipCode} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                data-testid="zipCode-input"
                className={` form-control ${errors.zipCode ? 'is-invalid' : ''}`}
                {...register('zipCode', { required: true, maxLength: 50 })}
              />
              {errors.zipCode && errors.zipCode.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
          </div>
          <div className="addcompany-footer">
            <Button 
              className="m-1"
              buttonText={Appconstants.company.button.saveAndClose}
              variant={"Primary"}
              isOutLined={true}
              type="submit"
              id="button1"
            />  
            {!isEditCompany && (
              <Button 
                className="m-1"
                buttonText={Appconstants.company.button.saveAndAddAnother}
                variant={"Primary"}
                id="button2"
                onClick={handleSubmit(handleOnSavAndaddAnother)}
              />
            )}
          </div>
        </form>
      </div>
    </div>
  )
}

export default CompanyForm
