
import { useUserContext } from './useUserContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { useToast } from '../../../atoms/toast/useToast';
import { postAPI } from '../../api/api';
import { IUserData } from '../UserPropsTypes';
import { CREATE_USER } from '../../api/urlConstants';

const useAddUser = () => {
  const { setIsloading , setflagToCallUserApi} =
  useUserContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const addUserData = async (userData: IUserData) => {
    setIsloading(true)
    const resultantData = await postAPI(CREATE_USER,userData)
      .then((data) => {   
        setIsloading(false)
        setflagToCallUserApi(true)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          let message = error.response?.data.message === 'User Already Exists' ? error.response?.data.message : Appconstants.user.toast.addFailureMessage
          callToast("error",message)
        }

        console.error(error)
      })
    return resultantData
  }

  return { addUserData }
}

export { useAddUser }
