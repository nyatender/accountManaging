import { useNavigate } from "react-router-dom";
import { useUserContext } from "./useUserContext";
import { getAPI } from "../../api/api";
import { GET_COMPANIES_NAME } from "../../api/urlConstants";

function useGetCompanyNameList(){
  const { setIsloading , setCompanyNamesData } = useUserContext()
  const navigate = useNavigate();
  
  const getCompanyIdAndName = async () => {
    setIsloading(true)
    const result = await getAPI(GET_COMPANIES_NAME,{})
      .then((data) => {
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }
        console.error(error)
      })
    
    let Data = result
    setCompanyNamesData(Data) 
  } 

  return { getCompanyIdAndName }
}
  
export { useGetCompanyNameList }








