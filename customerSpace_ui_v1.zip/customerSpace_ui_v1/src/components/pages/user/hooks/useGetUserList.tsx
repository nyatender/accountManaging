//@ts-nocheck
import { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom";
import { useUserContext } from './useUserContext';
import { Appconstants } from '../../../../constants';
import { useToast } from '../../../atoms/toast/useToast';
import { getAPI } from '../../api/api';
import { GET_USERS, SEARCH_USER } from '../../api/urlConstants';

export function useGetUserList() {
  const [rowData, setRowData] = useState([])
  const {
    setIsloading,
    setTotalPages,
    flagToCallUserApi,
    setflagToCallUserApi,
    startPage,pageSize,
    userSearchText
  } = useUserContext()
  const { callToast} = useToast()
  const navigate = useNavigate();
  useEffect(() => {
    if (flagToCallUserApi) {
      getUser(startPage, pageSize)
    }
  }, [flagToCallUserApi])

  const getUser = async (startPage: number, pageSize: number) => {
    setflagToCallUserApi(false)
    setIsloading(true)
    const result = await getAPI(GET_USERS,{ params: {filter: `page=${startPage}&size=${pageSize}`}})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          callToast("error",Appconstants.user.toast.getUserFailureMessage)
        }
        console.error(error)
      })
    setTotalPages(result?.totalPages)
    let Data = result?.items
    setRowData(Data || [])
  }   
  

  const getUserDataByName = async (startPage: number, pageSize: number) => {
    setIsloading(true)

    const result = await getAPI(SEARCH_USER,{  params: {
      name: userSearchText,
      filter: `page=${startPage}&size=${pageSize}`
    }})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response.status === 401){
          navigate("/notAuthorized");
        }
        console.error(error)
      })
    if(result){
      let dataArray=result.items
      setRowData(dataArray)
      setTotalPages(result?.totalPages)
    }
  } 

  return {
    rowData,
    getUser,
    getUserDataByName 
  }

}

