
import { useUserContext } from './useUserContext'
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { useToast } from '../../../atoms/toast/useToast';
import { putAPI } from '../../api/api';
import { IUserData } from '../UserPropsTypes';
import { UPDATE_USER } from '../../api/urlConstants';


const useEditUser = () => {
  const { setIsloading, setflagToCallUserApi } = useUserContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const editUserDetails = async (userData: IUserData) => {
    setIsloading(true)
    const resultantData = await await putAPI(UPDATE_USER,userData)
      .then((data) => {
        setIsloading(false)
        setflagToCallUserApi(true)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          callToast("error",Appconstants.user.toast.editFailureMessage)
        }
        console.error(error)
      })
    return resultantData
  }

  return { editUserDetails }
}

export { useEditUser } 

