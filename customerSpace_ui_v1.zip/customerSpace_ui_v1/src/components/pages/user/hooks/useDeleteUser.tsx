
import { useNavigate } from "react-router-dom";
import { Appconstants } from '../../../../constants'
import { useUserContext } from './useUserContext'
import { useToast } from "../../../atoms/toast/useToast";
import { deleteAPI } from "../../api/api";
import { DELETE_USER } from "../../api/urlConstants";
import { IDeleteData } from "../UserPropsTypes";

const useDeleteUser = () => {
  const { setIsloading } = useUserContext()
  const { callToast } = useToast()
  const navigate = useNavigate();

  const deleteUser = async (userId:IDeleteData ) => {
    setIsloading(true)

    const resultantData = await deleteAPI(DELETE_USER,{data:userId})
      .then((data) => {
        setIsloading(false)
        return data
      })
      .catch((error) => {
        setIsloading(false)
        if( error.response?.status === 401){
          navigate("/notAuthorized");
        }else if(error.response?.status === 500){
          callToast("error",Appconstants.user.toast.deleteFailureMessage)
        
        }

        console.error(error)
      })
    return resultantData
  }

  return { deleteUser }
}

export { useDeleteUser }
