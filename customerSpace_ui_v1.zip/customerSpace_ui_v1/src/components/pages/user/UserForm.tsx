//@ts-nocheck
import { IUserData, IUserProps } from './UserPropsTypes'
import ContentHeader from '../../atoms/contentHeader/ContentHeader'
import { useUserContext } from './hooks/useUserContext'
import { useEffect, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import "./user.css"
import { Appconstants } from '../../../constants'
import Select from '../../atoms/select/Select'
import { useGetCompanyNameList } from './hooks/useGetCompanyNameList'
import { useToast } from '../../atoms/toast/useToast'
import { useAddUser } from './hooks/useAddUser'
import { useEditUser } from './hooks/useEditUser'
import { Button } from '../../atoms/button/Button'

function UserForm({ hideAddUserPanel , showAddUserSidePanel}: IUserProps) {
  const { isEditUser, selectedEditData  , companyNamesData ,setCompanyValue ,companyValue ,isAddUserPanelOpen} = useUserContext()
  const {  getCompanyIdAndName } = useGetCompanyNameList()
  const { callToast } = useToast()
  let initialstate = {
    name: '',
    emailAddress: '',
    phoneNumber: '',
    companyId: '',
  }
  const { addUserData } = useAddUser()
  const { editUserDetails } = useEditUser() 
  const [, setValidation] = useState(false)
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    control
  } = useForm({
    defaultValues: initialstate,
  })

  useEffect(()=>{
    if (isEditUser) {
      // get data and set form fields
      const fields = [
        'name',
        'emailAddress',
        'phoneNumber',
        'companyId',
        'id'
      ]
      fields.forEach((field) => setValue(field, selectedEditData[field]))
      setCompanyValue(selectedEditData['companyId'])
    }else{
      reset()
    }
  },[isEditUser,isAddUserPanelOpen,selectedEditData])

  useEffect(()=>{
    getCompanyIdAndName()
  },[])


  const onSubmit = async (data: IUserData) => {
    setValidation(true)
    if (isEditUser) {
      const result = await editUserDetails(data)
      if (result) {
        callToast("success",Appconstants.user.toast.editSuccessMessage)
        hideAddUserPanel()
      } 
      reset()
    } else {
      const result = await addUserData(data)
      if (result) {
        callToast("success",Appconstants.user.toast.addSuccessMessage)
        hideAddUserPanel()
      }
      reset()
    } 
  }

  const handleOnSavAndaddAnother = async (data: IUserData) => {
    setValidation(true)
    const result = await addUserData(data)
    if (result) {
      callToast("success",Appconstants.user.toast.addSuccessMessage)
      reset()
      setCompanyValue('')
      showAddUserSidePanel()
    } 
  }

  function handleSelect(event:CustomEvent){
    setValue('companyId',event.detail[0])
    setCompanyValue(event.detail[0])
  }

  return (
    <div>
      <div className='userFlexContainer'>
        <ContentHeader
          hasBackButton={false}
          title={isEditUser ? Appconstants.user.label.editUser : Appconstants.user.label.addUser}
        />
      </div>
      <div className='userFormContainer'>
        <form
          className={`row g-3 needs-validation`}
          noValidate
          onSubmit={handleSubmit(onSubmit)}
        >
          <div className='userFormFields'>
            <div className="fieldgap">
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.user.label.name} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                id="validationCustom01"
                data-testid="userName-input"
                className={` form-control ${errors.name ? 'is-invalid' : ''}`}
                {...register('name', { required: true, maxLength: 50 })}
              />
              {errors.name && errors.name.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.user.label.emailAddress} <span className='requiredField'>*</span>
              </label>
              <input
                type="email"
                data-testid="email-input"
                placeholder="example@domain.com"
                className={` form-control ${errors.emailAddress ? 'is-invalid' : ''}`}
                readOnly={isEditUser ? true : false}
                disabled={isEditUser ? true : false}
                {...register('emailAddress', {
                  required: true,
                  maxLength: 50,
                  pattern: {
                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    message: Appconstants.company.validation.enterValidEmail
                  },
                })}
              />
              {errors.emailAddress &&
              errors.emailAddress.type === 'maxLength' && (<span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>)}
              {errors.emailAddress &&
             errors.emailAddress?.message && (<span role="alert" className="invalid-feedback">{errors.emailAddress.message}</span>)}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.user.label.phoneNumber} <span className='requiredField'>*</span>
              </label>
              <input
                type="text"
                data-testid="phoneNumber-input"
                className={` form-control ${errors.phoneNumber ? 'is-invalid' : ''}`}
                {...register('phoneNumber', { required: true, maxLength: 50 })}
              />
              {errors.phoneNumber && errors.phoneNumber.type === 'maxLength' && (
                <span role="alert" className="invalid-feedback">{Appconstants.company.validation.maxLengthExceeded}</span>
              )}
            </div>
            <div className='fieldLevelgap'>
              <label htmlFor="validationCustom01" className="form-label">
                {Appconstants.user.label.company} <span className='requiredField'>*</span>
              </label>
              <div>
                <Controller
                  name="companyId"
                  control={control}
                  render={({ field }) => (
                    <Select 
                      {...field}
                      className='companySelect'
                      options={companyNamesData} 
                      handleSelect={handleSelect} 
                      placeholder={Appconstants.user.placeholder.selectCompany}
                      editable={false}
                      selectedvalue={companyValue} {...register('companyId',{ required: true })}/>
                  )}
                  rules={{ required: true }}
                  
                />
                {errors.companyId && errors.companyId.type === 'required' && <div data-testid="requiredError"className={companyValue ?'hideErrorMsg':'requiredErrorMsg'}>{Appconstants.user.validation.requiredCompany}</div>}
                
              </div>
            </div>
           
          </div>
          <div className="addUser-footer">
            <Button 
              className="m-1"
              buttonText={Appconstants.user.button.saveAndClose}
              variant={"Primary"}
              isOutLined={true}
              type="submit"
              id="button1"
            />
            {!isEditUser && (
              <Button 
                className="m-1"
                buttonText={Appconstants.user.button.saveAndAddAnother}
                variant={"Primary"}
                id="button2"
                onClick={handleSubmit(handleOnSavAndaddAnother)}
              />
            )}
          </div>
        </form>
      </div>

    </div>
  )
}

export default UserForm
