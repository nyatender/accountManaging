import { createContext, useState } from 'react'
import {  IUserContextType, IuserContextMock } from './UserPropsTypes';
import { ConfigurationConstants } from '../../../constants';

let DEFAULT_STATE = {
  isAddUserPanelOpen: false,
  setIsAddUserPanelOpen: () => { },
  isLoading: false,
  setIsloading: () => { },
  userDetails: [],
  setUserDetails: () => { },
  isEditUser: false,
  setIsEditUser: () => { },
  totalPages: 0,
  setTotalPages: () => { },
  selectedEditData: [],
  setSelectedEditData: () => { },
  flagToCallUserApi: true,
  setflagToCallUserApi: () => { },
  userSearchText: '',
  setUserSearchText: () => { },
  startPage:0,
  setStartPage:()=>{},
  pageSize:ConfigurationConstants.number_of_record_per_page,
  setPageSize:()=>{},
  selectedPageVal:0,
  setSelectedPageVal:()=>{},
  companyNamesData:[],
  setCompanyNamesData:()=>{},
  isLoadingFlag:false,
  setIsloadingFlag:()=>{},
  companyValue:"",
  setCompanyValue:()=>{}
} as IUserContextType

export const UserContext = createContext<IUserContextType>(DEFAULT_STATE)

interface Props {
  children: React.ReactNode,
  mockData?:IuserContextMock
}

function UserContextProvider({ children , mockData }:Props) {
  DEFAULT_STATE = { ...DEFAULT_STATE, ...mockData };
  const [isAddUserPanelOpen, setIsAddUserPanelOpen] =
    useState<boolean>(DEFAULT_STATE.isAddUserPanelOpen)
  const [isLoading, setIsloading] = useState<boolean>(DEFAULT_STATE.isLoading)
  const [userDetails, setUserDetails] = useState(DEFAULT_STATE.userDetails)
  const [isEditUser, setIsEditUser] = useState<boolean>(DEFAULT_STATE.isEditUser)
  const [totalPages, setTotalPages] = useState(DEFAULT_STATE.totalPages)
  const [selectedEditData, setSelectedEditData] = useState(DEFAULT_STATE.selectedEditData)
  const [startPage, setStartPage] = useState(DEFAULT_STATE.startPage)
  const [selectedPageVal, setSelectedPageVal] = useState(DEFAULT_STATE.selectedPageVal)
  const [pageSize, setPageSize] = useState(DEFAULT_STATE.pageSize)
  
  const [flagToCallUserApi, setflagToCallUserApi] =
    useState<boolean>(DEFAULT_STATE.flagToCallUserApi)
  const [userSearchText, setUserSearchText] = useState(DEFAULT_STATE.userSearchText)
  const [companyNamesData, setCompanyNamesData] = useState(DEFAULT_STATE.companyNamesData)
  const [isLoadingFlag, setIsloadingFlag] = useState<boolean>(DEFAULT_STATE.isLoadingFlag)
  const [companyValue, setCompanyValue] = useState(DEFAULT_STATE.companyValue)
  return (
    <UserContext.Provider
      value={{
        isAddUserPanelOpen,
        setIsAddUserPanelOpen,
        isLoading,
        setIsloading,
        userDetails,
        setUserDetails,
        isEditUser,
        setIsEditUser,
        totalPages,
        setTotalPages,
        selectedEditData,
        setSelectedEditData,
        flagToCallUserApi,
        setflagToCallUserApi,
        userSearchText,
        setUserSearchText,
        startPage,
        setStartPage,
        pageSize,
        setPageSize,
        selectedPageVal,
        setSelectedPageVal,
        companyNamesData,
        setCompanyNamesData,
        isLoadingFlag,
        setIsloadingFlag,
        companyValue,
        setCompanyValue,
        


      }}
    >
      {children}
    </UserContext.Provider>
  )
}

export default UserContextProvider
