//@ts-nocheck
import React, { useEffect, useState } from 'react'
import './user.css'
import ContentHeader from '../../atoms/contentHeader/ContentHeader'
import Search from '../../atoms/search/Search'
import {
  IxDropdownButton,
  IxDropdownItem,
  IxPagination,
  showModal
} from '@siemens/ix-react'
import { useUserContext } from './hooks/useUserContext'
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-alpine.css'
import '@siemens/ix-aggrid/dist/ix-aggrid/ix-aggrid.css'
import Spinner from '../../atoms/spinner/Spinner'
import CustomModal from '../../atoms/customModal/CustomModal'
import { Appconstants } from '../../../constants'
import { Drawer } from '../../atoms/drawer/Drawer';
import { useGetUserList } from './hooks/useGetUserList'
import UserForm from './UserForm'
import { useDeleteUser } from './hooks/useDeleteUser'
import { useToast } from '../../atoms/toast/useToast'
import { ICellRendererParams } from 'ag-grid-community'
import { Button } from '../../atoms/button/Button'

function Users(): React.ReactElement {
  const {
    isAddUserPanelOpen,
    setIsAddUserPanelOpen,
    isLoading,
    isEditUser,
    setIsEditUser,
    totalPages,
    setSelectedEditData,
    startPage,
    setPageSize,
    pageSize,
    setStartPage,
    selectedPageVal,
    setSelectedPageVal,
    setUserSearchText,
    userSearchText,
    setflagToCallUserApi,
    setCompanyValue,
  } = useUserContext()
  const { callToast } = useToast()
  const { rowData, getUser  , getUserDataByName } = useGetUserList()
  const [, setSelectedRow] = useState({})
  const { deleteUser } = useDeleteUser()
  let selectedRowData = {} 

  useEffect(() => {
    if(userSearchText){
      getUserDataByName(startPage,pageSize)
    }

  }, [userSearchText]);

  function showAddUserSidePanel() {
    isEditUser && setIsEditUser(false)
    setIsAddUserPanelOpen(true)     
  } 

  function hideAddUserPanel() {
    isEditUser && setIsEditUser(false)
    setCompanyValue("")
    setIsAddUserPanelOpen(false)
  } 

  function handleAction(rowData: ICellRendererParams) {
    selectedRowData = rowData?.data
    setSelectedRow(rowData?.data)
  }

  const gridOptions= {
    columnDefs: [
      {
        colId: 'col1',
        field: 'name',
        headerName: 'Name',
        flex: 2,
      },
      {
        colId: 'col2',
        field: 'emailAddress',
        headerName: 'Email address',
        flex: 2,
      },
      { colId: 'col3', field: 'phoneNumber', headerName: 'Phone Number', flex: 1 },
      { colId: 'col4', field: 'companyName', headerName: 'Company', flex: 1 },
      {
        colId: 'col5',

        cellRenderer: (params: ICellRendererParams) => (
          <div>
            <IxDropdownButton
              variant="Secondary"
              ghost
              icon="context-menu"
              onClick={()=>handleAction(params)}
            >
              <IxDropdownItem
                label={Appconstants.user.button.edit}
                icon="pen-filled"
                onItemClick={(e) => {
                  e.stopPropagation()
                  setSelectedEditData(params.data)
                  setIsEditUser(true)
                  setIsAddUserPanelOpen(true)
                }}
              ></IxDropdownItem>
              <IxDropdownItem
                label={Appconstants.user.button.delete}
                icon="trashcan-filled"
                onItemClick={show}
              ></IxDropdownItem>
            </IxDropdownButton>
          </div>
        ),
        flex: 3,
        cellStyle: {
          display: 'flex',
          justifyContent: 'end',
        },
        cellClass: (params) => {
          if((params.node.rowIndex === 0) || (params.node.rowIndex === 1)){
            return null; 
          }
          else if((params.node.rowIndex === params.api.getDisplayedRowCount() - 1) || (params.node.rowIndex === params.api.getDisplayedRowCount() - 2)){
            return 'last-row-last-column'; 
          }else{
            return null;
          }

        },
        
      },
    ],
    suppressCellFocus: true,
  }

  function handlePageChange(e: CustomEvent) {
    let nextPage = e.detail
    let selectedPageValue = e.detail
    setSelectedPageVal(selectedPageValue)
    setStartPage(nextPage)
    if(userSearchText){
      getUserDataByName(nextPage,pageSize)
    }else{
      getUser(nextPage, pageSize)
    }

  }

  function handleItemChange(e: CustomEvent) {
    let pageSizeVal = e.detail
    setPageSize(pageSizeVal)
    getUser(startPage, pageSizeVal)
  }

  async function handleDelete() {
    setIsAddUserPanelOpen(false)
    let dataobj = {
      id: selectedRowData?.id,
    }
    let result = await deleteUser(dataobj)
    if (result) {
      callToast("success",Appconstants.user.toast.deleteSuccessMessage)
      getUser(startPage, pageSize)
    } 
  }

  async function show(): Promise<void> {
    await showModal({
      title: 'test',
      content: (
        <CustomModal
          logout={handleDelete}
          headerText={Appconstants.user.modal.delete.title}
          bodyText={Appconstants.user.modal.delete.bodyContent}
        />
      ),
      centered: true,
      icon: 'about',
      size: 'sm',
    })
  }

  return (
    <div className="users-container">
      <div className={
        (isAddUserPanelOpen )? ' halfSizeContainer mainSection' : 'fullWidthContainer mainSection'
      }>
        <div>
          <ContentHeader hasBackButton={false} title={Appconstants.user.label.users} />
        </div>
        <div
          className="userPageContainer">
          <div
            className='gridContainer'
          >
            <div className="searchContainer">
              <div className="searchInput">
                <Search placeholder={Appconstants.user.placeholder.searchUsers} 
                  setSearchText={setUserSearchText}
                  callApi={setflagToCallUserApi}
                  setStartPage={setStartPage}
                  setSelectedPageVal={setSelectedPageVal}
                />
              </div>
              {!isAddUserPanelOpen && (
                <Button  variant="Primary"
                  isOutLined={false}
                  onClick={showAddUserSidePanel}
                  buttonText={Appconstants.user.button.addUser}/>
              )}
            </div>
            {     isLoading ? (
              <div className='userLoader' data-testid="loader">
                {' '}
                <Spinner />
              </div>
            ):(
              <div>
                <div className="ag-theme-alpine-dark ag-theme-ix userTableGrid" data-testid="ag-grid">
                  <AgGridReact
                    gridOptions={gridOptions}
                    rowData={rowData}
                    overlayNoRowsTemplate={Appconstants.user.noData}
                  />
                </div>
                <div className='paginationBorder'>
                  <IxPagination
                    data-testid="pagination"
                    advanced
                    showItemCount
                    itemCount={pageSize}
                    count={totalPages}
                    i18nItems="Rows per page"
                    onItemCountChanged={(e) => handleItemChange(e)}
                    onPageSelected={(e) => handlePageChange(e)}
                    selectedPage={selectedPageVal}
                    className='userGridPagination'
                  ></IxPagination>
                </div>
              </div>)}
          </div>
        </div>
      </div>
      <Drawer
        show={isAddUserPanelOpen}
        setShow={hideAddUserPanel}
        children={UserForm({hideAddUserPanel ,showAddUserSidePanel})}   
        drawerWidth={25}
      />  
    </div>
    
  )
}

export { Users }


