declare type hideAddCompanyPanel = () => void
export interface IUser {
  name: string
  emailAddress: string
  phoneNumber: number
  companyName: string
  companyId: string
}
export interface IUserContextType {
  isAddUserPanelOpen: boolean
  isLoading: boolean
  userDetails: IUser[{ Name; Email; PhoneNumber; CompanyName }]
  isEditUser: boolean
  totalPages: number
  flagToCallUserApi: boolean
  userSearchText: string
  startPage: number
  pageSize: number
  selectedPageVal: number
  selectedEditData: IUser[{
    name
    emailAddress
    phoneNumber
    companyName
    companyId
    id
  }]
  companyNamesData: [number, string][]
  isLoadingFlag: boolean
  companyValue: string
  setIsAddUserPanelOpen: React.Dispatch<React.SetStateAction<boolean>>
  setIsloading: React.Dispatch<React.SetStateAction<boolean>>
  setUserDetails: React.Dispatch<React.SetStateAction<>>
  setIsEditUser: React.Dispatch<React.SetStateAction<boolean>>
  setTotalPages: React.Dispatch<React.SetStateAction<>>
  setSelectedEditData: React.Dispatch<React.SetStateAction<>>
  setflagToCallUserApi: React.Dispatch<React.SetStateAction<boolean>>
  setUserSearchText: React.Dispatch<React.SetStateAction<>>
  setPageSize: React.Dispatch<React.SetStateAction<>>
  setStartPage: React.Dispatch<React.SetStateAction<>>
  setSelectedPageVal: React.Dispatch<React.SetStateAction<>>
  setCompanyNamesData: React.Dispatch<React.SetStateAction<>>
  setIsloadingFlag: React.Dispatch<React.SetStateAction<boolean>>
  setCompanyValue: React.Dispatch<React.SetStateAction<>>
}

export interface IUserProps {
  hideAddUserPanel: () => void
  showAddUserSidePanel: () => void
}

export interface ICompanyData {
  id: number
  companyName: string
}

export interface IUserData {
  name: string
  emailAddress: string
  phoneNumber: string
  companyId: string
}

export interface IuserContextMock {
  isEditUser: boolean
  selectedEditData: IUser[{
    name
    emailAddress
    phoneNumber
    companyName
    companyId
    id
  }]
  setCompanyValue: React.Dispatch<React.SetStateAction<>>
  companyValue: string
  isAddUserPanelOpen: boolean
  isLoading: boolean
}

export interface IUserDataTypes {
  creationDate: string
  updatedDate: string
  createdBy: string
  updatedBy: string
  id: number
  name: string
  emailAddress: string
  phoneNumber: string
  companyId: number
}

export interface IgetuserApiResultType {
  hasNext: number
  hasPrevious: number
  items: IUserDataTypes[]
  page: number
  pageSize: number
  totalElements: number
  totalPages: number
}

export interface IDeleteData {
  Id: number
}
