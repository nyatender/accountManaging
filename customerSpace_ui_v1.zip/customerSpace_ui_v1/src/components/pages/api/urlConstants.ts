const CHECK_VALID_USER = `getPlatformUserByEmailAddress`;
const GET_COMPANY = `company`;
const CREATE_COMPANY = `company/addCompany`;
const GET_COMPANY_DETAILS=`company/`
const UPDATE_COMPANY = `company`;
const DELETE_COMPANY = `company`;
const SEARCH_COMPANY = `company/getByName`;
const GET_USERS = `user`;
const CREATE_USER = `user/addUser`;
const UPDATE_USER = `user`;
const DELETE_USER = `user`;
const SEARCH_USER = `user/getByName`;
const GET_COMPANIES_NAME=`company/getCompanyIdAndName`


export {
  GET_COMPANY,
  CREATE_COMPANY,
  UPDATE_COMPANY,
  DELETE_COMPANY,
  SEARCH_COMPANY,
  CREATE_USER, 
  GET_USERS, 
  CHECK_VALID_USER,
  SEARCH_USER,
  UPDATE_USER,DELETE_USER ,
  GET_COMPANIES_NAME,
  GET_COMPANY_DETAILS
}