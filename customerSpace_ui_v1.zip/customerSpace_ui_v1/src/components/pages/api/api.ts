import axios, { AxiosResponse } from 'axios';
import { authProvider } from '../../../authConfig';

const defaultOptions = {
  baseURL: 'http://localhost:8081/api/v1/',
  headers: {
    'Content-Type': 'application/json',
  },
};

const getAuthToken = async () => {
  const accessTokenRequest = {
    scopes: [process.env.REACT_APP_SCOPES ?? ''],
  } 
  try {
    const authToken = await authProvider.acquireTokenSilent(accessTokenRequest)
    // Call your API with this token
    return authToken
  } catch (error) {
          
    console.log(error)
  }
}

const instance = axios.create(defaultOptions);

instance.interceptors.request.use(async function (config) {
  const token = await getAuthToken()
  config.headers.Authorization =  token ? `Bearer ${token.accessToken}` : '';
  return config;
});

const responseBody = (response: AxiosResponse) => response.data;

const requests = {
  get: (url: string , params:{} ) => instance.get(url,params).then(responseBody),
  post: (url: string, body: {}) => instance.post(url, body).then(responseBody),
  put: (url: string, body: {}) => instance.put(url, body).then(responseBody),
  delete: (url: string ,params:{}) => instance.delete(url,params).then(responseBody),
};

async function getAPI<T>(url: string, params:{}): Promise<Awaited<T>> {
  return await requests.get(url,params)
}

async function postAPI<T>(url: string, body:{}):Promise<Awaited<T>> {
  return await requests.post(url,body)
}

async function putAPI<T>(url: string, body:{}):Promise<Awaited<T>>  {
  return await requests.put(url,body)
}

async function deleteAPI<T>(url: string ,params:{}):Promise<Awaited<T>> {
  return await requests.delete(url,params)
}

export { getAPI, postAPI, putAPI, deleteAPI }

