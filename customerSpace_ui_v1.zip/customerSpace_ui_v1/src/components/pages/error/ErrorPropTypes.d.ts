export interface ErrorPropTypes {
  errorMessage?: string
}
  