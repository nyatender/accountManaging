import { Appconstants } from '../../../constants';
import './notAuthorized.css'

const NotAuthorized = () => {
  return (
    <div className='notAuhtorizedContainer' data-testid="notAuthorized"> <h3>{Appconstants.errorPageText}</h3>
    </div>)

};

export default NotAuthorized;