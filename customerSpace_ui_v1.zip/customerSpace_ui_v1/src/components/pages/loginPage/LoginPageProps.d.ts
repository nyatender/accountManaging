
declare type LoginFunction = () => void
export interface ILoginPageProps {
  login: LoginFunction
}