import React from 'react'
import './loginPage.css'
import { ReactComponent as SiemensLogo } from '../../assets/Seimenslogo.svg'
import { IxIcon, IxTile, IxButton } from '@siemens/ix-react'
import { ReactComponent as Group } from '../../assets/Group.svg'
import { ILoginPageProps } from "./LoginPageProps"
import { Appconstants } from '../../../constants'


function LoginPage({ login }: ILoginPageProps): React.ReactElement {
  return (
    <div className="LoginPage">
      <div className="HeaderBar">
        <div className="DDXContainer headerContent">
          <div className="LogoContainer">
            <SiemensLogo className="" />
          </div>
          <div className="Language">
            <div className="languageSelection">
              <div className="colorCode">{Appconstants.login.label.english}</div>
              <div>
                <IxIcon name="chevron-down-small" size="24"></IxIcon>
              </div>
              <div>
                <IxIcon name="question" size="24"></IxIcon>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="middleContent">
        <div className="DDXContainer groupItems">
          <div>
            <Group className="ddxImage" />
          </div>
          <div>
            <IxTile className="contentTile">
              <div
                className="d-flex flex-grow-1 align-items-center justify-content-between tileHeader"
                slot="header"
              >
                {Appconstants.login.label.siemensAg}
              </div>
              <div slot="subheader" className="textLabel">
                {Appconstants.login.label.welocme}
              </div>
              <div className="textContent">
                <span className="">
                  {Appconstants.login.label.textContent}
                </span>
              </div>
              <div>
                <IxButton
                  className="loginButton"
                  variant="Primary"
                  outline={false}
                  onClick={login}
                >
                  {Appconstants.login.button.login}
                </IxButton>
              </div>
            </IxTile>
          </div>
        </div>
      </div>
      <div className="footer">
        <div className="DDXContainer footerLayout">
          <div className="footerText">
            <div className="footerLabel">{Appconstants.login.label.website}</div>
            <div className="colorCode">{Appconstants.login.label.support}</div>
          </div>
          <div className="footerText2">
            <div className="colorCode">{Appconstants.login.label.version}</div>
            <div className="colorCode">{Appconstants.login.label.siemensFooter}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
