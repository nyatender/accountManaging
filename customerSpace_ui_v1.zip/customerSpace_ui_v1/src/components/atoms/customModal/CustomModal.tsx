import React, { useRef } from 'react'
import { IxButton, IxIconButton, Modal, ModalRef } from '@siemens/ix-react'
import { ICustomModalTypes } from './CustomModalPropTypes'
import { Appconstants } from '../../../constants'
import "./customModal.css"

function CustomModal({ logout, headerText, bodyText }: ICustomModalTypes) {
  const modalRef = useRef<ModalRef>(null)

  const dismiss = () => {
    modalRef.current?.dismiss('dismiss payload')
  }

  function handleClose(){
    logout()
    dismiss()
  }

  return (
    <Modal ref={modalRef}>
      <div className="modal-header">
        {headerText}
        <IxIconButton
          data-testid="closeIcon"
          data-button-close
          ghost
          icon="close"
          onClick={() => dismiss()}
        ></IxIconButton>
      </div>
      <div className="modal-body" data-testid="ModalPopup">{bodyText}</div>
      <div className="modal-footer modalFooterContent">
        <IxButton data-testid="cancelButton" outline onClick={() => dismiss()}>
          {Appconstants.company.button.cancel}
        </IxButton>
        <IxButton data-testid="confirmButton" onClick={handleClose}>{Appconstants.company.button.ok}</IxButton>
      </div>
    </Modal>
  )
}

export default CustomModal
