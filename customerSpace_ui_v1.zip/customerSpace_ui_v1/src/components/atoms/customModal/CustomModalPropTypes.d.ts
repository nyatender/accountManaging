import { IAppProps } from "../../../App";

export interface ICustomModalTypes extends IAppProps {
  headerText: string
  bodyText:string
}