import { IxSpinner } from '@siemens/ix-react'

function Spinner() {
  return <IxSpinner  data-testid="spinner" size="large"></IxSpinner>
}

export default Spinner
