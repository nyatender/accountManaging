export interface ISelectPropTypes {
  options: [number,string][]
  handleSelect: (event: IxSelectCustomEvent<string | string[]>) => void
  selectedvalue:String
  className?:string
  placeholder?:string
  editable?:boolean
  disabled?:boolean
}

