import { IxSelect, IxSelectItem} from "@siemens/ix-react";
import { ISelectPropTypes } from "./Select.Propstypes";
import './select.css'

function Select({ className , options , handleSelect , selectedvalue ,placeholder ,editable ,disabled }:ISelectPropTypes){
  return(
    <div className="selectContainer">
      <IxSelect className={className} selectedIndices={selectedvalue.toString()} 
        hideListHeader={true} onItemSelectionChange={(event)=>handleSelect(event)} 
        editable={editable}
        i18nPlaceholder={placeholder}
        disabled={disabled}
        data-testid="custom-select"
      >
        {
          (options && options.length !== 0) && options.map((item:[number,string] , index:number)=>(
            <IxSelectItem  data-testid="ixSelectItem" key = {index} label={item[1]} value={item[0].toString()}></IxSelectItem>
          ))
        }  
      </IxSelect>
    </div>
  )
}

export default Select