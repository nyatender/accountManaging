import React from 'react'
import { IxDrawer } from '@siemens/ix-react'
import { IDrawerPropTypes } from './DrawerPropTypes'

function Drawer({
  show = false,
  setShow,
  className,
  children,
  drawerWidth,
}: IDrawerPropTypes) {
  return (
    <IxDrawer
      closeOnClickOutside={false}
      show={show}
      onDrawerClose={setShow}
      className={className}
      width={drawerWidth}
      fullHeight={true}
      data-testid="drawer-component"
    >
      {children}
    </IxDrawer>
  )
}

export { Drawer }
