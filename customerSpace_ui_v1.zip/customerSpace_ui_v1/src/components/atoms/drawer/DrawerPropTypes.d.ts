import { ReactElement } from 'react'

export interface IDrawerPropTypes {
  show: boolean
  setShow: () => void
  className?: string
  data?: object[]
  children: ReactElement
  drawerWidth?: number
}
