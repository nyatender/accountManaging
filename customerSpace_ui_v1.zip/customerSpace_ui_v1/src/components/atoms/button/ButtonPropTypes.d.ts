export interface IButtonPropTypes {
  buttonText: string
  className?:string
  variant: 'Primary' | 'Secondary'
  isDisabled?: boolean
  isGhost?: boolean
  isOutLined?: boolean
  onClick?: () => void
  type?: 'button' | 'submit';
  id?:string
}
  