import React from 'react'
import { IxButton } from '@siemens/ix-react'
import { IButtonPropTypes } from './ButtonPropTypes'

const Button = ({
  buttonText,
  className,
  variant = 'Primary',
  isDisabled = false,
  isGhost = false,
  isOutLined = false,
  type,
  onClick,
  id
}: IButtonPropTypes) => (
  <IxButton
    disabled={isDisabled}
    ghost={isGhost}
    variant={variant}
    outline={isOutLined}
    onClick={onClick}
    data-testid="button"
    type={type}
    className={className}
    id={id}
  >
    {buttonText}
  </IxButton>
)

export { Button }