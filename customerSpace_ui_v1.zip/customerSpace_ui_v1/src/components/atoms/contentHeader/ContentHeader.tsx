import { IxContentHeader } from '@siemens/ix-react';
import React from 'react';
import { IContentHeaderTypes } from './ContentHeaderPropTypes';

function ContentHeader({hasBackButton,title}:IContentHeaderTypes){
  return (
    <IxContentHeader
      has-back-button={hasBackButton}
      header-title={title}
      data-testid="contentHeader"
    >
    </IxContentHeader>
  );
}

export default ContentHeader