export interface IContentHeaderTypes {
  hasBackButton: boolean
  title: string
}