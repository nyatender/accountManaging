import { IxKeyValue } from '@siemens/ix-react'
import { IKeyValPropTypes } from './KeyValPropTypes'

function KeyValue({ label, value, className }: IKeyValPropTypes) {
  return (
    <IxKeyValue label={label} value={value} className={className} data-testid="keyValPairs"></IxKeyValue>
  )
}

export { KeyValue }