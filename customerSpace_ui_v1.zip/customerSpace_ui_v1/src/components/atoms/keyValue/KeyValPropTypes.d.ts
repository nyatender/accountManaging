export interface IKeyValPropTypes {
  label: string
  value: string
  className?: string
}
  