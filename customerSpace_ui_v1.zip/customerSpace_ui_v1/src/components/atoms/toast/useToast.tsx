import { useEffect } from 'react'

import { setToastPosition } from '@siemens/ix'
import { showToast } from '@siemens/ix-react'
import { ToastType } from './ToastPropsTypes'

function useToast() {
  useEffect(() => {
    setToastPosition('top-right')
  }, [])

  const callToast = (type:ToastType, message:string) => showToast({ type , message })

  return { callToast }
}
export { useToast }