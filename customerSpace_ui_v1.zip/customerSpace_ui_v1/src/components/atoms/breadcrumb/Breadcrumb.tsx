import { IxBreadcrumb, IxBreadcrumbItem } from '@siemens/ix-react';
import { IBreadcrumItemTypes } from './BreadcrumbPropTypes';
import './breadcrumb.css'

function Breadcrumb({icon,label}:IBreadcrumItemTypes){
  return (
    <IxBreadcrumb ghost={true} className='breadCrumbComponent' data-testid="breadcrumb">
      <IxBreadcrumbItem label={label} icon={icon}></IxBreadcrumbItem>
    </IxBreadcrumb>
  );
}

export default Breadcrumb