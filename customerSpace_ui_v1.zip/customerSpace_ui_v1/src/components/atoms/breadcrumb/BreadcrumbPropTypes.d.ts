export interface IBreadcrumItemTypes {
  icon: string
  label: string
}