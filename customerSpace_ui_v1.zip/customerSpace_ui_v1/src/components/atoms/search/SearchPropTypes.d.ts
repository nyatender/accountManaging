export interface ISearchTypes {
  placeholder: string,
  setSearchText:React.Dispatch<React.SetStateAction<>>;
  callApi:React.Dispatch<React.SetStateAction<>>;
  setStartPage?:React.Dispatch<React.SetStateAction<>>;
  setSelectedPageVal?:React.Dispatch<React.SetStateAction<>>
}