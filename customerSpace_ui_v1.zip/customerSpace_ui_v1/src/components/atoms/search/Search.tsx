import { IxIconButton, IxInputGroup } from '@siemens/ix-react'
import React, { useEffect, useState } from 'react'
import { ISearchTypes } from './SearchPropTypes'
import useDebounce from '../../hooks/useDebounce'
import { ConfigurationConstants } from '../../../constants'


function Search({ placeholder , setSearchText , callApi , setStartPage ,setSelectedPageVal}: ISearchTypes) {
  const [searchTerm, setSearchTerm] = useState('')

  function reset() {
    setSearchTerm('')
    setSearchText('')
    setStartPage && setStartPage(0)
    setSelectedPageVal && setSelectedPageVal(0)
    callApi(true)
    
  }

  const debouncedSearchTerm = useDebounce(searchTerm, ConfigurationConstants.debounce_delay_for_search);

  useEffect(
    () => {
      if (debouncedSearchTerm) {
        setSearchText(debouncedSearchTerm);
      }
    },
    [debouncedSearchTerm], // Only call effect if debounced search term changes
  ); 

  let display = searchTerm === '' ? 'none' : 'block'

  const handleChange = (event: {
    target: { value: React.SetStateAction<string> }
  }) => {
    setSearchTerm(event.target.value)
    setStartPage && setStartPage(0)
    setSelectedPageVal && setSelectedPageVal(0)
    if(event.target.value === ""){
      callApi(true)
    }
  }

  return (
    <form className="needs-validation" >
      <IxInputGroup>
        <input
          id="input-string"
          type="string"
          className="form-control"
          onChange={handleChange}
          value={searchTerm}
          placeholder={placeholder}
          data-testid="custom-search"
        />
        <span slot="input-end">
          <IxIconButton
            onClick={reset}
            id="clear-button"
            icon="clear"
            ghost
            size="16"
            style={{ display: display }}
          ></IxIconButton>
        </span>
      </IxInputGroup>
    </form>
  )
}

export default Search
