import { style } from '@vanilla-extract/css'

export const NavigationSidebarStyles = style([
  {
    position: 'fixed',
    top: '45px',
  },
])
