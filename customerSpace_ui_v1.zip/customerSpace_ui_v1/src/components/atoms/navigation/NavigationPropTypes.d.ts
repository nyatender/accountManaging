import { MouseEventHandler, ReactElement } from 'react'

export interface IMenuItemTypes {
  id: number
  icon: string
  name: string
  slot?: string
  disabled?: boolean = false
  onClick?: MouseEventHandler<HTMLIxMenuItemElement>
}
export interface INavigationPropTypes {
  logo?: ReactElement
  menuItems?: IMenuItemTypes[]
  hideHeader?: boolean = false
  applicationName?: string = 'Application Name'
  className?:string
  /*  children: React.ReactElement */
}
