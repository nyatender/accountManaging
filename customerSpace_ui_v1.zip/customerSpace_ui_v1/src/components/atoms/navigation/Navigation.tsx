import React from 'react'
import { IxBasicNavigation, IxMenu, IxMenuItem } from '@siemens/ix-react'
import { INavigationPropTypes } from './NavigationPropTypes'
import {
  NavigationSidebarStyles,
} from './NavigationStyles.css'
import './NavStyles.css'

/**
 *
 * @param param0
 * @returns Navigation pane and Header
 */
const Navigation = ({
  logo,
  menuItems,
  hideHeader,
  applicationName,
  className
}: INavigationPropTypes): React.ReactElement => {
  return (
    <IxBasicNavigation
      applicationName={applicationName}
      hideHeader={hideHeader}
      className={className}
    >
      {!!logo && (
        <div className="placeholder-logo" slot="logo">
          {logo}
        </div>
      )}
      <IxMenu className={NavigationSidebarStyles}>
        {!!menuItems?.length &&
          menuItems
            .sort((a, b) => a.id - b.id)
            .map((item) => (
              <IxMenuItem
                key={item.id}
                tab-icon={item.icon}
                disabled={item.disabled}
                onClick={item.onClick}
                slot={item.slot ?? ''}
              >
                {item.name}
              </IxMenuItem>
            ))}
      </IxMenu>
    </IxBasicNavigation>
  )
}

export { Navigation }
