import { getAPI } from '../pages/api/api'
import { CHECK_VALID_USER } from '../pages/api/urlConstants'
import { useEffect, useState } from 'react'

const useCheckEmail = () => {
  const [isLoading, setLoading] = useState<boolean>(true)
  const [isUserExist, setUserExist] = useState<boolean>(false)
  const [error, setError] = useState<null | Error>(null)

  useEffect(() => {
    checkEmail()
  }, [])

  const checkEmail = async () => {
    try {
      const resultantData: boolean = await getAPI(CHECK_VALID_USER, {})
      setUserExist(resultantData)
    } catch (err) {
      setError(() => new Error('error'))
    } finally {
      setLoading(false)
    }
  }

  return { isUserExist, isLoading, error }
}

export { useCheckEmail }
