export const Font = {
  "x-large": "text-xl",
  large: "text-l",
  medium: "text-default",
  small: "text-s",
  "x-small": "text-xs",
};
