import { ICompanyDetailsTypes } from "../pages/company/CompanyPropsTypes"

const companyDataMapping:ICompanyDetailsTypes ={
  companyName: "Company Name",
  generalEmailId: "General",
  billingEmailId:"Payment-report & Billing",
  incidentReportingEmailId:"Incident reporting",
  ddxToken:"DDX Token",
  telephone: "Telephone",
  country: "Country",
  userCount:"Users",
  address:  "Address",
  zipCode: "Zip Code",
  creationDate:"Date Created"

}

export const companydetailsKeys = [
  'companyName',
  'generalEmailId',
  'billingEmailId',
  'incidentReportingEmailId',
  'ddxToken',
  'telephone',
  'country',
  'userCount',
  'address',
  'zipCode',
  'creationDate',
]

export const companyDetailsKeyMappings = [
  {
    headerKeys: companydetailsKeys,
    headerTitle: '',
  }
]
export {companyDataMapping}