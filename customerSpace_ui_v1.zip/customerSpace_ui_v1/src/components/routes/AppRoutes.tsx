import React from 'react'
import { Route, Routes } from 'react-router-dom'
import { Home } from '../pages/home'
import { IAppProps } from '../../App'
import { Companies } from '../pages/company'
import CompanyContextProvider from '../pages/company/CompanyContext'
import NotAuthorized from '../pages/not-authorized/NotAuthorized'
import { Users } from '../pages/user/Users'
import UserContextProvider from '../pages/user/UserContext'

function AppRoutes({ logout }: IAppProps): React.ReactElement {
  return (
    <Routes>
      <Route path="/" element={<Home logout={logout} />}>
        <Route index element={
          <CompanyContextProvider>
            <Companies />
          </CompanyContextProvider>
        }
        />
        <Route
          path="users"
          element={
            <UserContextProvider>
              <Users />
            </UserContextProvider>
          }
        />
        <Route path="/notAuthorized" element={<NotAuthorized />} />
      </Route>
   
    </Routes>
  )
}

export default AppRoutes
