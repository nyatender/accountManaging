//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../components/pages/api/api';
import { useCheckEmail } from '../../../components/hooks/useCheckEmail';
import { CHECK_VALID_USER } from '../../../components/pages/api/urlConstants';


jest.mock('../../../components/pages/api/api');


describe('useCheckEmail', () => {
  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    
  });

  it('should call check email api successfully', async () => {

    jest.spyOn(api, 'getAPI').mockResolvedValue(true);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useCheckEmail(), { wrapper });
    // Ensure that the useEffect is called
    expect(api.getAPI).toHaveBeenCalledWith(CHECK_VALID_USER, {});

    // Wait for the hook's state to update
    await act(async () => {
      await Promise.resolve();
    });

    expect(result.current.isLoading).toBe(false);
    expect(result.current.isUserExist).toBe(true);
    expect(result.current.error).toBe(null);
 
  });

  it('should handle check email api error', async () => {

    jest.spyOn(api, 'getAPI').mockRejectedValue(new Error('API Error'));
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useCheckEmail(), { wrapper });
  
    expect(api.getAPI).toHaveBeenCalledWith(CHECK_VALID_USER, {});

    // Wait for the hook's state to update
    await act(async () => {
      await Promise.resolve();
    });
    expect(result.current.isLoading).toBe(false);
    expect(result.current.isUserExist).toBe(false);
    expect(result.current.error).toBeInstanceOf(Error);
      
    
  });
  
});