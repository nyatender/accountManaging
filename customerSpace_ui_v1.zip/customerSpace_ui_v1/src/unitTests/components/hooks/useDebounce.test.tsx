import { renderHook, act } from '@testing-library/react';
import useDebounce from '../../../components/hooks/useDebounce';

jest.useFakeTimers();

describe('useDebounce', () => {
  it('should debounce the value', () => {
    const { result, rerender } = renderHook((value) => useDebounce(value, 500), {
      initialProps: 'abhi',
    });

    // The debounced value should be the initial value initially
    expect(result.current).toBe('abhi');

    // Change the value now
    rerender('abhishek');

    jest.advanceTimersByTime(300);

    // The debounced value should still be the initial value because we haven't reached the delay
    expect(result.current).toBe('abhi');

    act(() => {
      // Fast-forward time to trigger the final debounced update after the delay (500ms)
      jest.advanceTimersByTime(500);
    });

    // The debounced value should now be the updated value
    expect(result.current).toBe('abhishek');
  });
});






