import { render, screen  , fireEvent} from '@testing-library/react';
import { Button } from '../../../../components/atoms/button/Button';

describe('Button Component', () => {
  it('should render button component with props', () => {
    const buttonText="Add Users";
    const variant = 'Primary';
    const isDisabled = false;
    const isGhost = false;
    const isOutLined = false;
    const onClick=jest.fn();
    const type='button';
    const id="addButton";
    const className="m1";

    render(<Button buttonText={buttonText} 
      variant={variant}
      isDisabled={isDisabled}
      isGhost={isGhost}
      isOutLined={isOutLined} 
      onClick={onClick}
      className={className}
      id={id}
      type={type}/>);

    // Assert that the custombuttoncomponent is rendered
    const customButton = screen.getByTestId('button');
    expect(customButton).toBeInTheDocument();
    expect(customButton).toHaveAttribute('disabled', 'false');
    expect(customButton).toHaveAttribute('ghost', 'false');
    expect(customButton).toHaveAttribute('variant', 'Primary');
    expect(customButton).toHaveAttribute('outline', 'false');
    expect(customButton).toHaveAttribute('type', 'button');
    expect(customButton).toHaveAttribute('class', 'm1');
    expect(customButton).toHaveAttribute('id', 'addButton');

    // Simulate a click on the button
    fireEvent.click(customButton);

    expect(onClick).toHaveBeenCalled();

  });
});