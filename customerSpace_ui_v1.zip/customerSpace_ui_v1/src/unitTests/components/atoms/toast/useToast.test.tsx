import { renderHook } from '@testing-library/react';
import { useToast } from '../../../../components/atoms/toast/useToast';
import { Appconstants } from '../../../../constants';

describe('Toast Component', () => {
  it('should render Toast component', async () => {

    const { result } = renderHook(() => useToast());


    const toast = result.current.callToast
    await toast("success",Appconstants.user.toast.addSuccessMessage)
  });
});