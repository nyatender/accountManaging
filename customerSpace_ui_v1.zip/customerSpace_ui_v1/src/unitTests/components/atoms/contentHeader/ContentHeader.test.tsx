import { render, screen } from '@testing-library/react';
import ContentHeader from '../../../../components/atoms/contentHeader/ContentHeader';

describe('Content Header Component', () => {
  it('should render contentHeader component with title and backbutton', () => {
    
    const title = 'Users';
    const hasBackButton = false;

    render(<ContentHeader title={title} hasBackButton={hasBackButton} />);

    const contentHeader = screen.getByTestId('contentHeader');
    expect(contentHeader).toBeInTheDocument();

  });
});