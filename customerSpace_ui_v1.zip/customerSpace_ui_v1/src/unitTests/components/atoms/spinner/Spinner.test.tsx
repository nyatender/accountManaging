import { render, screen } from '@testing-library/react';
import Spinner from '../../../../components/atoms/spinner/Spinner';

describe('Spinner Component', () => {
  it('should render spinner component', () => {

    render(<Spinner/>);

    const spinnerElement = screen.getByTestId('spinner');
    expect(spinnerElement).toBeInTheDocument();

  });
});