import React from 'react'
import { customRender } from '../../../testUtils/TestUtils'
import CustomModal from '../../../../components/atoms/customModal/CustomModal'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('testing Modal component', () => {
  const logoutFn = jest.fn()
  it('should render modal popup', () => {
    customRender(<CustomModal logout={logoutFn} headerText='Logout' bodyText='Are you sure you want to logout?'/>)
    const modal = screen.getByTestId('ModalPopup')
    expect(modal).toBeInTheDocument()
  })

  it('should check whether logout button is working', async() => {
    customRender(<CustomModal logout={logoutFn} headerText='Logout' bodyText='Are you sure you want to logout?'/>)

    const logoutButton = screen.getByTestId('confirmButton')
    expect(logoutButton).toBeInTheDocument()
    userEvent.click(logoutButton)
  })
  it('should check whether cancel button is working', async() => {
    customRender(<CustomModal logout={logoutFn} headerText='Logout' bodyText='Are you sure you want to logout?'/>)
    const cancelbutton = screen.getByTestId('cancelButton')
    expect(cancelbutton).toBeInTheDocument()
    userEvent.click(cancelbutton)
  })
})