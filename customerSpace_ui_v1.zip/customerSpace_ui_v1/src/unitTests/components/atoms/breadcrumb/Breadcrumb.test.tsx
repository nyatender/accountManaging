import { render, screen } from '@testing-library/react';
import Breadcrumb from '../../../../components/atoms/breadcrumb/Breadcrumb';

describe('Breadcrumb Component', () => {
  it('renders breadcrumb component with label and icon', () => {
    const label = 'companies';
    const icon = 'companies-icon';
    render(<Breadcrumb label={label} icon={icon} />);
  
    // Assert that the breadcrumb component is rendered
    const breadcrumb = screen.getByTestId('breadcrumb');
    expect(breadcrumb).toBeInTheDocument();

  });
});