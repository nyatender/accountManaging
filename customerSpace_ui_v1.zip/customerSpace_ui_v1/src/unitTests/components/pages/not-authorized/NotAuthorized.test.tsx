import { render, screen } from '@testing-library/react';
import NotAuthorized from '../../../../components/pages/not-authorized/NotAuthorized';

describe('Not Authorized Component', () => {
  it('should render Not Authorized component', () => {

    render(<NotAuthorized />);
    expect(screen.getByTestId("notAuthorized")).toBeInTheDocument();

  });
});