//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';
import { getCompanyMockData , mockResponse , getCompanyByNameMockData} from '../mocks/companyMockdata';
import { useGetCompanyList } from '../../../../../components/pages/company/hooks/useGetCompanyList';
import { GET_COMPANY } from '../../../../../components/pages/api/urlConstants';

jest.mock('../../../../../components/pages/api/api');

describe('useGetUserList', () => {
  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })
  it('calls the getCompany function and updates the state correctly', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    const startPage=1
    const pageSize=10
    jest.spyOn(api, 'getAPI').mockResolvedValue(getCompanyMockData);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyList(), { wrapper });

    await act(async () => {
      const getCompany=result.current.getCompany
      await getCompany(1,10);
    });
    expect(api.getAPI).toHaveBeenCalledWith(GET_COMPANY, { params: {filter: `page=${startPage}&size=${pageSize}`}});
    console.log(result.current.rowData)
    expect(result.current.rowData).toStrictEqual(mockResponse); 
      
  });

  it('should handle API error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyList(), { wrapper });
    await act(async () => {
      const getCompany=result.current.getCompany
      await getCompany(1,10);
      expect(window.location.pathname).toEqual('/notAuthorized')
    });
    
    // Assert that the error has been set in the state
    expect(result.current.rowData).toEqual([]);
  });

  it('should handle 500 api  error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyList(), { wrapper });
  
    await act(async () => {
      const getCompany=result.current.getCompany
      await getCompany(1,10);
      expect(useToast).toBeCalled()
      expect(useToast.mock.results[0].value.callToast).toHaveBeenCalledWith('error', `The Company details can't be fetched.Please try again later`);
  
    });
    
  });

  

  it('should call the getCompanyDataByName function and updates the table data correctly', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'getAPI').mockResolvedValue(getCompanyByNameMockData);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyList(), { wrapper });
    await act(async () => {
      await result.current.getCompanyDataByName();
    });
    expect(result.current.rowData[0]).toStrictEqual(getCompanyByNameMockData); 
      
  });

  it('should getCompanyDataByName API 401 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyList(), { wrapper });
    await act(async () => {
      await result.current.getCompanyDataByName();
      expect(window.location.pathname).toEqual('/notAuthorized')
    });
    
    // Assert that the error has been set in the state
    expect(result.current.rowData).toEqual([]);
  });

});

