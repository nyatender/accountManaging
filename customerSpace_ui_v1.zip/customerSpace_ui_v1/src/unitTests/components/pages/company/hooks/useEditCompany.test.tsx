//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';
import { useEditCompany } from '../../../../../components/pages/company/hooks/useEditCompany';
import { editCompanyMockdata } from '../mocks/companyMockdata';
import { UPDATE_COMPANY } from '../../../../../components/pages/api/urlConstants';


jest.mock('../../../../../components/pages/api/api');

describe('useEditUser', () => {

  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call edit company api successfully', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'putAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useEditCompany(), { wrapper });

    await act(async () => {
      const editCompanyData = result.current.editCompanyData;
      let response = await editCompanyData(editCompanyMockdata);
      expect(response).toEqual('Success');
    });
    expect(api.putAPI).toHaveBeenCalledWith(UPDATE_COMPANY, editCompanyMockdata);

  });

  
  it('should handle edit company api 401 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'putAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useEditCompany(), { wrapper });
    
    await act(async () => {
      const editCompanyData = result.current.editCompanyData;
      await editCompanyData(editCompanyMockdata);
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should handle  edit company api 500 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'putAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;

    const { result } = renderHook(() => useEditCompany(), { wrapper });
    await act(async () => {
      const editCompanyData = result.current.editCompanyData;
      await editCompanyData(editCompanyMockdata);
      expect(useToast).toBeCalled()
      expect(useToast.mock.results[0].value.callToast).toHaveBeenCalledWith('error', `The Company can’t be edited. Please try again later`);
  
  
    });
    
  });
  
});