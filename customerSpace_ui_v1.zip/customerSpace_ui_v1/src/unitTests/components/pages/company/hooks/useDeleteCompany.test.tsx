//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';
import { useDeleteCompany } from '../../../../../components/pages/company/hooks/useDeleteCompany';
import { DELETE_COMPANY } from '../../../../../components/pages/api/urlConstants';


jest.mock('../../../../../components/pages/api/api');


describe('useDeleteUser', () => {
  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call delete company api successfully', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 
 
    jest.spyOn(api, 'deleteAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useDeleteCompany(), { wrapper });


    const companyId = { id: 9};
    await act(async () => {
         
      const deleteCompany = result.current.deleteCompany
      let response = await deleteCompany(companyId);
      expect(response).toEqual('Success');
    });
    expect(api.deleteAPI).toHaveBeenCalledWith(DELETE_COMPANY, {data:companyId});


  });

  it('should handle delete company api 401 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'deleteAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useDeleteCompany(), { wrapper });
    const companyId = { id: 9};

    await act(async () => {
      const deleteCompany = result.current.deleteCompany
      await deleteCompany(companyId);
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should handle delete company api 500 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'deleteAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const companyId = { id: 9};
    const { result } = renderHook(() => useDeleteCompany(), { wrapper });
  
    await act(async () => {
      const deleteCompany = result.current.deleteCompany
      await deleteCompany(companyId);
      expect(useToast).toBeCalled()
      expect(useToast.mock.results[0].value.callToast).toHaveBeenCalledWith('error', `The Company can’t be deleted. Please try again later`);
  
    });
    
  });
  
});