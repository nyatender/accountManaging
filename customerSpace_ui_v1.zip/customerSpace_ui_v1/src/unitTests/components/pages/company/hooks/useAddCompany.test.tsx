//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';
import { useAddCompany } from '../../../../../components/pages/company/hooks/useAddCompany';
import { addCompanyMockdata } from '../mocks/companyMockdata';
import { CREATE_COMPANY } from '../../../../../components/pages/api/urlConstants';


jest.mock('../../../../../components/pages/api/api');


describe('useAddCompany', () => {

  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call add company api successfully', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'postAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useAddCompany(), { wrapper });
    await act(async () => {
      const addCompanyData = result.current.addCompanyData;
      let response = await addCompanyData(addCompanyMockdata);
      expect(response).toEqual('Success');

    })

    expect(api.postAPI).toHaveBeenCalledWith(CREATE_COMPANY, addCompanyMockdata);

  });

  it('should handle add company api 401 error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'postAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useAddCompany(), { wrapper });

    await act(async () => {
      const addCompanyData = result.current.addCompanyData;
      await addCompanyData(addCompanyMockdata);
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should show notification when company already exists', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'postAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' , message:"Company Already Exists"} } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useAddCompany(), { wrapper });
  
    await act(async () => {
      const addCompanyData = result.current.addCompanyData;
      await addCompanyData(addCompanyMockdata);
      expect(useToast).toBeCalled()
      expect(useToast.mock.results[0].value.callToast).toHaveBeenCalledWith('error', `Company Already Exists`);
  
    });
    
  });

  it('should handle 500 Api error', async () => {
    useToast.mockReturnValue({
      callToast:jest.fn()
    }) 

    jest.spyOn(api, 'postAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error'} } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useAddCompany(), { wrapper });
  
    await act(async () => {
      const addCompanyData = result.current.addCompanyData;
      await addCompanyData(addCompanyMockdata);
      expect(useToast).toBeCalled()
      expect(useToast.mock.results[0].value.callToast).toHaveBeenCalledWith('error', `The Company can’t be created. Please try again later`);
  
    });
    
  });
  
});