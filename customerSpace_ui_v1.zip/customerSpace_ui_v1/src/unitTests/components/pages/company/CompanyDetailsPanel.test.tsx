//@ts-nocheck
import { render, screen } from '@testing-library/react';
import CompanyDetailsPanel from '../../../../components/pages/company/CompanyDetailsPanel';
import { BrowserRouter } from 'react-router-dom';
import CompanyContextProvider from '../../../../components/pages/company/CompanyContext';
import { companyDetailsContextMock } from './mocks/companyMockdata';



describe('Company Details Panel', () => {

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));

  });

  afterEach(() => {
    jest.clearAllMocks();
  })

  it('should render company details data', () => {
    render(
      <CompanyContextProvider mockData={companyDetailsContextMock}>
        <BrowserRouter>
          <CompanyDetailsPanel />
        </BrowserRouter>
    
      </CompanyContextProvider>

    )
    expect(screen.getByTestId('contentHeader')).toBeInTheDocument()
    expect(screen.getAllByTestId('keyValPairs')).toHaveLength(10)
  });

});