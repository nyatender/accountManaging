//@ts-nocheck
import React from 'react';
import userEvent from '@testing-library/user-event'
import { fireEvent, render, screen , waitFor} from '@testing-library/react';
import CompanyForm from '../../../../components/pages/company/CompanyForm';
import { BrowserRouter } from 'react-router-dom';
import * as useAddCompanyHook  from '../../../../components/pages/company/hooks/useAddCompany';
import * as useEditCompanyHook  from '../../../../components/pages/company/hooks/useEditCompany';
import { customRender } from '../../../testUtils/TestUtils';
import CompanyContextProvider from '../../../../components/pages/company/CompanyContext';
import { addCompanyContextMock, editCompanyContextMock } from './mocks/companyMockdata';
import { ICompanyData } from '../../../../components/pages/company/CompanyPropsTypes';


describe('Company Form', () => {
  let useAddCompany = null
  let useEditCompany = null
  const mockonSubmit = jest.fn((data:ICompanyData) => {
    return Promise.resolve({ data })
  })

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));

    useAddCompany = jest.spyOn(useAddCompanyHook, 'useAddCompany')
    useEditCompany = jest.spyOn(useEditCompanyHook, 'useEditCompany')
  });

  beforeEach(() => {
    useAddCompany.mockClear()
    useEditCompany.mockClear()
  })

  afterEach(() => {
    jest.clearAllMocks();
  })

  it('should render form fields & buttons', () => {

    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    }) 
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })
    customRender( <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()}/>)
    expect(screen.getByTestId('companyName-input')).toBeInTheDocument();
    expect(screen.getByTestId('billingEmailId-input')).toBeInTheDocument();
    expect(screen.getByTestId('generalEmailId-input')).toBeInTheDocument();
    expect(screen.getByTestId('incidentReportingEmailId-input')).toBeInTheDocument();
    expect(screen.getByTestId('ddxToken-input')).toBeInTheDocument();
    expect(screen.getByTestId('telephone-input')).toBeInTheDocument();
    expect(screen.getByTestId('country-input')).toBeInTheDocument();
    expect(screen.getByTestId('address-input')).toBeInTheDocument();
    expect(screen.getByTestId('zipCode-input')).toBeInTheDocument();
    expect(screen.getByText('Save & close')).toBeInTheDocument();
    expect(screen.getByText('Save & Add Another')).toBeInTheDocument();

  });

  it('should check initial state values of form are set correctly for add company', () => {

    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    })
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <BrowserRouter>
        <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()}/>
      </BrowserRouter>);

    // Check if initial values are set correctly if edit company is false
    expect(screen.getByTestId('companyName-input')).toHaveValue('');
    expect(screen.getByTestId('billingEmailId-input')).toHaveValue('');
    expect(screen.getByTestId('generalEmailId-input')).toHaveValue('');
    expect(screen.getByTestId('incidentReportingEmailId-input')).toHaveValue('');
    expect(screen.getByTestId('ddxToken-input')).toHaveValue('');
    expect(screen.getByTestId('telephone-input')).toHaveValue('');
    expect(screen.getByTestId('country-input')).toHaveValue('');
    expect(screen.getByTestId('address-input')).toHaveValue('');
    expect(screen.getByTestId('zipCode-input')).toHaveValue('');

    expect(screen.getByTestId('companyName-input')).not.toBeDisabled();
    expect(screen.getByTestId('billingEmailId-input')).not.toBeDisabled();
    expect(screen.getByTestId('generalEmailId-input')).not.toBeDisabled();
    expect(screen.getByTestId('incidentReportingEmailId-input')).not.toBeDisabled();
  });

  it("should not call submit when form fields are empty", async () => {
  
    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    })
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <CompanyContextProvider mockData={addCompanyContextMock}>
        <BrowserRouter>
          <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()} />
        </BrowserRouter>
        
      </CompanyContextProvider>
    );
  
    fireEvent.submit(screen.getByText('Save & close'));
    expect(mockonSubmit).not.toBeCalled()
  })

  it("should display error className if required fields are empty on Submit click", async () => {
    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    })
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <CompanyContextProvider mockData={addCompanyContextMock}>
        <BrowserRouter>
          <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()} />
        </BrowserRouter>
        
      </CompanyContextProvider>
    );
    let saveButton = await screen.findByText('Save & close')
    expect(saveButton).toBeInTheDocument()
    fireEvent.submit(saveButton);
    await waitFor(() => {
      expect(screen.getByTestId('companyName-input')).toHaveClass('form-control is-invalid');
    });

    expect(screen.getByTestId('billingEmailId-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('generalEmailId-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('incidentReportingEmailId-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('ddxToken-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('telephone-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('zipCode-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('country-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('address-input')).toHaveClass('form-control is-invalid'); 
  })

  
  it('should submit the form and adds a company', async () => {

    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    }) 
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    }) 
    const user = userEvent.setup()
    const mockCallToast = jest.fn(); // Mock the callToast function
    jest.doMock('../../../../components/atoms/toast/useToast', () => ({
      useToast: () => ({
        callToast: mockCallToast,
      }),
    }));
    render(
      <CompanyContextProvider mockData={addCompanyContextMock}>
        <BrowserRouter>
          <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()} />
        </BrowserRouter>
        
      </CompanyContextProvider>);

    // Enter valid data in form fields
    await user.type(screen.getByTestId('companyName-input'), 'cisco');
    await user.type(screen.getByTestId('billingEmailId-input'), 'loveleen.rawat@gmail.com');
    await user.type(screen.getByTestId('generalEmailId-input'), 'loveleen.rawat@gmail.com');
    await user.type(screen.getByTestId('incidentReportingEmailId-input'), 'loveleen.rawat@gmail.com');
    await user.type(screen.getByTestId('ddxToken-input'), 'asd1234');
    await user.type(screen.getByTestId('telephone-input'), '0997766509');
    await user.type(screen.getByTestId('country-input'), 'india');
    await user.type(screen.getByTestId('address-input'), 'bangalore');
    await user.type(screen.getByTestId('zipCode-input'), '0997766');

    
  
    expect(screen.getByTestId('companyName-input')).toHaveValue('cisco');
    expect(screen.getByTestId('billingEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('generalEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('incidentReportingEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('ddxToken-input')).toHaveValue('asd1234');
    expect(screen.getByTestId('telephone-input')).toHaveValue('0997766509');
    expect(screen.getByTestId('country-input')).toHaveValue('india');
    expect(screen.getByTestId('address-input')).toHaveValue('bangalore');
    expect(screen.getByTestId('zipCode-input')).toHaveValue('0997766');
    
    // Simulate form submission
    fireEvent.submit(screen.getByText('Save & close'));
   

  });

  it('displays the company data in the form for edit company', () => {
    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    })
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <CompanyContextProvider mockData={editCompanyContextMock}>
        <BrowserRouter>
          <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()} />
        </BrowserRouter>
        
      </CompanyContextProvider>
    );

    // Assert that the company details is displayed in the form fields
    expect(screen.getByTestId('companyName-input')).toHaveValue('cisco');
    expect(screen.getByTestId('billingEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('generalEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('incidentReportingEmailId-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('ddxToken-input')).toHaveValue('abc');
    expect(screen.getByTestId('telephone-input')).toHaveValue('456');
    expect(screen.getByTestId('country-input')).toHaveValue('india');
    expect(screen.getByTestId('address-input')).toHaveValue('bangalore');
    expect(screen.getByTestId('zipCode-input')).toHaveValue('123');
  });

  it('should not render save and add another button in edit user',async () => {
 
    useAddCompany.mockReturnValue({
      addCompanyData: jest.fn().mockResolvedValue(true)
    })
    useEditCompany.mockReturnValue({
      editCompanyDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <CompanyContextProvider mockData={editCompanyContextMock}>
        <BrowserRouter>
          <CompanyForm hideAddCompanyPanel={jest.fn()} showAddCompanySidePanel={jest.fn()} />
        </BrowserRouter>
        
      </CompanyContextProvider>
    );
    await waitFor(() => {
      expect(screen.queryByText('Save & Add Another')).not.toBeInTheDocument()
    });
   
  });



});

