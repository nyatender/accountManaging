export const addCompanyMockdata={
  "companyName":"XYZ",
  "companyEmailAddress":"abhi.r@siemens.com",
  "telephone": "96350000789",
  "country":"India",
  "userCount":1,
  "address":"Bangalore",
  "zipCode":"560100",
  "id":0
}

export const editCompanyMockdata={
  "companyName":"XYZ",
  "companyEmailAddress":"abhi.r@siemens.com",
  "telephone": "96350000789",
  "country":"India",
  "userCount":1,
  "address":"Bangalore",
  "zipCode":"560100",
  "id":0
}

export const getCompanyMockData={
  totalPages: 1,
  page: 0,
  pageSize: 10,
  totalElements: 2,
  hasNext: false,
  hasPrevious: false,
  items: [
    {
      "creationDate": "2023-07-05 13:31:41",
      "updatedDate": "2023-07-05 13:31:41",
      "createdBy": "admin",
      "updatedBy": "admin",
      "id": 4,
      "name": "Loveleen Rawat",
      "emailAddress": "loveleen@siemens.com",
      "phoneNumber": "9800997868",
      "companyId": 2,
      "userEntityList":[{companyId:164,
        companyName:null,
        createdBy:"loveleen.rawat@siemens.com",
        creationDate:"2023-07-17 11:48:39",
        emailAddress:"abhi@redit.com",
        id:1912,
        name:"abhi",
        phoneNumber:"567980",
        updatedBy:"loveleen.rawat@siemens.com",
        updatedDate:"2023-07-17 11:48:39"}]
    },
    {
      "creationDate": "2023-07-05 17:31:48",
      "updatedDate": "2023-07-06 12:16:56",
      "createdBy": "Admin",
      "updatedBy": "Admin",
      "id": 10,
      "name": "nimith",
      "emailAddress": "nimith@gmail.com",
      "phoneNumber": "439900",
      "companyId": 65,
      "userEntityList":[{companyId:164,
        companyName:null,
        createdBy:"loveleen.rawat@siemens.com",
        creationDate:"2023-07-17 11:48:39",
        emailAddress:"abhi@redit.com",
        id:1912,
        name:"abhi",
        phoneNumber:"567980",
        updatedBy:"loveleen.rawat@siemens.com",
        updatedDate:"2023-07-17 11:48:39"}]
    }
  ]
      
}

export const getCompanyByNameMockData={
  "id": 164,
  "creationDate": [
    2023,
    7,
    17,
    11,
    15,
    5,
    183430400
  ],
  "updatedDate": [
    2023,
    7,
    17,
    11,
    15,
    5,
    183430400
  ],
  "createdBy": "loveleen.rawat@siemens.com",
  "updatedBy": "loveleen.rawat@siemens.com",
  "companyName": "Cisco",
  "emailAddress": "neha@gmail.com",
  "country": "India",
  "telephone": "0876576",
  "address": "bangalore",
  "zipCode": "723864",
  "userCount": 3
}


export const addCompanyContextMock={
  isEditCompany:false,
  selectedEditData:[],
  isAddCompanyPanelOpen:true
}

export const editCompanyContextMock={
  isEditCompany:true,
  isAddCompanyPanelOpen: false,
  selectedEditData: {
    companyName: 'cisco',
    generalEmailId: 'loveleen.rawat@gmail.com',
    billingEmailId: 'loveleen.rawat@gmail.com',
    incidentReportingEmailId: 'loveleen.rawat@gmail.com',
    ddxToken: 'abc',
    telephone:"456",
    country:"india",
    address:"bangalore",
    zipCode:"123",
    id:"1",
    userEntityList:[{companyId:164,
      companyName:null,
      createdBy:"loveleen.rawat@siemens.com",
      creationDate:"2023-07-17 11:48:39",
      emailAddress:"abhi@redit.com",
      id:1912,
      name:"abhi",
      phoneNumber:"567980",
      updatedBy:"loveleen.rawat@siemens.com",
      updatedDate:"2023-07-17 11:48:39"}]
  }
  
}

export const companyDetailsContextMock={
  companyDetails:{
    creationDate: '2023-07-05 13:31:41',
    updatedDate: '2023-07-05 13:31:41',
    createdBy: 'admin',
    updatedBy: 'admin',
    id: 4,
    companyName: 'Hp',
    companyEmailAddress: 'loveleen@hp.com',
    billingEmailId: 'loveleen@hp.com',
    incidentReportingEmailId:"loveleen@hp.com",
    telephone: "09876",
    country:"india",
    address:"bangalore",
    zipCode:"1234",
    userCount:2

  }
}

export const mockResponse=[
  {
    creationDate: '2023-07-05 13:31:41',
    updatedDate: '2023-07-05 13:31:41',
    createdBy: 'admin',
    updatedBy: 'admin',
    id: 4,
    name: 'Loveleen Rawat',
    emailAddress: 'loveleen@siemens.com',
    phoneNumber: '9800997868',
    companyId: 2,
    userEntityList: [{companyId:164,
      companyName:null,
      createdBy:"loveleen.rawat@siemens.com",
      creationDate:"2023-07-17 11:48:39",
      emailAddress:"abhi@redit.com",
      id:1912,
      name:"abhi",
      phoneNumber:"567980",
      updatedBy:"loveleen.rawat@siemens.com",
      updatedDate:"2023-07-17 11:48:39"}],
    userCount: 1
  },
  {
    creationDate: '2023-07-05 17:31:48',
    updatedDate: '2023-07-06 12:16:56',
    createdBy: 'Admin',
    updatedBy: 'Admin',
    id: 10,
    name: 'nimith',
    emailAddress: 'nimith@gmail.com',
    phoneNumber: '439900',
    companyId: 65,
    userEntityList: [{companyId:164,
      companyName:null,
      createdBy:"loveleen.rawat@siemens.com",
      creationDate:"2023-07-17 11:48:39",
      emailAddress:"abhi@redit.com",
      id:1912,
      name:"abhi",
      phoneNumber:"567980",
      updatedBy:"loveleen.rawat@siemens.com",
      updatedDate:"2023-07-17 11:48:39"}],
    userCount: 1
  }
]
