import { render, screen } from '@testing-library/react';
import UserNotFound from '../../../../components/pages/userNotFound/UserNotFound';

describe('User Not Found Component', () => {
  it('should render user not found component', () => {

    render(<UserNotFound />);
    const errorText = screen.getByTestId("usernotFound");
    expect(errorText).toBeInTheDocument();

  });
});