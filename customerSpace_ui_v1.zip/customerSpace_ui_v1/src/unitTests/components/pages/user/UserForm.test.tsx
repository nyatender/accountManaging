//@ts-nocheck
import React from 'react';
import userEvent from '@testing-library/user-event'
import { fireEvent, render, screen , waitFor} from '@testing-library/react';
import UserForm from '../../../../components/pages/user/UserForm';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../components/pages/api/api';
import UserContextProvider from '../../../../components/pages/user/UserContext';
import { MockData } from './mocks/mockdata';
import * as  useGetCompanyNameListHook from '../../../../components/pages/user/hooks/useGetCompanyNameList';
import * as useAddUserHook  from '../../../../components/pages/user/hooks/useAddUser';
import * as useEditUserHook  from '../../../../components/pages/user/hooks/useEditUser';
import { customRender } from "../../../testUtils/TestUtils";
import { IUserData } from '../../../../components/pages/user/UserPropsTypes';
import { Appconstants } from '../../../../constants';

describe('User Form', () => {
  let useAddUser = null
  let useGetCompanyNameList = null
  let useEditUser = null
  const mockonSubmit = jest.fn((data:IUserData) => {
    return Promise.resolve({ data })
  })
  const handleSelect = jest.fn();
  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));

    useAddUser = jest.spyOn(useAddUserHook, 'useAddUser')
    useEditUser = jest.spyOn(useEditUserHook, 'useEditUser')
    useGetCompanyNameList = jest.spyOn(useGetCompanyNameListHook, 'useGetCompanyNameList')
  });

  beforeEach(() => {
    useAddUser.mockClear()
    useEditUser.mockClear()
    useGetCompanyNameList.mockClear()
    handleSelect.mockClear()
  })

  afterEach(() => {
    jest.clearAllMocks();
  })

  it('should call api to fetch company names list', async() => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    }) 
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })
    jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getCompanyNameAndIdMockData);
    customRender( <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()}/>)
    expect(screen.getByTestId('userName-input')).toBeInTheDocument();
  });

  it('should render form fields & buttons', () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    }) 
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })
    jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getCompanyNameAndIdMockData);
    customRender( <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()}/>)
    expect(screen.getByTestId('userName-input')).toBeInTheDocument();
    expect(screen.getByTestId('phoneNumber-input')).toBeInTheDocument();
    expect(screen.getByTestId('email-input')).toBeInTheDocument();
    expect(screen.getByLabelText('Company *')).toBeInTheDocument();
    expect(screen.getByText('Save & close')).toBeInTheDocument();
    expect(screen.getByText('Save & Add Another')).toBeInTheDocument();

  });

  it('should check initial state values of form are set correctly for add user', () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <BrowserRouter>
        <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()}/>
      </BrowserRouter>);

    // Check if initial values are set correctly if edit user is false
    expect(screen.getByTestId('userName-input')).toHaveValue('');
    expect(screen.getByTestId('email-input')).toHaveValue('');
    expect(screen.getByTestId('phoneNumber-input')).toHaveValue('');
    expect(screen.getByTestId('userName-input')).not.toBeDisabled();
    expect(screen.getByTestId('email-input')).not.toBeDisabled();
    expect(screen.getByTestId('phoneNumber-input')).not.toBeDisabled();
  });

  it('should display company dropdown', async () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    }) 
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    }) 
    render(
      <UserContextProvider mockData={MockData.mockAddUserContextData}>
        <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()}/>
      </UserContextProvider>);

    expect(screen.getByTestId('custom-select')).toBeInTheDocument();
    expect(screen.getAllByTestId('ixSelectItem').length).toBe(2)
    expect(screen.getAllByTestId('ixSelectItem')[0]).toHaveProperty("label","cisco");
    expect(screen.getAllByTestId('ixSelectItem')[1]).toHaveProperty("label","HP");
    const select = screen.getByTestId('custom-select');
    select.selectedIndices = 1; // Select the third option (index 2)
    fireEvent.change(select);
    await waitFor(()=>{
      expect(select.selectedIndices).toEqual("1");
    }
      
    )


  });
  

  it("should not call submit when form fields are empty", async () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <UserContextProvider mockData={MockData.mockEditUserContextData}>
        <BrowserRouter>
          <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()} />
        </BrowserRouter>
        
      </UserContextProvider>
    );
  
    fireEvent.submit(screen.getByText('Save & close'));
    expect(mockonSubmit).not.toBeCalled()
  })

  it("should display error className if required fields are empty on Submit click", async () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <UserContextProvider mockData={MockData.mockAddUserContextData}>
        <BrowserRouter>
          <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()} />
        </BrowserRouter>
        
      </UserContextProvider>
    );
    let saveButton = await screen.findByText('Save & close')
    expect(saveButton).toBeInTheDocument()
    fireEvent.submit(saveButton);
    await waitFor(() => {
      let nameInput = screen.getByTestId('userName-input');
      expect(nameInput).toHaveClass('form-control is-invalid');
    });
    expect(screen.getByTestId('email-input')).toHaveClass('form-control is-invalid');
    expect(screen.getByTestId('phoneNumber-input')).toHaveClass('form-control is-invalid');
  })

  it("should display error message if company dropdown is not selected on submit click", async () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <UserContextProvider mockData={MockData.mockAddUserContextData}>
        <BrowserRouter>
          <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()} />
        </BrowserRouter>
        
      </UserContextProvider>
    );
    let saveButton = await screen.findByText('Save & close')
    expect(saveButton).toBeInTheDocument()
    fireEvent.submit(saveButton);
    await waitFor(() => {
      let errorText = screen.getByTestId('requiredError');
      expect(errorText).toBeInTheDocument();
    })
    expect(screen.getByTestId('requiredError')).toHaveTextContent(Appconstants.user.validation.requiredCompany);

  })

  it('should submit the form and adds a user', async () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    }) 
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    }) 
    const user = userEvent.setup()
    const mockCallToast = jest.fn(); // Mock the callToast function
    jest.doMock('../../../../components/atoms/toast/useToast', () => ({
      useToast: () => ({
        callToast: mockCallToast,
      }),
    }));
    const hidePanel = jest.fn();
    render(
      <BrowserRouter>
        <UserContextProvider mockData={MockData.mockAddUserContextData}>
          <UserForm hideAddUserPanel={hidePanel} showAddUserSidePanel={jest.fn()}/>
        </UserContextProvider>
      </BrowserRouter>);


    // Enter valid data in form fields
    await user.type(screen.getByTestId('userName-input'), 'Loveleen Rawat');
    await user.type(screen.getByTestId('email-input'), 'loveleen.rawat@gmail.com');
    await user.type(screen.getByTestId('phoneNumber-input'), '0997766509');
    

    // Verify that addUserData is called with the correct data
    expect(screen.getByTestId('userName-input')).toHaveValue('Loveleen Rawat');
    expect(screen.getByTestId('email-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('phoneNumber-input')).toHaveValue('0997766509');
    expect(screen.getByTestId('custom-select')).toHaveAttribute("selected-indices", '1')
    
    // Simulate form submission
    fireEvent.submit(screen.getByText('Save & close'));
   

  });

  it('displays the user data in the userform for edit user', () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <UserContextProvider mockData={MockData.mockEditUserContextData}>
        <BrowserRouter>
          <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()} />
        </BrowserRouter>
        
      </UserContextProvider>
    );

    // Assert that the user data is displayed in the form fields
    expect(screen.getByTestId('userName-input')).toHaveValue('Loveleen Rawat');
    expect(screen.getByTestId('email-input')).toHaveValue('loveleen.rawat@gmail.com');
    expect(screen.getByTestId('phoneNumber-input')).toHaveValue('0997766509');
    expect(screen.getByTestId('custom-select')).toHaveAttribute("selected-indices", '1')
  });

  it('should not render save and add another button in edit user', () => {
    useGetCompanyNameList.mockReturnValue({
      getCompanyIdAndName: jest.fn().mockResolvedValue({
        companyNamesData: [[2,"cisco"],[3,"HP"]],
      }),
    }) 
    useAddUser.mockReturnValue({
      addUserData: jest.fn().mockResolvedValue(true)
    })
    useEditUser.mockReturnValue({
      editUserDetails: jest.fn().mockResolvedValue(true)
    })  
    render(
      <UserContextProvider mockData={MockData.mockEditUserContextData}>
        <BrowserRouter>
          <UserForm hideAddUserPanel={jest.fn()} showAddUserSidePanel={jest.fn()} />
        </BrowserRouter>
        
      </UserContextProvider>
    );
    expect(screen.queryByText('Save & Add Another')).not.toBeInTheDocument()
  });



});

