export const MockData = {
  getUserMockData:{
    totalPages: 1,
    page: 0,
    pageSize: 10,
    totalElements: 2,
    hasNext: false,
    hasPrevious: false,
    items: [
      {
        "creationDate": "2023-07-05 13:31:41",
        "updatedDate": "2023-07-05 13:31:41",
        "createdBy": "admin",
        "updatedBy": "admin",
        "id": 4,
        "name": "Loveleen Rawat",
        "emailAddress": "loveleen@siemens.com",
        "phoneNumber": "9800997868",
        "companyId": 2
      },
      {
        "creationDate": "2023-07-05 17:31:48",
        "updatedDate": "2023-07-06 12:16:56",
        "createdBy": "Admin",
        "updatedBy": "Admin",
        "id": 10,
        "name": "nimith",
        "emailAddress": "nimith@gmail.com",
        "phoneNumber": "439900",
        "companyId": 65
      }
    ]
  },
  getUserByNameMockData:{
    items: [
      {
        "creationDate": "2023-07-05 13:31:41",
        "updatedDate": "2023-07-05 13:31:41",
        "createdBy": "admin",
        "updatedBy": "admin",
        "id": 4,
        "name": "Loveleen Rawat",
        "emailAddress": "loveleen@siemens.com",
        "phoneNumber": "9800997868",
        "companyId": 2
      },
    ]
  },
  getCompanyNameAndIdMockData:[[1,"cisco"],[2,"HP"]],
  mockEditUserContextData:{
    isEditUser: true,
    selectedEditData: {
      name: 'Loveleen Rawat',
      emailAddress: 'loveleen.rawat@gmail.com',
      phoneNumber: '0997766509',
      companyId: '1',
      id: '456',
    },
    setCompanyValue: jest.fn(),
    companyValue: '1',
    isAddUserPanelOpen: true,  
    isLoading:false ,
    companyNamesData:[[1,"cisco"],[2,"HP"]]
  },
  mockAddUserContextData:{
    isEditUser: false,
    setCompanyValue: jest.fn(),
    isAddUserPanelOpen: true,  
    isLoading:false ,
    companyNamesData:[[1,"cisco"],[2,"HP"]]
  },
  mockUserContext:{
    isEditUser: false,
    selectedEditData: {},
    setCompanyValue: jest.fn(),
    companyValue: '',
    isAddUserPanelOpen: false, 
    setStartPage: jest.fn(),
    isLoading:false,
    showAddUserSidePanel:jest.fn()
  }

}
  