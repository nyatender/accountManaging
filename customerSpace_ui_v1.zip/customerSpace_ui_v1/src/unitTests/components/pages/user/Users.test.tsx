//@ts-nocheck
import { render, screen, waitFor } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { Users } from "../../../../components/pages/user/Users";
import userEvent from "@testing-library/user-event";
import UserContextProvider from "../../../../components/pages/user/UserContext";
import { MockData } from "./mocks/mockdata";
import * as useGetUserListHook from "../../../../components/pages/user/hooks/useGetUserList";
import { customRender } from "../../../testUtils/TestUtils";
import * as api from '../../../../components/pages/api/api';

describe('Users Component', () => {
  let useNavigate = jest.fn()
  let useGetUserList = null
  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useGetUserList = jest.spyOn(useGetUserListHook, 'useGetUserList')
    
  });

  beforeEach(() => {
    useGetUserList.mockClear()
    useNavigate.mockClear()
  })

  afterEach(() => {
    jest.clearAllMocks();
  })

  
  it('should render page header title', () => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    customRender(<Users/>)
    const contentHeaders = screen.getAllByTestId('contentHeader')
    expect(contentHeaders).toHaveLength(2)
    expect(contentHeaders[0]).toHaveAttribute("header-title", 'Users')
    expect(contentHeaders[1]).toHaveAttribute("header-title", 'Add User')
    
  });

  it('should render empty search input on load', () => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    customRender(<Users/>)
    let searchInput = screen.getAllByPlaceholderText('Search users')
    expect(searchInput[0]).toHaveAttribute("value","")
  });

  it('should update the search field', async() => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    const user = userEvent.setup()
    customRender(<Users/>)
    let searchInput = screen.getAllByPlaceholderText('Search users')
    expect(searchInput[0]).toHaveAttribute("value","")
    await user.type(searchInput[0], 'test');
  
    expect(searchInput[0]).toHaveAttribute("value","test")
  });

  it('should render Add user button', async() => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    render(
      <UserContextProvider mockData={MockData.mockUserContext}>
        <BrowserRouter> <Users/></BrowserRouter>
      </UserContextProvider>
    );
    let addButton = screen.getByText('Add User')
    expect(addButton).toBeInTheDocument();
  
  });
  it('should render spinner when loading is true', async () => {
    useGetUserList.mockReturnValue({
      rowData: [],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    render(
      <UserContextProvider mockData={{isLoading:true}}> <BrowserRouter>
        <Users/>
      </BrowserRouter>
      </UserContextProvider>)

    const spinnerComponent = await screen.findByTestId(/loader/)
    expect(spinnerComponent).toBeInTheDocument()
  })
  it('should render empty table with header row when data is null', async () => {
    useGetUserList.mockReturnValue({
      rowData: [],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    customRender(<Users/>)

    await waitFor(() => {
      let grid = screen.getAllByRole('grid')
      expect(grid[0]).toHaveAttribute("aria-rowcount","1");
    });
  })

  it('should render company table rows', async () => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    customRender(<Users/>)
    await waitFor(() => {
      let grid = screen.getAllByRole('grid')
      expect(grid[0]).toHaveAttribute("aria-rowcount","3"); // Including header row
    });

  });



  it('should render the pagination', async () => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    })      
    customRender(<Users/>)
    let pagination = screen.getAllByTestId("pagination")
    expect(pagination[0]).toBeInTheDocument();

  });

  it('should open Drawer Component when user click on add user Button', async() => {
    const user = userEvent.setup();
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    render(
      <UserContextProvider mockData={{isAddUserPanelOpen:false}}> <BrowserRouter>
        <Users/>
      </BrowserRouter>
      </UserContextProvider>)
    let addButton = screen.getByText('Add User')
    await user.click(addButton);
    const drawerComponent = await screen.findByTestId('drawer-component');
    expect(drawerComponent).toHaveAttribute("show","true");
  
  })

  it('should call search by user name api when search text is there', () => {
    jest.mock('../../../../components/pages/api/api');
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    const getSpy=jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getUserByNameMockData);
    const userSearchText="Loveleen" 
    const startPage = 0 
    const pageSize=10
    render(
      <UserContextProvider mockData={{userSearchText:userSearchText, startPage:startPage,pageSie:pageSize}}> <BrowserRouter>
        <Users/>
      </BrowserRouter>
      </UserContextProvider>)
    expect(getSpy).toBeCalled();
  });

  it.skip('should hide Drawer Component if setshow is false', async() => {
    useGetUserList.mockReturnValue({
      rowData: [
        { id: 1, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
        { id: 2, name: 'lovely', emailAddress: 'lovely@gmail.com', phoneNumber: '1234567890', companyName: 'HP' },
      ],
      getUser: jest.fn(),
      getUserDataByName: jest.fn(),
    }) 
    render(
      <UserContextProvider mockData={{isAddUserPanelOpen:false}}> <BrowserRouter>
        <Users/>
      </BrowserRouter>
      </UserContextProvider>)


    const drawer = await screen.findByTestId('drawer-component');
    expect(drawer).toHaveAttribute("show","false");
  
  })

})