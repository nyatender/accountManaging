//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { useAddUser } from '../../../../../components/pages/user/hooks/useAddUser';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import { CREATE_USER } from '../../../../../components/pages/api/urlConstants';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';



jest.mock('../../../../../components/pages/api/api');


describe('useAddUser', () => {

  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call add user api successfully', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'postAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useAddUser(), { wrapper });


    const userData = { name: 'lovely', emailAddress: 'lovely@gmail.com' , phoneNumber:'3453456',companyId:"456"};
    await act(async () => {
      const addUserData = result.current.addUserData;
      let response = await addUserData(userData);
      expect(response).toEqual('Success');

    })

    expect(api.postAPI).toHaveBeenCalledWith(CREATE_USER, userData);

  });

  it('should handle add user api 401 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 


    jest.spyOn(api, 'postAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const userData = { name: 'lovely', emailAddress: 'lovely@gmail.com' , phoneNumber:'3453456',companyId:"456"};
    const { result } = renderHook(() => useAddUser(), { wrapper });

    await act(async () => {
      const addUserData = result.current.addUserData;
      await addUserData(userData);
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should handle add user api 500 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'postAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' , message:"User Already Exists"} } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const userData = { name: 'lovely', emailAddress: 'lovely@gmail.com' , phoneNumber:'3453456',companyId:"456"};
    const { result } = renderHook(() => useAddUser(), { wrapper });
  
    await act(async () => {
      const addUserData = result.current.addUserData;
      await addUserData(userData);
      expect(mockToast).toBeCalled()
  
    });
    
  });
  
});