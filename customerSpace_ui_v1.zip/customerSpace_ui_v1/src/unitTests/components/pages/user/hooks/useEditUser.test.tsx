//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import { useEditUser } from '../../../../../components/pages/user/hooks/useEditUser';
import { UPDATE_USER } from '../../../../../components/pages/api/urlConstants';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';


jest.mock('../../../../../components/pages/api/api');

describe('useEditUser', () => {

  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call edit user api successfully', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'putAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useEditUser(), { wrapper });


    const userData = { name: 'neha', emailAddress: 'neha@gmial.com' , phoneNumber:'09876',companyId:"13"};
    // Call editUserDetails and wait for the API call to resolve and wait for the API call to resolve
    await act(async () => {
      const editUserData = result.current.editUserDetails;
      let response = await editUserData(userData);
      expect(response).toEqual('Success');
    });
    expect(api.putAPI).toHaveBeenCalledWith(UPDATE_USER, userData);

  });

  
  it('should handle edit user api 401 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'putAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useEditUser(), { wrapper });
    
    const userData = { name: 'neha', emailAddress: 'neha@gmial.com' , phoneNumber:'09876',companyId:"13"};

    await act(async () => {
      const editUserData = result.current.editUserDetails;
      await editUserData(userData);
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should handle  edit user api 500 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'putAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const userData = { name: 'neha', emailAddress: 'neha@gmial.com' , phoneNumber:'09876',companyId:"13"};
    const { result } = renderHook(() => useEditUser(), { wrapper });
    await act(async () => {
      const editUserData = result.current.editUserDetails;
      await editUserData(userData);
      expect(mockToast).toBeCalled()
  
    });
    
  });
  
});