//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import { useDeleteUser } from '../../../../../components/pages/user/hooks/useDeleteUser';
import { DELETE_USER } from '../../../../../components/pages/api/urlConstants';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';


jest.mock('../../../../../components/pages/api/api');


describe('useDeleteUser', () => {
  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })

  it('should call delete user api successfully', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 
    jest.spyOn(api, 'deleteAPI').mockResolvedValue('Success');
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useDeleteUser(), { wrapper });


    const userId = { Id: 9};
    await act(async () => {
         
      const deleteUser = result.current.deleteUser;
      let response = await deleteUser(userId);
      expect(response).toEqual('Success');
    });
    expect(api.deleteAPI).toHaveBeenCalledWith(DELETE_USER, {data:userId});


  });

  it('should handle deleter user api 401 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 


    jest.spyOn(api, 'deleteAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useDeleteUser(), { wrapper });
    const userId = { id: 9};

    await act(async () => {
         
      const deleteUser = result.current.deleteUser;
      await deleteUser(userId);;
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });

  it('should handle delete user api 500 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'deleteAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const userId = { id: 9};
    const { result } = renderHook(() => useDeleteUser(), { wrapper });
  
    await act(async () => {
         
      const deleteUser = result.current.deleteUser;
      await deleteUser(userId);;
      expect(mockToast).toBeCalled()
  
    });
    
  });
  
});