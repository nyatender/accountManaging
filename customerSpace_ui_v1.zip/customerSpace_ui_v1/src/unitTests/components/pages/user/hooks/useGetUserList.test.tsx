//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { useGetUserList } from '../../../../../components/pages/user/hooks/useGetUserList';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import { MockData } from '../mocks/mockdata';
import { GET_USERS } from '../../../../../components/pages/api/urlConstants';
import * as useToastHook from '../../../../../components/atoms/toast/useToast';

jest.mock('../../../../../components/pages/api/api');

describe('useGetUserList', () => {
  let useToast = null

  beforeAll(() => {
    const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
    const mockAuthenticate = jest.fn().mockResolvedValue({
      access_token: 'mockAccessToken',
      id_token: 'mockIdToken',
    });
    jest.mock('../../../../../authConfig', () => ({
      authProvider: {
        acquireTokenSilent: mockGetAuthToken,
        authenticate: mockAuthenticate,
      },
    }));
    useToast = jest.spyOn(useToastHook, 'useToast')
    
  });

  beforeEach(() => {
    useToast.mockClear()
  })
  it('calls the getUser function and updates the state correctly', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 
    const startPage=1
    const pageSize=10
    jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getUserMockData);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetUserList(), { wrapper });

    await act(async () => {
      const getUser=result.current.getUser
      await getUser(1,10);
    });
    expect(api.getAPI).toHaveBeenCalledWith(GET_USERS, { params: {filter: `page=${startPage}&size=${pageSize}`}});
    expect(result.current.rowData).toBe(MockData.getUserMockData.items); 
      
  });

  it('should handle API error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 
    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetUserList(), { wrapper });
    await act(async () => {
      const getUser=result.current.getUser
      await getUser(1,10);
      expect(window.location.pathname).toEqual('/notAuthorized')
    });
    
    // Assert that the error has been set in the state
    expect(result.current.rowData).toEqual([]);
  });

  it('should handle 500 api  error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 

    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 500, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetUserList(), { wrapper });
  
    await act(async () => {
      const getUser=result.current.getUser
      await getUser(1,10);
      expect(mockToast).toBeCalled()
  
    });
    
  });

  

  it('calls the getuserByName function and updates the table data correctly', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 
    jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getUserByNameMockData);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetUserList(), { wrapper });
    await act(async () => {
      await result.current.getUserDataByName(1,10);
    });
    expect(result.current.rowData).toBe(MockData.getUserByNameMockData.items); 
      
  });

  it('should getuserByName API 401 error', async () => {
    let mockToast=jest.fn()
    useToast.mockReturnValue({
      callToast:mockToast
    }) 
    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetUserList(), { wrapper });
    await act(async () => {
      await result.current.getUserDataByName(1,10);
      expect(window.location.pathname).toEqual('/notAuthorized')
    });
    
    // Assert that the error has been set in the state
    expect(result.current.rowData).toEqual([]);
  });

});

