//@ts-nocheck
import { act, renderHook } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as api from '../../../../../components/pages/api/api';
import { useGetCompanyNameList } from '../../../../../components/pages/user/hooks/useGetCompanyNameList';
import { MockData } from '../mocks/mockdata';
import { GET_COMPANIES_NAME } from '../../../../../components/pages/api/urlConstants';

jest.mock('../../../../../components/pages/api/api');



beforeEach(() => {
  const mockGetAuthToken = jest.fn().mockResolvedValue({ accessToken: 'mock-access-token' });
  jest.mock('../../../../../authConfig', () => ({
    authProvider: {
      acquireTokenSilent: mockGetAuthToken,
    },
  }));
});
describe('useGetCompnayNameList', () => {

  it('should call getCompanyNameAndId api successfully', async () => {
    jest.spyOn(api, 'getAPI').mockResolvedValue(MockData.getCompanyNameAndIdMockData);
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyNameList(), { wrapper });

    await act(async () => {
      const getCompanyIdAndName = result.current.getCompanyIdAndName;
      await getCompanyIdAndName();
    });

    expect(api.getAPI).toHaveBeenCalledWith(GET_COMPANIES_NAME, {});
  
  
  });

  it('should handle API 401 error', async () => {

    jest.spyOn(api, 'getAPI').mockRejectedValue({ response: { status: 401, data: { error: 'Error' } } });
    const wrapper = ({ children }) => <BrowserRouter>{children}</BrowserRouter>;
    const { result } = renderHook(() => useGetCompanyNameList(), { wrapper });

    await act(async () => {
      const getCompanyIdAndName = result.current.getCompanyIdAndName;
      await getCompanyIdAndName();
      expect(window.location.pathname).toEqual('/notAuthorized')

    });
  });
  
});