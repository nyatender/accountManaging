export const Appconstants = {
  errorPageText: 'You are not authorized to see the page.',
  login: {
    label: {
      english: 'English',
      siemensAg: 'SIEMENS AG',
      welocme: 'Welcome to Data Driven X',
      textContent: `We envision a cross-industry ecosystem, in which data is
      easy-to-process and valuable for all stakeholders. With our
      DDX platform we match IoT-data with contract information, so
      that finance institutes, machines users and machine builders
      benefit from more flexibility due to maximum transparency.`,
      website: 'Website',
      support: 'Support',
      version: 'Version 3.01',
      siemensFooter: '© 2021–2023 Siemens AG',
    },
    button: {
      login: 'Log in with Azure AD',
    },
  },
  company: {
    appName: 'DDX - User management',
    noData: 'No Data',
    label: {
      companies: 'Companies',
      addCompany: 'Add Company',
      editCompany: 'Edit Company',
      name: 'Name',
      generalEmailId: 'General',
      billingEmailId: 'Payment-report & Billing',
      incidentReportingEmailId: 'Incident reporting',
      country: 'Country',
      telephone: 'Telephone',
      address: 'Address',
      zipCode: 'Zip Code',
      companyDetails: 'Company details',
      companyName: 'Company Name',
      emailAddress: 'Email address',
      users: 'Users',
      dateCreated: 'Date Created',
      mailInbox: 'Mail Inbox',
      mindsphereConfig: 'MindSphere Configuration',
      ddxToken: 'DDX Token',
    },
    button: {
      addCompany: ' Add Company',
      saveAndAddAnother: 'Save & Add Another',
      saveAndClose: 'Save & close',
      edit: 'Edit',
      delete: 'Delete',
      ok: 'Ok',
      cancel: 'Cancel',
    },
    menu: {
      dashboardMenuTitle: 'Dashboard',
      companiesMenuTitle: 'Companies',
      logout: 'logout',
    },
    validation: {
      maxLengthExceeded: 'Max length exceeded',
      enterValidEmail: 'Please enter a valid email',
    },
    placeholder: {
      searchCompanies: 'Search companies',
    },
    modal: {
      delete: {
        title: 'Delete',
        bodyContent: 'Are you sure you want to delete ?',
      },
      logout: {
        title: 'Logout',
        bodyContent: 'Are you sure you want to logout?',
      },
    },
    toast: {
      deleteSuccessMessage: 'Company deleted successfully',
      deleteFailureMessage:
        'The Company can’t be deleted. Please try again later',
      editSuccessMessage: 'Company edited successfully',
      editFailureMessage: 'The Company can’t be edited. Please try again later',
      addFailureMessage: 'The Company can’t be created. Please try again later',
      addSuccessMessage: 'Company added successfully',
      getCompanyFailureMessage:
        "The Company details can't be fetched.Please try again later",
      serverDuplicateMsg:"Unable to create company: Company Already Exists",
      duplicateCompanyerorMessage: 'Company Already Exists',
      deleteFailureServerMessage:
        'Company cannot be deleted as user is associated with it, please delete the associated user first and then delete the company.',
    },
  },
  user: {
    noData: 'No Data',
    label: {
      users: 'Users',
      addUser: 'Add User',
      editUser: 'Edit User',
      name: 'Name',
      email: 'Email',
      company: 'Company',
      phoneNumber: 'Phone Number',
      userDetails: 'User details',
      companyName: 'Company Name',
      emailAddress: 'Email address',
    },
    button: {
      addUser: ' Add User',
      saveAndAddAnother: 'Save & Add Another',
      saveAndClose: 'Save & close',
      edit: 'Edit',
      delete: 'Delete',
      ok: 'Ok',
      cancel: 'Cancel',
    },
    menu: {
      usersMenuTitle: 'Users',
    },
    validation: {
      maxLengthExceeded: 'Max length exceeded',
      enterValidEmail: 'Please enter a valid email',
      requiredCompany: 'Please Select a company',
    },
    placeholder: {
      searchUsers: 'Search users',
      selectCompany: 'Select a company',
    },
    modal: {
      delete: {
        title: 'Delete',
        bodyContent: 'Are you sure you want to delete ?',
      },
      logout: {
        title: 'Logout',
        bodyContent: 'Are you sure you want to logout?',
      },
    },
    toast: {
      deleteSuccessMessage: 'User deleted successfully',
      deleteFailureMessage: 'The User can’t be deleted. Please try again later',
      editSuccessMessage: 'User Details edited successfully',
      editFailureMessage: 'The User can’t be edited. Please try again later',
      addFailureMessage: 'The User can’t be created. Please try again later',
      addSuccessMessage: 'User added successfully',
      getUserFailureMessage:
        "The User details can't be fetched.Please try again later",
    },
  },
}

export const ConfigurationConstants = {
  debounce_delay_for_search: 500,
  number_of_record_per_page: 10,
  toastTypeConfig: {
    success: 'success',
    error: 'error',
    warning: 'warning',
    info: 'info',
  },
}
