package com.example.doc_download;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
public class TestController {

    @GetMapping("/downloaddoc")
    public ResponseEntity<byte[]> downloadDoc(@RequestParam String hash, @RequestParam String filename) throws IOException {
        byte[] decodedBytes = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        String baseUrl="https://app.thinksurance.de/api";

        String secret="c928cdd82311d0b509895bbeb97dcc00";
        String hash1= "070d5091e7a99413decf45191c0c2ae18b408b92e291cdae9c67946ebb16730f1a78bf8bf0d2125136552340510dee8fc24a23de927f64a066827f27ce6780c8";


        String bToken = "4e078e316a5a38b95dc3bc399";

        String doc_hash = hash;


        // Prepare the request body for the token endpoint
        String requestBody = "{\"hash\": \"" + hash1 + "\", \"secret\": \"" + secret + "\"}";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> tokenResponseEntity = restTemplate.exchange(baseUrl + "/token", HttpMethod.POST,
                new HttpEntity<>(requestBody, headers), String.class);

        if (tokenResponseEntity.getStatusCode() == HttpStatus.OK) {
            String tokenResponse = tokenResponseEntity.getBody();
            if (tokenResponse != null && !tokenResponse.isEmpty()) {

                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(tokenResponseEntity.getBody());
                String token = jsonNode.get("token").toString();
                token = token.replace("\"", "");

                System.out.println("***********************");
                System.out.println("Token:");
                System.out.println(token);
                System.out.println("***********************");

                String documentRequestBody = "{\"bToken\": \"" + bToken + "\", \"hash\": \"" + doc_hash + "\"}";
                HttpEntity<String> documentRequestEntity = new HttpEntity<>(documentRequestBody, headers);

                // Send the HTTP POST request with the request body
                String url = baseUrl + "/doc/get/" + token;
                System.out.println("Url:");
                System.out.println(url);
                ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, documentRequestEntity, String.class);

                // Get the response body as a string
                String responseBody = responseEntity.getBody();

                decodedBytes = Base64.decodeBase64(responseBody);
                headers.setContentType(MediaType.APPLICATION_PDF);
                headers.setContentDispositionFormData("attachment", filename+".pdf");

            }
        }
        return new ResponseEntity<>(decodedBytes, headers, org.springframework.http.HttpStatus.OK);

    }

    @GetMapping("/ts")
    public ResponseEntity<byte[]> downloadDocument() throws IOException {
        byte[] decodedBytes = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        String baseUrl="https://app.thinksurance.de/api";

        String secret="c928cdd82311d0b509895bbeb97dcc00";
        String hash= "070d5091e7a99413decf45191c0c2ae18b408b92e291cdae9c67946ebb16730f1a78bf8bf0d2125136552340510dee8fc24a23de927f64a066827f27ce6780c8";


        String bToken = "4e078e316a5a38b95dc3bc399";

        String doc_hash = "4aeee2c4-6d4e-4ecb-8609-a36ce41fe5b9";
        String filename ="Contract.pdf";

        // Prepare the request body for the token endpoint
        String requestBody = "{\"hash\": \"" + hash + "\", \"secret\": \"" + secret + "\"}";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> tokenResponseEntity = restTemplate.exchange(baseUrl + "/token", HttpMethod.POST,
                new HttpEntity<>(requestBody, headers), String.class);

        if (tokenResponseEntity.getStatusCode() == HttpStatus.OK) {
            String tokenResponse = tokenResponseEntity.getBody();
            if (tokenResponse != null && !tokenResponse.isEmpty()) {

                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(tokenResponseEntity.getBody());
                String token = jsonNode.get("token").toString();
                token = token.replace("\"", "");

                System.out.println("***********************");
                System.out.println("Token:");
                System.out.println(token);
                System.out.println("***********************");

                String documentRequestBody = "{\"bToken\": \"" + bToken + "\", \"hash\": \"" + doc_hash + "\"}";
                HttpEntity<String> documentRequestEntity = new HttpEntity<>(documentRequestBody, headers);

                // Send the HTTP POST request with the request body
                String url = baseUrl + "/doc/get/" + token;
                System.out.println("Url:");
                System.out.println(url);
                ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, documentRequestEntity, String.class);

                // Get the response body as a string
                String responseBody = responseEntity.getBody();

                decodedBytes = Base64.decodeBase64(responseBody);
                headers.setContentType(MediaType.APPLICATION_PDF);
                headers.setContentDispositionFormData("attachment", "file.pdf");

            }
         }
        return new ResponseEntity<>(decodedBytes, headers, org.springframework.http.HttpStatus.OK);

    }

}
