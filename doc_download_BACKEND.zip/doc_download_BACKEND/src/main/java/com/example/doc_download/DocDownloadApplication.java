package com.example.doc_download;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class DocDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocDownloadApplication.class, args);
		System.out.println("Application Started!");
	}

}
