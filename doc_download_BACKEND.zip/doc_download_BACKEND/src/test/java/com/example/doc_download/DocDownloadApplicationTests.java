package com.example.doc_download;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocDownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
